"""Background workers. Everything slow runs here so the GUI never freezes."""
from __future__ import annotations

import logging
import json
import os
import threading
import time
import urllib.request

from PySide6.QtCore import QObject, QThread, Signal

from core import settings, testfile

log = logging.getLogger("visionauto.gui")


class RecordingSession(QObject):
    """Wraps core.recorder.Recorder: its callbacks come from worker threads, so they become signals."""

    step = Signal(dict)
    stop_requested = Signal()

    def __init__(self, name: str, overwrite: bool = False):
        super().__init__()
        from core.recorder.recorder import Recorder

        self.overwrite = overwrite
        self.rec = Recorder(
            name,
            on_step=lambda s: self.step.emit(s),
            on_stop_requested=lambda: self.stop_requested.emit(),
            ignore_pids={os.getpid()},          # never record clicks on VisionAuto's own windows
        )

    def start(self) -> None:
        self.rec.start(overwrite=self.overwrite)


class FinishRecordingWorker(QThread):
    """Stop the recorder, then let the 'AI' read the recording (labels, descriptions, validation suggestions)."""

    progress = Signal(str, float)
    done = Signal(object, str)      # test dict, test directory
    failed = Signal(str)

    def __init__(self, session: RecordingSession):
        super().__init__()
        self.session = session

    def run(self):
        try:
            from core.ai.analyze import analyze
            from core.ai.llm import OllamaClient

            self.progress.emit("Saving recording", 0.02)
            self.session.rec.stop()
            test, directory = testfile.load_test(self.session.rec.dir)
            opts = settings.load()
            llm = OllamaClient(opts["llm_model"], base_url=opts["llm_base_url"]) if opts.get("use_llm") else None
            analyze(test, directory, use_ocr=opts.get("ocr_labels_after_record", True), llm=llm,
                    progress=lambda m, f: self.progress.emit(m, f))
            self.done.emit(test, str(directory))
        except Exception as e:
            log.exception("finishing the recording failed")
            self.failed.emit(f"{type(e).__name__}: {e}")


class PlayWorker(QThread):
    """Runs one test off the GUI thread and exposes the run controls (all thread-safe).

    Pause/Resume act at step boundaries; Stop ends after the current step and keeps the report; Cancel is final.
    The worker also relays the "retry this failed step?" question to the GUI and waits for the answer (or the
    configured timeout) without blocking the GUI thread."""

    step = Signal(dict)
    finished_run = Signal(dict)
    failed = Signal(str)
    state_changed = Signal(str)
    retry_question = Signal(dict)
    data_progress = Signal(int, int)

    def __init__(self, item: dict, dry_run: bool = False, data=None, data_select=None):
        super().__init__()
        from core.execution import RunController

        self.item, self.dry_run = item, dry_run
        self.data, self.data_select = data, data_select
        self.controller = RunController()
        self.controller.start()                      # RUNNING from the moment the worker exists: Stop works at once
        self._answer = None
        self._answer_event = threading.Event()

    # ---- GUI-thread API -------------------------------------------------
    @property
    def supports_pause(self) -> bool:
        return self.item.get("kind", "native") == "native"

    def pause(self) -> bool:
        ok = self.supports_pause and self.controller.pause()
        if ok:
            self.state_changed.emit(self.controller.state)
        return ok

    def resume(self) -> bool:
        ok = self.controller.resume()
        if ok:
            self.state_changed.emit(self.controller.state)
        return ok

    def stop(self) -> bool:
        ok = self.controller.stop()
        self._answer_event.set()                     # a pending retry question must not keep the run alive
        if ok:
            self.state_changed.emit(self.controller.state)
        return ok

    def cancel(self) -> bool:
        ok = self.controller.cancel()
        self._answer_event.set()
        if ok:
            self.state_changed.emit(self.controller.state)
        return ok

    abort = stop                                      # older callers

    def answer_retry(self, choice: str) -> None:
        self._answer = choice
        self._answer_event.set()

    # ---- worker thread --------------------------------------------------
    def _ask(self, payload: dict, timeout_s: float):
        self._answer = None
        self._answer_event.clear()
        self.retry_question.emit(payload)
        deadline = time.monotonic() + float(timeout_s) + 2.0       # the dialog counts down the same time itself
        while time.monotonic() < deadline:
            if self._answer_event.wait(0.1):
                return self._answer
            if self.controller.should_stop():
                return None
        return None

    def run(self):
        try:
            opts = settings.load()
            cb = lambda r: self.step.emit(r)  # noqa: E731
            stop = self.controller.should_stop
            if self.item["kind"] == "ranorex":
                from core.importers.ranorex.runtime import run_script

                run = run_script(self.item["script"], self.item["repo"], opts, dry_run=self.dry_run,
                                 on_step=cb, should_stop=stop)
            elif self.item["kind"] == "uft":
                from core.importers.uft.runner import run_script as run_uft

                run = run_uft(self.item["script"], self.item.get("repo"), opts, dry_run=self.dry_run,
                              on_step=cb, should_stop=stop)
            else:
                from core.playback.player import Player

                run = Player(self.item["name"], opts, dry_run=self.dry_run, on_step=cb, controller=self.controller,
                             ask_user=self._ask, data=self.data, data_select=self.data_select).run()
            self.finished_run.emit(run)
        except Exception as e:
            log.exception("playback failed")
            self.failed.emit(f"{type(e).__name__}: {e}")
        finally:
            self.state_changed.emit(self.controller.finish())


class TableWorker(QThread):
    """Bulk read / write of a CSV / XLSX / JSON file with progress and cancel (never on the GUI thread)."""

    progress = Signal(int, int)
    done = Signal(object)
    failed = Signal(str)

    def __init__(self, mode: str, path: str, rows=None, sheet=None, start: str = "A1"):
        super().__init__()
        self.mode, self.path, self.rows, self.sheet, self.start_cell = mode, path, rows, sheet, start
        self._cancel = False

    def cancel(self) -> None:
        self._cancel = True

    def run(self):
        from core import excel_io

        try:
            tick = lambda d, t: self.progress.emit(d, t)  # noqa: E731
            if self.mode == "read":
                self.done.emit(excel_io.read_table(self.path, self.sheet, progress=tick, cancel=lambda: self._cancel))
            else:
                self.done.emit(excel_io.write_table(self.path, self.rows, self.sheet, self.start_cell,
                                                    progress=tick, cancel=lambda: self._cancel))
        except excel_io.Cancelled:
            self.failed.emit("Cancelled.")
        except excel_io.TableError as e:
            self.failed.emit(str(e))
        except Exception as e:                      # noqa: BLE001
            log.exception("table job failed")
            self.failed.emit(f"{type(e).__name__}: {e}")


class GenerateWorker(QThread):
    """Test case generation (may call the local AI model) off the GUI thread."""

    done = Signal(object)
    failed = Signal(str)

    def __init__(self, text: str, topic, categories):
        super().__init__()
        self.text, self.topic, self.categories = text, topic, categories

    def run(self):
        try:
            from core import testcases, testgen
            from core.ai.llm import OllamaClient

            opts = settings.load()
            llm = OllamaClient(opts["llm_model"], base_url=opts["llm_base_url"], timeout=60.0) if opts.get("use_llm") else None
            existing = testcases.list_cases()
            self.done.emit(testgen.generate(self.text, self.topic, self.categories, llm=llm, existing=existing))
        except Exception as e:                      # noqa: BLE001
            log.exception("test case generation failed")
            self.failed.emit(f"{type(e).__name__}: {e}")


class LaunchWorker(QThread):
    """Launch / attach one or several registered applications without freezing the GUI.

    Each application is validated first (path exists, no shell binaries) and reported separately; one failure does
    not stop the others. The launched processes stay running (they are the user's applications)."""

    one_done = Signal(str, bool, str)      # name, ok, message
    all_done = Signal()

    def __init__(self, apps: list):
        super().__init__()
        self.apps = apps

    def run(self):
        from core import applications
        from core.playback.app_context import AppContextManager

        for app in self.apps:
            name = str(app.get("name") or app.get("alias") or "?")
            problems = applications.validate_app_def(app)
            exe = str(app.get("exe_path") or "").strip()
            if not problems and app.get("type", "desktop") == "desktop" and exe:
                import os

                if not os.path.isfile(exe):
                    problems.append(f"Executable not found: {exe}")
            if problems:
                self.one_done.emit(name, False, "; ".join(problems))
                continue
            try:
                AppContextManager([app]).ensure_app(app.get("alias", "default"))
                self.one_done.emit(name, True, "launched")
            except Exception as e:                      # noqa: BLE001 - reported per application
                log.exception("launching %s failed", name)
                self.one_done.emit(name, False, f"{type(e).__name__}: {e}")
        self.all_done.emit()


class ImportWorker(QThread):
    done = Signal(dict)
    failed = Signal(str)

    def __init__(self, rxrep, cs_files, project, use_llm=False, force_script=False):
        super().__init__()
        self.args = (rxrep, cs_files, project, use_llm, force_script)

    def run(self):
        try:
            from core.importers.ranorex.importer import import_project

            rxrep, cs_files, project, use_llm, force_script = self.args
            llm = None
            if use_llm:
                from core.importers.ranorex.llm_fallback import LlmTranslator

                opts = settings.load()
                llm = LlmTranslator(model=opts["llm_model"], base_url=opts["llm_base_url"])
            self.done.emit(import_project(rxrep or None, cs_files, project, llm=llm, force_script=force_script))
        except Exception as e:
            log.exception("import failed")
            self.failed.emit(f"{type(e).__name__}: {e}")


class OllamaPullWorker(QThread):
    """Pull a configured Ollama model without blocking the GUI thread."""
    progress = Signal(str)
    done = Signal(str)
    failed = Signal(str)

    def __init__(self, base_url: str, model: str):
        super().__init__()
        self.base_url, self.model = base_url.rstrip("/"), model.strip()

    def run(self):
        try:
            body = json.dumps({"name": self.model, "stream": True}).encode()
            request = urllib.request.Request(
                self.base_url + "/api/pull", data=body,
                headers={"Content-Type": "application/json"}, method="POST")
            with urllib.request.urlopen(request, timeout=30) as response:
                for raw in response:
                    if not raw.strip():
                        continue
                    item = json.loads(raw)
                    status = item.get("status", "Downloading model")
                    total, completed = item.get("total"), item.get("completed")
                    if total:
                        status += f" ({100 * completed // total}%)"
                    self.progress.emit(status)
                    if item.get("error"):
                        raise RuntimeError(item["error"])
            self.done.emit(self.model)
        except Exception as exc:
            self.failed.emit(f"{type(exc).__name__}: {exc}")


class AiSetupWorker(QThread):
    """Install (with the user's consent) + start Ollama and fetch the model, without freezing the GUI."""
    progress = Signal(str)
    done = Signal(str)
    failed = Signal(str)

    def __init__(self, base_url: str, model: str, allow_install: bool):
        super().__init__()
        self.base_url, self.model, self.allow_install = base_url, model, allow_install

    def run(self):
        try:
            from core.ai import ollama_manager

            ollama_manager.ensure_ready(self.model, self.base_url, self.progress.emit, allow_install=self.allow_install)
            self.done.emit(self.model)
        except Exception as exc:
            log.exception("local AI setup failed")
            self.failed.emit(f"{type(exc).__name__}: {exc}")


class Job(QThread):
    """Run any callable off the GUI thread: ``done(result)`` or ``failed(message)``."""

    done = Signal(object)
    failed = Signal(str)

    def __init__(self, fn, *args, **kwargs):
        super().__init__()
        self.fn, self.args, self.kwargs = fn, args, kwargs

    def run(self):
        try:
            self.done.emit(self.fn(*self.args, **self.kwargs))
        except Exception as e:
            log.exception("background job failed")
            self.failed.emit(f"{type(e).__name__}: {e}")
