"""
Floating recording toolbar: always on top, never takes focus (so the app being
recorded keeps the keyboard), shows what was just recorded.

   [● REC 00:42]  [12 steps]   [Pause] [Validate] [■ Stop]
   Clicked 'Save' button in 'Untitled - Notepad'
"""
from __future__ import annotations

import time

from PySide6.QtCore import QPoint, Qt, QTimer, Signal
from PySide6.QtGui import QGuiApplication
from PySide6.QtWidgets import QHBoxLayout, QLabel, QPushButton, QVBoxLayout, QWidget


class RecorderBar(QWidget):
    pause_toggled = Signal(bool)
    validate_clicked = Signal()
    stop_clicked = Signal()

    def __init__(self):
        flags = (Qt.WindowType.Tool | Qt.WindowType.FramelessWindowHint | Qt.WindowType.WindowStaysOnTopHint
                 | Qt.WindowType.WindowDoesNotAcceptFocus)
        super().__init__(None, flags)
        self.setObjectName("recbar")
        self.setAttribute(Qt.WidgetAttribute.WA_ShowWithoutActivating)
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        self._t0 = time.monotonic()
        self._paused = False
        self._drag: QPoint | None = None
        self._steps = 0

        outer = QVBoxLayout(self)
        outer.setContentsMargins(14, 10, 14, 10)
        outer.setSpacing(6)
        row = QHBoxLayout()
        self.rec = QLabel("● REC 00:00")
        self.rec.setStyleSheet("color:#ef5350; font-weight:700;")
        self.count = QLabel("0 steps")
        self.count.setObjectName("muted")
        self.pause = QPushButton("Pause")
        self.validate = QPushButton("✓ Validate")
        self.validate.setToolTip("Add a validation for the item you clicked last  (hotkey F8 = item under the mouse)")
        self.stop = QPushButton("■ Stop")
        self.stop.setProperty("kind", "danger")
        self.stop.setToolTip("Stop recording  (hotkey F9)")
        for w in (self.rec, self.count):
            row.addWidget(w)
        row.addStretch(1)
        for b in (self.pause, self.validate, self.stop):
            b.setFocusPolicy(Qt.FocusPolicy.NoFocus)
            row.addWidget(b)
        outer.addLayout(row)
        self.last = QLabel("Use the application normally - every click, drag, scroll and keystroke is recorded.")
        self.last.setObjectName("muted")
        outer.addWidget(self.last)
        self.setFixedWidth(560)

        self.pause.clicked.connect(self._toggle_pause)
        self.validate.clicked.connect(self.validate_clicked.emit)
        self.stop.clicked.connect(self.stop_clicked.emit)

        self._timer = QTimer(self)
        self._timer.timeout.connect(self._tick)
        self._timer.start(500)

    # ------------------------------------------------------------------
    def place_top_center(self) -> None:
        geo = QGuiApplication.primaryScreen().availableGeometry()
        self.adjustSize()
        self.move(geo.center().x() - self.width() // 2, geo.top() + 12)

    def _tick(self) -> None:
        if self._paused:
            self.rec.setText("❚❚ PAUSED")
            return
        s = int(time.monotonic() - self._t0)
        dot = "●" if s % 2 == 0 else "○"
        self.rec.setText(f"{dot} REC {s // 60:02d}:{s % 60:02d}")

    def _toggle_pause(self) -> None:
        self._paused = not self._paused
        self.pause.setText("Resume" if self._paused else "Pause")
        self.pause_toggled.emit(self._paused)

    def on_step(self, step: dict) -> None:
        self._steps += 1
        self.count.setText(f"{self._steps} step{'s' if self._steps != 1 else ''}")
        text = step.get("description", "")
        target = step.get("target") or {}
        x, y = target.get("x"), target.get("y")
        if isinstance(x, int) and isinstance(y, int):
            text = f"{text} · screen ({x}, {y})"
            details = [f"Recorded screen location: ({x}, {y})"]
            for key in ("name", "role", "automation_id", "class_name", "rect", "rel"):
                value = target.get(key)
                if value not in (None, "", [], {}):
                    details.append(f"Saved element {key}: {value}")
            self.last.setToolTip("\n".join(details))
        else:
            self.last.setToolTip("")
        self.last.setText(self.last.fontMetrics().elidedText(text, Qt.TextElideMode.ElideRight, 520))

    def set_busy(self, text: str) -> None:
        for b in (self.pause, self.validate, self.stop):
            b.setEnabled(False)
        self._timer.stop()
        self.rec.setText("Saving...")
        self.last.setText(text)

    # drag the bar by its background
    def mousePressEvent(self, e):
        if e.button() == Qt.MouseButton.LeftButton:
            self._drag = e.globalPosition().toPoint() - self.frameGeometry().topLeft()

    def mouseMoveEvent(self, e):
        if self._drag is not None and e.buttons() & Qt.MouseButton.LeftButton:
            self.move(e.globalPosition().toPoint() - self._drag)

    def mouseReleaseEvent(self, e):
        self._drag = None
