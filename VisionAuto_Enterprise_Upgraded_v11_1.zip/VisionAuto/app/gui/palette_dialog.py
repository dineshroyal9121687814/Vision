"""Add a step from the palette: pick WHAT it should do from a grouped list, fill the plain-language fields, press Add.
No code, no JSON. Every field comes from core.steplib.catalog, so new step types appear here automatically."""
from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QCheckBox, QComboBox, QDialog, QFileDialog, QFormLayout, QHBoxLayout, QLabel, QLineEdit,
                               QListWidget, QListWidgetItem, QMessageBox, QPushButton, QVBoxLayout, QWidget)

from core import editing
from core.steplib import catalog, custom as custom_steps


class PaletteDialog(QDialog):
    def __init__(self, test: dict, directory, parent=None):
        super().__init__(parent)
        self.test, self.directory = test, Path(directory)
        self.setWindowTitle("Add a step")
        self.resize(820, 520)
        self.widgets: dict = {}
        root = QHBoxLayout(self)
        self.steps_list = QListWidget()
        self.steps_list.setMaximumWidth(280)
        for category, entries in catalog.grouped().items():
            head = QListWidgetItem(category.upper())
            head.setFlags(head.flags() & ~Qt.ItemFlag.ItemIsSelectable)
            self.steps_list.addItem(head)
            for e in entries:
                it = QListWidgetItem("   " + e["label"])
                it.setData(256, e["type"])
                self.steps_list.addItem(it)
        self.steps_list.currentItemChanged.connect(self._pick)
        root.addWidget(self.steps_list)
        right = QVBoxLayout()
        self.help = QLabel("Pick a step on the left.")
        self.help.setWordWrap(True)
        right.addWidget(self.help)
        self.form_host = QWidget()
        self.form = QFormLayout(self.form_host)
        right.addWidget(self.form_host)
        self.after = QComboBox()
        for s in test.get("steps") or []:
            self.after.addItem(f"after step {s.get('id')}: {s.get('description') or s.get('type')}", s.get("id"))
        self.after.setCurrentIndex(max(0, self.after.count() - 1))
        right.addWidget(self.after)
        self.suggest = QLabel("")
        self.suggest.setWordWrap(True)
        right.addWidget(self.suggest)
        right.addStretch(1)
        buttons = QHBoxLayout()
        add = QPushButton("Add step")
        add.clicked.connect(self._add)
        close = QPushButton("Close")
        close.clicked.connect(self.accept)
        buttons.addStretch(1)
        buttons.addWidget(add)
        buttons.addWidget(close)
        right.addLayout(buttons)
        root.addLayout(right, 1)
        self.added = False
        self._type = None
        last = (test.get("steps") or [{}])[-1].get("type")
        self.suggest.setText("Likely next: " + ", ".join(s["label"] for s in catalog.suggest(last)[:4]))

    def _pick(self, item, _prev=None) -> None:
        t = item.data(256) if item else None
        if not t:
            return
        self._type = t
        e = catalog.BY_TYPE[t]
        self.help.setText(f"<b>{e['label']}</b><br>{e.get('help', '')}")
        while self.form.rowCount():
            self.form.removeRow(0)
        self.widgets = {}
        for f in e["fields"]:
            kind, w = f["kind"], None
            if kind == "choice":
                w = QComboBox()
                choices = custom_steps.names() if f.get("choices_from") == "custom_steps" else f.get("choices", [])
                w.addItems([str(c) for c in choices])
                if f.get("default") not in (None, ""):
                    w.setCurrentText(str(f["default"]))
            elif kind == "bool":
                w = QCheckBox()
            else:
                w = QLineEdit()
                if f.get("default") not in (None, ""):
                    w.setText(str(f["default"]))
                if kind in ("target", "target2"):
                    w.setPlaceholderText("the text you see on the element, e.g. Save")
                elif kind in ("window", "window2"):
                    w.setPlaceholderText("part of the window title, e.g. Book1 - Excel")
                elif kind == "file":
                    pass
            label = f["label"] + (" *" if f.get("required") else "")
            if kind == "file":
                row = QHBoxLayout()
                row.addWidget(w)
                b = QPushButton("…")
                b.clicked.connect(lambda _=False, edit=w: edit.setText(QFileDialog.getOpenFileName(self, "Choose a file")[0] or edit.text()))
                row.addWidget(b)
                self.form.addRow(label, row)
            else:
                self.form.addRow(label, w)
            self.widgets[f["name"]] = w

    def values(self) -> dict:
        out = {}
        for name, w in self.widgets.items():
            out[name] = w.isChecked() if isinstance(w, QCheckBox) else (w.currentText() if isinstance(w, QComboBox) else w.text())
        return out

    def _add(self) -> None:
        if not self._type:
            QMessageBox.information(self, "Add a step", "Pick a step on the left first.")
            return
        try:
            step = catalog.build_step(self._type, self.values())
            editing.add_step_after(self.test, int(self.after.currentData()), step)
            editing.save(self.test, self.directory)
        except ValueError as exc:
            QMessageBox.warning(self, "Cannot add this step", str(exc))
            return
        self.added = True
        self.after.clear()
        for s in self.test.get("steps") or []:
            self.after.addItem(f"after step {s.get('id')}: {s.get('description') or s.get('type')}", s.get("id"))
        self.after.setCurrentIndex(self.after.count() - 1)
        QMessageBox.information(self, "Added", f"'{catalog.BY_TYPE[self._type]['label']}' was added.")
