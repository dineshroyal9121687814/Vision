"""Edit and add steps in a saved VisionAuto test."""
from __future__ import annotations

import shutil
from copy import deepcopy
from pathlib import Path

from PySide6.QtWidgets import (QAbstractItemView, QComboBox, QDialog, QFileDialog, QFormLayout, QHBoxLayout,
                               QCheckBox, QLabel, QLineEdit, QMessageBox, QPushButton, QTableWidget,
                               QTableWidgetItem, QVBoxLayout, QWidget)

from core import applications, testfile
from core.automation import target_config
from core.ai.describe import describe_step
from core.importers.ranorex.cs_to_steps import UIA_ROLES
from core.importers.ranorex.rxpath import parse_rxpath
from core.system.imageio import imread

ACTION_TYPES = ("click", "double_click", "right_click", "middle_click", "drag_drop", "scroll", "type",
                "key", "hotkey", "wait", "hover", "launch_app", "validate",
                "set_value", "append_value", "clear_value", "read_value", "select_option", "set_state", "upload_file",
                "wait_for_window", "custom")
LOCATOR_TYPES = ("Text", "UI Automation", "Ranorex XPath", "Image", "Coordinates", "None")


def _locator(kind: str, value: str, directory: Path, step_id: int, automation_id: str = "",
             role: str = "", x: str = "", y: str = "") -> dict:
    value = value.strip()
    target: dict = {}
    if kind == "Text":
        if not value:
            raise ValueError("Enter text for the text locator.")
        target.update(name=value, text=value)
    elif kind == "UI Automation":
        if not (value or automation_id.strip()):
            raise ValueError("Enter a control name or Automation ID.")
        if value:
            target["name"] = value
        if automation_id.strip():
            target["automation_id"] = automation_id.strip()
        if role.strip():
            target["role"] = role.strip()
    elif kind == "Ranorex XPath":
        info = parse_rxpath(value)
        from core.xpath import XPathError, compile_xpath
        try:
            compile_xpath(value, "ranorex")          # real XPath 1.0 / RanoreXPath, evaluated against the live UI tree
        except XPathError as exc:
            raise ValueError(f"This is not a valid XPath: {exc}. Example: /form[@title='Calculator']//button[@text='Save']") from exc
        if not info.segments:
            raise ValueError("This XPath is not in the supported RanoreXPath form. Use a path such as /form[@title='Calculator']/button[@text='Save'].")
        leaf = info.segments[-1]
        target["xpath"], target["xpath_dialect"] = value, "ranorex"
        target["source_locator"] = {"kind": "ranorex", "path": value}
        if info.label:
            target.update(name=info.label, text=info.label)
        if info.automation_id:
            target["automation_id"] = info.automation_id
        if leaf.role in UIA_ROLES:
            target["role"] = UIA_ROLES[leaf.role]
    elif kind == "Image":
        if not value:
            raise ValueError("Choose an image file for the image locator.")
        source = Path(value).expanduser().resolve()
        image = imread(source)
        if image is None:
            raise ValueError(f"Could not read locator image: {source}")
        if source.parent == (directory / "assets").resolve():
            rel = source.relative_to(directory.resolve()).as_posix()
        else:
            assets = directory / "assets"
            assets.mkdir(parents=True, exist_ok=True)
            ext = source.suffix.lower() if source.suffix.lower() in {".png", ".jpg", ".jpeg", ".bmp"} else ".png"
            dest = assets / f"s{step_id:03d}_manual{ext}"
            shutil.copy2(source, dest)
            rel = dest.relative_to(directory).as_posix()
        h, w = image.shape[:2]
        target["templates"] = {"crop300": {"path": rel, "click": [w // 2, h // 2], "size": [w, h]}}
    elif kind == "Coordinates":
        try:
            target["x"], target["y"] = int(x), int(y)
        except (TypeError, ValueError) as exc:
            raise ValueError("Coordinates locator needs integer X and Y values.") from exc
        target["locator_mode"] = "coordinates"
    elif kind != "None":
        raise ValueError(f"Unsupported locator type: {kind}")
    # A position hint is independent of the locator. It helps resolve duplicate
    # labels by preferring the matching control nearest the recorded click while
    # retaining a dynamic text/UIA/XPath/image locator.
    if kind not in {"Coordinates", "None"} and (str(x).strip() or str(y).strip()):
        try:
            if not str(x).strip() or not str(y).strip():
                raise ValueError
            target["x"], target["y"] = int(x), int(y)
        except (TypeError, ValueError) as exc:
            raise ValueError("Position hint needs integer X and Y values, or leave both empty.") from exc
    return target


def make_step(action: str, directory: Path, step_id: int, locator_kind: str, locator_value: str,
              automation_id: str = "", role: str = "", x: str = "", y: str = "",
              window_title: str = "", process: str = "", value: str = "", extra: str = "",
              destination: str = "", destination_x: str = "", destination_y: str = "",
              validation_type: str = "element_exists", expected: str = "",
              app: str = "", save_as: str = "",
              original: dict | None = None, target_cfg: dict | None = None) -> dict:
    """Build a backward-compatible test/2 step from editor fields."""
    step = deepcopy(original) if original else {"id": step_id, "t_ms": 0, "validations": []}
    step["id"] = step_id
    target = _locator(locator_kind, locator_value, Path(directory), step_id, automation_id, role, x, y)
    if locator_kind == "Ranorex XPath":
        xpath_info = parse_rxpath(locator_value)
        window_title = window_title or xpath_info.window_title
        process = process or xpath_info.process_name
    # keep what the recorder knew about the window (rect, owner, popup ...) - only title / process are edited here
    step["window"] = {**{k: v for k, v in (step.get("window") or {}).items() if k not in ("title", "process")},
                      "title": window_title.strip(), "process": process.strip()}
    if action in {"click", "double_click", "right_click", "middle_click", "drag_drop", "scroll", "hover", "validate",
                  "set_value", "append_value", "clear_value", "read_value", "select_option", "set_state"}:
        if not target:
            raise ValueError(f"{action.replace('_', ' ').title()} needs a locator.")
        step["target"] = target
    else:
        step.pop("target", None)
        if target:
            step["target"] = target
    params = {}
    if action in {"click", "double_click", "right_click", "middle_click", "drag_drop"}:
        params["button"] = extra.strip() or ("right" if action == "right_click" else "middle" if action == "middle_click" else "left")
    elif action == "scroll":
        try:
            params = {"dx": int(value or 0), "dy": int(extra or 0)}
        except ValueError as exc:
            raise ValueError("Scroll distance must be an integer.") from exc
    elif action == "type":
        if not value:
            raise ValueError("Enter the text to type.")
        params["text"] = value
    elif action == "key":
        if not value.strip():
            raise ValueError("Enter a key name, such as enter or tab.")
        params["key"] = value.strip()
    elif action == "hotkey":
        if not value.strip():
            raise ValueError("Enter a shortcut, such as ctrl+s.")
        params["keys"] = value.strip()
    elif action == "wait":
        try:
            params["ms"] = max(0, int(value or 0))
        except ValueError as exc:
            raise ValueError("Wait duration must be a non-negative integer in milliseconds.") from exc
    elif action == "launch_app":
        if not value.strip():
            raise ValueError("Enter the executable path to launch.")
        params = {"exe": value.strip(), "args": extra.strip()}
    elif action in {"set_value", "append_value"}:
        params["text"] = value
    elif action == "select_option":
        if not value.strip():
            raise ValueError("Enter the exact option text to select.")
        params["text"] = value.strip()
    elif action == "set_state":
        params["state"] = (value.strip() or "check").lower()
        if params["state"] not in ("check", "uncheck", "toggle", "select"):
            raise ValueError("State must be check, uncheck, toggle or select.")
    elif action == "upload_file":
        if not value.strip():
            raise ValueError("Enter the full path of the file to upload.")
        params["path"] = value.strip()
    elif action == "custom":
        from core.steplib import catalog, custom as custom_steps
        if not value.strip():
            raise ValueError("Pick the custom method name (Steps > Custom). Missing one? Ask the AI: visionauto steps new.")
        if value.strip() not in custom_steps.names():
            raise ValueError(f"Custom step '{value.strip()}' does not exist yet. Ask the AI to create it: visionauto steps new.")
        params = {"method": value.strip(), "args": catalog.parse_args(extra)}
    elif action == "read_value" and save_as.strip():
        params["save_as"] = save_as.strip()
    if action in {"type", "key", "hotkey", "wait", "launch_app", "upload_file"} and target:
        step["target"] = target
    if params:
        step["params"] = params
    else:
        step.pop("params", None)
    if action == "drag_drop":
        dest = destination.strip()
        if dest.startswith("/"):
            to = _locator("Ranorex XPath", dest, Path(directory), step_id)
        elif dest:
            to = _locator("Text", dest, Path(directory), step_id)
        else:
            to = _locator("Coordinates", "", Path(directory), step_id, x=destination_x, y=destination_y)
        step["to"] = to
    else:
        step.pop("to", None)
    if action == "validate":
        check = {"type": validation_type}
        if validation_type in {"text_equals", "text_contains"}:
            check["expected"] = expected
        step["check"] = check
    else:
        step.pop("check", None)
    if app.strip():
        step["app"] = app.strip()
    elif "app" in step:
        del step["app"]
    if save_as.strip():
        step["save_as"] = save_as.strip()
    elif "save_as" in step:
        del step["save_as"]
    step["type"] = action
    if target_cfg is not None:
        target_config.apply_config(step, target_cfg)         # raises ValueError with every problem listed
    step["description"] = describe_step(step)
    return step


class StepFormDialog(QDialog):
    def __init__(self, directory: Path, step_id: int, step: dict | None = None, parent=None):
        super().__init__(parent)
        self.directory, self.step_id, self.original = Path(directory), step_id, deepcopy(step)
        self.result_step = None
        self.setWindowTitle("Edit step" if step else "Add step")
        form = QFormLayout(self)
        self.action = QComboBox()
        self.action.addItems(ACTION_TYPES)
        self.locator_kind = QComboBox()
        self.locator_kind.addItems(LOCATOR_TYPES)
        self.locator_value = QLineEdit()
        self.automation_id = QLineEdit()
        self.role = QLineEdit()
        self.x = QLineEdit()
        self.y = QLineEdit()
        self.image = QLineEdit()
        image_row = QWidget()
        image_layout = QHBoxLayout(image_row)
        image_layout.setContentsMargins(0, 0, 0, 0)
        image_layout.addWidget(self.image, 1)
        browse = QPushButton("Browse…")
        browse.clicked.connect(self._browse_image)
        image_layout.addWidget(browse)
        self.destination = QLineEdit()
        self.destination_x = QLineEdit()
        self.destination_y = QLineEdit()
        self.window_title = QLineEdit()
        self.process = QLineEdit()
        self.value = QLineEdit()
        self.extra = QLineEdit()
        self.validation_type = QComboBox()
        self.validation_type.addItems(("element_exists", "element_not_exists", "text_equals", "text_contains", "image_visible"))
        self.expected = QLineEdit()
        self.app_alias = QComboBox()
        self.app_alias.setEditable(True)
        self.app_alias.addItem("")
        try:
            for app_item in applications.list_apps():
                al = app_item.get("alias")
                if al:
                    self.app_alias.addItem(al)
        except Exception:
            pass
        self.save_as = QLineEdit()
        self.save_as.setPlaceholderText("e.g. customer_id, order_num")
        # --- Target configuration (window / container / fallbacks) ---
        self.window_match = QComboBox()
        self.window_match.addItems(target_config.WINDOW_MATCH)
        self.main_window = QCheckBox("Use Main Window of the application (set Process above)")
        self.container = QLineEdit()
        self.container.setPlaceholderText("container name or automation id (panel, tab, dialog, table ...)")
        self.quadrant = QComboBox()
        self.quadrant.addItems(("", "all", "tl", "tr", "bl", "br"))
        self.text_match = QComboBox()
        self.text_match.addItems(target_config.TEXT_MATCH)
        self.position_mode = QComboBox()
        self.position_mode.addItems(("", "window", "normalized", "container", "anchor", "absolute"))
        self.require_unique = QCheckBox("Fail if more than one element matches (recommended)")
        self.require_unique.setChecked(True)
        form.addRow("Target application", self.app_alias)
        form.addRow("Action", self.action)
        form.addRow("Locator type", self.locator_kind)
        form.addRow("Text / XPath / name", self.locator_value)
        form.addRow("Automation ID", self.automation_id)
        form.addRow("UIA role", self.role)
        form.addRow("Position hint X (screen pixels)", self.x)
        form.addRow("Position hint Y (screen pixels)", self.y)
        form.addRow("Image", image_row)
        form.addRow("Destination text / XPath", self.destination)
        form.addRow("Destination X (coordinate drag)", self.destination_x)
        form.addRow("Destination Y (coordinate drag)", self.destination_y)
        form.addRow("Window title", self.window_title)
        form.addRow("Process", self.process)
        form.addRow("Action value / text / executable", self.value)
        form.addRow("Extra: button / scroll Y / app arguments", self.extra)
        form.addRow("Validation", self.validation_type)
        form.addRow("Expected text", self.expected)
        form.addRow("Save result as variable", self.save_as)
        form.addRow("Window match", self.window_match)
        form.addRow("Main Window", self.main_window)
        form.addRow("Container", self.container)
        form.addRow("Search quadrant (fallback)", self.quadrant)
        form.addRow("Text match", self.text_match)
        form.addRow("Position locator", self.position_mode)
        form.addRow("Ambiguity", self.require_unique)
        hint = QLabel("Position hints disambiguate duplicate labels while keeping text, UIA, XPath, and image locators dynamic. Choosing Coordinates creates a fixed-position locator. XPath support follows the RanoreXPath subset. Type/key actions use current focus; add a click/focus step first.")
        hint.setWordWrap(True)
        form.addRow(hint)
        buttons = QHBoxLayout()
        save = QPushButton("Apply")
        save.clicked.connect(self._apply)
        cancel = QPushButton("Cancel")
        cancel.clicked.connect(self.reject)
        buttons.addStretch(1)
        buttons.addWidget(cancel)
        buttons.addWidget(save)
        form.addRow(buttons)
        if step:
            self._load_step(step)

    def _browse_image(self):
        path, _ = QFileDialog.getOpenFileName(self, "Choose locator image", "", "Images (*.png *.jpg *.jpeg *.bmp)")
        if path:
            self.image.setText(path)
            self.locator_kind.setCurrentText("Image")

    def _load_step(self, step: dict):
        self.action.setCurrentText(step.get("type", "click"))
        target = step.get("target") or {}
        templates = target.get("templates") or {}
        xpath = (target.get("source_locator") or {}).get("path", "")
        if templates.get("crop300"):
            self.locator_kind.setCurrentText("Image")
            self.image.setText(str(self.directory / templates["crop300"]["path"]))
        elif xpath:
            self.locator_kind.setCurrentText("Ranorex XPath")
            self.locator_value.setText(xpath)
        elif target.get("automation_id"):
            self.locator_kind.setCurrentText("UI Automation")
            self.locator_value.setText(target.get("name", ""))
        elif target.get("name") or target.get("text"):
            self.locator_kind.setCurrentText("Text")
            self.locator_value.setText(target.get("text") or target.get("name", ""))
        elif "x" in target and "y" in target:
            self.locator_kind.setCurrentText("Coordinates")
        else:
            self.locator_kind.setCurrentText("None")
        self.automation_id.setText(target.get("automation_id", ""))
        self.role.setText(target.get("role", ""))
        self.x.setText(str(target.get("x", "")))
        self.y.setText(str(target.get("y", "")))
        self.window_title.setText((step.get("window") or {}).get("title", ""))
        self.process.setText((step.get("window") or {}).get("process", ""))
        params = step.get("params") or {}
        self.value.setText(str(params.get("text", params.get("key", params.get("keys", params.get("ms", params.get("exe", "")))))))
        self.extra.setText(str(params.get("args", params.get("dy", params.get("button", "")))))
        to = step.get("to") or {}
        self.destination.setText((to.get("source_locator") or {}).get("path", to.get("text", to.get("name", ""))))
        self.destination_x.setText(str(to.get("x", "")))
        self.destination_y.setText(str(to.get("y", "")))
        check = step.get("check") or {}
        if check.get("type"):
            self.validation_type.setCurrentText(check["type"])
        self.expected.setText(str(check.get("expected", "")))
        self.app_alias.setCurrentText(str(step.get("app", "")))
        self.save_as.setText(str(step.get("save_as", "")))
        cfg = target_config.extract_config(step)
        self.window_match.setCurrentText(cfg["window_match"])
        self.main_window.setChecked(cfg["main_window"])
        c = cfg["container"]
        self.container.setText(str(c.get("automation_id") or c.get("name") or "") if isinstance(c, dict) else "")
        self.quadrant.setCurrentText(str(cfg["search_quadrant"] or ""))
        self.text_match.setCurrentText(cfg["text_match"])
        self.position_mode.setCurrentText(str((cfg["position"] or {}).get("mode", "")))
        self.require_unique.setChecked(bool(cfg["require_unique"]))

    def _target_cfg(self) -> dict:
        orig_c = (self.original or {}).get("target", {}).get("container") if self.original else None
        cont = orig_c if isinstance(orig_c, dict) and not self.container.text().strip() else (
            {"automation_id" if self.container.text().strip().replace("_", "").isalnum() else "name": self.container.text().strip()}
            if self.container.text().strip() else {})
        pos = ((self.original or {}).get("target") or {}).get("position") or {}
        mode = self.position_mode.currentText()
        cfg = {"window_match": self.window_match.currentText(), "main_window": self.main_window.isChecked(),
               "container": cont, "search_quadrant": self.quadrant.currentText(),
               "text_match": self.text_match.currentText(), "require_unique": self.require_unique.isChecked()}
        if mode and pos.get("mode") == mode:
            cfg["position"] = pos                      # a point is captured by the Inspector / recorder, not typed here
        elif mode:
            raise ValueError("Capture the position with the Inspector (pick a point) before choosing a position locator.")
        return cfg

    def _apply(self):
        try:
            kind = self.locator_kind.currentText()
            locator_value = self.image.text() if kind == "Image" else self.locator_value.text()
            self.result_step = make_step(
                self.action.currentText(), self.directory, self.step_id, kind, locator_value,
                self.automation_id.text(), self.role.text(), self.x.text(), self.y.text(),
                self.window_title.text(), self.process.text(), self.value.text(), self.extra.text(),
                self.destination.text(), self.destination_x.text(), self.destination_y.text(),
                self.validation_type.currentText(), self.expected.text(),
                self.app_alias.currentText(), self.save_as.text(), self.original, self._target_cfg())
        except Exception as exc:
            QMessageBox.warning(self, "Step", str(exc))
            return
        self.accept()


class StepEditorDialog(QDialog):
    def __init__(self, test: dict, directory: str | Path, parent=None):
        super().__init__(parent)
        self.test, self.directory = deepcopy(test), Path(directory)
        self.setWindowTitle(f"Edit steps — {test.get('title') or test.get('name')}")
        self.resize(950, 580)
        root = QVBoxLayout(self)
        self.table = QTableWidget(0, 5)
        self.table.setHorizontalHeaderLabels(("#", "App", "Action", "Description", "Locator"))
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        root.addWidget(self.table, 1)
        row = QHBoxLayout()
        for label, callback in (("Add step", self.add_step), ("Edit step", self.edit_step),
                                ("Delete step", self.delete_step), ("Move up", lambda: self.move(-1)),
                                ("Move down", lambda: self.move(1))):
            button = QPushButton(label)
            button.clicked.connect(callback)
            row.addWidget(button)
        root.addLayout(row)
        foot = QHBoxLayout()
        self.status = QLabel("Changes are written to the existing visionauto.test/2 file on Save.")
        foot.addWidget(self.status, 1)
        cancel, save = QPushButton("Cancel"), QPushButton("Save steps")
        cancel.clicked.connect(self.reject)
        save.clicked.connect(self.save_steps)
        foot.addWidget(cancel)
        foot.addWidget(save)
        root.addLayout(foot)
        self.refresh()

    def refresh(self, selected: int | None = None):
        steps = self.test.get("steps", [])
        self.table.setRowCount(len(steps))
        for row, step in enumerate(steps):
            target = step.get("target") or {}
            locator = ((target.get("source_locator") or {}).get("path") or target.get("automation_id")
                       or target.get("text") or target.get("name") or
                       ("image template" if target.get("templates") else f"{target.get('x', '')},{target.get('y', '')}"))
            for col, text in enumerate((str(row + 1), step.get("app", ""), step.get("type", ""), step.get("description", ""), locator)):
                self.table.setItem(row, col, QTableWidgetItem(str(text)))
        if selected is not None and 0 <= selected < len(steps):
            self.table.selectRow(selected)

    def selected_row(self):
        rows = sorted({idx.row() for idx in self.table.selectedIndexes()})
        return rows[0] if rows else None

    def add_step(self):
        index = len(self.test["steps"])
        dlg = StepFormDialog(self.directory, index + 1, parent=self)
        if dlg.exec():
            self.test["steps"].insert(index, dlg.result_step)
            self._renumber()
            self.refresh(index)

    def edit_step(self):
        index = self.selected_row()
        if index is None:
            QMessageBox.information(self, "Edit step", "Select a step first.")
            return
        dlg = StepFormDialog(self.directory, index + 1, self.test["steps"][index], self)
        if dlg.exec():
            self.test["steps"][index] = dlg.result_step
            self._renumber()
            self.refresh(index)

    def delete_step(self):
        index = self.selected_row()
        if index is None:
            QMessageBox.information(self, "Delete step", "Select a step first.")
            return
        if QMessageBox.question(self, "Delete step", "Delete the selected step?") != QMessageBox.StandardButton.Yes:
            return
        del self.test["steps"][index]
        self._renumber()
        self.refresh(min(index, len(self.test["steps"]) - 1))

    def move(self, offset: int):
        index = self.selected_row()
        if index is None or not 0 <= index + offset < len(self.test["steps"]):
            return
        steps = self.test["steps"]
        steps[index], steps[index + offset] = steps[index + offset], steps[index]
        self._renumber()
        self.refresh(index + offset)

    def _renumber(self):
        testfile.renumber(self.test)
        for step in self.test["steps"]:
            step["description"] = describe_step(step)

    def save_steps(self):
        testfile.backup_test(self.directory)
        testfile.save_test(self.test, self.directory)
        self.accept()
