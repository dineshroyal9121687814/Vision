"""One stylesheet for the whole app, light and dark. Colours are defined once here and nowhere else.

Use ``stylesheet("dark" | "light")``; ``STYLE`` is the dark sheet (kept for older imports).
Buttons pick a look from their ``kind`` property: primary, success, danger, warning, ghost (default = neutral).
"""
from __future__ import annotations

PALETTES = {
    "dark": dict(BG="#0d1017", PANEL="#151a24", PANEL2="#1d2431", LINE="#2a3243", TEXT="#e8ecf4", MUTED="#8c97ab",
                 ACCENT="#6c8cff", ACCENT2="#9b6cff", OK="#33d6a0", BAD="#ff5d73", WARN="#ffb547", INFO="#38bdf8",
                 NAVSEL="#222b3d", INPUT="#111621"),
    "light": dict(BG="#f4f6fb", PANEL="#ffffff", PANEL2="#eef1f8", LINE="#d9deea", TEXT="#1b2233", MUTED="#667089",
                  ACCENT="#4361ee", ACCENT2="#7b4cf0", OK="#0f9d73", BAD="#d93a55", WARN="#c77c0a", INFO="#0284c7",
                  NAVSEL="#e3e9fb", INPUT="#ffffff"),
}


def colors(theme: str = "dark") -> dict:
    return PALETTES.get(theme, PALETTES["dark"])


def status_color(status: str, theme: str = "dark") -> str:
    c = colors(theme)
    return {"passed": c["OK"], "failed": c["BAD"], "skipped": c["MUTED"], "aborted": c["WARN"], "cancelled": c["WARN"],
            "inconclusive": c["INFO"], "invalid": c["BAD"], "unreadable": c["BAD"]}.get(status, c["TEXT"])


def stylesheet(theme: str = "dark") -> str:
    c = colors(theme)
    return f"""
* {{ font-family: "Segoe UI", "Inter", "Helvetica Neue", sans-serif; font-size: 13px; color: {c['TEXT']}; }}
QMainWindow, QDialog, QWidget#page {{ background: {c['BG']}; }}
QWidget {{ background: transparent; }}
QToolTip {{ background: {c['PANEL2']}; color: {c['TEXT']}; border: 1px solid {c['LINE']}; padding: 4px 6px; }}
QLabel#toast {{ background: {c['PANEL2']}; border: 1px solid {c['LINE']}; border-left: 4px solid {c['INFO']}; border-radius: 8px; padding: 10px 14px; }}
QLabel#toast[level="ok"] {{ border-left-color: {c['OK']}; }}
QLabel#toast[level="warn"] {{ border-left-color: {c['WARN']}; }}
QLabel#toast[level="bad"] {{ border-left-color: {c['BAD']}; }}
QWidget#topbar {{ background: {c['PANEL']}; border-bottom: 1px solid {c['LINE']}; }}
QWidget#bottombar {{ background: {c['PANEL']}; border-top: 1px solid {c['LINE']}; }}
QLabel#brand {{ font-size: 15px; font-weight: 700; color: {c['ACCENT']}; }}
QPlainTextEdit#console {{ background: {c['INPUT']}; border: 0; font-family: Consolas, 'Cascadia Mono', monospace; font-size: 12px; }}
QListWidget#nav {{ background: {c['PANEL']}; border: 0; border-right: 1px solid {c['LINE']}; padding: 12px 8px; outline: 0; }}
QListWidget#nav::item {{ padding: 8px 12px; border-radius: 9px; margin: 1px 4px; color: {c['MUTED']}; }}
QListWidget#nav::item:disabled {{ color: {c['MUTED']}; background: transparent; padding: 14px 14px 4px 14px; margin: 0 4px; }}
QListWidget#nav::item:hover {{ background: {c['PANEL2']}; color: {c['TEXT']}; }}
QListWidget#nav::item:selected {{ background: {c['NAVSEL']}; color: {c['ACCENT']}; font-weight: 600; border-left: 3px solid {c['ACCENT']}; }}
QLabel#h1 {{ font-size: 22px; font-weight: 700; }}
QLabel#h2 {{ font-size: 15px; font-weight: 600; }}
QLabel#muted {{ color: {c['MUTED']}; }}
QLabel#empty {{ color: {c['MUTED']}; font-size: 14px; padding: 28px; }}
QLabel#statusbadge {{ border-radius: 10px; padding: 3px 12px; font-weight: 600; background: {c['PANEL2']}; border: 1px solid {c['LINE']}; }}
QFrame#card {{ background: {c['PANEL']}; border: 1px solid {c['LINE']}; border-radius: 12px; }}
QFrame#card[tone="ok"] {{ border-top: 3px solid {c['OK']}; }}
QFrame#card[tone="bad"] {{ border-top: 3px solid {c['BAD']}; }}
QFrame#card[tone="info"] {{ border-top: 3px solid {c['INFO']}; }}
QFrame#card[tone="accent"] {{ border-top: 3px solid {c['ACCENT']}; }}
QFrame#card[tone="warn"] {{ border-top: 3px solid {c['WARN']}; }}
QLabel#stat {{ font-size: 28px; font-weight: 700; }}
QPushButton {{ background: {c['PANEL2']}; border: 1px solid {c['LINE']}; border-radius: 8px; padding: 7px 16px; }}
QPushButton:hover {{ border-color: {c['ACCENT']}; }}
QPushButton:pressed {{ background: {c['LINE']}; }}
QPushButton:disabled {{ color: {c['MUTED']}; background: {c['PANEL']}; border-color: {c['LINE']}; }}
QPushButton[kind="primary"] {{ background: qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 {c['ACCENT']}, stop:1 {c['ACCENT2']});
    border: 0; color: white; font-weight: 600; }}
QPushButton[kind="primary"]:disabled {{ background: {c['PANEL2']}; color: {c['MUTED']}; }}
QPushButton[kind="success"] {{ background: {c['OK']}; border-color: {c['OK']}; color: #06251a; font-weight: 600; }}
QPushButton[kind="danger"] {{ background: {c['BAD']}; border-color: {c['BAD']}; color: white; font-weight: 600; }}
QPushButton[kind="warning"] {{ background: {c['WARN']}; border-color: {c['WARN']}; color: #2b1d00; font-weight: 600; }}
QPushButton[kind="success"]:disabled, QPushButton[kind="danger"]:disabled, QPushButton[kind="warning"]:disabled {{
    background: {c['PANEL']}; border-color: {c['LINE']}; color: {c['MUTED']}; }}
QPushButton[kind="ghost"] {{ background: transparent; border: 1px solid {c['LINE']}; }}
QLineEdit, QSpinBox, QDoubleSpinBox, QTextEdit, QPlainTextEdit, QComboBox {{
    background: {c['INPUT']}; border: 1px solid {c['LINE']}; border-radius: 8px; padding: 6px 8px; selection-background-color: {c['ACCENT']}; }}
QLineEdit:focus, QSpinBox:focus, QDoubleSpinBox:focus, QTextEdit:focus, QPlainTextEdit:focus, QComboBox:focus {{ border-color: {c['ACCENT']}; }}
QComboBox QAbstractItemView {{ background: {c['PANEL']}; border: 1px solid {c['LINE']}; selection-background-color: {c['NAVSEL']}; }}
QTableWidget, QListWidget, QTreeWidget {{ background: {c['PANEL']}; alternate-background-color: {c['PANEL2']}; border: 1px solid {c['LINE']};
    border-radius: 10px; gridline-color: {c['LINE']}; }}
QTableWidget::item, QListWidget::item, QTreeWidget::item {{ padding: 5px 7px; }}
QTableWidget::item:selected, QListWidget::item:selected, QTreeWidget::item:selected {{ background: {c['NAVSEL']}; color: {c['TEXT']}; }}
QHeaderView::section {{ background: {c['PANEL2']}; color: {c['MUTED']}; border: 0; border-bottom: 1px solid {c['LINE']}; padding: 8px 8px; font-weight: 600; }}
QTabWidget::pane {{ border: 1px solid {c['LINE']}; border-radius: 10px; top: -1px; }}
QTabBar::tab {{ background: transparent; padding: 8px 16px; color: {c['MUTED']}; border-bottom: 2px solid transparent; }}
QTabBar::tab:selected {{ color: {c['ACCENT']}; border-bottom: 2px solid {c['ACCENT']}; font-weight: 600; }}
QGroupBox {{ border: 1px solid {c['LINE']}; border-radius: 10px; margin-top: 14px; padding: 12px; font-weight: 600; }}
QGroupBox::title {{ subcontrol-origin: margin; left: 12px; padding: 0 6px; color: {c['ACCENT']}; }}
QListWidget::indicator, QTableWidget::indicator {{ width: 15px; height: 15px; border: 1px solid {c['MUTED']}; border-radius: 4px; background: {c['INPUT']}; }}
QListWidget::indicator:checked, QTableWidget::indicator:checked {{ background: {c['ACCENT']}; border-color: {c['ACCENT']}; }}
QCheckBox::indicator {{ width: 16px; height: 16px; border: 1px solid {c['LINE']}; border-radius: 4px; background: {c['INPUT']}; }}
QCheckBox::indicator:checked {{ background: {c['ACCENT']}; border-color: {c['ACCENT']}; }}
QProgressBar {{ background: {c['PANEL']}; border: 1px solid {c['LINE']}; border-radius: 7px; height: 12px; text-align: center; }}
QProgressBar::chunk {{ background: qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 {c['ACCENT']}, stop:1 {c['ACCENT2']}); border-radius: 6px; }}
QScrollBar:vertical {{ background: transparent; width: 11px; margin: 2px; }}
QScrollBar::handle:vertical {{ background: {c['LINE']}; border-radius: 5px; min-height: 30px; }}
QScrollBar::handle:vertical:hover {{ background: {c['MUTED']}; }}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{ height: 0; }}
QScrollBar:horizontal {{ background: transparent; height: 11px; margin: 2px; }}
QScrollBar::handle:horizontal {{ background: {c['LINE']}; border-radius: 5px; min-width: 30px; }}
QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal {{ width: 0; }}
QStatusBar {{ background: {c['PANEL']}; border-top: 1px solid {c['LINE']}; color: {c['MUTED']}; }}
QWidget#recbar {{ background: {c['PANEL']}; border: 1px solid {c['LINE']}; border-radius: 12px; }}
"""


STYLE = stylesheet("dark")
