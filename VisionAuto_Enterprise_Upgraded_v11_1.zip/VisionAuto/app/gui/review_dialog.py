"""
Review screen shown right after recording.

Left : every recorded step in plain English.
Right: preview of the clicked element + the validation points for that step.
       AI suggestions come pre-ticked when confident; the user confirms or changes them.
"""
from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtGui import QPixmap
from PySide6.QtWidgets import (QAbstractItemView, QDialog, QHBoxLayout, QHeaderView, QLabel, QLineEdit,
                               QListWidget, QListWidgetItem, QMessageBox, QPushButton, QSplitter,
                               QTableWidget, QTableWidgetItem, QTextEdit, QVBoxLayout, QWidget)

from core import review


class ReviewDialog(QDialog):
    def __init__(self, test: dict, directory: str, parent=None):
        super().__init__(parent)
        self.test, self.dir = test, Path(directory)
        self.run_after = False
        self.discarded = False
        self.setWindowTitle("Review recording")
        self.resize(1100, 720)
        self._building = False
        self._current: int | None = None
        self._build_candidates()

        root = QVBoxLayout(self)
        head = QHBoxLayout()
        head.addWidget(QLabel("Test name"))
        self.title = QLineEdit(test.get("title") or test["name"])
        head.addWidget(self.title, 1)
        root.addLayout(head)
        self.summary = QLabel(test.get("summary", ""))
        self.summary.setObjectName("muted")
        self.summary.setWordWrap(True)
        root.addWidget(self.summary)

        split = QSplitter()
        left = QWidget()
        lv = QVBoxLayout(left)
        lv.setContentsMargins(0, 0, 0, 0)
        bar = QHBoxLayout()
        self.use_btn = QPushButton("Use selected steps as validation points")
        self.use_btn.clicked.connect(self._use_selected)
        self.del_btn = QPushButton("Delete selected steps")
        self.del_btn.clicked.connect(self._delete_selected)
        bar.addWidget(self.use_btn)
        bar.addWidget(self.del_btn)
        bar.addStretch(1)
        lv.addLayout(bar)
        self.table = QTableWidget(0, 4)
        self.table.setHorizontalHeaderLabels(["#", "What you did", "Checks", "AI suggested"])
        self.table.verticalHeader().setVisible(False)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        hh = self.table.horizontalHeader()
        hh.setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        for c in (0, 2, 3):
            hh.setSectionResizeMode(c, QHeaderView.ResizeMode.ResizeToContents)
        self.table.itemSelectionChanged.connect(self._on_select)
        lv.addWidget(self.table)
        split.addWidget(left)

        right = QWidget()
        rv = QVBoxLayout(right)
        rv.setContentsMargins(8, 0, 0, 0)
        self.preview = QLabel("")
        self.preview.setMinimumHeight(150)
        self.preview.setAlignment(Qt.AlignmentFlag.AlignCenter)
        rv.addWidget(self.preview)
        self.details = QTextEdit()
        self.details.setReadOnly(True)
        self.details.setMaximumHeight(130)
        rv.addWidget(self.details)
        rv.addWidget(QLabel("Validation points for this step  (ticked = checked after the step during playback)"))
        self.checks = QListWidget()
        self.checks.itemChanged.connect(self._on_check)
        rv.addWidget(self.checks, 1)
        split.addWidget(right)
        split.setSizes([620, 440])
        root.addWidget(split, 1)

        foot = QHBoxLayout()
        self.stats = QLabel("")
        self.stats.setObjectName("muted")
        foot.addWidget(self.stats)
        foot.addStretch(1)
        discard = QPushButton("Discard recording")
        discard.clicked.connect(self._discard)
        save = QPushButton("Save")
        save.clicked.connect(lambda: self._save(False))
        save_run = QPushButton("Save and run")
        save_run.setProperty("kind", "primary")
        save_run.clicked.connect(lambda: self._save(True))
        for b in (discard, save, save_run):
            foot.addWidget(b)
        root.addLayout(foot)
        self._fill_table()

    # ------------------------------------------------------------ model
    def _build_candidates(self) -> None:
        for s in self.test["steps"]:
            seen, out = set(), []

            def put(v, checked, source, reason=""):
                k = review._key(v)
                if k in seen:
                    return
                seen.add(k)
                out.append({"v": v, "checked": checked, "source": source, "reason": reason})

            for v in s.get("validations", []):
                put(v, True, "yours")
            for v in s.get("suggestions", []):
                put(v, v.get("confidence", 0) >= 0.8, "AI suggested", v.get("reason", ""))
            for o in review.validation_options(s):
                put(o["validation"], False, "option")
            s["_cands"] = out

    def _cands(self, step_id: int) -> list[dict]:
        step = next((s for s in self.test["steps"] if s["id"] == step_id), None)
        return step["_cands"] if step else []

    def _fill_table(self) -> None:
        self._building = True
        steps = self.test["steps"]
        self.table.setRowCount(len(steps))
        for r, s in enumerate(steps):
            n_checked = sum(1 for c in s["_cands"] if c["checked"])
            n_ai = sum(1 for c in s["_cands"] if c["source"] == "AI suggested")
            vals = [str(s["id"]), s.get("description", ""), str(n_checked) if n_checked else "", str(n_ai) if n_ai else ""]
            for c, text in enumerate(vals):
                self.table.setItem(r, c, QTableWidgetItem(text))
            self.table.item(r, 0).setData(Qt.ItemDataRole.UserRole, s["id"])
        self._building = False
        self._update_stats()

    def _update_stats(self, extra: str = "") -> None:
        total = sum(1 for s in self.test["steps"] for c in s["_cands"] if c["checked"])
        self.stats.setText(f"{len(self.test['steps'])} steps, {total} validation points ticked{extra}")

    def _selected_ids(self) -> list[int]:
        rows = sorted({i.row() for i in self.table.selectedIndexes()})
        return [self.table.item(r, 0).data(Qt.ItemDataRole.UserRole) for r in rows]

    # ------------------------------------------------------------ events
    def _on_select(self) -> None:
        ids = self._selected_ids()
        self._current = ids[0] if len(ids) == 1 else None
        self._show_step(self._current)

    def _show_step(self, step_id) -> None:
        self._building = True
        self.checks.clear()
        self.details.clear()
        self.preview.clear()
        step = next((s for s in self.test["steps"] if s["id"] == step_id), None)
        if step:
            self.details.setPlainText("\n".join(f"{k}: {v}" for k, v in review.target_summary(step)))
            tpl = ((step.get("target") or {}).get("templates") or {}).get("crop300")
            if tpl and (self.dir / tpl["path"]).exists():
                pm = QPixmap(str(self.dir / tpl["path"]))
                self.preview.setPixmap(pm.scaled(300, 150, Qt.AspectRatioMode.KeepAspectRatio,
                                                 Qt.TransformationMode.SmoothTransformation))
            for c in self._cands(step_id):
                tag = {"yours": "", "AI suggested": "  [AI suggested]", "option": ""}[c["source"]]
                item = QListWidgetItem(c["v"].get("description", c["v"]["type"]) + tag)
                item.setFlags(item.flags() | Qt.ItemFlag.ItemIsUserCheckable)
                item.setCheckState(Qt.CheckState.Checked if c["checked"] else Qt.CheckState.Unchecked)
                if c["reason"]:
                    item.setToolTip(c["reason"])
                self.checks.addItem(item)
        self._building = False

    def _on_check(self, item: QListWidgetItem) -> None:
        if self._building or self._current is None:
            return
        self._cands(self._current)[self.checks.row(item)]["checked"] = item.checkState() == Qt.CheckState.Checked
        row = next(r for r in range(self.table.rowCount()) if self.table.item(r, 0).data(Qt.ItemDataRole.UserRole) == self._current)
        n = sum(1 for c in self._cands(self._current) if c["checked"])
        self.table.item(row, 2).setText(str(n) if n else "")
        self._update_stats()

    def _use_selected(self) -> None:
        ids = self._selected_ids()
        if not ids:
            QMessageBox.information(self, "Validation points", "Select one or more steps first.")
            return
        n = 0
        for sid in ids:
            cands = self._cands(sid)
            best = next((c for c in cands if c["source"] != "AI suggested"), cands[0] if cands else None)
            if best and not best["checked"]:
                best["checked"] = True
                n += 1
        self._fill_table()
        if self._current is not None:
            self._show_step(self._current)
        self._update_stats(f"   ({n} added)")

    def _delete_selected(self) -> None:
        ids = self._selected_ids()
        if not ids:
            return
        if QMessageBox.question(self, "Delete steps", f"Delete {len(ids)} step(s)?") != QMessageBox.StandardButton.Yes:
            return
        review.delete_steps(self.test, ids)           # renumbers ids; candidates travel with their steps
        self._current = None
        self._fill_table()
        self._show_step(None)

    def _discard(self) -> None:
        if QMessageBox.question(self, "Discard", "Throw this recording away?") == QMessageBox.StandardButton.Yes:
            self.discarded = True
            self.done(0)

    def _save(self, run: bool) -> None:
        for s in self.test["steps"]:
            s["validations"] = []
            for c in s.pop("_cands", []):
                if c["checked"]:
                    review.add_validation(s, c["v"])
        review.finalize(self.test, self.dir, accepted=None, title=self.title.text().strip() or None)
        self.run_after = run
        self.accept()
