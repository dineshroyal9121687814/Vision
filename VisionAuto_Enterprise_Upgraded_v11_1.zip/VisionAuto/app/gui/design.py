"""Small design system: painter-drawn icons (no image files), KPI cards, two charts, toast notifications and an event bus.

Everything is drawn with QPainter from the colours in ``app.gui.theme`` so light and dark stay consistent and the package
needs no extra assets or dependencies."""
from __future__ import annotations

from PySide6.QtCore import QObject, QPointF, QRectF, Qt, QTimer, Signal
from PySide6.QtGui import QColor, QFont, QIcon, QPainter, QPainterPath, QPen, QPixmap
from PySide6.QtWidgets import QFrame, QLabel, QVBoxLayout, QWidget

from app.gui import theme as _theme

_current = {"theme": "dark"}


def set_theme(name: str) -> None:
    _current["theme"] = name if name in _theme.PALETTES else "dark"


def colors() -> dict:
    return _theme.colors(_current["theme"])


# ------------------------------------------------------------------------------------------------------------ icons
def _poly(p: QPainter, pts):
    path = QPainterPath(QPointF(*pts[0]))
    for x, y in pts[1:]:
        path.lineTo(x, y)
    path.closeSubpath()
    p.drawPath(path)


def _draw(name: str, p: QPainter, s: float) -> None:
    u = s / 24.0
    p.scale(u, u)
    if name == "dashboard":
        for x, y, w, h in ((3, 3, 8, 10), (13, 3, 8, 6), (13, 11, 8, 10), (3, 15, 8, 6)):
            p.drawRoundedRect(QRectF(x, y, w, h), 2, 2)
    elif name == "record":
        p.drawEllipse(QRectF(4, 4, 16, 16))
        p.setBrush(p.pen().color())
        p.drawEllipse(QRectF(9, 9, 6, 6))
    elif name == "apps":
        for x in (4, 14):
            for y in (4, 14):
                p.drawRoundedRect(QRectF(x, y, 6, 6), 1.5, 1.5)
    elif name == "tests":
        p.drawRoundedRect(QRectF(5, 3, 14, 18), 2, 2)
        p.drawLine(QPointF(8.5, 8), QPointF(15.5, 8))
        p.drawLine(QPointF(8.5, 12), QPointF(15.5, 12))
        p.drawLine(QPointF(8.5, 16), QPointF(13, 16))
    elif name == "design":
        p.drawLine(QPointF(4, 20), QPointF(8, 19))
        p.drawLine(QPointF(8, 19), QPointF(19, 8))
        p.drawLine(QPointF(19, 8), QPointF(16, 5))
        p.drawLine(QPointF(16, 5), QPointF(5, 16))
        p.drawLine(QPointF(5, 16), QPointF(4, 20))
    elif name == "objects":
        _poly(p, [(12, 3), (20, 7.5), (20, 16.5), (12, 21), (4, 16.5), (4, 7.5)])
        p.drawLine(QPointF(12, 12), QPointF(12, 21))
        p.drawLine(QPointF(12, 12), QPointF(20, 7.5))
        p.drawLine(QPointF(12, 12), QPointF(4, 7.5))
    elif name == "data":
        p.drawEllipse(QRectF(5, 3, 14, 5))
        p.drawLine(QPointF(5, 5.5), QPointF(5, 18.5))
        p.drawLine(QPointF(19, 5.5), QPointF(19, 18.5))
        p.drawArc(QRectF(5, 11, 14, 5), 180 * 16, 180 * 16)
        p.drawArc(QRectF(5, 16, 14, 5), 180 * 16, 180 * 16)
    elif name == "run":
        p.setBrush(p.pen().color())
        _poly(p, [(7, 4.5), (19, 12), (7, 19.5)])
    elif name == "reports":
        for i, h in enumerate((8, 13, 6, 16)):
            p.drawRoundedRect(QRectF(4 + i * 4.6, 20 - h, 3, h), 1, 1)
    elif name == "ai":
        _poly(p, [(12, 2.5), (14.2, 9.8), (21.5, 12), (14.2, 14.2), (12, 21.5), (9.8, 14.2), (2.5, 12), (9.8, 9.8)])
    elif name == "inspect":
        p.drawEllipse(QRectF(4, 4, 11, 11))
        p.drawLine(QPointF(13, 13), QPointF(20, 20))
    elif name == "plugins":
        p.drawRoundedRect(QRectF(5, 9, 14, 10), 2, 2)
        p.drawLine(QPointF(9, 9), QPointF(9, 4))
        p.drawLine(QPointF(15, 9), QPointF(15, 4))
    elif name == "import":
        p.drawLine(QPointF(12, 4), QPointF(12, 15))
        p.drawLine(QPointF(12, 15), QPointF(8, 11))
        p.drawLine(QPointF(12, 15), QPointF(16, 11))
        p.drawLine(QPointF(5, 20), QPointF(19, 20))
    elif name == "settings":
        p.drawEllipse(QRectF(8, 8, 8, 8))
        for a in range(8):
            p.save()
            p.translate(12, 12)
            p.rotate(a * 45)
            p.drawLine(QPointF(0, -7), QPointF(0, -10))
            p.restore()
    elif name == "search":
        p.drawEllipse(QRectF(4, 4, 11, 11))
        p.drawLine(QPointF(13, 13), QPointF(20, 20))
    elif name == "sun":
        p.drawEllipse(QRectF(8, 8, 8, 8))
        for a in range(8):
            p.save()
            p.translate(12, 12)
            p.rotate(a * 45)
            p.drawLine(QPointF(0, -9.5), QPointF(0, -11.5))
            p.restore()
    elif name == "moon":
        path = QPainterPath()
        path.addEllipse(QRectF(4, 4, 16, 16))
        cut = QPainterPath()
        cut.addEllipse(QRectF(9, 2, 14, 14))
        p.drawPath(path.subtracted(cut))
    else:
        p.drawEllipse(QRectF(6, 6, 12, 12))


def icon(name: str, color: str | None = None, size: int = 20) -> QIcon:
    dpr = 2
    pm = QPixmap(size * dpr, size * dpr)
    pm.setDevicePixelRatio(dpr)
    pm.fill(Qt.GlobalColor.transparent)
    p = QPainter(pm)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    pen = QPen(QColor(color or colors()["MUTED"]))
    pen.setWidthF(1.7)
    pen.setCapStyle(Qt.PenCapStyle.RoundCap)
    pen.setJoinStyle(Qt.PenJoinStyle.RoundJoin)
    p.setPen(pen)
    p.setBrush(Qt.BrushStyle.NoBrush)
    _draw(name, p, size)
    p.end()
    return QIcon(pm)


# ------------------------------------------------------------------------------------------------------------ widgets
def page_background(w: QWidget) -> QWidget:
    """Custom QWidget pages ignore stylesheet backgrounds unless this attribute is set (found with a screenshot)."""
    w.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
    return w


def card(title: str = "") -> tuple[QFrame, QVBoxLayout]:
    f = QFrame()
    f.setObjectName("card")
    lay = QVBoxLayout(f)
    lay.setContentsMargins(16, 14, 16, 14)
    lay.setSpacing(8)
    if title:
        t = QLabel(title)
        t.setObjectName("h2")
        lay.addWidget(t)
    return f, lay


def kpi(title: str, value: str, tone: str = "", hint: str = "") -> QFrame:
    f = QFrame()
    f.setObjectName("card")
    f.setProperty("tone", tone)
    lay = QVBoxLayout(f)
    lay.setContentsMargins(16, 12, 16, 12)
    lay.setSpacing(2)
    t = QLabel(title)
    t.setObjectName("muted")
    v = QLabel(value)
    v.setObjectName("stat")
    lay.addWidget(t)
    lay.addWidget(v)
    if hint:
        h = QLabel(hint)
        h.setObjectName("muted")
        h.setWordWrap(True)
        lay.addWidget(h)
    return f


class TrendChart(QWidget):
    """Stacked daily bars (passed / failed). Draws only what it is given; no data -> says so."""

    def __init__(self):
        super().__init__()
        self.days: list[dict] = []
        self.setMinimumHeight(150)

    def set_days(self, days: list[dict]) -> None:
        self.days = days
        self.update()

    def paintEvent(self, _):
        c = colors()
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        r = self.rect().adjusted(8, 8, -8, -22)
        peak = max((d["total"] for d in self.days), default=0)
        if not peak:
            p.setPen(QColor(c["MUTED"]))
            p.drawText(self.rect(), Qt.AlignmentFlag.AlignCenter, "No runs in this period yet.")
            return
        n = len(self.days)
        slot = r.width() / n
        bw = max(4.0, slot * 0.6)
        p.setPen(Qt.PenStyle.NoPen)
        for i, d in enumerate(self.days):
            x = r.left() + i * slot + (slot - bw) / 2
            y = r.bottom()
            for key, col in (("passed", c["OK"]), ("failed", c["BAD"])):
                h = r.height() * d[key] / peak
                if h:
                    p.setBrush(QColor(col))
                    p.drawRoundedRect(QRectF(x, y - h, bw, h), 2, 2)
                    y -= h
            if i % max(1, n // 7) == 0:
                p.setPen(QColor(c["MUTED"]))
                f = QFont(p.font())
                f.setPointSizeF(7.5)
                p.setFont(f)
                p.drawText(QRectF(x - 14, r.bottom() + 4, bw + 28, 14), Qt.AlignmentFlag.AlignCenter, d["date"][5:])
                p.setPen(Qt.PenStyle.NoPen)


class DonutChart(QWidget):
    def __init__(self):
        super().__init__()
        self.parts: list[tuple[str, int, str]] = []
        self.setMinimumSize(150, 150)

    def set_parts(self, parts: list[tuple[str, int, str]]) -> None:
        self.parts = [x for x in parts if x[1] > 0]
        self.update()

    def paintEvent(self, _):
        c = colors()
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        side = min(self.width(), self.height()) - 16
        box = QRectF((self.width() - side) / 2, (self.height() - side) / 2, side, side)
        total = sum(v for _, v, _ in self.parts)
        pen = QPen(QColor(c["LINE"]))
        pen.setWidthF(16)
        p.setPen(pen)
        p.drawArc(box.adjusted(8, 8, -8, -8), 0, 360 * 16)
        if total:
            start = 90 * 16
            for _, v, col in self.parts:
                span = int(-360 * 16 * v / total)
                pen = QPen(QColor(col))
                pen.setWidthF(16)
                p.setPen(pen)
                p.drawArc(box.adjusted(8, 8, -8, -8), start, span)
                start += span
        p.setPen(QColor(c["TEXT"]))
        f = QFont(p.font())
        f.setPointSizeF(15)
        f.setBold(True)
        p.setFont(f)
        p.drawText(box, Qt.AlignmentFlag.AlignCenter, str(total) if total else "0")


# ------------------------------------------------------------------------------------------------------------ events
class Bus(QObject):
    """Process-wide channel so any page can raise a toast or a status/log line without knowing the window."""

    notify = Signal(str, str)                # level (info/ok/warn/bad), text
    log = Signal(str)
    progress = Signal(int, int)             # done, total  (total 0 = idle)
    data_changed = Signal()


bus = Bus()


class Toast(QLabel):
    def __init__(self, parent: QWidget):
        super().__init__(parent)
        self.setObjectName("toast")
        self.setWordWrap(True)
        self.setMaximumWidth(380)
        self.hide()
        self._t = QTimer(self)
        self._t.setSingleShot(True)
        self._t.timeout.connect(self.hide)

    def show_message(self, level: str, text: str, ms: int = 4500) -> None:
        self.setProperty("level", level)
        self.style().unpolish(self)
        self.style().polish(self)
        self.setText(text)
        self.adjustSize()
        par = self.parentWidget()
        self.move(par.width() - self.width() - 24, par.height() - self.height() - 48)
        self.raise_()
        self.show()
        self._t.start(ms)
