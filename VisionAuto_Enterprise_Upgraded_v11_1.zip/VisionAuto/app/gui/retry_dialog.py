"""'A step failed - retry?' question shown while the run waits. Counts down; no answer = the configured fallback."""
from __future__ import annotations

from PySide6.QtCore import QTimer, Qt
from PySide6.QtWidgets import QDialog, QHBoxLayout, QLabel, QPushButton, QVBoxLayout

ACTION_TEXT = {"retry": "retry the step", "skip": "give up on this step and continue", "stop": "stop the run"}


class RetryDialog(QDialog):
    """``choice`` is "retry", "skip", "stop" or "" (nobody answered in time)."""

    def __init__(self, payload: dict, fallback: str = "retry", parent=None):
        super().__init__(parent)
        self.choice = ""
        self.left = max(1, int(payload.get("timeout_s", 30)))
        self.fallback = fallback
        self.setWindowTitle("Step failed")
        self.setModal(True)
        self.setWindowFlag(Qt.WindowType.WindowStaysOnTopHint, True)
        self.setMinimumWidth(520)
        lay = QVBoxLayout(self)
        title = QLabel(f"Step {payload.get('step_id', '?')} failed: {payload.get('description', '')}")
        title.setObjectName("h2")
        title.setWordWrap(True)
        lay.addWidget(title)
        err = QLabel(str(payload.get("error", "")))
        err.setWordWrap(True)
        lay.addWidget(err)
        diag = payload.get("diagnosis") or {}
        cls = payload.get("classification") or {}
        if diag:
            d = QLabel(f"<b>AI diagnosis:</b> {diag.get('summary', '')}<br><b>Likely cause:</b> {diag.get('likely_cause', '')}"
                       f"<br><b>Suggestion:</b> {diag.get('suggestion', '')}")
            d.setWordWrap(True)
            lay.addWidget(d)
        note = QLabel(f"Attempt {payload.get('attempt', 1)} of {payload.get('max_attempts', 1)}. "
                      + ("No input had been sent, so retrying is safe." if not cls.get("input_sent")
                         else "The action may already have run once - retrying could repeat it."))
        note.setObjectName("muted")
        note.setWordWrap(True)
        lay.addWidget(note)
        self.timer_label = QLabel("")
        self.timer_label.setObjectName("muted")
        lay.addWidget(self.timer_label)
        row = QHBoxLayout()
        for text, value, kind in (("Retry", "retry", "primary"), ("Give up on step", "skip", ""), ("Stop run", "stop", "danger")):
            b = QPushButton(text)
            if kind:
                b.setProperty("kind", kind)
            b.clicked.connect(lambda _=False, v=value: self._answer(v))
            row.addWidget(b)
        lay.addLayout(row)
        self.timer = QTimer(self)
        self.timer.setInterval(1000)
        self.timer.timeout.connect(self._tick)
        self._show_left()
        self.timer.start()

    def _show_left(self) -> None:
        self.timer_label.setText(f"No answer in {self.left}s: VisionAuto will {ACTION_TEXT.get(self.fallback, self.fallback)}.")

    def _tick(self) -> None:
        self.left -= 1
        if self.left <= 0:
            self.timer.stop()
            self.choice = ""
            self.accept()
            return
        self._show_left()

    def _answer(self, value: str) -> None:
        self.timer.stop()
        self.choice = value
        self.accept()

    def reject(self) -> None:          # Esc / window close = no answer (the fallback policy applies)
        self.timer.stop()
        self.choice = ""
        super().reject()
