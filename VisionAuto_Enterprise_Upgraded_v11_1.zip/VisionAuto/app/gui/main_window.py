from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtGui import QColor, QFont
from PySide6.QtWidgets import (QHBoxLayout, QLabel, QLineEdit, QListWidget, QListWidgetItem, QMainWindow, QPlainTextEdit,
                               QProgressBar, QPushButton, QStackedWidget, QVBoxLayout, QWidget)

from app.gui import design
from app.gui.pages.ai_page import AIPage
from app.gui.pages.applications_page import ApplicationsPage
from app.gui.pages.dashboard import DashboardPage
from app.gui.pages.data_page import DataPage
from app.gui.pages.execution_page import ExecutionPage
from app.gui.pages.import_page import ImportPage
from app.gui.pages.inspector_page import InspectorPage
from app.gui.pages.library_page import LibraryPage
from app.gui.pages.object_repo_page import ObjectRepoPage
from app.gui.pages.plugins_page import PluginsPage
from app.gui.pages.recorder_page import RecorderPage
from app.gui.pages.reports_page import ReportsPage
from app.gui.pages.settings_page import SettingsPage
from app.gui.pages.testcases_page import TestCasesPage
from core import paths

# (section header, [(key, label, icon)]) - the sidebar is built from this; ``key`` is how code navigates ("go('ai')")
MODULES = [
    ("OVERVIEW", [("dashboard", "Dashboard", "dashboard")]),
    ("BUILD", [("recorder", "Recorder", "record"), ("applications", "Applications", "apps"), ("library", "Test Explorer", "tests"),
               ("testcases", "Test Designer", "design"), ("objects", "Object Repository", "objects"), ("data", "Data Manager", "data")]),
    ("RUN", [("execution", "Execution Center", "run"), ("reports", "Reports & Analytics", "reports")]),
    ("INTELLIGENCE", [("ai", "AI Assistant", "ai"), ("inspector", "Inspector", "inspect")]),
    ("SYSTEM", [("plugins", "Plugins & Integrations", "plugins"), ("importer", "Import Ranorex", "import"), ("settings", "Settings", "settings")]),
]


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("VisionAuto")
        self.resize(1360, 860)
        paths.ensure_dirs()
        self.dashboard = DashboardPage()
        self.recorder = RecorderPage()
        self.library = LibraryPage()
        self.testcases = TestCasesPage()
        self.applications = ApplicationsPage()
        self.reports = ReportsPage()
        self.importer = ImportPage()
        self.inspector = InspectorPage()
        self.settings = SettingsPage()
        self.execution = ExecutionPage()
        self.objects = ObjectRepoPage()
        self.data = DataPage()
        self.ai = AIPage()
        self.plugins = PluginsPage()
        self.settings.theme_changed.connect(self.apply_theme)
        self.pages = {"dashboard": self.dashboard, "recorder": self.recorder, "applications": self.applications,
                      "library": self.library, "testcases": self.testcases, "objects": self.objects, "data": self.data,
                      "execution": self.execution, "reports": self.reports, "ai": self.ai, "inspector": self.inspector,
                      "plugins": self.plugins, "importer": self.importer, "settings": self.settings}

        central = QWidget()
        outer = QVBoxLayout(central)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)
        outer.addWidget(self._build_topbar())

        body = QHBoxLayout()
        body.setContentsMargins(0, 0, 0, 0)
        body.setSpacing(0)
        self.nav = QListWidget()
        self.nav.setObjectName("nav")
        self.nav.setFixedWidth(232)
        self.nav.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.nav.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self.stack = QStackedWidget()
        self.rows: dict[str, int] = {}
        self._icons: list[tuple[QListWidgetItem, str]] = []
        for section, items in MODULES:
            head = QListWidgetItem(section)
            head.setFlags(Qt.ItemFlag.NoItemFlags)                      # a label, not selectable
            f = QFont(head.font())
            f.setPointSizeF(8)
            f.setBold(True)
            head.setFont(f)
            self.nav.addItem(head)
            for key, label, ico in items:
                it = QListWidgetItem(label)
                it.setData(Qt.ItemDataRole.UserRole, key)
                self.rows[key] = self.nav.count()
                self.nav.addItem(it)
                self._icons.append((it, ico))
                design.page_background(self.pages[key])
                self.stack.addWidget(self.pages[key])
        self.nav.currentRowChanged.connect(self._on_nav)
        body.addWidget(self.nav)
        body.addWidget(self.stack, 1)
        wrap = QWidget()
        wrap.setLayout(body)
        outer.addWidget(wrap, 1)
        outer.addWidget(self._build_bottom())
        self.setCentralWidget(central)
        self._paint_icons()
        self.toast = design.Toast(central)
        design.bus.notify.connect(self.toast.show_message)
        design.bus.log.connect(self._log)
        design.bus.progress.connect(self._progress)
        design.bus.data_changed.connect(self._data_changed)
        self.go("dashboard")

        self.dashboard.record_clicked.connect(lambda: self.go("recorder"))
        self.dashboard.navigate.connect(self.go)
        self.recorder.test_saved.connect(self._on_test_saved)
        self.importer.imported.connect(self.library.refresh)

    # ------------------------------------------------------------------ shell pieces
    def _build_topbar(self) -> QWidget:
        bar = QWidget()
        bar.setObjectName("topbar")
        design.page_background(bar)
        bar.setFixedHeight(48)
        row = QHBoxLayout(bar)
        row.setContentsMargins(16, 0, 16, 0)
        brand = QLabel("◈  VisionAuto")
        brand.setObjectName("brand")
        row.addWidget(brand)
        row.addSpacing(24)
        self.search = QLineEdit()
        self.search.setPlaceholderText("Jump to a module…  (Enter)")
        self.search.setMaximumWidth(320)
        self.search.returnPressed.connect(self._search_go)
        row.addWidget(self.search)
        row.addStretch(1)
        self.workspace_lbl = QLabel(f"Workspace: {paths.workspace()}")
        self.workspace_lbl.setObjectName("muted")
        row.addWidget(self.workspace_lbl)
        self.theme_btn = QPushButton("")
        self.theme_btn.setProperty("kind", "ghost")
        self.theme_btn.setToolTip("Switch light / dark theme")
        self.theme_btn.clicked.connect(self._toggle_theme)
        row.addWidget(self.theme_btn)
        return bar

    def _build_bottom(self) -> QWidget:
        box = QWidget()
        box.setObjectName("bottombar")
        design.page_background(box)
        lay = QVBoxLayout(box)
        lay.setContentsMargins(12, 4, 12, 4)
        lay.setSpacing(4)
        row = QHBoxLayout()
        self.status_lbl = QLabel("Ready")
        self.status_lbl.setObjectName("muted")
        self.prog = QProgressBar()
        self.prog.setMaximumWidth(220)
        self.prog.setMaximumHeight(14)
        self.prog.setVisible(False)
        self.log_btn = QPushButton("Activity log ▴")
        self.log_btn.setProperty("kind", "ghost")
        self.log_btn.setCheckable(True)
        row.addWidget(self.status_lbl, 1)
        row.addWidget(self.prog)
        row.addWidget(self.log_btn)
        lay.addLayout(row)
        self.console = QPlainTextEdit()
        self.console.setObjectName("console")
        self.console.setReadOnly(True)
        self.console.setMaximumBlockCount(2000)
        self.console.setFixedHeight(150)
        self.console.setVisible(False)
        self.log_btn.toggled.connect(self.console.setVisible)
        lay.addWidget(self.console)
        return box

    def _paint_icons(self) -> None:
        for it, ico in self._icons:
            it.setIcon(design.icon(ico, design.colors()["MUTED"]))

    # ------------------------------------------------------------------ navigation
    def go(self, key: str) -> None:
        row = self.rows.get(key)
        if row is not None:
            self.nav.setCurrentRow(row)

    def _search_go(self) -> None:
        q = self.search.text().strip().casefold()
        if not q:
            return
        for section, items in MODULES:
            for key, label, _ in items:
                if q in label.casefold() or q in key:
                    self.go(key)
                    self.search.clear()
                    return
        design.bus.notify.emit("warn", f"No module matches '{q}'.")

    def _toggle_theme(self) -> None:
        from core import settings

        try:
            opts = settings.load()
            new = "light" if opts.get("theme", "dark") == "dark" else "dark"
            settings.save({**opts, "theme": new})
        except Exception as e:
            design.bus.notify.emit("bad", f"Could not save the theme: {e}")
            return
        self.apply_theme(new)

    def _log(self, line: str) -> None:
        from core.security import mask

        self.console.appendPlainText(mask(line))
        self.status_lbl.setText(mask(line).strip()[:160])

    def _progress(self, done: int, total: int) -> None:
        self.prog.setVisible(bool(total))
        if total:
            self.prog.setRange(0, total)
            self.prog.setValue(done)

    def _data_changed(self) -> None:
        for p in (self.dashboard, self.reports):
            if self.stack.currentWidget() is p and hasattr(p, "refresh"):
                p.refresh()

    def offer_ai_setup(self) -> None:
        """First launch only: ask once whether to set up the local AI (Ollama + small model) automatically."""
        from PySide6.QtWidgets import QMessageBox
        from core import settings
        from core.ai import ollama_manager

        try:
            opts = settings.load()
            if opts.get("ai_setup_prompted"):
                return
            settings.save({**opts, "ai_setup_prompted": True})           # ask once, whatever the answer
            if ollama_manager.status(opts["llm_base_url"], opts["llm_model"])["model_ready"]:
                return
            ask = QMessageBox.question(
                self, "Set up the local AI?",
                "VisionAuto can run a small AI model on this computer (nothing is sent anywhere). It helps pick the right "
                "app / element when several look alike.\n\nSet it up now? It installs Ollama for your user account and "
                "downloads one model (about 1-2 GB). You can also do this later in Settings.")
            if ask == QMessageBox.StandardButton.Yes:
                self.go("settings")
                self.settings.auto_setup(confirmed=True)
        except Exception:
            import logging
            logging.getLogger("visionauto.app").exception("AI setup offer failed")

    def _on_nav(self, row: int) -> None:
        it = self.nav.item(row)
        key = it.data(Qt.ItemDataRole.UserRole) if it else None
        if key is None:
            return
        self.stack.setCurrentWidget(self.pages[key])
        page = self.stack.currentWidget()
        if hasattr(page, "refresh"):
            page.refresh()

    def _on_test_saved(self, name: str, run_now: bool) -> None:
        self.library.refresh()
        self.go("library")
        self.library.select_by_name(name)
        if run_now:
            self.library.run_selected(False)

    def apply_theme(self, theme: str) -> None:
        from PySide6.QtWidgets import QApplication

        from app.gui.theme import stylesheet

        design.set_theme(theme)
        app = QApplication.instance()
        if app is not None:
            app.setStyleSheet(stylesheet(theme))
        self._paint_icons()
        self.theme_btn.setIcon(design.icon("sun" if theme == "dark" else "moon", design.colors()["TEXT"]))
        self.theme_btn.setText("Light" if theme == "dark" else "Dark")
        page = self.stack.currentWidget()
        if hasattr(page, "refresh"):
            page.refresh()

    def closeEvent(self, event):
        """Closing never leaves a worker or a recorder running.

        * a recording in progress must be stopped first (its hooks would otherwise keep listening)
        * an active test run is cancelled (after asking) and its worker is joined before the window closes
        * other background jobs (recording analysis, model download) are waited for, not abandoned"""
        from PySide6.QtWidgets import QMessageBox

        if self.recorder.session is not None and not self.recorder._finishing:
            self.statusBar().showMessage("A recording is in progress. Stop it first (red button on the bar, or F9).")
            event.ignore()
            return
        run = self.library.worker
        if run is not None and run.isRunning():
            ask = QMessageBox.question(self, "Test is running", "A test is still running. Cancel it and close VisionAuto?")
            if ask != QMessageBox.StandardButton.Yes:
                event.ignore()
                return
            self.statusBar().showMessage("Cancelling the running test…")
            if not self.library.shutdown(15000):
                self.statusBar().showMessage("The test did not stop within 15 s. Try Stop, then close again.")
                event.ignore()
                return
        ex = self.execution.worker
        if ex is not None and ex.isRunning():
            ask = QMessageBox.question(self, "Test is running", "A run in the Execution Center is still active. Cancel it and close VisionAuto?")
            if ask != QMessageBox.StandardButton.Yes:
                event.ignore()
                return
            if not self.execution.shutdown(15000):
                self.statusBar().showMessage("The run did not stop within 15 s. Try Stop, then close again.")
                event.ignore()
                return
        for w in (self.reports, self.testcases):
            gen = getattr(w, "worker", None)
            if gen is not None and gen.isRunning():
                gen.wait(5000)
        workers = (self.recorder.worker, self.importer.worker, self.settings.model_worker, self.testcases.worker,
                   self.objects.job, self.data.job, self.ai.job)
        active = [worker for worker in workers if worker is not None and worker.isRunning()]
        if active:
            self.statusBar().showMessage("Please wait for the current background task to finish before closing.")
            event.ignore()
            return
        event.accept()
