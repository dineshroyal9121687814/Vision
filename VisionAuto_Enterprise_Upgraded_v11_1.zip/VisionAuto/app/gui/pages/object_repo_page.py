"""Object Repository: every UI element the tests know about, with its locators, measured reliability and editable identity."""
from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtGui import QColor, QPixmap
from PySide6.QtWidgets import (QComboBox, QFileDialog, QFormLayout, QHBoxLayout, QLabel, QLineEdit, QListWidget,
                               QMessageBox, QPushButton, QSpinBox, QSplitter, QTableWidget, QTableWidgetItem, QVBoxLayout,
                               QWidget, QAbstractItemView)

from app.gui import design
from app.gui.pages.common import heading
from app.gui.workers import Job
from core import ai_assistant, object_repo

COLS = ["Name", "Application", "Window", "Type", "Best locator", "Reliability", "Last success", "Test / step"]


class ObjectRepoPage(QWidget):
    def __init__(self):
        super().__init__()
        self.setObjectName("page")
        self.objs: list[dict] = []
        self.shown: list[dict] = []
        self.job = None
        lay = QVBoxLayout(self)
        lay.setContentsMargins(28, 24, 28, 24)
        lay.addWidget(heading("Object Repository", "Elements recorded in your tests. Reliability is measured from real runs when they exist; "
                                                    "otherwise it is estimated from the strongest recorded locator and labelled so."))
        bar = QHBoxLayout()
        self.search = QLineEdit()
        self.search.setPlaceholderText("Search name, test, value, type…")
        self.app_filter = QComboBox()
        self.app_filter.addItem("All applications", "")
        self.min_rel = QSpinBox()
        self.min_rel.setRange(0, 100)
        self.min_rel.setPrefix("min reliability ")
        self.min_rel.setSuffix(" %")
        self.advice_btn = QPushButton("Weak locators…")
        self.export_btn = QPushButton("Export JSON")
        self.import_btn = QPushButton("Import JSON")
        self.reload_btn = QPushButton("Reload")
        for w in (self.search, self.app_filter, self.min_rel, self.advice_btn, self.export_btn, self.import_btn, self.reload_btn):
            bar.addWidget(w, 1 if w is self.search else 0)
        lay.addLayout(bar)
        self.status = QLabel("")
        self.status.setObjectName("muted")
        lay.addWidget(self.status)

        split = QSplitter(Qt.Orientation.Horizontal)
        self.table = QTableWidget(0, len(COLS))
        self.table.setHorizontalHeaderLabels(COLS)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.horizontalHeader().setStretchLastSection(True)
        self.table.verticalHeader().setVisible(False)
        self.table.setSortingEnabled(False)
        split.addWidget(self.table)
        side = QWidget()
        sl = QVBoxLayout(side)
        sl.setContentsMargins(12, 0, 0, 0)
        self.thumb = QLabel("")
        self.thumb.setMinimumHeight(70)
        self.thumb.setAlignment(Qt.AlignmentFlag.AlignCenter)
        sl.addWidget(self.thumb)
        self.basis = QLabel("Select an object.")
        self.basis.setObjectName("muted")
        self.basis.setWordWrap(True)
        sl.addWidget(self.basis)
        sl.addWidget(QLabel("Locator strategies (strongest first)"))
        self.alts = QListWidget()
        self.alts.setMaximumHeight(150)
        sl.addWidget(self.alts)
        form = QFormLayout()
        self.f_name, self.f_id, self.f_group = QLineEdit(), QLineEdit(), QLineEdit()
        form.addRow("Name", self.f_name)
        form.addRow("Automation ID", self.f_id)
        form.addRow("Group", self.f_group)
        sl.addLayout(form)
        row = QHBoxLayout()
        self.save_btn = QPushButton("Save changes")
        self.save_btn.setProperty("kind", "primary")
        self.forget_btn = QPushButton("Forget recorded name…")
        row.addWidget(self.save_btn)
        row.addWidget(self.forget_btn)
        sl.addLayout(row)
        sl.addStretch(1)
        split.addWidget(side)
        split.setStretchFactor(0, 3)
        split.setStretchFactor(1, 1)
        split.setSizes([800, 380])
        lay.addWidget(split, 1)

        self.search.textChanged.connect(self._apply)
        self.app_filter.currentIndexChanged.connect(self._apply)
        self.min_rel.valueChanged.connect(self._apply)
        self.table.itemSelectionChanged.connect(self._select)
        self.reload_btn.clicked.connect(self.refresh)
        self.save_btn.clicked.connect(self._save)
        self.forget_btn.clicked.connect(self._forget)
        self.export_btn.clicked.connect(self._export)
        self.import_btn.clicked.connect(self._import)
        self.advice_btn.clicked.connect(self._advice)
        self._set_enabled(False)

    # ------------------------------------------------------------------
    def _set_enabled(self, on: bool) -> None:
        for w in (self.save_btn, self.forget_btn, self.f_name, self.f_id, self.f_group):
            w.setEnabled(on)

    def refresh(self) -> None:
        if self.job and self.job.isRunning():
            return
        self.status.setText("Reading tests…")
        self.job = Job(object_repo.collect)
        self.job.done.connect(self._loaded)
        self.job.failed.connect(lambda m: self.status.setText(m))
        self.job.start()

    def _loaded(self, objs) -> None:
        self.objs = objs
        keep = self.app_filter.currentData()
        self.app_filter.blockSignals(True)
        self.app_filter.clear()
        self.app_filter.addItem("All applications", "")
        for a in sorted({o["application"] for o in objs if o["application"]}):
            self.app_filter.addItem(a, a)
        i = self.app_filter.findData(keep)
        self.app_filter.setCurrentIndex(max(0, i))
        self.app_filter.blockSignals(False)
        self._apply()

    def _apply(self) -> None:
        self.shown = object_repo.search(self.objs, self.search.text(), self.app_filter.currentData() or "", self.min_rel.value())
        self.table.setRowCount(len(self.shown))
        c = design.colors()
        for r, o in enumerate(self.shown):
            vals = [o["name"], o["application"], o["window"], o["type"], o["locator"], f"{o['reliability']} %",
                    o["last_success"][:16].replace("T", " "), f"{o['test']} · step {o['step']}{' (drop)' if o['tag'] == 'dst' else ''}"]
            for col, v in enumerate(vals):
                it = QTableWidgetItem(str(v))
                if col == 5:
                    it.setForeground(QColor(c["OK"] if o["reliability"] >= 80 else c["WARN"] if o["reliability"] >= 55 else c["BAD"]))
                self.table.setItem(r, col, it)
        self.table.resizeColumnsToContents()
        for col in range(len(COLS)):
            self.table.setColumnWidth(col, min(self.table.columnWidth(col), 240))
        total = len(self.objs)
        self.status.setText(f"{len(self.shown)} of {total} object(s)." if total else
                            "No objects yet. Record a test and its clicked elements appear here.")
        self._select()

    def current(self) -> dict | None:
        r = self.table.currentRow()
        return self.shown[r] if 0 <= r < len(self.shown) else None

    def _select(self) -> None:
        o = self.current()
        self._set_enabled(bool(o))
        self.alts.clear()
        self.thumb.clear()
        if not o:
            self.basis.setText("Select an object.")
            return
        self.basis.setText(f"Reliability {o['reliability']} % - {o['reliability_basis']}." +
                           (f" {o['healed_note']}" if o.get("healed_note") else ""))
        for a in [{"label": o["locator"], "value": o["value"]}] + o["alternatives"]:
            self.alts.addItem(f"{a['label']}: {a['value']}")
        self.f_name.setText(o["name"])
        self.f_id.setText("")
        self.f_group.setText(o["group"])
        if o.get("thumbnail") and Path(o["thumbnail"]).is_file():
            pm = QPixmap(o["thumbnail"])
            if not pm.isNull():
                self.thumb.setPixmap(pm.scaledToHeight(80, Qt.TransformationMode.SmoothTransformation))

    def _save(self) -> None:
        o = self.current()
        if not o:
            return
        changes = {"name": self.f_name.text().strip(), "group": self.f_group.text().strip()}
        if self.f_id.text().strip():
            changes["automation_id"] = self.f_id.text().strip()
        try:
            object_repo.update(o["test"], o["step"], o["tag"], changes)
        except Exception as e:
            QMessageBox.warning(self, "Object Repository", str(e))
            return
        design.bus.notify.emit("ok", f"Saved. The previous version of '{o['test']}' is kept in its history.")
        self.refresh()

    def _forget(self) -> None:
        o = self.current()
        if not o:
            return
        if QMessageBox.question(self, "Forget recorded name",
                                "Remove the recorded name / ids of this object? Position, pictures and neighbours stay, and the "
                                "previous version of the test stays restorable from its history.") != QMessageBox.StandardButton.Yes:
            return
        try:
            object_repo.forget_identity(o["test"], o["step"], o["tag"])
        except Exception as e:
            QMessageBox.warning(self, "Object Repository", str(e))
            return
        self.refresh()

    def _export(self) -> None:
        path, _ = QFileDialog.getSaveFileName(self, "Export objects", "object_repository.json", "JSON (*.json)")
        if path:
            object_repo.export_json(self.shown or self.objs, path)
            design.bus.notify.emit("ok", f"Exported {len(self.shown or self.objs)} object(s).")

    def _import(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "Import objects", "", "JSON (*.json)")
        if not path:
            return
        try:
            res = object_repo.import_json(path)
        except Exception as e:
            QMessageBox.warning(self, "Import", str(e))
            return
        design.bus.notify.emit("ok", f"Imported: {res.get('applied', 0)} applied, {res.get('skipped', 0)} skipped.")
        self.refresh()

    def _advice(self) -> None:
        fx = ai_assistant.locator_fixes(self.objs)
        text = "\n".join(f"• {f['test']} step {f['step']} - {f['object']} ({f['reliability']} %): {f['fix']}" for f in fx[:30]) \
            or "No object is below the reliability threshold."
        QMessageBox.information(self, "Weak locators", text)
