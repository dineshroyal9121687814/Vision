"""Data Manager: open CSV / XLSX / JSON, see it, map its columns to a test's ${variables}, validate rows, bulk-edit, export."""
from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QAbstractItemView, QComboBox, QFileDialog, QHBoxLayout, QLabel, QLineEdit, QListWidget,
                               QMessageBox, QPushButton, QSplitter, QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget)

from app.gui import design
from app.gui.pages.common import heading
from app.gui.workers import Job
from core import datamgr, datasource, testfile


class DataPage(QWidget):
    def __init__(self):
        super().__init__()
        self.setObjectName("page")
        self.path = ""
        self.columns: list[str] = []
        self.rows: list[dict] = []
        self.total = 0
        self.job = None
        lay = QVBoxLayout(self)
        lay.setContentsMargins(28, 24, 28, 24)
        lay.addWidget(heading("Data Manager", "Open a data file, check it against a test, fix values in bulk and export. "
                                              "Your original file is never changed - use Export to save a copy."))
        bar = QHBoxLayout()
        self.open_btn = QPushButton("Open file…")
        self.open_btn.setProperty("kind", "primary")
        self.test_combo = QComboBox()
        self.test_combo.addItem("(no test selected)", "")
        self.export_btn = QPushButton("Export copy…")
        bar.addWidget(self.open_btn)
        bar.addWidget(QLabel("Map to test:"))
        bar.addWidget(self.test_combo, 1)
        bar.addWidget(self.export_btn)
        lay.addLayout(bar)
        self.info = QLabel("No file open.")
        self.info.setObjectName("muted")
        self.info.setWordWrap(True)
        lay.addWidget(self.info)

        split = QSplitter(Qt.Orientation.Vertical)
        self.table = QTableWidget()
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.DoubleClicked)
        split.addWidget(self.table)
        tools = QWidget()
        tl = QHBoxLayout(tools)
        tl.setContentsMargins(0, 8, 0, 0)
        v1 = QVBoxLayout()
        v1.addWidget(QLabel("Validate (comma-separated column names)"))
        self.req, self.num, self.uniq = QLineEdit(), QLineEdit(), QLineEdit()
        self.req.setPlaceholderText("required columns")
        self.num.setPlaceholderText("numeric columns")
        self.uniq.setPlaceholderText("unique columns")
        for w in (self.req, self.num, self.uniq):
            v1.addWidget(w)
        self.check_btn = QPushButton("Validate")
        v1.addWidget(self.check_btn)
        tl.addLayout(v1, 1)
        v2 = QVBoxLayout()
        v2.addWidget(QLabel("Bulk edit"))
        self.b_col = QComboBox()
        self.b_find, self.b_rep = QLineEdit(), QLineEdit()
        self.b_find.setPlaceholderText("find")
        self.b_rep.setPlaceholderText("replace with")
        for w in (self.b_col, self.b_find, self.b_rep):
            v2.addWidget(w)
        self.bulk_btn = QPushButton("Replace in column")
        v2.addWidget(self.bulk_btn)
        tl.addLayout(v2, 1)
        v3 = QVBoxLayout()
        v3.addWidget(QLabel("Mapping and problems"))
        self.report = QListWidget()
        v3.addWidget(self.report, 1)
        tl.addLayout(v3, 2)
        split.addWidget(tools)
        split.setStretchFactor(0, 3)
        lay.addWidget(split, 1)

        self.open_btn.clicked.connect(self.choose)
        self.export_btn.clicked.connect(self.export)
        self.check_btn.clicked.connect(self.validate)
        self.bulk_btn.clicked.connect(self.bulk)
        self.test_combo.currentIndexChanged.connect(self.validate)
        self.table.itemChanged.connect(self._edited)
        self._loading = False

    def refresh(self) -> None:
        cur = self.test_combo.currentData()
        self.test_combo.blockSignals(True)
        self.test_combo.clear()
        self.test_combo.addItem("(no test selected)", "")
        for t in testfile.list_tests():
            self.test_combo.addItem(t["name"], t["name"])
        self.test_combo.setCurrentIndex(max(0, self.test_combo.findData(cur)))
        self.test_combo.blockSignals(False)

    def choose(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "Open data file", "", "Data (*.csv *.xlsx *.xlsm *.json)")
        if path:
            self.load(path)

    def load(self, path: str) -> None:
        self.path = path
        self.info.setText("Reading…")
        self.job = Job(datasource.load_file, path)
        self.job.done.connect(self._loaded)
        self.job.failed.connect(lambda m: (self.info.setText(m), QMessageBox.warning(self, "Data", m)))
        self.job.start()

    def _loaded(self, res) -> None:
        self.columns, rows = res
        self.total = len(rows)
        self.rows = rows[:datamgr.LIMIT_PREVIEW * 50]                 # the editable working copy (large files: first 10 000 rows)
        trunc = f" Showing and editing the first {len(self.rows)}." if len(self.rows) < self.total else ""
        self.info.setText(f"{self.path}: {self.total} row(s), {len(self.columns)} column(s).{trunc}")
        self._loading = True
        self.table.setColumnCount(len(self.columns))
        self.table.setHorizontalHeaderLabels(self.columns)
        shown = self.rows[:500]
        self.table.setRowCount(len(shown))
        for r, row in enumerate(shown):
            for c, col in enumerate(self.columns):
                self.table.setItem(r, c, QTableWidgetItem(str(row.get(col, ""))))
        self._loading = False
        self.b_col.clear()
        self.b_col.addItems(self.columns)
        self.validate()

    def _edited(self, item) -> None:
        if not self._loading and item.row() < len(self.rows):
            self.rows[item.row()][self.columns[item.column()]] = item.text()

    def validate(self) -> None:
        self.report.clear()
        if not self.columns:
            return
        split = lambda w: [x.strip() for x in w.text().split(",") if x.strip()]  # noqa: E731
        tname = self.test_combo.currentData()
        if tname:
            try:
                m = datamgr.mapping(testfile.load_test(tname)[0], self.columns)
                for v, c in m["mapped"].items():
                    self.report.addItem(f"✓ ${{{v}}}  ←  column '{c}'")
                for v in m["missing"]:
                    self.report.addItem(f"✗ ${{{v}}} has no matching column")
                if m["unused_columns"]:
                    self.report.addItem("• Unused columns: " + ", ".join(m["unused_columns"]))
            except Exception as e:
                self.report.addItem(f"Could not read the test: {e}")
        probs = datamgr.check(self.columns, self.rows, split(self.req), split(self.num), split(self.uniq))
        for p in probs[:200]:
            self.report.addItem(f"✗ row {p['row']} · {p['column']}: {p['problem']}")
        if not probs and (self.req.text() or self.num.text() or self.uniq.text()):
            self.report.addItem("✓ No problems found.")

    def bulk(self) -> None:
        if not self.columns or not self.b_find.text():
            return
        n = datamgr.bulk_edit(self.rows, self.b_col.currentText(), self.b_find.text(), self.b_rep.text())
        self._loaded((self.columns, self.rows))
        design.bus.notify.emit("ok", f"{n} cell(s) changed in memory. Export to save a copy.")

    def export(self) -> None:
        if not self.columns:
            return
        path, _ = QFileDialog.getSaveFileName(self, "Export copy", "data_copy.csv", "CSV (*.csv);;Excel (*.xlsx);;JSON (*.json)")
        if not path:
            return
        if path == self.path:
            QMessageBox.warning(self, "Export", "Choose a different file name; the original is never overwritten.")
            return
        try:
            datamgr.export(self.columns, self.rows, path)
            design.bus.notify.emit("ok", f"Exported {len(self.rows)} row(s).")
        except Exception as e:
            QMessageBox.warning(self, "Export", str(e))
