"""
Application Manager UI for VisionAuto.

Allows registering, managing, inspecting, and launching desktop applications,
web browsers, and running processes for multi-application testing.
"""
from __future__ import annotations

import subprocess
from copy import deepcopy
from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QAbstractItemView, QCheckBox, QComboBox, QDialog, QFileDialog, QFormLayout,
    QHBoxLayout, QHeaderView, QLabel, QLineEdit, QMessageBox, QPushButton,
    QTabWidget, QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget
)

from app.gui.pages.common import heading
from core import applications
from core.system import winenv


class AppFormDialog(QDialog):
    """Dialog to create or edit an application configuration."""

    def __init__(self, app_def: dict | None = None, parent=None):
        super().__init__(parent)
        self.result_def: dict | None = None
        self.original = deepcopy(app_def) if app_def else None
        self.setWindowTitle("Edit Application" if app_def else "Add Application")
        self.resize(550, 420)

        form = QFormLayout(self)

        self.name_edit = QLineEdit()
        self.alias_edit = QLineEdit()
        self.alias_edit.setPlaceholderText("e.g. browser, calc, crm (no spaces)")

        self.type_combo = QComboBox()
        self.type_combo.addItems(["desktop", "web", "running"])
        self.type_combo.currentIndexChanged.connect(self._on_type_changed)

        # Desktop fields
        self.exe_edit = QLineEdit()
        exe_row = QWidget()
        exe_lay = QHBoxLayout(exe_row)
        exe_lay.setContentsMargins(0, 0, 0, 0)
        exe_lay.addWidget(self.exe_edit, 1)
        browse_exe = QPushButton("Browse…")
        browse_exe.clicked.connect(self._browse_exe)
        exe_lay.addWidget(browse_exe)

        self.args_edit = QLineEdit()
        self.workdir_edit = QLineEdit()

        # Web fields
        self.browser_combo = QComboBox()
        self.browser_combo.addItems(["chrome", "msedge", "firefox", "brave", "opera", "vivaldi"])
        self.url_edit = QLineEdit()
        self.url_edit.setPlaceholderText("https://...")

        # Shared fields
        self.title_edit = QLineEdit()
        self.title_edit.setPlaceholderText("Window title substring or pattern")
        self.proc_edit = QLineEdit()
        self.proc_edit.setPlaceholderText("Process executable name, e.g. calc.exe")

        self.adapter_combo = QComboBox()
        self.adapter_combo.addItems(["auto", "desktop", "web", "uia"])

        self.timeout_edit = QLineEdit("15.0")
        self.close_check = QCheckBox("Close application on test completion (if launched by test)")
        self.close_check.setChecked(True)

        # Form layout
        form.addRow("Application Name *", self.name_edit)
        form.addRow("Alias (used in steps) *", self.alias_edit)
        form.addRow("Application Type", self.type_combo)

        self.exe_label = QLabel("Executable Path *")
        form.addRow(self.exe_label, exe_row)
        self.args_label = QLabel("Arguments")
        form.addRow(self.args_label, self.args_edit)
        self.workdir_label = QLabel("Working Directory")
        form.addRow(self.workdir_label, self.workdir_edit)

        self.browser_label = QLabel("Web Browser")
        form.addRow(self.browser_label, self.browser_combo)
        self.url_label = QLabel("Startup / Base URL *")
        form.addRow(self.url_label, self.url_edit)

        form.addRow("Window Title", self.title_edit)
        form.addRow("Process Name", self.proc_edit)
        form.addRow("Adapter", self.adapter_combo)
        form.addRow("Readiness Timeout (s)", self.timeout_edit)
        form.addRow(self.close_check)

        # Buttons
        buttons = QHBoxLayout()
        cancel_btn = QPushButton("Cancel")
        cancel_btn.clicked.connect(self.reject)
        save_btn = QPushButton("Save Application")
        save_btn.setProperty("kind", "primary")
        save_btn.clicked.connect(self._save)
        buttons.addStretch(1)
        buttons.addWidget(cancel_btn)
        buttons.addWidget(save_btn)
        form.addRow(buttons)

        if app_def:
            self._load(app_def)
        else:
            self._on_type_changed()

    def _browse_exe(self):
        path, _ = QFileDialog.getOpenFileName(self, "Select Executable", "", "Executables (*.exe *.bat *.cmd);;All Files (*)")
        if path:
            self.exe_edit.setText(path)
            if not self.name_edit.text():
                self.name_edit.setText(Path(path).stem.title())
            if not self.alias_edit.text():
                self.alias_edit.setText(Path(path).stem.lower().replace(" ", "_"))

    def _on_type_changed(self):
        t = self.type_combo.currentText()
        is_desktop = (t == "desktop")
        is_web = (t == "web")

        self.exe_label.setVisible(is_desktop)
        self.exe_edit.parentWidget().setVisible(is_desktop)
        self.args_label.setVisible(is_desktop)
        self.args_edit.setVisible(is_desktop)
        self.workdir_label.setVisible(is_desktop)
        self.workdir_edit.setVisible(is_desktop)

        self.browser_label.setVisible(is_web)
        self.browser_combo.setVisible(is_web)
        self.url_label.setVisible(is_web)
        self.url_edit.setVisible(is_web)

        if is_web:
            self.adapter_combo.setCurrentText("web")
        elif is_desktop:
            self.adapter_combo.setCurrentText("desktop")

    def _load(self, d: dict):
        self.name_edit.setText(d.get("name", ""))
        self.alias_edit.setText(d.get("alias", ""))
        self.type_combo.setCurrentText(d.get("type", "desktop"))
        self.exe_edit.setText(d.get("exe_path", ""))
        args = d.get("args", [])
        self.args_edit.setText(" ".join(args) if isinstance(args, list) else str(args))
        self.workdir_edit.setText(d.get("working_dir", ""))
        self.browser_combo.setCurrentText(d.get("browser", "chrome"))
        self.url_edit.setText(d.get("url") or d.get("base_url") or "")
        self.title_edit.setText(d.get("window_title", ""))
        self.proc_edit.setText(d.get("process_name", ""))
        self.adapter_combo.setCurrentText(d.get("adapter", "auto"))
        self.timeout_edit.setText(str(d.get("timeout_s", 15.0)))
        self.close_check.setChecked(bool(d.get("close_on_exit", True)))
        self._on_type_changed()

    def _save(self):
        app_type = self.type_combo.currentText()
        name = self.name_edit.text().strip()
        alias = self.alias_edit.text().strip()

        data = deepcopy(self.original) if self.original else {}
        data.update({
            "name": name,
            "alias": alias,
            "type": app_type,
            "adapter": self.adapter_combo.currentText(),
            "window_title": self.title_edit.text().strip(),
            "process_name": self.proc_edit.text().strip(),
            "close_on_exit": self.close_check.isChecked(),
        })

        try:
            data["timeout_s"] = float(self.timeout_edit.text().strip() or 15.0)
        except ValueError:
            QMessageBox.warning(self, "Invalid Timeout", "Timeout must be a valid number of seconds.")
            return

        if app_type == "desktop":
            data["exe_path"] = self.exe_edit.text().strip()
            args_str = self.args_edit.text().strip()
            data["args"] = args_str.split() if args_str else []
            data["working_dir"] = self.workdir_edit.text().strip()
        elif app_type == "web":
            data["browser"] = self.browser_combo.currentText()
            data["url"] = self.url_edit.text().strip()

        errors = applications.validate_app_def(data)
        if errors:
            QMessageBox.warning(self, "Validation Error", "\n".join(errors))
            return

        self.result_def = data
        self.accept()


class HierarchyInspectorDialog(QDialog):
    """Dialog displaying the UI Automation control tree of a selected window."""

    def __init__(self, hwnd: int, title: str, parent=None):
        super().__init__(parent)
        self.setWindowTitle(f"Control Hierarchy — {title} (HWND: {hwnd})")
        self.resize(800, 500)

        lay = QVBoxLayout(self)
        info = QLabel(f"Inspecting controls for: <b>{title}</b>")
        lay.addWidget(info)

        self.table = QTableWidget(0, 4)
        self.table.setHorizontalHeaderLabels(["Name / Text", "Control Role", "Automation ID", "Bounds [L, T, R, B]"])
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        lay.addWidget(self.table, 1)

        close_btn = QPushButton("Close")
        close_btn.clicked.connect(self.accept)
        btn_box = QHBoxLayout()
        btn_box.addStretch(1)
        btn_box.addWidget(close_btn)
        lay.addLayout(btn_box)

        # Populate hierarchy
        data = applications.inspect_window_hierarchy(hwnd)
        controls = data.get("controls", [])
        self.table.setRowCount(len(controls))
        for row, c in enumerate(controls):
            self.table.setItem(row, 0, QTableWidgetItem(str(c.get("name", ""))))
            self.table.setItem(row, 1, QTableWidgetItem(str(c.get("role", ""))))
            self.table.setItem(row, 2, QTableWidgetItem(str(c.get("automation_id", ""))))
            self.table.setItem(row, 3, QTableWidgetItem(str(c.get("rect", ""))))


class ApplicationsPage(QWidget):
    """Main page for managing applications."""

    def __init__(self):
        super().__init__()
        self.setObjectName("page")
        self.apps: list[dict] = []
        self.discovered: list[dict] = []

        root = QVBoxLayout(self)
        root.setContentsMargins(28, 24, 28, 24)
        root.addWidget(heading("Application Manager",
                               "Configure, launch, inspect, and automate multiple desktop and web applications within unified test cases."))

        # Action bar
        bar = QHBoxLayout()
        self.add_btn = QPushButton("+ Add Application")
        self.add_btn.setProperty("kind", "primary")
        self.add_btn.clicked.connect(self.add_application)

        self.edit_btn = QPushButton("Edit")
        self.edit_btn.clicked.connect(self.edit_selected)

        self.del_btn = QPushButton("Delete")
        self.del_btn.clicked.connect(self.delete_selected)

        self.launch_btn = QPushButton("▶ Launch selected")
        self.launch_btn.setProperty("kind", "success")
        self.launch_btn.setToolTip("Launch every selected application (Ctrl/Shift-click to select several)")
        self.launch_btn.clicked.connect(self.launch_selected)

        self.refresh_btn = QPushButton("Refresh")
        self.refresh_btn.clicked.connect(self.refresh)

        self.kill_btn = QPushButton("Stop Ranorex / UFT…")
        self.kill_btn.setToolTip("Find and stop stuck Ranorex and UFT processes (asks first)")
        self.kill_btn.clicked.connect(self.stop_ranorex_uft)

        for b in (self.add_btn, self.edit_btn, self.del_btn, self.launch_btn, self.kill_btn):
            bar.addWidget(b)
        bar.addStretch(1)
        bar.addWidget(self.refresh_btn)
        root.addLayout(bar)

        # Tabs: Registered Applications vs Inspect Running
        self.tabs = QTabWidget()

        # Tab 1: Registered Applications
        reg_widget = QWidget()
        reg_lay = QVBoxLayout(reg_widget)
        reg_lay.setContentsMargins(0, 8, 0, 0)
        self.reg_table = QTableWidget(0, 6)
        self.reg_table.setHorizontalHeaderLabels(["Name", "Alias", "Type", "Target (Path / URL)", "Window Title", "Adapter"])
        self.reg_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        self.reg_table.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeMode.Stretch)
        self.reg_table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.reg_table.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.reg_table.doubleClicked.connect(self.edit_selected)
        reg_lay.addWidget(self.reg_table)
        self.tabs.addTab(reg_widget, "Registered Applications")

        # Tab 2: Discovered Running Applications
        disc_widget = QWidget()
        disc_lay = QVBoxLayout(disc_widget)
        disc_lay.setContentsMargins(0, 8, 0, 0)

        disc_bar = QHBoxLayout()
        self.add_disc_btn = QPushButton("Add to Registry")
        self.add_disc_btn.clicked.connect(self.add_discovered_to_registry)
        self.inspect_btn = QPushButton("Inspect Window Controls")
        self.inspect_btn.clicked.connect(self.inspect_discovered)
        self.disc_refresh_btn = QPushButton("Refresh Processes")
        self.disc_refresh_btn.clicked.connect(self.refresh_discovered)
        disc_bar.addWidget(self.add_disc_btn)
        disc_bar.addWidget(self.inspect_btn)
        disc_bar.addStretch(1)
        disc_bar.addWidget(self.disc_refresh_btn)
        disc_lay.addLayout(disc_bar)

        self.disc_table = QTableWidget(0, 5)
        self.disc_table.setHorizontalHeaderLabels(["Window Title", "Process Name", "PID", "HWND", "Type"])
        self.disc_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        self.disc_table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.disc_table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        disc_lay.addWidget(self.disc_table)
        self.tabs.addTab(disc_widget, "Inspect Running Applications")

        root.addWidget(self.tabs, 1)

        self.refresh()

    def refresh(self):
        self.apps = applications.list_apps()
        self.reg_table.setRowCount(len(self.apps))
        for row, a in enumerate(self.apps):
            target = a.get("exe_path") or a.get("url") or a.get("process_name") or ""
            self.reg_table.setItem(row, 0, QTableWidgetItem(str(a.get("name", ""))))
            self.reg_table.setItem(row, 1, QTableWidgetItem(str(a.get("alias", ""))))
            self.reg_table.setItem(row, 2, QTableWidgetItem(str(a.get("type", ""))))
            self.reg_table.setItem(row, 3, QTableWidgetItem(str(target)))
            self.reg_table.setItem(row, 4, QTableWidgetItem(str(a.get("window_title", ""))))
            self.reg_table.setItem(row, 5, QTableWidgetItem(str(a.get("adapter", ""))))

        self.refresh_discovered()

    def refresh_discovered(self):
        self.discovered = applications.discover_running_apps()
        self.disc_table.setRowCount(len(self.discovered))
        for row, d in enumerate(self.discovered):
            self.disc_table.setItem(row, 0, QTableWidgetItem(str(d.get("title", ""))))
            self.disc_table.setItem(row, 1, QTableWidgetItem(str(d.get("process", ""))))
            self.disc_table.setItem(row, 2, QTableWidgetItem(str(d.get("pid", ""))))
            self.disc_table.setItem(row, 3, QTableWidgetItem(str(d.get("hwnd", ""))))
            self.disc_table.setItem(row, 4, QTableWidgetItem(str(d.get("type", ""))))

    def selected_app(self) -> dict | None:
        idx = self.reg_table.currentRow()
        if 0 <= idx < len(self.apps):
            return self.apps[idx]
        return None

    def selected_discovered(self) -> dict | None:
        idx = self.disc_table.currentRow()
        if 0 <= idx < len(self.discovered):
            return self.discovered[idx]
        return None

    def add_application(self):
        dlg = AppFormDialog(parent=self)
        if dlg.exec() and dlg.result_def:
            try:
                applications.register_app(dlg.result_def)
                self.refresh()
            except Exception as e:
                QMessageBox.warning(self, "Error", f"Failed to register application: {e}")

    def edit_selected(self):
        app = self.selected_app()
        if not app:
            QMessageBox.information(self, "Edit Application", "Select an application to edit.")
            return
        dlg = AppFormDialog(app, parent=self)
        if dlg.exec() and dlg.result_def:
            try:
                applications.register_app(dlg.result_def)
                self.refresh()
            except Exception as e:
                QMessageBox.warning(self, "Error", f"Failed to update application: {e}")

    def delete_selected(self):
        apps = self.selected_apps()
        if not apps:
            QMessageBox.information(self, "Delete Application", "Select an application to delete.")
            return
        names = ", ".join(str(a.get("name")) for a in apps[:5])
        if QMessageBox.question(self, "Confirm Delete", f"Delete {len(apps)} application(s): {names}?") == QMessageBox.StandardButton.Yes:
            for a in apps:
                applications.remove_app(a["id"])
            self.refresh()

    def stop_ranorex_uft(self):
        """List Ranorex / UFT processes, ask, then stop only the ones listed."""
        from core.tools import process_killer

        try:
            found = process_killer.find_processes()
        except Exception as e:  # noqa: BLE001
            QMessageBox.warning(self, "Stop Ranorex / UFT", f"Could not list processes: {e}")
            return
        if not found:
            QMessageBox.information(self, "Stop Ranorex / UFT", "No Ranorex or UFT processes are running.")
            return
        listing = "\n".join(f"{process_killer.PRODUCTS.get(f.product, f.product)}  pid {f.pid}  {f.name}" for f in found)
        if QMessageBox.question(self, "Stop Ranorex / UFT",
                                f"Stop these {len(found)} process(es)? Unsaved work in them will be lost.\n\n{listing}") \
                != QMessageBox.StandardButton.Yes:
            return
        results = process_killer.kill_processes(found)
        QMessageBox.information(self, "Stop Ranorex / UFT",
                                "\n".join(f"pid {r['pid']}  {r['name']}: {r['result']}" for r in results))

    def selected_apps(self) -> list[dict]:
        rows = sorted({i.row() for i in self.reg_table.selectedIndexes()})
        return [self.apps[r] for r in rows if 0 <= r < len(self.apps)]

    def launch_selected(self):
        apps = self.selected_apps()
        if not apps:
            QMessageBox.information(self, "Launch Application", "Select one or more applications to launch.")
            return
        if getattr(self, "launcher", None) is not None and self.launcher.isRunning():
            return
        from app.gui.workers import LaunchWorker

        self._launch_log: list[str] = []
        self.launch_btn.setEnabled(False)
        self.launcher = LaunchWorker(apps)
        self.launcher.one_done.connect(lambda n, ok, m: self._launch_log.append(f"{'✓' if ok else '✗'} {n}: {m}"))
        self.launcher.all_done.connect(self._launch_finished)
        self.launcher.start()

    def _launch_finished(self):
        self.launch_btn.setEnabled(True)
        QMessageBox.information(self, "Launch Application", "\n".join(self._launch_log) or "Nothing was launched.")

    def add_discovered_to_registry(self):
        d = self.selected_discovered()
        if not d:
            QMessageBox.information(self, "Add to Registry", "Select a running application from the list first.")
            return
        initial_def = applications.default_app_def(name=d.get("title", ""), app_type=d.get("type", "desktop"))
        initial_def["window_title"] = d.get("title", "")
        initial_def["process_name"] = d.get("process", "")
        dlg = AppFormDialog(initial_def, parent=self)
        if dlg.exec() and dlg.result_def:
            try:
                applications.register_app(dlg.result_def)
                self.tabs.setCurrentIndex(0)
                self.refresh()
            except Exception as e:
                QMessageBox.warning(self, "Error", f"Failed to register application: {e}")

    def inspect_discovered(self):
        d = self.selected_discovered()
        if not d:
            QMessageBox.information(self, "Inspect Controls", "Select a running application from the list first.")
            return
        hwnd = d.get("hwnd", 0)
        title = d.get("title", "")
        dlg = HierarchyInspectorDialog(hwnd, title, parent=self)
        dlg.exec()

