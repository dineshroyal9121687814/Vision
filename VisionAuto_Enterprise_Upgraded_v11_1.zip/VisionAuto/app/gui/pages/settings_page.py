from __future__ import annotations

from PySide6.QtCore import Signal
from PySide6.QtWidgets import (QCheckBox, QComboBox, QDoubleSpinBox, QFileDialog, QFormLayout, QGroupBox, QHBoxLayout, QLabel,
                               QLineEdit, QPushButton, QScrollArea, QSpinBox, QVBoxLayout, QWidget)

from app.gui.pages.common import heading
from core import paths, settings
from core.ai import embedder
from core.ai.llm import OllamaClient
from app.gui.workers import OllamaPullWorker

LABELS = {
    "timeout_s": "Wait for an element / validation (seconds)",
    "use_native": "Use UI Automation (fastest, most reliable)",
    "use_ocr": "Use text recognition (OCR) as a fallback",
    "use_ai": "Use AI similarity as a fallback",
    "engine_profile": "Click engine: Classic (proven picture-first path) or Strict (extra checks, refusals, retries)",
    "ocr_engine": "Text recognition engine (OCR is only the last resort)",
    "park_pointer": "Move the mouse pointer away before reading text from the screen",
    "ocr_budget_s": "Maximum seconds spent on text recognition per step",
    "record_neighbors": "Recording: capture neighbouring elements and the scroll container",
    "scroll_mode": "Scrolling: adaptive (skip when not needed) or exact",
    "scroll_find": "Scroll to find an element that is out of view",
    "scroll_find_steps": "Maximum scroll steps when searching",
    "scroll_find_budget_s": "Maximum seconds spent scrolling to find an element",
    "ocr_short_mismatch": "Short value only readable by OCR and OCR disagrees: warn (not verified) or fail",
    "ensure_focus": "Before typing, click the recorded field again if it lost the keyboard focus",
    "scroll_notch_ms": "Pause between wheel notches when replaying a scroll (ms)",
    "ensure_state": "Check boxes: reach the recorded state (skip the click if already set)",
    "llm_warmup": "Load the local AI model once before the run (no console flashes mid-test)",
    "record_video": "Save a screen video of each run",
    "video_fps": "Video frames per second",
    "typeahead": "In dropdowns and lists, type the option text before scrolling",
    "settle_wait": "Wait for the screen to settle after each action",
    "fast_entry": "Fast data entry: skip the settle wait between consecutive typing steps",
    "auto_heal_update": "Self-healing: save the new appearance when an element moved or changed",
    "min_recovery_confidence": "Minimum confidence for visual recovery (0 to 1)",
    "continue_on_failure": "Keep going after a failed step",
    "type_interval_ms": "Delay between typed characters (ms)",
    "use_llm": "Use the local AI model (Ollama) for diagnosis, test generation and summaries",
    "llm_model": "Local model name",
    "llm_base_url": "Local Ollama service URL",
    "ocr_labels_after_record": "Read labels from the screen after recording (OCR)",
    "input_backend": "Input backend (auto / pynput / pyautogui)",
    "collect_training_data": "Keep a local record of every recording / run to train automation models",
    "dataset_include_text": "...also store typed text (off = only its length)",
    "dataset_include_images": "...also keep small crops of failed / healed elements",
    "dataset_max_mb": "Training data size limit (MB)",
    "ai_auto_start": "Start the local AI service automatically when needed",
    "retry_enabled": "Diagnose failed steps and retry them",
    "retry_max_attempts": "Maximum retry attempts per failed step",
    "retry_delay_s": "Delay before each retry (seconds)",
    "retry_timeout_s": "How long to wait for your answer to 'retry?' (seconds)",
    "retry_ask_before": "Ask me before retrying",
    "retry_auto": "Retry automatically (when not asking)",
    "retry_mode": "What to retry",
    "retry_timeout_action": "If I do not answer in time",
    "retry_allow_after_input": "Allow retrying steps that already sent input (may repeat a click)",
    "retry_stop_after_failures": "Stop the run after N failed steps in a row (0 = never)",
    "testcases_dir": "Test case folder (empty = workspace/testcases)",
    "theme": "Theme",
    "report_keep_days": "'Delete old reports' default age (days)",
}
CHOICES = {
    "retry_mode": [("Retry the failed step", "retry_step"), ("Restart the whole test case", "restart_test"), ("Stop the run", "stop")],
    "retry_timeout_action": [("Retry", "retry"), ("Give up on the step and continue", "skip"), ("Stop the run", "stop")],
    "theme": [("Dark", "dark"), ("Light", "light")],
    "input_backend": [("Auto", "auto"), ("pynput", "pynput"), ("pyautogui", "pyautogui")],
    "ocr_search": [("Local, then whole screen", "local_then_screen"), ("Local only", "local_only"), ("Whole screen only", "screen_only")],
    "ocr_engine": [("Auto (fastest installed first)", "auto"), ("RapidOCR", "rapidocr"), ("EasyOCR", "easyocr"), ("Tesseract", "tesseract")],
    "engine_profile": [("Classic (recommended: the proven click path)", "classic"), ("Strict (full verification pipeline)", "strict")],
    "native_policy": [("Auto", "auto"), ("Always", "always"), ("Never", "never")],
}
SECTIONS = [
    ("Playback & speed", ["engine_profile", "timeout_s", "use_native", "use_ocr", "ocr_engine", "park_pointer", "ocr_budget_s", "use_ai", "settle_wait", "fast_entry", "type_interval_ms",
                          "continue_on_failure", "auto_heal_update", "input_backend"]),
    ("Scrolling & neighbours", ["record_neighbors", "scroll_mode", "scroll_find", "scroll_find_steps", "scroll_find_budget_s", "typeahead", "ocr_short_mismatch", "ensure_focus", "scroll_notch_ms", "ensure_state", "llm_warmup", "record_video", "video_fps"]),
    ("Failure recovery & retries", ["retry_enabled", "retry_mode", "retry_max_attempts", "retry_delay_s", "retry_ask_before",
                                    "retry_timeout_s", "retry_timeout_action", "retry_auto", "retry_allow_after_input",
                                    "retry_stop_after_failures"]),
    ("Storage & appearance", ["testcases_dir", "theme", "report_keep_days"]),
    ("Local AI", ["use_llm", "llm_model", "llm_base_url", "ai_auto_start", "ocr_labels_after_record"]),
]


class SettingsPage(QWidget):
    theme_changed = Signal(str)

    def __init__(self):
        super().__init__()
        self.setObjectName("page")
        outer = QVBoxLayout(self)
        outer.setContentsMargins(28, 24, 28, 24)
        outer.addWidget(heading("Settings", f"Workspace: {paths.workspace()}"))
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        inner = QWidget()
        lay = QVBoxLayout(inner)
        scroll.setWidget(inner)
        outer.addWidget(scroll, 1)
        self.w: dict = {}
        self.model_worker = None
        options = settings.load()
        placed = {k for _, keys in SECTIONS for k in keys}
        sections = SECTIONS + [("Advanced", [k for k in settings.DEFAULTS if k not in placed])]
        for title, keys in sections:
            box = QGroupBox(title)
            form = QFormLayout(box)
            for key in keys:
                w = self._make_widget(key, settings.DEFAULTS[key], options[key])
                self.w[key] = w
                if key == "testcases_dir":
                    row = QHBoxLayout()
                    row.addWidget(w, 1)
                    browse = QPushButton("Browse…")
                    browse.clicked.connect(self._browse_testcases)
                    row.addWidget(browse)
                    form.addRow(LABELS.get(key, key), row)
                else:
                    form.addRow(LABELS.get(key, key), w)
            lay.addWidget(box)
            if title == "Local AI":
                self.pull_model = QPushButton("Download / load selected Ollama model")
                self.pull_model.setToolTip("Downloads the model through your local Ollama service.")
                self.pull_model.clicked.connect(self.download_model)
                self.setup_ai = QPushButton("Set up local AI automatically (install Ollama + model)")
                self.setup_ai.setToolTip("Downloads the official Ollama installer, checks its digital signature, installs it for this "
                                         "user, starts it and downloads the model. Asks for your confirmation first.")
                self.setup_ai.clicked.connect(self.auto_setup)
                form.addRow("Local AI model", self.pull_model)
                form.addRow("One click", self.setup_ai)
        self.env = QLabel(self._env_text())
        self.env.setObjectName("muted")
        self.env.setWordWrap(True)
        lay.addWidget(self.env)
        lay.addStretch(1)
        save = QPushButton("Save settings")
        save.setProperty("kind", "primary")
        save.clicked.connect(self.save)
        outer.addWidget(save)

    @staticmethod
    def _make_widget(key: str, default, value):
        if key in CHOICES:
            w = QComboBox()
            for label, data in CHOICES[key]:
                w.addItem(label, data)
            idx = w.findData(value)
            w.setCurrentIndex(max(idx, 0))
            return w
        if isinstance(default, bool):
            w = QCheckBox()
            w.setChecked(bool(value))
        elif isinstance(default, float):
            w = QDoubleSpinBox()
            if key == "min_recovery_confidence":
                w.setRange(0.0, 1.0)
                w.setSingleStep(0.05)
                w.setDecimals(2)
            elif key == "retry_delay_s":
                w.setRange(0.0, 300.0)
            elif key == "retry_timeout_s":
                w.setRange(1.0, 3600.0)
            else:
                w.setRange(0.5, 120)
            w.setValue(float(value))
        elif isinstance(default, int):
            w = QSpinBox()
            lo, hi = settings.INT_LIMITS.get(key, (0, 1000))
            w.setRange(lo, hi)
            w.setValue(int(value))
        else:
            w = QLineEdit(str(value))
        return w

    def _browse_testcases(self) -> None:
        d = QFileDialog.getExistingDirectory(self, "Test case folder", self.w["testcases_dir"].text() or str(paths.testcases_dir()))
        if d:
            self.w["testcases_dir"].setText(d)

    def _env_text(self) -> str:
        try:
            from core.ocr import ocr_engine

            ocr = ("available: " + ", ".join(ocr_engine.engines())) if ocr_engine.available() else "not installed (pip install rapidocr-onnxruntime)"
        except Exception:
            ocr = "not installed (pip install rapidocr-onnxruntime)"
        opts = settings.load()
        try:
            llm = "running" if OllamaClient(opts["llm_model"], base_url=opts["llm_base_url"]).available() else "not running (optional)"
        except ValueError as exc:
            llm = f"invalid configuration ({exc})"
        try:
            from core import dataset
            d = dataset.stats()
            data = f"\nTraining data: {d['recordings']} recordings, {d['steps']} steps, {d['size_mb']} MB at {d['path']}"
        except Exception:
            data = ""
        return f"OCR: {ocr}\nAI matching backend: {embedder.backend_name()}\nLocal language model (Ollama): {llm}{data}"

    def save(self) -> None:
        data = {}
        for key, w in self.w.items():
            if isinstance(w, QComboBox):
                data[key] = w.currentData()
            elif isinstance(w, QCheckBox):
                data[key] = w.isChecked()
            elif isinstance(w, QLineEdit):
                data[key] = w.text().strip() if key == "testcases_dir" else w.text()
            else:
                data[key] = w.value()
        try:
            OllamaClient(data["llm_model"], base_url=data["llm_base_url"])
        except ValueError as exc:
            self.env.setText(f"Settings not saved: {exc}")
            return
        from core import testcases

        old = settings.load()
        note = ""
        try:
            if data["testcases_dir"] != old.get("testcases_dir", ""):
                if data["testcases_dir"]:
                    out = testcases.change_root(data["testcases_dir"], migrate=True)      # validates, copies, never deletes
                    note = f"\nTest cases now stored in {out['root']} (copied {out['copied']} file(s); old folder left in place)."
                    data["testcases_dir"] = out["root"]
                    old = settings.load()
            settings.save({**data})
        except testcases.CaseError as exc:
            self.env.setText(f"Settings not saved: {exc}")
            return
        except ValueError as exc:
            self.env.setText(f"Settings not saved: {exc}")
            return
        except OSError as exc:
            self.env.setText(f"Settings could not be written: {exc}")
            return
        if data["theme"] != old.get("theme"):
            self.theme_changed.emit(data["theme"])
        self.env.setText(self._env_text() + note + "\n\nSaved.")

    def download_model(self) -> None:
        if self.model_worker and self.model_worker.isRunning():
            return
        model = self.w["llm_model"].text().strip()
        base_url = self.w["llm_base_url"].text().strip()
        if not model:
            self.env.setText("Enter an Ollama model name first (for example qwen2.5-coder:1.5b).")
            return
        try:
            OllamaClient(model, base_url=base_url)
        except ValueError as exc:
            self.env.setText(str(exc))
            return
        self.pull_model.setEnabled(False)
        self.env.setText(f"Connecting to Ollama and downloading {model}…")
        self.model_worker = OllamaPullWorker(base_url, model)
        self.model_worker.progress.connect(self.env.setText)
        self.model_worker.done.connect(self._model_ready)
        self.model_worker.failed.connect(self._model_failed)
        self.model_worker.start()

    def auto_setup(self, confirmed: bool = False) -> None:
        if self.model_worker and self.model_worker.isRunning():
            return
        from PySide6.QtWidgets import QMessageBox
        model = self.w["llm_model"].text().strip()
        base_url = self.w["llm_base_url"].text().strip()
        from core.ai import ollama_manager
        st = ollama_manager.status(base_url, model)
        allow = False
        if not st["installed"] and not st["running"]:
            ok = QMessageBox.StandardButton.Yes if confirmed is True else QMessageBox.question(
                self, "Install local AI?",
                "VisionAuto will download the official Ollama installer from ollama.com (about 1 GB), verify its digital "
                "signature, install it for your user account, then download the model (about 1 GB). Continue?")
            if ok != QMessageBox.StandardButton.Yes:
                return
            allow = True
        self.setup_ai.setEnabled(False)
        from app.gui.workers import AiSetupWorker
        self.model_worker = AiSetupWorker(base_url, model, allow)
        self.model_worker.progress.connect(self.env.setText)
        self.model_worker.done.connect(self._ai_ready)
        self.model_worker.failed.connect(self._ai_failed)
        self.model_worker.start()

    def _ai_ready(self, model: str) -> None:
        self.setup_ai.setEnabled(True)
        self.w["use_llm"].setChecked(True)
        self.env.setText(f"Local AI is ready ({model}). 'Use the local AI model' is now ticked - press Save settings.\n" + self._env_text())

    def _ai_failed(self, message: str) -> None:
        self.setup_ai.setEnabled(True)
        self.env.setText(f"Local AI setup failed: {message}")

    def _model_ready(self, model: str) -> None:
        self.pull_model.setEnabled(True)
        self.env.setText(f"{model} downloaded. Save settings to select it; Ollama loads it when AI features use it.\n" + self._env_text())

    def _model_failed(self, message: str) -> None:
        self.pull_model.setEnabled(True)
        self.env.setText(f"Model download failed: {message}\nStart Ollama, then try again.")
