"""Execution Center: run one or several tests with Start / Pause / Resume / Stop / Cancel, live step results, progress and
the same 'step failed - retry?' question the Tests page uses. Queue = the ticked tests, run one after the other."""
from __future__ import annotations

import time
from pathlib import Path

from PySide6.QtCore import QTimer, Qt
from PySide6.QtGui import QColor
from PySide6.QtWidgets import (QHBoxLayout, QLabel, QListWidget, QListWidgetItem, QMessageBox, QPlainTextEdit, QProgressBar,
                               QPushButton, QSplitter, QVBoxLayout, QWidget)

from app.gui import design
from app.gui.pages.common import fmt_duration, heading, open_path, status_icon
from app.gui.retry_dialog import RetryDialog
from app.gui.theme import status_color
from app.gui.workers import PlayWorker
from core import testfile


class ExecutionPage(QWidget):
    def __init__(self):
        super().__init__()
        self.setObjectName("page")
        self.worker: PlayWorker | None = None
        self.queue: list[dict] = []
        self.current: dict | None = None
        self.results: list[dict] = []                  # finished run dicts of this session's queue
        self.last_run: dict | None = None
        self._t0 = 0.0
        self._total_steps = 0
        self._done_steps = 0
        self._stop_queue = False

        lay = QVBoxLayout(self)
        lay.setContentsMargins(28, 24, 28, 24)
        lay.addWidget(heading("Execution Center", "Tick the tests to run. Pause and Resume act between steps; Stop finishes the current "
                                                  "step and keeps the report; Cancel ends the run at once."))
        bar = QHBoxLayout()
        self.run_btn = QPushButton("▶  Start")
        self.run_btn.setProperty("kind", "success")
        self.dry_btn = QPushButton("Dry run")
        self.pause_btn = QPushButton("⏸  Pause")
        self.stop_btn = QPushButton("■  Stop")
        self.stop_btn.setProperty("kind", "warning")
        self.cancel_btn = QPushButton("⊘  Cancel")
        self.cancel_btn.setProperty("kind", "danger")
        self.rep_btn = QPushButton("Open last report")
        for b in (self.run_btn, self.dry_btn, self.pause_btn, self.stop_btn, self.cancel_btn):
            bar.addWidget(b)
        bar.addStretch(1)
        bar.addWidget(self.rep_btn)
        lay.addLayout(bar)

        self.progress = QProgressBar()
        self.progress.setTextVisible(True)
        lay.addWidget(self.progress)
        self.summary = QLabel("Idle.")
        self.summary.setObjectName("muted")
        self.summary.setWordWrap(True)
        lay.addWidget(self.summary)

        split = QSplitter(Qt.Orientation.Horizontal)
        left = QWidget()
        ll = QVBoxLayout(left)
        ll.setContentsMargins(0, 0, 8, 0)
        ll.addWidget(QLabel("Tests (tick to queue)"))
        self.tests = QListWidget()
        ll.addWidget(self.tests, 1)
        row = QHBoxLayout()
        self.all_btn = QPushButton("Tick all")
        self.none_btn = QPushButton("Clear")
        row.addWidget(self.all_btn)
        row.addWidget(self.none_btn)
        ll.addLayout(row)
        split.addWidget(left)
        right = QWidget()
        rl = QVBoxLayout(right)
        rl.setContentsMargins(8, 0, 0, 0)
        rl.addWidget(QLabel("Live steps"))
        self.steps = QListWidget()
        rl.addWidget(self.steps, 3)
        rl.addWidget(QLabel("Detail of the selected step"))
        self.detail = QPlainTextEdit()
        self.detail.setObjectName("console")
        self.detail.setReadOnly(True)
        rl.addWidget(self.detail, 1)
        split.addWidget(right)
        split.setStretchFactor(0, 1)
        split.setStretchFactor(1, 3)
        lay.addWidget(split, 1)

        self.run_btn.clicked.connect(lambda: self.start(False))
        self.dry_btn.clicked.connect(lambda: self.start(True))
        self.pause_btn.clicked.connect(self._pause_resume)
        self.stop_btn.clicked.connect(self._stop)
        self.cancel_btn.clicked.connect(self._cancel)
        self.rep_btn.clicked.connect(self.open_report)
        self.all_btn.clicked.connect(lambda: self._tick(True))
        self.none_btn.clicked.connect(lambda: self._tick(False))
        self.steps.currentRowChanged.connect(self._show_detail)
        self.clock = QTimer(self)
        self.clock.timeout.connect(self._tick_clock)
        self._idle_ui()
        self._items: list[dict] = []

    # ------------------------------------------------------------------ list
    def refresh(self) -> None:
        if self.worker and self.worker.isRunning():
            return
        ticked = {self._items[i]["name"] for i in range(self.tests.count()) if self.tests.item(i).checkState() == Qt.CheckState.Checked}
        self._items = testfile.list_runnable()
        self.tests.clear()
        for it in self._items:
            li = QListWidgetItem(f"{it['name']}" + ("   (script)" if it.get("kind") != "native" else ""))
            li.setFlags(li.flags() | Qt.ItemFlag.ItemIsUserCheckable)
            li.setCheckState(Qt.CheckState.Checked if it["name"] in ticked else Qt.CheckState.Unchecked)
            self.tests.addItem(li)
        if not self._items:
            self.summary.setText("No tests yet. Record one first.")

    def select(self, name: str) -> None:
        """Called by other pages ('run this test in the Execution Center')."""
        self.refresh()
        for i, it in enumerate(self._items):
            self.tests.item(i).setCheckState(Qt.CheckState.Checked if it["name"] == name else Qt.CheckState.Unchecked)

    def _tick(self, on: bool) -> None:
        for i in range(self.tests.count()):
            self.tests.item(i).setCheckState(Qt.CheckState.Checked if on else Qt.CheckState.Unchecked)

    def ticked(self) -> list[dict]:
        return [self._items[i] for i in range(self.tests.count()) if self.tests.item(i).checkState() == Qt.CheckState.Checked]

    # ------------------------------------------------------------------ run
    def start(self, dry: bool) -> None:
        if self.worker and self.worker.isRunning():
            return
        q = self.ticked()
        if not q:
            QMessageBox.information(self, "Execution Center", "Tick at least one test.")
            return
        self.queue, self.results, self._stop_queue, self.dry = list(q), [], False, dry
        self.steps.clear()
        self.detail.clear()
        self.run_btn.setEnabled(False)
        self.dry_btn.setEnabled(False)
        self.pause_btn.setEnabled(True)
        self.stop_btn.setEnabled(True)
        self.cancel_btn.setEnabled(True)
        self.queue_total = len(q)
        self._next()

    def _next(self) -> None:
        if not self.queue or self._stop_queue:
            self._finish_all()
            return
        self.current = self.queue.pop(0)
        n = self.queue_total - len(self.queue)
        self._total_steps = self._count_steps(self.current)
        self._done_steps = 0
        self.progress.setRange(0, self._total_steps or 0)
        self.progress.setValue(0)
        self.steps.addItem(QListWidgetItem(f"━━ {self.current['name']}  ({n} of {self.queue_total})"))
        self.summary.setText(f"Starting {self.current['name']}…")
        self._t0 = time.monotonic()
        self.clock.start(500)
        w = PlayWorker(self.current, dry_run=self.dry)
        self.worker = w
        w.step.connect(self._on_step)
        w.finished_run.connect(self._on_finished)
        w.failed.connect(self._on_failed)
        w.state_changed.connect(self._on_state)
        w.retry_question.connect(self._on_retry_question)
        w.start()
        design.bus.log.emit(f"Run started: {self.current['name']}")

    @staticmethod
    def _count_steps(it: dict) -> int:
        try:
            if it.get("kind", "native") == "native":
                return len(testfile.load_test(it["name"])[0].get("steps") or [])
        except Exception:
            pass
        return 0

    def _on_step(self, r: dict) -> None:
        if r.get("status") == "running":
            self.summary.setText(f"Step {r.get('id')}: {r.get('description', '')}")
            return
        self._done_steps += 1
        if self._total_steps:
            self.progress.setValue(min(self._done_steps, self._total_steps))
            design.bus.progress.emit(self._done_steps, self._total_steps)
        text = f"{status_icon(r['status'])}  {r['id']:>3}.  {r.get('description', '')}" + (f"    [{r['method']}]" if r.get("method") else "")
        it = QListWidgetItem(text)
        it.setForeground(QColor(status_color(r["status"], design._current["theme"])))
        it.setData(Qt.ItemDataRole.UserRole, r)
        self.steps.addItem(it)
        for h in r.get("retry_history") or []:
            sub = QListWidgetItem(f"        ↻ retry {h.get('attempt')}: {h.get('decision', '-')} ({h.get('via', '-')}) → {h.get('result', '-')}")
            self.steps.addItem(sub)
        self.steps.scrollToBottom()
        design.bus.log.emit(f"  {text.strip()}" + (f" - {r['error']}" if r.get("error") else ""))

    def _on_state(self, state: str) -> None:
        paused = state == "paused"
        self.pause_btn.setText("▶  Resume" if paused else "⏸  Pause")
        if state in ("stopping", "cancelling"):
            self.pause_btn.setEnabled(False)
            self.stop_btn.setEnabled(False)
            self.summary.setText("Stopping after the current step…" if state == "stopping" else "Cancelling…")
        elif paused:
            self.summary.setText("Paused. Press Resume to continue with the next step.")

    def _pause_resume(self) -> None:
        w = self.worker
        if w and w.isRunning():
            w.resume() if w.controller.state == "paused" else w.pause()

    def _stop(self) -> None:
        self._stop_queue = True
        if self.worker and self.worker.isRunning():
            self.worker.stop()

    def _cancel(self) -> None:
        self._stop_queue = True
        if self.worker and self.worker.isRunning():
            self.worker.cancel()

    def _on_retry_question(self, payload: dict) -> None:
        w = self.worker
        if not w:
            return
        from core import settings as _settings

        win = self.window()
        win.showNormal()
        win.raise_()
        win.activateWindow()
        dlg = RetryDialog(payload, _settings.load().get("retry_timeout_action", "retry"), self)
        dlg.exec()
        w.answer_retry(dlg.choice)

    def _on_finished(self, run: dict) -> None:
        self.last_run = run
        self.results.append(run)
        s = run["summary"]
        line = (f"{run['status'].upper()}: {run.get('title') or run.get('test')} - {s['passed']}/{s['total']} steps passed, "
                f"{s['healed']} self-healed")
        self.steps.addItem(QListWidgetItem("━━ " + line))
        design.bus.log.emit(line)
        design.bus.notify.emit("ok" if run["status"] == "passed" else "bad" if run["status"] == "failed" else "warn", line)
        design.bus.data_changed.emit()
        self.worker = None
        self._next()

    def _on_failed(self, msg: str) -> None:
        self.steps.addItem(QListWidgetItem(f"✗ The run could not start or crashed: {msg}"))
        design.bus.notify.emit("bad", msg)
        self.worker = None
        self._next()

    def _finish_all(self) -> None:
        self.clock.stop()
        self._idle_ui()
        design.bus.progress.emit(0, 0)
        n = len(self.results)
        failed = sum(1 for r in self.results if r["status"] == "failed")
        self.summary.setText(f"Finished {n} test(s): {n - failed} not failed, {failed} failed." if n else "Nothing ran.")
        win = self.window()
        win.showNormal()
        win.raise_()

    def _idle_ui(self) -> None:
        self.run_btn.setEnabled(True)
        self.dry_btn.setEnabled(True)
        self.pause_btn.setEnabled(False)
        self.pause_btn.setText("⏸  Pause")
        self.stop_btn.setEnabled(False)
        self.cancel_btn.setEnabled(False)

    def _tick_clock(self) -> None:
        if self.worker and self.worker.isRunning() and self.worker.controller.state != "paused":
            self.progress.setFormat(f"%v / %m steps   {fmt_duration((time.monotonic() - self._t0) * 1000)}")

    def _show_detail(self, row: int) -> None:
        it = self.steps.item(row)
        r = it.data(Qt.ItemDataRole.UserRole) if it else None
        if not r:
            self.detail.clear()
            return
        lines = [f"Step {r.get('id')}: {r.get('description', '')}", f"Status: {r['status']}   Method: {r.get('method', '-')}"]
        for v in r.get("validations") or []:
            lines.append(f"  {status_icon(v['status'])} check: {v['description']}" + (f" ({v['detail']})" if v.get("detail") else ""))
        if r.get("error"):
            lines += ["", "Error: " + str(r["error"])]
        if r["status"] == "failed":
            from core import ai_assistant

            e = ai_assistant.explain_failure({"steps": [r]})
            lines += ["", f"Likely cause ({e['category']}): {e['cause']}"] + [f"  - {f}" for f in e["fixes"]]
        self.detail.setPlainText("\n".join(lines))

    def open_report(self) -> None:
        if self.last_run:
            from core.reports.report import write_report

            d = Path(self.last_run["_dir"])
            open_path(d / "report.html" if (d / "report.html").exists() else write_report(d))

    def shutdown(self, timeout_ms: int = 15000) -> bool:
        self._stop_queue = True
        w = self.worker
        if not w or not w.isRunning():
            return True
        w.cancel()
        return bool(w.wait(timeout_ms))
