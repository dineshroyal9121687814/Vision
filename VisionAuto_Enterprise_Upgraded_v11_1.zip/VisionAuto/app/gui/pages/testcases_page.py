"""Test Cases page: topic-wise library (create / edit / clone / delete / import / export) and the AI generator."""
from __future__ import annotations

import json
from copy import deepcopy

from PySide6.QtWidgets import (QAbstractItemView, QCheckBox, QComboBox, QDialog, QFileDialog, QFormLayout, QHBoxLayout,
                               QHeaderView, QLabel, QLineEdit, QMessageBox, QPlainTextEdit, QProgressBar, QPushButton,
                               QTableWidget, QTableWidgetItem, QTabWidget, QVBoxLayout, QWidget)

from app.gui.pages.common import empty_label, heading, open_path
from app.gui.workers import GenerateWorker
from core import testcases, testgen


def _lines(text: str) -> list[str]:
    return [ln.strip() for ln in text.splitlines() if ln.strip()]


class CaseDialog(QDialog):
    """Edit one test case. ``result_case`` is set on Save."""

    def __init__(self, case: dict | None = None, topic: str = "", parent=None):
        super().__init__(parent)
        self.setWindowTitle("Edit test case" if case else "New test case")
        self.setMinimumWidth(620)
        self.result_case: dict | None = None
        self.original = deepcopy(case) if case else {}
        form = QFormLayout()
        self.id = QLineEdit((case or {}).get("id", ""))
        self.id.setPlaceholderText("Auto")
        self.id.setReadOnly(bool(case))
        self.title = QLineEdit((case or {}).get("title", ""))
        self.topic = QLineEdit((case or {}).get("topic", topic))
        self.category = QComboBox()
        self.category.addItems(testcases.CATEGORIES)
        self.category.setCurrentText((case or {}).get("category", "positive"))
        self.priority = QComboBox()
        self.priority.addItems(testcases.PRIORITIES)
        self.priority.setCurrentText((case or {}).get("priority", "Medium"))
        self.desc = QPlainTextEdit((case or {}).get("description", ""))
        self.pre = QPlainTextEdit("\n".join((case or {}).get("preconditions", [])))
        self.data = QPlainTextEdit(json.dumps((case or {}).get("test_data", {}), indent=2, ensure_ascii=False))
        self.steps = QPlainTextEdit("\n".join(str(s) for s in (case or {}).get("steps", [])))
        self.expected = QPlainTextEdit("\n".join((case or {}).get("expected_results", [])))
        for label, w in (("ID", self.id), ("Title", self.title), ("Topic", self.topic), ("Category", self.category),
                         ("Priority", self.priority), ("Description", self.desc), ("Preconditions (one per line)", self.pre),
                         ("Test data (JSON)", self.data), ("Steps (one per line)", self.steps),
                         ("Expected results (one per line)", self.expected)):
            form.addRow(label, w)
        self.error = QLabel("")
        self.error.setObjectName("muted")
        row = QHBoxLayout()
        save, cancel = QPushButton("Save"), QPushButton("Cancel")
        save.setProperty("kind", "primary")
        save.clicked.connect(self._save)
        cancel.clicked.connect(self.reject)
        row.addStretch(1)
        row.addWidget(cancel)
        row.addWidget(save)
        lay = QVBoxLayout(self)
        lay.addLayout(form)
        lay.addWidget(self.error)
        lay.addLayout(row)

    def _save(self) -> None:
        try:
            data = json.loads(self.data.toPlainText() or "{}")
        except ValueError as exc:
            self.error.setText(f"Test data is not valid JSON: {exc}")
            return
        case = {**self.original, "id": self.id.text().strip(), "title": self.title.text().strip(), "topic": self.topic.text().strip() or "General",
                "category": self.category.currentText(), "priority": self.priority.currentText(),
                "description": self.desc.toPlainText(), "preconditions": _lines(self.pre.toPlainText()), "test_data": data,
                "steps": _lines(self.steps.toPlainText()), "expected_results": _lines(self.expected.toPlainText())}
        try:
            testcases.normalize_case(case)
        except testcases.CaseError as exc:
            self.error.setText(str(exc))
            return
        self.result_case = case
        self.accept()


class TestCasesPage(QWidget):
    __test__ = False                       # not a unittest class

    def __init__(self):
        super().__init__()
        self.setObjectName("page")
        self.cases: list[dict] = []
        self.shown: list[dict] = []
        self.generated: dict = {}
        self.flat: list[tuple[str, dict]] = []
        self.worker: GenerateWorker | None = None
        lay = QVBoxLayout(self)
        lay.setContentsMargins(28, 24, 28, 24)
        lay.addWidget(heading("Test Cases", "Organise cases by topic. Generated cases are saved as separate files per topic and "
                                            "category. Cases are never marked passed until a real run says so."))
        self.root_label = QLabel("")
        self.root_label.setObjectName("muted")
        lay.addWidget(self.root_label)
        self.tabs = QTabWidget()
        lay.addWidget(self.tabs, 1)
        self.tabs.addTab(self._library_tab(), "Library")
        self.tabs.addTab(self._generate_tab(), "Generate")
        self.refresh()

    # ------------------------------------------------------------------ library
    def _library_tab(self) -> QWidget:
        w = QWidget()
        lay = QVBoxLayout(w)
        bar = QHBoxLayout()
        self.btns = {}
        for key, text, kind in (("new", "+ New", "primary"), ("edit", "Edit", ""), ("clone", "Clone", ""), ("delete", "Delete", "danger"),
                                ("import", "Import…", ""), ("export", "Export…", ""), ("folder", "Open folder", ""),
                                ("storage", "Change storage folder…", "")):
            b = QPushButton(text)
            if kind:
                b.setProperty("kind", kind)
            self.btns[key] = b
            bar.addWidget(b)
        bar.addStretch(1)
        lay.addLayout(bar)
        self.btns["new"].clicked.connect(self.new_case)
        self.btns["edit"].clicked.connect(self.edit_case)
        self.btns["clone"].clicked.connect(self.clone_case)
        self.btns["delete"].clicked.connect(self.delete_cases)
        self.btns["import"].clicked.connect(self.import_cases)
        self.btns["export"].clicked.connect(self.export_cases)
        self.btns["folder"].clicked.connect(lambda: open_path(testcases.root()))
        self.btns["storage"].clicked.connect(self.change_storage)
        flt = QHBoxLayout()
        self.search = QLineEdit()
        self.search.setPlaceholderText("Search id, title, steps…")
        self.topic = QComboBox()
        self.category = QComboBox()
        self.priority = QComboBox()
        self.sort = QComboBox()
        for label, key in (("Sort: ID", "id"), ("Sort: Title", "title"), ("Sort: Priority", "priority"), ("Sort: Topic", "topic")):
            self.sort.addItem(label, key)
        for cb in (self.topic, self.category, self.priority):
            cb.currentIndexChanged.connect(self.apply_filter)
        self.sort.currentIndexChanged.connect(self.apply_filter)
        self.search.textChanged.connect(self.apply_filter)
        for x in (self.search, self.topic, self.category, self.priority, self.sort):
            flt.addWidget(x, 1 if x is self.search else 0)
        lay.addLayout(flt)
        self.table = QTableWidget(0, 6)
        self.table.setHorizontalHeaderLabels(["ID", "Title", "Topic", "Category", "Priority", "Status"])
        self.table.verticalHeader().setVisible(False)
        self.table.setAlternatingRowColors(True)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        self.table.doubleClicked.connect(lambda *_: self.edit_case())
        lay.addWidget(self.table, 1)
        self.empty = empty_label("No test cases yet. Use + New, Import…, or the Generate tab to create them from a requirement.")
        lay.addWidget(self.empty)
        self.count = QLabel("")
        self.count.setObjectName("muted")
        lay.addWidget(self.count)
        return w

    def refresh(self) -> None:
        self.root_label.setText(f"Storage folder: {testcases.root()}")
        try:
            self.cases = testcases.list_cases()
        except OSError as exc:
            self.cases = []
            self.count.setText(f"Could not read the test case folder: {exc}")
        for cb, label, values in ((self.topic, "All topics", sorted({c.get("topic", "") for c in self.cases})),
                                  (self.category, "All categories", list(testcases.CATEGORIES)),
                                  (self.priority, "All priorities", list(testcases.PRIORITIES))):
            cur = cb.currentData()
            cb.blockSignals(True)
            cb.clear()
            cb.addItem(label, "")
            for v in values:
                cb.addItem(v, v)
            idx = cb.findData(cur) if cur else 0
            cb.setCurrentIndex(max(idx, 0))
            cb.blockSignals(False)
        self.apply_filter()

    def apply_filter(self) -> None:
        self.shown = testcases.search(self.cases, self.search.text(), self.topic.currentData() or "", self.category.currentData() or "",
                                      self.priority.currentData() or "", sort_by=self.sort.currentData() or "id")
        self.table.setRowCount(len(self.shown))
        for r, c in enumerate(self.shown):
            for col, v in enumerate([c.get("id", ""), c.get("title", ""), c.get("topic", ""), c.get("category", ""),
                                     c.get("priority", ""), c.get("status", "not_run")]):
                self.table.setItem(r, col, QTableWidgetItem(str(v)))
        self.empty.setVisible(not self.shown)
        self.count.setText(f"{len(self.shown)} of {len(self.cases)} test cases · {len({c.get('topic') for c in self.cases})} topics")

    def _selected(self) -> list[dict]:
        rows = sorted({i.row() for i in self.table.selectedIndexes()})
        return [self.shown[i] for i in rows if 0 <= i < len(self.shown)]

    def _guard(self, fn, *a):
        try:
            return fn(*a)
        except (testcases.CaseError, OSError) as exc:
            QMessageBox.warning(self, "Test cases", str(exc))
            return None

    def new_case(self) -> None:
        dlg = CaseDialog(topic=self.topic.currentData() or "", parent=self)
        if dlg.exec() and dlg.result_case:
            self._guard(testcases.add_case, dlg.result_case)
            self.refresh()

    def edit_case(self) -> None:
        sel = self._selected()
        if len(sel) != 1:
            QMessageBox.information(self, "Test cases", "Select one test case to edit.")
            return
        case = {k: v for k, v in sel[0].items() if k != "_file"}
        dlg = CaseDialog(case, parent=self)
        if dlg.exec() and dlg.result_case:
            self._guard(testcases.update_case, case["id"], dlg.result_case)
            self.refresh()

    def clone_case(self) -> None:
        sel = self._selected()
        for c in sel:
            self._guard(testcases.clone_case, c["id"])
        if sel:
            self.refresh()

    def delete_cases(self) -> None:
        sel = self._selected()
        if not sel:
            QMessageBox.information(self, "Test cases", "Select the test case(s) to delete.")
            return
        if QMessageBox.question(self, "Delete test cases", f"Delete {len(sel)} test case(s)? Execution reports are not affected.") \
                != QMessageBox.StandardButton.Yes:
            return
        for c in sel:
            self._guard(testcases.delete_case, c["id"])
        self.refresh()

    def import_cases(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "Import test cases", "", "Test cases (*.json)")
        if path:
            out = self._guard(testcases.import_cases, path)
            if out:
                QMessageBox.information(self, "Import", f"Imported {out['added']} test case(s); skipped {out['skipped']} duplicate(s).")
            self.refresh()

    def export_cases(self) -> None:
        path, flt = QFileDialog.getSaveFileName(self, "Export test cases", "testcases.json", "JSON (*.json);;CSV (*.csv)")
        if path:
            out = self._guard(testcases.export_cases, path, None, "csv" if path.lower().endswith(".csv") else "json")
            if out:
                QMessageBox.information(self, "Export", f"Exported {out['cases']} test case(s) to {out['path']}")

    def change_storage(self) -> None:
        folder = QFileDialog.getExistingDirectory(self, "Choose the test case folder", str(testcases.root()))
        if not folder:
            return
        out = self._guard(testcases.change_root, folder, True)
        if out:
            QMessageBox.information(self, "Storage folder", f"Now using {out['root']}\nCopied {out['copied']} file(s); "
                                                             f"{out['skipped_existing']} already existed. The old folder was left untouched.")
        self.refresh()

    # ------------------------------------------------------------------ generator
    def _generate_tab(self) -> QWidget:
        w = QWidget()
        lay = QVBoxLayout(w)
        self.gen_topic = QLineEdit()
        self.gen_topic.setPlaceholderText("Topic (optional). Leave empty to use 'Topic:' headings in the text, e.g. 'Login:' / 'Payment:'")
        lay.addWidget(self.gen_topic)
        self.gen_text = QPlainTextEdit()
        self.gen_text.setPlaceholderText("Paste a feature, requirement, user story, workflow or manual scenario…")
        self.gen_text.setMaximumHeight(150)
        lay.addWidget(self.gen_text)
        row = QHBoxLayout()
        self.cat_boxes = {}
        for cat in testcases.CATEGORIES:
            cb = QCheckBox(testgen.CATEGORY_TITLES[cat])
            cb.setChecked(True)
            self.cat_boxes[cat] = cb
            row.addWidget(cb)
        lay.addLayout(row)
        row2 = QHBoxLayout()
        self.gen_btn = QPushButton("Generate test cases")
        self.gen_btn.setProperty("kind", "primary")
        self.gen_btn.clicked.connect(self.generate)
        self.gen_progress = QProgressBar()
        self.gen_progress.setRange(0, 0)
        self.gen_progress.hide()
        row2.addWidget(self.gen_btn)
        row2.addWidget(self.gen_progress, 1)
        lay.addLayout(row2)
        self.gen_info = QLabel("")
        self.gen_info.setObjectName("muted")
        self.gen_info.setWordWrap(True)
        lay.addWidget(self.gen_info)
        self.gen_table = QTableWidget(0, 5)
        self.gen_table.setHorizontalHeaderLabels(["Save", "ID", "Title", "Category", "Priority"])
        self.gen_table.verticalHeader().setVisible(False)
        self.gen_table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.gen_table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.gen_table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        self.gen_table.doubleClicked.connect(lambda *_: self.edit_generated())
        lay.addWidget(self.gen_table, 1)
        out = QHBoxLayout()
        self.out_dir = QLineEdit(str(testcases.root()))
        browse = QPushButton("Browse…")
        browse.clicked.connect(self._browse_out)
        edit = QPushButton("Edit selected…")
        edit.clicked.connect(self.edit_generated)
        self.save_btn = QPushButton("Save selected to folder")
        self.save_btn.setProperty("kind", "success")
        self.save_btn.clicked.connect(self.save_generated)
        self.save_btn.setEnabled(False)
        out.addWidget(QLabel("Output folder"))
        out.addWidget(self.out_dir, 1)
        out.addWidget(browse)
        out.addWidget(edit)
        out.addWidget(self.save_btn)
        lay.addLayout(out)
        return w

    def _browse_out(self) -> None:
        d = QFileDialog.getExistingDirectory(self, "Output folder", self.out_dir.text())
        if d:
            self.out_dir.setText(d)

    def generate(self) -> None:
        if self.worker and self.worker.isRunning():
            return
        cats = [c for c, b in self.cat_boxes.items() if b.isChecked()]
        if not cats:
            QMessageBox.information(self, "Generate", "Tick at least one category.")
            return
        self.gen_btn.setEnabled(False)
        self.gen_progress.show()
        self.gen_info.setText("Generating…")
        self.worker = GenerateWorker(self.gen_text.toPlainText(), self.gen_topic.text().strip() or None, cats)
        self.worker.done.connect(self._generated)
        self.worker.failed.connect(self._gen_failed)
        self.worker.start()

    def _gen_failed(self, msg: str) -> None:
        self.gen_btn.setEnabled(True)
        self.gen_progress.hide()
        self.gen_info.setText("")
        QMessageBox.warning(self, "Generate", msg)

    def _generated(self, result: dict) -> None:
        self.gen_btn.setEnabled(True)
        self.gen_progress.hide()
        self.generated = result
        self.flat = [(t, c) for t, cs in result["topics"].items() for c in cs]
        self.gen_table.setRowCount(len(self.flat))
        self.gen_checks = []
        for r, (t, c) in enumerate(self.flat):
            chk = QCheckBox()
            chk.setChecked(True)
            self.gen_checks.append(chk)
            self.gen_table.setCellWidget(r, 0, chk)
            for col, v in enumerate([c["id"], f"[{t}] {c['title']}", c["category"], c["priority"]], 1):
                self.gen_table.setItem(r, col, QTableWidgetItem(str(v)))
        parts = []
        for t, cov in result["coverage"].items():
            parts.append(f"{t}: {len(result['topics'][t])} cases, requirement coverage {cov['percent']}% "
                         f"({len(cov['uncovered'])} statement(s) not covered), {len(result['duplicates'][t])} duplicate(s) removed")
        self.gen_info.setText(" | ".join(parts) + ".  Review / edit, then save. Nothing has been run.")
        self.save_btn.setEnabled(bool(self.flat))

    def edit_generated(self) -> None:
        rows = sorted({i.row() for i in self.gen_table.selectedIndexes()})
        if len(rows) != 1:
            QMessageBox.information(self, "Generate", "Select one generated case to edit.")
            return
        topic, case = self.flat[rows[0]]
        dlg = CaseDialog(case, topic, self)
        if dlg.exec() and dlg.result_case:
            case.update(dlg.result_case)
            self.gen_table.setItem(rows[0], 2, QTableWidgetItem(f"[{topic}] {case['title']}"))
            self.gen_table.setItem(rows[0], 3, QTableWidgetItem(case["category"]))
            self.gen_table.setItem(rows[0], 4, QTableWidgetItem(case["priority"]))

    def save_generated(self) -> None:
        chosen: dict[str, list[dict]] = {}
        for chk, (t, c) in zip(self.gen_checks, self.flat):
            if chk.isChecked():
                chosen.setdefault(t, []).append(c)
        if not chosen:
            QMessageBox.information(self, "Generate", "Tick at least one case to save.")
            return
        out = self._guard(testgen.save_generated, chosen, self.out_dir.text().strip() or None)
        if out:
            QMessageBox.information(self, "Saved", f"Saved {out['cases']} case(s) in {len(out['files'])} file(s) under {out['root']}")
            self.refresh()
