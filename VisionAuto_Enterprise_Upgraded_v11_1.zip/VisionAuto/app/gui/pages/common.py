from __future__ import annotations

from PySide6.QtCore import QUrl
from PySide6.QtGui import QDesktopServices
from PySide6.QtWidgets import QFrame, QLabel, QVBoxLayout, QWidget


def heading(text: str, sub: str = "") -> QWidget:
    box = QWidget()
    lay = QVBoxLayout(box)
    lay.setContentsMargins(0, 0, 0, 6)
    lay.setSpacing(2)
    h = QLabel(text)
    h.setObjectName("h1")
    lay.addWidget(h)
    if sub:
        s = QLabel(sub)
        s.setObjectName("muted")
        s.setWordWrap(True)
        lay.addWidget(s)
    return box


def stat_card(title: str, value: str, tone: str = "") -> QFrame:
    card = QFrame()
    card.setObjectName("card")
    if tone:
        card.setProperty("tone", tone)
    lay = QVBoxLayout(card)
    v = QLabel(value)
    v.setObjectName("stat")
    t = QLabel(title)
    t.setObjectName("muted")
    lay.addWidget(v)
    lay.addWidget(t)
    return card


def open_path(path) -> None:
    QDesktopServices.openUrl(QUrl.fromLocalFile(str(path)))


def status_icon(status: str) -> str:
    return {"passed": "✓", "failed": "✗", "skipped": "–", "aborted": "■", "cancelled": "⊘", "inconclusive": "?",
            "invalid": "!", "unreadable": "!"}.get(status, "•")


def empty_label(text: str) -> QLabel:
    """A friendly 'nothing here yet' message shown in place of an empty table."""
    lab = QLabel(text)
    lab.setObjectName("empty")
    lab.setWordWrap(True)
    return lab


def fmt_duration(ms) -> str:
    s = float(ms or 0) / 1000.0
    return f"{s:.1f}s" if s < 60 else f"{int(s // 60)}m {int(s % 60):02d}s"


def fmt_size(n) -> str:
    n = float(n or 0)
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024 or unit == "GB":
            return f"{n:.0f} {unit}" if unit == "B" else f"{n:.1f} {unit}"
        n /= 1024.0
    return ""
