"""AI Assistant: requirements -> test cases, sentences -> validated steps (saved only after you confirm), failure
explanations and regression suggestions. Everything works without an AI model (rule-based); a model only adds to it."""
from __future__ import annotations

import json

from PySide6.QtWidgets import (QHBoxLayout, QLabel, QLineEdit, QListWidget, QMessageBox, QPlainTextEdit, QPushButton,
                               QTabWidget, QVBoxLayout, QWidget, QComboBox)

from app.gui import design
from app.gui.pages.common import heading
from app.gui.workers import Job
from core import ai_assistant, settings, testfile
from core.reports import manage


def _llm():
    try:
        opts = settings.load()
        if not opts.get("use_llm"):
            return None
        from core.ai.llm import OllamaClient

        l = OllamaClient(opts["llm_model"], base_url=opts["llm_base_url"], timeout=60.0)
        return l if l.available() else None
    except Exception:
        return None


class AIPage(QWidget):
    def __init__(self):
        super().__init__()
        self.setObjectName("page")
        self.job = None
        self.draft: dict | None = None
        lay = QVBoxLayout(self)
        lay.setContentsMargins(28, 24, 28, 24)
        lay.addWidget(heading("AI Assistant", "Generates drafts. Nothing is saved or run until you confirm, and every generated step is "
                                              "validated first. Works without an AI model; a model only improves the wording."))
        self.mode = QLabel("")
        self.mode.setObjectName("muted")
        lay.addWidget(self.mode)
        self.tabs = QTabWidget()
        lay.addWidget(self.tabs, 1)

        # --- steps from sentences
        t1 = QWidget()
        l1 = QVBoxLayout(t1)
        l1.addWidget(QLabel("Describe the test, one action per line. Example: Open notepad / Type 'hello' into Editor / press ctrl+s / wait 2 seconds"))
        self.nl = QPlainTextEdit()
        self.nl.setPlaceholderText("Open notepad\nType 'hello' into Editor\nPress ctrl+s")
        l1.addWidget(self.nl, 1)
        r = QHBoxLayout()
        self.name = QLineEdit()
        self.name.setPlaceholderText("Test name to save as")
        self.gen_btn = QPushButton("Generate steps")
        self.gen_btn.setProperty("kind", "primary")
        self.save_btn = QPushButton("Save as test…")
        self.save_btn.setEnabled(False)
        r.addWidget(self.name, 1)
        r.addWidget(self.gen_btn)
        r.addWidget(self.save_btn)
        l1.addLayout(r)
        self.out = QPlainTextEdit()
        self.out.setReadOnly(True)
        self.out.setObjectName("console")
        l1.addWidget(self.out, 1)
        self.tabs.addTab(t1, "Sentences → steps")

        # --- requirements -> cases
        t2 = QWidget()
        l2 = QVBoxLayout(t2)
        l2.addWidget(QLabel("Paste a requirement or user story to get test-case ideas (positive, negative, boundary)."))
        self.req = QPlainTextEdit()
        l2.addWidget(self.req, 1)
        self.cases_btn = QPushButton("Suggest test cases")
        l2.addWidget(self.cases_btn)
        self.cases = QPlainTextEdit()
        self.cases.setReadOnly(True)
        self.cases.setObjectName("console")
        l2.addWidget(self.cases, 2)
        self.tabs.addTab(t2, "Requirements → cases")

        # --- failures + regression
        t3 = QWidget()
        l3 = QVBoxLayout(t3)
        row = QHBoxLayout()
        self.run_combo = QComboBox()
        self.explain_btn = QPushButton("Explain this failure")
        self.reg_btn = QPushButton("Suggest regression tests")
        row.addWidget(self.run_combo, 1)
        row.addWidget(self.explain_btn)
        row.addWidget(self.reg_btn)
        l3.addLayout(row)
        self.explain = QPlainTextEdit()
        self.explain.setReadOnly(True)
        self.explain.setObjectName("console")
        l3.addWidget(self.explain, 1)
        self.tabs.addTab(t3, "Failures & regression")

        self.gen_btn.clicked.connect(self.generate_steps)
        self.save_btn.clicked.connect(self.save_draft)
        self.cases_btn.clicked.connect(self.suggest_cases)
        self.explain_btn.clicked.connect(self.explain_selected)
        self.reg_btn.clicked.connect(self.regression)

    def refresh(self) -> None:
        self.mode.setText("AI model: connected (suggestions are validated like everything else)." if _llm() else
                          "AI model: off - using built-in rules. Turn on the local AI in Settings for richer wording.")
        self.run_combo.clear()
        for r in [x for x in manage.list_reports() if x.get("status") == "failed" and not x.get("dry_run")][:30]:
            self.run_combo.addItem(f"{r['test']} · {r['started_at'][:16].replace('T', ' ')}", r["dir"])

    # ------------------------------------------------------------------
    def generate_steps(self) -> None:
        res = ai_assistant.nl_to_steps(self.nl.toPlainText(), llm=_llm())
        self.draft = res
        lines = [f"{s['id']:>2}. [{s['type']}] {s['description']}" for s in res["steps"]]
        if res.get("unparsed"):
            lines += ["", "Could not understand these lines (nothing was guessed):"] + [f"  ? {u}" for u in res["unparsed"]]
        if res.get("issues"):
            lines += ["", "Validation:"] + [f"  ! {i}" for i in res["issues"]]
        self.out.setPlainText("\n".join(lines) or "No steps produced.")
        self.save_btn.setEnabled(bool(res["steps"]))

    def save_draft(self) -> None:
        if not self.draft or not self.draft["steps"]:
            return
        name = self.name.text().strip()
        if not name:
            QMessageBox.information(self, "Save", "Type a test name first.")
            return
        if any(t["name"] == name for t in testfile.list_tests()):
            QMessageBox.warning(self, "Save", f"A test named '{name}' already exists. Choose another name; existing tests are never overwritten here.")
            return
        test = testfile.new_test(name)
        test["steps"] = self.draft["steps"]
        test["generated_by"] = "ai_assistant"
        d = testfile.test_dir(name)
        if d.exists():
            QMessageBox.warning(self, "Save", "That folder name already exists. Choose another name.")
            return
        try:
            d.mkdir(parents=True)
            testfile.save_test(test, d)
        except Exception as e:
            QMessageBox.warning(self, "Save", f"Could not save: {e}")
            return
        design.bus.notify.emit("ok", f"Saved '{name}'. Open it in Tests to review the targets before running.")
        design.bus.data_changed.emit()

    def suggest_cases(self) -> None:
        text = self.req.toPlainText().strip()
        if not text:
            return
        self.cases_btn.setEnabled(False)
        self.cases.setPlainText("Working…")
        self.job = Job(ai_assistant.requirements_to_cases, text, None, _llm())
        self.job.done.connect(self._cases)
        self.job.failed.connect(lambda m: (self.cases.setPlainText(m), self.cases_btn.setEnabled(True)))
        self.job.start()

    def _cases(self, out) -> None:
        self.cases_btn.setEnabled(True)
        self.cases.setPlainText(json.dumps(out, indent=2, ensure_ascii=False, default=str))

    def explain_selected(self) -> None:
        d = self.run_combo.currentData()
        if not d:
            self.explain.setPlainText("No failed run to explain.")
            return
        try:
            run = json.loads((__import__("pathlib").Path(d) / "run.json").read_text(encoding="utf-8"))
        except Exception as e:
            self.explain.setPlainText(f"Could not read the run: {e}")
            return
        e = ai_assistant.explain_failure(run, llm=_llm())
        txt = [ai_assistant.summarize_run(run), "", f"Category: {e['category']} (recoverable: {e['recoverable']})", f"Cause: {e['cause']}"]
        txt += [f" - {f}" for f in e["fixes"]]
        if e.get("ai_explanation"):
            txt += ["", "AI: " + e["ai_explanation"]]
        self.explain.setPlainText("\n".join(txt))

    def regression(self) -> None:
        rows = ai_assistant.regression_suggestions(manage.list_reports())
        self.explain.setPlainText("\n".join(f"{x['priority']}. {x['test']}: {x['reason']}" for x in rows) or "Nothing to re-run: no failures, healing or retries.")
