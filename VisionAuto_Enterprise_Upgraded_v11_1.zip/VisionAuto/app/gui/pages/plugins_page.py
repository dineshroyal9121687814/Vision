"""Plugins & Integrations: what is installed, what each optional part gives you. Read-only: it never installs anything."""
from __future__ import annotations

from PySide6.QtWidgets import QLabel, QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget, QAbstractItemView

from app.gui.pages.common import heading
from core import integrations


class PluginsPage(QWidget):
    def __init__(self):
        super().__init__()
        self.setObjectName("page")
        lay = QVBoxLayout(self)
        lay.setContentsMargins(28, 24, 28, 24)
        lay.addWidget(heading("Plugins & Integrations", "Technology plugins that find elements, and optional components. "
                                                        "Missing components are listed honestly; nothing is installed from here."))
        lay.addWidget(QLabel("Technology plugins"))
        self.plugins = QTableWidget(0, 3)
        self.plugins.setHorizontalHeaderLabels(["Plugin", "Handles", "Needs accessibility API"])
        lay.addWidget(self.plugins, 1)
        lay.addWidget(QLabel("Components on this computer"))
        self.comps = QTableWidget(0, 3)
        self.comps.setHorizontalHeaderLabels(["Component", "Status", "Package / detail"])
        lay.addWidget(self.comps, 1)
        for t in (self.plugins, self.comps):
            t.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
            t.horizontalHeader().setStretchLastSection(True)
            t.verticalHeader().setVisible(False)

    def refresh(self) -> None:
        ps = integrations.plugins()
        self.plugins.setRowCount(len(ps))
        for r, p in enumerate(ps):
            for c, v in enumerate((p["title"], p["how"], "yes" if p["uses_accessibility"] else "no")):
                self.plugins.setItem(r, c, QTableWidgetItem(v))
        cs = integrations.components()
        self.comps.setRowCount(len(cs))
        for r, p in enumerate(cs):
            for c, v in enumerate((p["name"], "✓ available" if p["installed"] else "✗ not installed", p["package"])):
                self.comps.setItem(r, c, QTableWidgetItem(v))
        self.plugins.resizeColumnsToContents()
        self.comps.resizeColumnsToContents()
