from __future__ import annotations

from pathlib import Path

from PySide6.QtGui import QColor
from PySide6.QtWidgets import (QAbstractItemView, QComboBox, QHBoxLayout, QHeaderView, QInputDialog, QLabel, QLineEdit,
                               QMessageBox, QPushButton, QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget)

from app.gui.pages.common import empty_label, fmt_duration, fmt_size, heading, open_path, status_icon
from app.gui.theme import status_color
from core import settings
from core.reports import manage
from core.reports.report import write_report

STATUSES = ["", "passed", "failed", "aborted", "cancelled", "inconclusive", "invalid", "unreadable"]
SORTS = [("Date", "date"), ("Status", "status"), ("Test case", "test"), ("Duration", "duration"), ("Size", "size")]


class ReportsPage(QWidget):
    def __init__(self):
        super().__init__()
        self.setObjectName("page")
        self.all_rows: list[dict] = []
        self.rows: list[dict] = []
        lay = QVBoxLayout(self)
        lay.setContentsMargins(28, 24, 28, 24)
        lay.addWidget(heading("Reports", "Every run keeps a self-contained HTML report (steps, validations, retries, AI diagnosis, "
                                         "screenshots). Delete removes only the selected run folder."))
        bar = QHBoxLayout()
        self.open_btn = QPushButton("Open report")
        self.open_btn.setProperty("kind", "primary")
        self.open_btn.clicked.connect(self.open_report)
        self.folder_btn = QPushButton("Open folder")
        self.folder_btn.clicked.connect(self.open_folder)
        self.refresh_btn = QPushButton("Refresh")
        self.refresh_btn.clicked.connect(self.refresh)
        self.del_btn = QPushButton("Delete selected")
        self.del_btn.setProperty("kind", "danger")
        self.del_btn.clicked.connect(self.delete_selected)
        self.old_btn = QPushButton("Delete old…")
        self.old_btn.clicked.connect(self.delete_old)
        for b in (self.open_btn, self.folder_btn, self.refresh_btn, self.del_btn, self.old_btn):
            bar.addWidget(b)
        bar.addStretch(1)
        lay.addLayout(bar)
        flt = QHBoxLayout()
        self.search = QLineEdit()
        self.search.setPlaceholderText("Search test, run id, status…")
        self.search.textChanged.connect(self.apply_filter)
        self.status = QComboBox()
        for s in STATUSES:
            self.status.addItem(s.title() if s else "All statuses", s)
        self.status.currentIndexChanged.connect(self.apply_filter)
        self.sort = QComboBox()
        for label, key in SORTS:
            self.sort.addItem("Sort: " + label, key)
        self.sort.currentIndexChanged.connect(self.apply_filter)
        self.order = QPushButton("Newest first")
        self.order.setCheckable(True)
        self.order.setChecked(True)
        self.order.clicked.connect(self._flip_order)
        flt.addWidget(self.search, 1)
        flt.addWidget(self.status)
        flt.addWidget(self.sort)
        flt.addWidget(self.order)
        lay.addLayout(flt)
        self.table = QTableWidget(0, 8)
        self.table.setHorizontalHeaderLabels(["Result", "Test", "Passed", "Failed", "Retries", "Duration", "Started", "Size"])
        self.table.verticalHeader().setVisible(False)
        self.table.setAlternatingRowColors(True)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        self.table.doubleClicked.connect(lambda *_: self.open_report())
        self.table.itemSelectionChanged.connect(self._buttons)
        lay.addWidget(self.table, 1)
        self.empty = empty_label("No reports yet. Run a test from the Tests page and its report will appear here.")
        lay.addWidget(self.empty)
        self.summary = QLabel("")
        self.summary.setObjectName("muted")
        lay.addWidget(self.summary)
        self.refresh()

    def _flip_order(self) -> None:
        self.order.setText("Newest first" if self.order.isChecked() else "Oldest first")
        self.apply_filter()

    def refresh(self) -> None:
        self.all_rows = manage.list_reports()
        self.apply_filter()

    def apply_filter(self) -> None:
        self.rows = manage.filter_sort(self.all_rows, self.search.text(), self.status.currentData() or "",
                                       self.sort.currentData() or "date", self.order.isChecked())
        self.table.setRowCount(len(self.rows))
        for r, run in enumerate(self.rows):
            vals = [f"{status_icon(run['status'])} {run['status'].upper()}", run["test"], f"{run['passed']}/{run['total']}",
                    str(run["failed"]), str(run["retries"]), fmt_duration(run["duration_ms"]),
                    run["started_at"].replace("T", " "), fmt_size(run["size"])]
            for c, v in enumerate(vals):
                item = QTableWidgetItem(v)
                if c == 0:
                    item.setForeground(QColor(status_color(run["status"])))
                self.table.setItem(r, c, item)
        self.empty.setVisible(not self.rows)
        self.empty.setText("No reports yet. Run a test from the Tests page and its report will appear here."
                           if not self.all_rows else "No report matches the search / filter.")
        self.summary.setText(f"{len(self.rows)} of {len(self.all_rows)} reports · {fmt_size(sum(r['size'] for r in self.all_rows))} on disk")
        self._buttons()

    def selected(self) -> list[dict]:
        rows = sorted({i.row() for i in self.table.selectedIndexes()})
        return [self.rows[i] for i in rows if 0 <= i < len(self.rows)]

    def _buttons(self) -> None:
        n = len(self.selected())
        self.open_btn.setEnabled(n == 1)
        self.folder_btn.setEnabled(n == 1)
        self.del_btn.setEnabled(n >= 1)

    def open_report(self) -> None:
        sel = self.selected()
        if len(sel) != 1:
            QMessageBox.information(self, "Reports", "Select one report first.")
            return
        d = Path(sel[0]["dir"])
        try:
            open_path(d / "report.html" if (d / "report.html").exists() else write_report(d))
        except Exception as exc:  # noqa: BLE001 - e.g. run.json missing / unreadable
            QMessageBox.warning(self, "Reports", f"Could not open the report: {exc}")

    def open_folder(self) -> None:
        sel = self.selected()
        if len(sel) == 1:
            open_path(sel[0]["dir"])

    def _confirm_and_delete(self, dirs: list[str], what: str) -> None:
        if not dirs:
            QMessageBox.information(self, "Reports", "Nothing to delete.")
            return
        if QMessageBox.question(self, "Delete reports", f"Delete {what}? This removes only the report folder(s) "
                                                        "(screenshots, HTML, run data). It cannot be undone.") != QMessageBox.StandardButton.Yes:
            return
        out = manage.delete_runs(dirs)
        self.refresh()                                   # list is up to date immediately
        if out["failed"]:
            QMessageBox.warning(self, "Delete reports", f"Deleted {out['deleted']}; {len(out['failed'])} could not be deleted:\n\n"
                                + "\n".join(f"{Path(f['dir']).name}: {f['error']}" for f in out["failed"][:6]))
        else:
            self.summary.setText(f"Deleted {out['deleted']} report(s), freed {fmt_size(out['bytes'])}.")

    def delete_selected(self) -> None:
        sel = self.selected()
        self._confirm_and_delete([s["dir"] for s in sel], f"{len(sel)} selected report(s)")

    def delete_old(self) -> None:
        days, ok = QInputDialog.getInt(self, "Delete old reports", "Delete reports older than (days):",
                                       int(settings.load().get("report_keep_days", 30)), 0, 3650)
        if ok:
            old = manage.find_old(days)
            self._confirm_and_delete([r["dir"] for r in old], f"{len(old)} report(s) older than {days} day(s)")
