from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import Signal
from PySide6.QtWidgets import (QCheckBox, QFileDialog, QHBoxLayout, QLabel, QLineEdit, QMessageBox, QPlainTextEdit,
                               QPushButton, QVBoxLayout, QWidget)

from app.gui.pages.common import heading
from app.gui.workers import ImportWorker


class ImportPage(QWidget):
    imported = Signal()

    def __init__(self):
        super().__init__()
        self.setObjectName("page")
        self.rxrep = ""
        self.cs: list[str] = []
        self.worker: ImportWorker | None = None
        lay = QVBoxLayout(self)
        lay.setContentsMargins(28, 24, 28, 24)
        lay.addWidget(heading("Import Ranorex tests",
                              "Pick the Ranorex repository (.rxrep) and the C# recordings / code modules (.cs). Simple "
                              "recordings become normal tests (with validation points, reports and self-healing). Code "
                              "with loops, variables or custom helpers is translated to a Python script that runs on the same engine."))
        r1 = QHBoxLayout()
        self.rx_label = QLabel("No repository selected")
        b1 = QPushButton("Choose .rxrep...")
        b1.clicked.connect(self._pick_rxrep)
        r1.addWidget(b1)
        r1.addWidget(self.rx_label, 1)
        lay.addLayout(r1)
        r2 = QHBoxLayout()
        self.cs_label = QLabel("No .cs files selected")
        b2 = QPushButton("Choose .cs files...")
        b2.clicked.connect(self._pick_cs)
        r2.addWidget(b2)
        r2.addWidget(self.cs_label, 1)
        lay.addLayout(r2)
        r3 = QHBoxLayout()
        r3.addWidget(QLabel("Project name"))
        self.project = QLineEdit()
        self.project.setPlaceholderText("e.g. Billing")
        r3.addWidget(self.project, 1)
        lay.addLayout(r3)
        self.force = QCheckBox("Always create scripts (never convert to recorded-style steps)")
        self.llm = QCheckBox("Let the local AI model (Ollama) try lines the rules can't translate")
        lay.addWidget(self.force)
        lay.addWidget(self.llm)
        self.go = QPushButton("Import")
        self.go.setProperty("kind", "primary")
        self.go.clicked.connect(self._run)
        lay.addWidget(self.go)
        self.out = QPlainTextEdit()
        self.out.setReadOnly(True)
        lay.addWidget(self.out, 1)

    def _pick_rxrep(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "Ranorex repository", "", "Ranorex repository (*.rxrep);;All files (*)")
        if path:
            self.rxrep = path
            self.rx_label.setText(path)
            if not self.project.text():
                self.project.setText(Path(path).stem)

    def _pick_cs(self) -> None:
        paths, _ = QFileDialog.getOpenFileNames(self, "Ranorex C# files", "", "C# (*.cs);;All files (*)")
        if paths:
            self.cs = paths
            self.cs_label.setText(f"{len(paths)} file(s): " + ", ".join(Path(p).name for p in paths[:4]))

    def _run(self) -> None:
        if not self.cs or not self.project.text().strip():
            QMessageBox.information(self, "Import", "Choose at least one .cs file and enter a project name.")
            return
        self.go.setEnabled(False)
        self.out.setPlainText("Importing...")
        self.worker = ImportWorker(self.rxrep, self.cs, self.project.text().strip(), self.llm.isChecked(), self.force.isChecked())
        self.worker.done.connect(self._on_done)
        self.worker.failed.connect(self._on_failed)
        self.worker.start()

    def _on_done(self, res: dict) -> None:
        self.go.setEnabled(True)
        lines = [f"Project '{res['project']}': {res['repository_items']} repository elements"]
        for it in res["items"]:
            if it["mode"] == "native":
                lines.append(f"\n{it['file']}  ->  test '{it['test']}' ({it['steps']} steps)")
            else:
                lines.append(f"\n{it['file']}  ->  script ({it['reason']})")
            lines += [f"    not translated: {u}" for u in it["unsupported"]]
        self.out.setPlainText("\n".join(lines))
        self.imported.emit()

    def _on_failed(self, msg: str) -> None:
        self.go.setEnabled(True)
        self.out.setPlainText("Import failed:\n" + msg)
