"""Inspector page: pick a window, see its element tree (Window > Pane > Tab > Button ...), copy an element's XPath."""
from __future__ import annotations

from PySide6.QtCore import QTimer
from PySide6.QtGui import QGuiApplication
from PySide6.QtWidgets import (QComboBox, QHBoxLayout, QLabel, QLineEdit, QPlainTextEdit, QPushButton, QSplitter,
                               QTreeWidget, QTreeWidgetItem, QVBoxLayout, QWidget)

from app.gui.pages.common import heading
from core import inspector
from core.system import winenv


class InspectorPage(QWidget):
    def __init__(self):
        super().__init__()
        self.setObjectName("page")
        self.root = None
        self._items: dict[int, QTreeWidgetItem] = {}
        self._nodes: dict[int, object] = {}
        lay = QVBoxLayout(self)
        lay.setContentsMargins(28, 24, 28, 24)
        lay.addWidget(heading("Inspector",
                              "See exactly how an application window is built - which pane and tab a control lives in - "
                              "like Microsoft Inspect. Use the XPath of any element as its locator."))
        row = QHBoxLayout()
        self.windows = QComboBox()
        self.windows.setMinimumWidth(320)
        row.addWidget(QLabel("Window"))
        row.addWidget(self.windows, 1)
        self.reload_btn = QPushButton("Refresh windows")
        self.reload_btn.clicked.connect(self.refresh)
        self.capture_btn = QPushButton("Capture tree")
        self.capture_btn.setProperty("kind", "primary")
        self.capture_btn.clicked.connect(self.capture)
        self.pick_btn = QPushButton("Pick under mouse (3 s)")
        self.pick_btn.clicked.connect(self._pick_countdown)
        for w in (self.reload_btn, self.capture_btn, self.pick_btn):
            row.addWidget(w)
        lay.addLayout(row)
        frow = QHBoxLayout()
        self.search = QLineEdit()
        self.search.setPlaceholderText("Find by name or automation id (e.g. Nine)")
        self.search.returnPressed.connect(self.find_next)
        frow.addWidget(self.search, 1)
        lay.addLayout(frow)
        split = QSplitter()
        self.tree = QTreeWidget()
        self.tree.setHeaderLabels(["Element", "AutomationId"])
        self.tree.currentItemChanged.connect(self._on_select)
        split.addWidget(self.tree)
        right = QWidget()
        rl = QVBoxLayout(right)
        self.details = QPlainTextEdit()
        self.details.setReadOnly(True)
        rl.addWidget(self.details, 1)
        self.xpath = QLineEdit()
        self.xpath.setReadOnly(True)
        rl.addWidget(QLabel("XPath (unique inside this window)"))
        rl.addWidget(self.xpath)
        self.copy_btn = QPushButton("Copy XPath")
        self.copy_btn.clicked.connect(self._copy)
        rl.addWidget(self.copy_btn)
        split.addWidget(right)
        lay.addWidget(split, 1)
        self.status = QLabel("")
        lay.addWidget(self.status)
        self._hits: list = []
        self._hit_i = 0

    # ------------------------------------------------------------ actions
    def refresh(self) -> None:
        self.windows.clear()
        for w in winenv.list_windows():
            self.windows.addItem(f"{w['title']}  ({w['process']})", w["hwnd"])
        if not winenv.IS_WINDOWS:
            self.status.setText("The Inspector reads live Windows applications (UI Automation); it is not available on this OS.")

    def capture(self) -> None:
        hwnd = self.windows.currentData()
        from core.system import uia_tree
        root = uia_tree.snapshot_window(hwnd=int(hwnd)) if hwnd else None
        if root is None:
            self.status.setText("Could not read that window (is it still open? is pywinauto installed?).")
            return
        self.show_tree(root)

    def show_tree(self, root) -> None:
        self.root = root
        self.tree.clear()
        self._items.clear()
        self._nodes.clear()

        def add(node, parent):
            if node.control_type == "Desktop":
                for c in node.children:
                    add(c, parent)
                return
            label = f"{node.control_type} '{node.name}'" if node.name else node.control_type
            it = QTreeWidgetItem(parent if parent is not None else self.tree)
            it.setText(0, label)
            it.setText(1, node.automation_id)
            self._items[id(node)] = it
            self._nodes[id(it)] = node
            for c in node.children:
                add(c, it)

        add(root, None)
        n = len(self._items)
        self.status.setText(f"{n} elements captured")

    def select_node(self, node) -> None:
        it = self._items.get(id(node))
        if it is not None:
            self.tree.setCurrentItem(it)

    def _on_select(self, item, _prev=None) -> None:
        node = self._nodes.get(id(item)) if item is not None else None
        if node is None:
            return
        lines = [inspector.breadcrumb(node), ""] + [f"{k}: {v}" for k, v in inspector.properties(node).items()]
        self.details.setPlainText("\n".join(lines))
        self.xpath.setText(inspector.xpath_of(node, self.root))

    def find_next(self) -> None:
        if self.root is None:
            return
        text = self.search.text().strip()
        if not self._hits or getattr(self, "_hit_q", "") != text:
            self._hits, self._hit_i, self._hit_q = inspector.find_nodes(self.root, text), 0, text
        if not self._hits:
            self.status.setText(f"Nothing matches '{text}'")
            return
        self.select_node(self._hits[self._hit_i % len(self._hits)])
        self.status.setText(f"match {self._hit_i % len(self._hits) + 1} of {len(self._hits)}")
        self._hit_i += 1

    def _pick_countdown(self) -> None:
        self.status.setText("Move the mouse over the element you want... capturing in 3 seconds")
        QTimer.singleShot(3000, self._pick_now)

    def _pick_now(self) -> None:
        try:
            from pynput import mouse
            x, y = mouse.Controller().position
        except Exception as e:
            self.status.setText(f"Could not read the mouse position: {e}")
            return
        w = winenv.window_at(int(x), int(y))
        from core.system import uia_tree
        root = uia_tree.snapshot_window(hwnd=w.get("hwnd", 0)) if w.get("hwnd") else None
        if root is None:
            self.status.setText("No readable window under the mouse.")
            return
        self.show_tree(root)
        node = inspector.deepest_at(root, int(x), int(y))
        if node is not None:
            self.select_node(node)
            self.status.setText(f"Picked: {inspector.breadcrumb(node)}")

    def _copy(self) -> None:
        QGuiApplication.clipboard().setText(self.xpath.text())
        self.status.setText("XPath copied")
