from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtGui import QColor
from PySide6.QtWidgets import (QWidget, QAbstractItemView, QHBoxLayout, QHeaderView, QLabel, QListWidget, QListWidgetItem,
                               QMessageBox, QPushButton, QTableWidget, QTableWidgetItem, QVBoxLayout)

from app.gui.pages.common import heading, open_path, status_icon
from app.gui.review_dialog import ReviewDialog
from app.gui.step_editor import StepEditorDialog
from app.gui.palette_dialog import PaletteDialog
from app.gui.workers import PlayWorker
from core import review, testfile
from core.reports.report import write_report

from app.gui.retry_dialog import RetryDialog
from app.gui.theme import status_color
from PySide6.QtWidgets import QFileDialog, QInputDialog

COLORS = {k: status_color(k) for k in ("passed", "failed", "skipped", "aborted", "cancelled")}


class LibraryPage(QWidget):
    def __init__(self):
        super().__init__()
        self.setObjectName("page")
        self.worker: PlayWorker | None = None
        self.items: list[dict] = []
        self.last_run: dict | None = None

        lay = QVBoxLayout(self)
        lay.setContentsMargins(28, 24, 28, 24)
        lay.addWidget(heading("Tests", "Recorded tests and imported Ranorex tests. Playback finds each element again by "
                                       "UI Automation, image, text or AI and checks your validation points."))
        bar = QHBoxLayout()
        self.run_btn = QPushButton("▶  Run")
        self.run_btn.setProperty("kind", "primary")
        self.run_btn.clicked.connect(lambda: self.run_selected(False))
        self.dry_btn = QPushButton("Dry run")
        self.dry_btn.setToolTip("Walk through the steps without touching the mouse or keyboard")
        self.dry_btn.clicked.connect(lambda: self.run_selected(True))
        self.data_btn = QPushButton("Data file…")
        self.data_btn.setToolTip("Run the selected test once per row of a CSV / XLSX / JSON file (columns become ${variables})")
        self.data_btn.clicked.connect(self.run_with_data)
        self.pause_btn = QPushButton("⏸  Pause")
        self.pause_btn.setToolTip("Pause after the current step; press again to resume with the next step")
        self.pause_btn.clicked.connect(self._pause_resume)
        self.pause_btn.setEnabled(False)
        self.stop_btn = QPushButton("■  Stop")
        self.stop_btn.setProperty("kind", "warning")
        self.stop_btn.setToolTip("Finish safely after the current step and keep the partial report")
        self.stop_btn.clicked.connect(self._abort)
        self.stop_btn.setEnabled(False)
        self.cancel_btn = QPushButton("✕  Cancel")
        self.cancel_btn.setProperty("kind", "danger")
        self.cancel_btn.setToolTip("Abort the run now; the report is marked cancelled")
        self.cancel_btn.clicked.connect(self._cancel)
        self.cancel_btn.setEnabled(False)
        self.edit_btn = QPushButton("Edit validations")
        self.edit_btn.clicked.connect(self.edit_selected)
        self.edit_steps_btn = QPushButton("Edit steps")
        self.edit_steps_btn.clicked.connect(self.edit_steps)
        self.add_step_btn = QPushButton("Add step…")
        self.add_step_btn.setToolTip("Add any step from the palette: calculate, call another test, API / command / database, checks ...")
        self.add_step_btn.clicked.connect(self.add_step)
        self.patterns_btn = QPushButton("What does it do?")
        self.patterns_btn.setToolTip("Explain the recording in plain words and turn repeated actions into a loop")
        self.patterns_btn.clicked.connect(self.show_patterns)
        self.restore_btn = QPushButton("Restore pre-heal backup")
        self.restore_btn.setToolTip("Restore the latest test.json backup created before a self-healing update")
        self.restore_btn.clicked.connect(self.restore_heal_backup)
        self.del_btn = QPushButton("Delete")
        self.del_btn.clicked.connect(self.delete_selected)
        self.rep_btn = QPushButton("Open last report")
        self.rep_btn.clicked.connect(self.open_report)
        self.rep_btn.setEnabled(False)
        for b in (self.run_btn, self.dry_btn, self.data_btn, self.pause_btn, self.stop_btn, self.cancel_btn,
                  self.edit_btn, self.edit_steps_btn, self.add_step_btn, self.patterns_btn, self.restore_btn, self.del_btn):
            bar.addWidget(b)
        bar.addStretch(1)
        bar.addWidget(self.rep_btn)
        lay.addLayout(bar)

        self.table = QTableWidget(0, 5)
        self.table.setHorizontalHeaderLabels(["Name", "Type", "Steps", "Created", ""])
        self.table.verticalHeader().setVisible(False)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.itemSelectionChanged.connect(self._update_restore_button)
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        self.table.doubleClicked.connect(lambda *_: self.run_selected(False))
        lay.addWidget(self.table, 3)

        self.summary = QLabel("")
        self.summary.setObjectName("muted")
        lay.addWidget(self.summary)
        self.results = QListWidget()
        lay.addWidget(self.results, 2)
        self.refresh()

    def _update_restore_button(self) -> None:
        it = self._selected()
        self.edit_steps_btn.setEnabled(bool(it and it["kind"] == "native"))
        self.add_step_btn.setEnabled(bool(it and it["kind"] == "native"))
        self.patterns_btn.setEnabled(bool(it and it["kind"] == "native"))
        self.restore_btn.setEnabled(bool(it and it["kind"] == "native"
                                         and (Path(it["dir"]) / "test.json.bak").is_file()))

    # ------------------------------------------------------------------
    def refresh(self) -> None:
        self.items = testfile.list_runnable()
        self.table.setRowCount(len(self.items))
        for r, it in enumerate(self.items):
            kind = {"native": "Recorded", "ranorex": "Ranorex script", "uft": "UFT script"}.get(it["kind"], it["kind"])
            if it["kind"] == "native" and it.get("recovered"):
                kind += " (recovered)"
            for c, v in enumerate([it.get("title") or it["name"], kind, str(it["steps"] or ""), it["created_at"][:16].replace("T", " ")]):
                self.table.setItem(r, c, QTableWidgetItem(v))
        self._update_restore_button()

    def _selected(self) -> dict | None:
        rows = sorted({i.row() for i in self.table.selectedIndexes()})
        return self.items[rows[0]] if rows else None

    def select_by_name(self, name: str) -> None:
        for r, it in enumerate(self.items):
            if it["name"] == name:
                self.table.selectRow(r)

    # ------------------------------------------------------------------ run
    def run_with_data(self) -> None:
        it = self._selected()
        if not it or it.get("kind") != "native":
            QMessageBox.information(self, "Data file", "Select a recorded test first.")
            return
        path, _ = QFileDialog.getOpenFileName(self, "Choose a data file", "", "Data (*.csv *.tsv *.xlsx *.xlsm *.json)")
        if not path:
            return
        rows, ok = QInputDialog.getText(self, "Rows to run", "Rows (e.g. 1-3,5,8-). Leave empty for all rows:")
        if ok:
            self.run_selected(False, data=path, data_select=rows.strip() or None)

    def run_selected(self, dry: bool, data=None, data_select=None) -> None:
        it = self._selected()
        if not it:
            QMessageBox.information(self, "Tests", "Select a test first.")
            return
        if self.worker and self.worker.isRunning():
            return
        if it.get("kind") == "native" and not dry:
            # Show invalid application references BEFORE anything is launched.
            try:
                from core import validation

                test, _ = testfile.load_test(it["name"])
                problems = validation.errors_only(validation.validate_test(test))
            except Exception as e:  # noqa: BLE001 - an unreadable test is reported, not run
                problems = [{"level": "error", "message": f"Test could not be loaded: {e}"}]
            if problems:
                QMessageBox.warning(self, "Test is not valid",
                                    "Fix these before running:\n\n" + "\n".join("- " + p["message"] for p in problems[:12]))
                return
        self.results.clear()
        self.summary.setText(f"Running '{it['name']}'..." + ("  (dry run)" if dry else ""))
        self.run_btn.setEnabled(False)
        self.dry_btn.setEnabled(False)
        self.data_btn.setEnabled(False)
        self.stop_btn.setEnabled(True)
        self.cancel_btn.setEnabled(True)
        self.worker = PlayWorker(it, dry, data=data, data_select=data_select)
        self.pause_btn.setEnabled(self.worker.supports_pause and not dry)
        self.pause_btn.setText("⏸  Pause")
        self.worker.state_changed.connect(self._on_state)
        self.worker.retry_question.connect(self._on_retry_question)
        self.worker.step.connect(self._on_step)
        self.worker.finished_run.connect(self._on_finished)
        self.worker.failed.connect(self._on_failed)
        if not dry:
            self.window().showMinimized()       # get out of the way of the application under test
        self.worker.start()

    def _on_step(self, r: dict) -> None:
        if r.get("status") == "running":
            self.summary.setText(f"Step {r['id']}: {r.get('description', '')}")
            return
        text = f"{status_icon(r['status'])}  {r['id']:>3}.  {r.get('description', '')}"
        if r.get("method"):
            text += f"    [{r['method']}]"
        item = QListWidgetItem(text)
        item.setForeground(QColor(COLORS.get(r["status"], "#e6e9ef")))
        self.results.addItem(item)
        for v in r.get("validations", []):
            sub = QListWidgetItem(f"        {status_icon(v['status'])} check: {v['description']}"
                                  + (f"  ({v['detail']})" if v.get("detail") else ""))
            sub.setForeground(QColor(COLORS.get(v["status"], "#e6e9ef")))
            self.results.addItem(sub)
        for h in r.get("retry_history") or []:
            ri = QListWidgetItem(f"        ↻ retry {h.get('attempt')}: {h.get('decision', '-')} ({h.get('via', '-')}) → {h.get('result', '-')}")
            ri.setForeground(QColor(status_color("aborted")))
            self.results.addItem(ri)
        if r.get("error"):
            err = QListWidgetItem("        " + r["error"])
            err.setForeground(QColor(status_color("failed")))
            self.results.addItem(err)
        self.results.scrollToBottom()

    def _on_state(self, state: str) -> None:
        """Keep the buttons consistent with the run controller's state."""
        paused = state == "paused"
        self.pause_btn.setText("▶  Resume" if paused else "⏸  Pause")
        if state in ("stopping", "cancelling"):
            self.pause_btn.setEnabled(False)
            self.stop_btn.setEnabled(False)
            self.summary.setText("Stopping… finishing the current step." if state == "stopping" else "Cancelling…")
        elif paused:
            self.summary.setText("Paused. Press Resume to continue with the next step.")

    def _pause_resume(self) -> None:
        w = self.worker
        if w and w.isRunning():
            w.resume() if w.controller.state == "paused" else w.pause()

    def _cancel(self) -> None:
        if self.worker and self.worker.isRunning():
            self.worker.cancel()

    def _on_retry_question(self, payload: dict) -> None:
        w = self.worker
        if not w:
            return
        from core import settings as _settings

        win = self.window()
        win.showNormal()
        win.raise_()
        win.activateWindow()
        dlg = RetryDialog(payload, _settings.load().get("retry_timeout_action", "retry"), self)
        dlg.exec()
        w.answer_retry(dlg.choice)
        if not w.controller.should_stop() and not self.dry_btn.isEnabled():
            win.showMinimized()

    def shutdown(self, timeout_ms: int = 15000) -> bool:
        """Called when the application closes: cancel an active run and wait for the worker. True = nothing left running."""
        w = self.worker
        if not w or not w.isRunning():
            return True
        w.cancel()
        return bool(w.wait(timeout_ms))

    def _done_ui(self) -> None:
        self.run_btn.setEnabled(True)
        self.dry_btn.setEnabled(True)
        self.data_btn.setEnabled(True)
        self.pause_btn.setEnabled(False)
        self.pause_btn.setText("⏸  Pause")
        self.cancel_btn.setEnabled(False)
        self.stop_btn.setEnabled(False)
        win = self.window()
        win.showNormal()
        win.raise_()
        win.activateWindow()

    def _on_finished(self, run: dict) -> None:
        self._done_ui()
        self.last_run = run
        self.rep_btn.setEnabled(True)
        s = run["summary"]
        self.summary.setText(f"{run['status'].upper()}: {s['passed']}/{s['total']} steps passed, "
                             f"{s['validations'] - s['validations_failed']}/{s['validations']} validations ok, "
                             f"{s['healed']} self-healed")

    def _on_failed(self, msg: str) -> None:
        self._done_ui()
        self.summary.setText("")
        QMessageBox.critical(self, "Run", msg)

    def _abort(self) -> None:
        if self.worker:
            self.worker.abort()

    def open_report(self) -> None:
        if self.last_run:
            from pathlib import Path

            d = Path(self.last_run["_dir"])
            open_path(d / "report.html" if (d / "report.html").exists() else write_report(d))

    # ------------------------------------------------------------------ edit / delete
    def edit_selected(self) -> None:
        it = self._selected()
        if not it or it["kind"] != "native":
            QMessageBox.information(self, "Tests", "Select a recorded test (scripts are edited as .py files).")
            return
        test, directory = testfile.load_test(it["name"])
        from core.ai.analyze import suggest_validations

        suggest_validations(test)
        if ReviewDialog(test, str(directory), self).exec():
            self.refresh()

    def edit_steps(self) -> None:
        it = self._selected()
        if not it or it["kind"] != "native":
            QMessageBox.information(self, "Edit steps", "Select a recorded test first.")
            return
        test, directory = testfile.load_test(it["name"])
        if StepEditorDialog(test, directory, self).exec():
            self.refresh()
            self.select_by_name(it["name"])

    def add_step(self) -> None:
        it = self._selected()
        if not it or it["kind"] != "native":
            QMessageBox.information(self, "Add step", "Select a recorded test first.")
            return
        test, directory = testfile.load_test(it["name"])
        dlg = PaletteDialog(test, directory, self)
        dlg.exec()
        if dlg.added:
            self.refresh()
            self.select_by_name(it["name"])

    def show_patterns(self) -> None:
        it = self._selected()
        if not it or it["kind"] != "native":
            QMessageBox.information(self, "What does it do?", "Select a recorded test first.")
            return
        from core.recorder import patterns
        test, directory = testfile.load_test(it["name"])
        found = patterns.analyze(test.get("steps") or [])
        if not found:
            QMessageBox.information(self, "What does it do?", "A plain sequence of actions - nothing repeated or form-like was found.")
            return
        text = "\n".join(f"{n}. steps {f['start'] + 1}-{f['start'] + f['length'] * f.get('repeats', 1)}: {f['title']}"
                         for n, f in enumerate(found, 1))
        loops = [f for f in found if f["kind"] == "repeated_block"]
        if loops and QMessageBox.question(self, "What does it do?", text + f"\n\nTurn '{loops[0]['title']}' into a loop over its values?") \
                == QMessageBox.StandardButton.Yes:
            testfile.save_test(patterns.apply_data_loop(test, loops[0]), directory)
            self.refresh()
            self.select_by_name(it["name"])
        elif not loops:
            QMessageBox.information(self, "What does it do?", text)

    def delete_selected(self) -> None:
        it = self._selected()
        if not it or it["kind"] != "native":
            return
        if QMessageBox.question(self, "Delete", f"Delete test '{it['name']}' and its screenshots?") \
                == QMessageBox.StandardButton.Yes:
            testfile.delete_test(it["name"])
            self.refresh()

    def restore_heal_backup(self) -> None:
        it = self._selected()
        if not it or it["kind"] != "native" or not (Path(it["dir"]) / "test.json.bak").is_file():
            QMessageBox.information(self, "Restore backup", "Select a recorded test with a self-heal backup first.")
            return
        if QMessageBox.question(self, "Restore backup", f"Restore the previous locator state for '{it['name']}'?") \
                != QMessageBox.StandardButton.Yes:
            return
        try:
            testfile.restore_backup(it["name"])
        except Exception as exc:
            QMessageBox.critical(self, "Restore backup", f"Could not restore the test backup:\n{exc}")
            return
        self.refresh()
        self.select_by_name(it["name"])
