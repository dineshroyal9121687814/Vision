"""Dashboard: every number is computed from the tests and runs on disk (core.analytics). Nothing is sample data."""
from __future__ import annotations

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (QGridLayout, QHBoxLayout, QLabel, QListWidget, QListWidgetItem, QPushButton, QScrollArea,
                               QVBoxLayout, QWidget)

from app.gui import design
from app.gui.pages.common import fmt_duration, heading, status_icon
from core import ai_assistant, analytics


class DashboardPage(QWidget):
    record_clicked = Signal()
    navigate = Signal(str)                         # a module key, e.g. "execution", "ai"

    def __init__(self):
        super().__init__()
        self.setObjectName("page")
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(scroll.Shape.NoFrame)
        outer.addWidget(scroll)
        body = QWidget()
        body.setObjectName("page")
        design.page_background(body)
        scroll.setWidget(body)
        self.lay = QVBoxLayout(body)
        self.lay.setContentsMargins(28, 24, 28, 24)
        self.lay.setSpacing(14)
        self.lay.addWidget(heading("Dashboard", "Live numbers from your workspace: tests, executions and results. Empty until you record and run."))

        actions = QHBoxLayout()
        for text, kind, slot in (("●  Record a test", "primary", self.record_clicked.emit),
                                 ("▶  Run tests", "", lambda: self.navigate.emit("execution")),
                                 ("✦  AI Assistant", "", lambda: self.navigate.emit("ai")),
                                 ("Open reports", "ghost", lambda: self.navigate.emit("reports"))):
            b = QPushButton(text)
            if kind:
                b.setProperty("kind", kind)
            b.clicked.connect(slot)
            actions.addWidget(b)
        actions.addStretch(1)
        self.lay.addLayout(actions)

        self.kpis = QHBoxLayout()
        self.kpis.setSpacing(12)
        self.lay.addLayout(self.kpis)

        mid = QHBoxLayout()
        mid.setSpacing(12)
        f1, l1 = design.card("Executions - last 14 days")
        self.trend = design.TrendChart()
        l1.addWidget(self.trend)
        c0 = design.colors()
        legend = QLabel(f"<span style='color:{c0['OK']}'>■</span> passed &nbsp;&nbsp; <span style='color:{c0['BAD']}'>■</span> failed")
        legend.setTextFormat(Qt.TextFormat.RichText)
        self.trend_legend = legend
        l1.addWidget(legend)
        mid.addWidget(f1, 3)
        f2, l2 = design.card("Latest result per test")
        row = QHBoxLayout()
        self.donut = design.DonutChart()
        row.addWidget(self.donut)
        self.legend = QLabel()
        self.legend.setTextFormat(Qt.TextFormat.RichText)
        row.addWidget(self.legend, 1)
        l2.addLayout(row)
        mid.addWidget(f2, 2)
        self.lay.addLayout(mid)

        grid = QGridLayout()
        grid.setSpacing(12)
        self.recent = QListWidget()
        self.attention = QListWidget()
        self.apps = QListWidget()
        self.fails = QListWidget()
        for i, (title, w) in enumerate((("Recent executions", self.recent), ("Needs attention", self.attention),
                                        ("Application health", self.apps), ("Most frequent failures", self.fails))):
            f, l = design.card(title)
            w.setMinimumHeight(150)
            l.addWidget(w)
            grid.addWidget(f, i // 2, i % 2)
        self.lay.addLayout(grid)
        self.lay.addStretch(1)
        self.refresh()

    # ------------------------------------------------------------------
    def refresh(self) -> None:
        try:
            s = analytics.snapshot()
        except Exception as e:                      # a corrupt run file must not blank the home page
            s = analytics.snapshot([], [])
            self.attention.clear()
            self.attention.addItem(f"Could not read some results: {e}")
        while self.kpis.count():
            w = self.kpis.takeAt(0).widget()
            if w:
                w.setParent(None)
                w.deleteLater()
        rate = "-" if s["success_rate"] is None else f"{s['success_rate']:g}%"
        tone = "accent" if s["success_rate"] is None else ("ok" if s["success_rate"] >= 90 else "warn" if s["success_rate"] >= 70 else "bad")
        for title, value, t, hint in (
                ("Tests", str(s["tests"]), "accent", f"{s['never_run']} never run"),
                ("Executions", str(s["executions"]), "info", "real runs (dry runs excluded)"),
                ("Success rate", rate, tone, "last 50 runs"),
                ("Failing now", str(s["failed"]), "bad" if s["failed"] else "ok", "latest result failed"),
                ("Self-healed", str(s["healed"]), "info", "locators repaired - review them"),
                ("Avg duration", fmt_duration(s["avg_duration_ms"]) if s["executions"] else "-", "info", "per execution")):
            self.kpis.addWidget(design.kpi(title, value, t, hint))
        self.trend.set_days(s["trend"])
        c = design.colors()
        parts = [("Passed", s["passed"], c["OK"]), ("Failed", s["failed"], c["BAD"]), ("Skipped / stopped", s["skipped"], c["WARN"]),
                 ("Never run", s["never_run"], c["MUTED"])]
        self.donut.set_parts(parts)
        self.legend.setText("<br>".join(f"<span style='color:{col}'>■</span> {n}: <b>{v}</b>" for n, v, col in parts))

        self.recent.clear()
        for r in s["recent_runs"]:
            tag = "  (dry run)" if r.get("dry_run") else ""
            self.recent.addItem(f"{status_icon(r.get('status', ''))}  {r.get('test')}   {r.get('passed', 0)}/{r.get('total', 0)} steps   "
                                f"{fmt_duration(r.get('duration_ms'))}   {r.get('started_at', '')[:16].replace('T', ' ')}{tag}")
        if not s["recent_runs"]:
            self.recent.addItem("No executions yet. Record a test and press Run.")

        self.attention.clear()
        for x in ai_assistant.regression_suggestions(analytics.manage.list_reports())[:10]:
            self.attention.addItem(f"{x['test']}: {x['reason']}")
        if not self.attention.count():
            self.attention.addItem("Nothing needs attention.")

        self.apps.clear()
        for a in s["app_health"][:10]:
            self.apps.addItem(f"{a['app']}: {a['pass_rate']:g}% passed over {a['runs']} run(s)")
        if not s["app_health"]:
            self.apps.addItem("Application results appear after tests that open applications have run.")

        self.fails.clear()
        for f in s["failed_insights"]:
            it = QListWidgetItem(f"{f['count']}x  {f['test']} - step {f['step']}: {f['description']}  [{f['category']}]")
            it.setToolTip(f["last_error"])
            self.fails.addItem(it)
        if not s["failed_insights"]:
            self.fails.addItem("No failed steps in recent runs.")
