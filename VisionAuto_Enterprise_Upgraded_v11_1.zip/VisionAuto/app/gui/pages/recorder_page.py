from __future__ import annotations

from PySide6.QtCore import Signal
from PySide6.QtWidgets import (QWidget, QHBoxLayout, QLabel, QLineEdit, QListWidget, QMessageBox, QProgressBar,
                               QPushButton, QVBoxLayout)

from app.gui.pages.common import heading
from app.gui.recorder_bar import RecorderBar
from app.gui.review_dialog import ReviewDialog
from app.gui.workers import FinishRecordingWorker, RecordingSession
from core import testfile


class RecorderPage(QWidget):
    test_saved = Signal(str, bool)       # test name, run it now?

    def __init__(self):
        super().__init__()
        self.setObjectName("page")
        self.session: RecordingSession | None = None
        self.bar: RecorderBar | None = None
        self.worker: FinishRecordingWorker | None = None
        self._finishing = False

        lay = QVBoxLayout(self)
        lay.setContentsMargins(28, 24, 28, 24)
        lay.addWidget(heading(
            "Record",
            "Name the test, press Start, then use your application normally. Clicks, double and right clicks, drag and "
            "drop, scrolling, typing and shortcuts are recorded together with the window and the exact control you "
            "touched. Stop with the red button on the floating bar (or F9)."))
        row = QHBoxLayout()
        self.name = QLineEdit()
        self.name.setPlaceholderText("Test name, e.g. Create invoice")
        self.start_btn = QPushButton("●  Start recording")
        self.start_btn.setProperty("kind", "primary")
        self.start_btn.clicked.connect(self.start)
        row.addWidget(self.name, 1)
        row.addWidget(self.start_btn)
        lay.addLayout(row)
        self.status = QLabel("")
        self.status.setObjectName("muted")
        lay.addWidget(self.status)
        self.progress = QProgressBar()
        self.progress.setRange(0, 100)
        self.progress.hide()
        lay.addWidget(self.progress)
        self.log = QListWidget()
        lay.addWidget(self.log, 1)

    # ------------------------------------------------------------------ start
    def start(self) -> None:
        name = self.name.text().strip()
        if not name:
            QMessageBox.information(self, "Record", "Give the test a name first.")
            return
        overwrite = False
        if (testfile.test_dir(name) / "test.json").exists():
            if QMessageBox.question(self, "Record", f"A test named '{name}' already exists. Replace it?") \
                    != QMessageBox.StandardButton.Yes:
                return
            overwrite = True
        self.log.clear()
        try:
            self.session = RecordingSession(name, overwrite)
            self.session.step.connect(self._on_step)
            self.session.stop_requested.connect(self.stop)
            self.session.start()
        except Exception as e:
            QMessageBox.critical(self, "Record", f"Could not start recording:\n{e}")
            self.session = None
            return
        self._finishing = False
        self.bar = RecorderBar()
        self.bar.pause_toggled.connect(lambda p: self.session.rec.pause() if p else self.session.rec.resume())
        self.bar.validate_clicked.connect(lambda: self.session.rec.add_validation())
        self.bar.stop_clicked.connect(self.stop)
        self.bar.place_top_center()
        self.bar.show()
        self.start_btn.setEnabled(False)
        self.status.setText(f"Recording '{name}'...")
        self.window().showMinimized()

    def _on_step(self, step: dict) -> None:
        self.log.addItem(f"{step['id']:>3}.  {step['description']}")
        self.log.scrollToBottom()
        if self.bar:
            self.bar.on_step(step)

    # ------------------------------------------------------------------ stop + analyse
    def stop(self) -> None:
        if not self.session or self._finishing:
            return
        self._finishing = True
        if self.bar:
            self.bar.set_busy("Saving the recording...")
        self.worker = FinishRecordingWorker(self.session)
        self.worker.progress.connect(self._on_progress)
        self.worker.done.connect(self._on_done)
        self.worker.failed.connect(self._on_failed)
        self.worker.start()

    def _on_progress(self, msg: str, frac: float) -> None:
        self.progress.show()
        self.progress.setValue(int(frac * 100))
        self.status.setText(msg)
        if self.bar:
            self.bar.last.setText(msg)

    def _cleanup(self) -> None:
        if self.bar:
            self.bar.close()
            self.bar = None
        self.session = None
        self.progress.hide()
        self.start_btn.setEnabled(True)
        win = self.window()
        win.showNormal()
        win.raise_()
        win.activateWindow()

    def _on_failed(self, msg: str) -> None:
        self._cleanup()
        self.status.setText("")
        QMessageBox.critical(self, "Record", f"Could not finish the recording:\n{msg}\n\n"
                                             "The steps captured so far are saved in your workspace and can be recovered.")

    def _on_done(self, test: dict, directory: str) -> None:
        self._cleanup()
        self.status.setText(f"Recorded {len(test['steps'])} steps. Review them and choose the validation points.")
        if not test["steps"]:
            QMessageBox.information(self, "Record", "Nothing was recorded.")
            return
        dlg = ReviewDialog(test, directory, self)
        if dlg.exec():
            self.status.setText(f"Saved '{test['name']}'.")
            self.test_saved.emit(test["name"], dlg.run_after)
        elif dlg.discarded:
            testfile.delete_test(test["name"])
            self.status.setText("Recording discarded.")
        else:
            # Closing the review window is not consent to delete the recording.
            # Persist the captured steps without unchecked suggestions, then
            # surface the test in the library so the user can review it later.
            from core import review

            review.finalize(test, directory, accepted={}, title=dlg.title.text().strip() or None)
            self.status.setText(f"Saved '{test['name']}' without validation points.")
            self.test_saved.emit(test["name"], False)
