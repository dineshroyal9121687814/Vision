"""VisionAuto desktop app:  python -m app   (or python app/main.py)"""
from __future__ import annotations

import logging
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from core import paths  # noqa: E402


def _preload_input_hooks():
    """Import pynput before Qt/Torch install competing import hooks on Windows."""
    from pynput import keyboard, mouse

    return keyboard, mouse


def _dependency_error(exc: ModuleNotFoundError) -> int:
    missing = exc.name or "a required package"
    message = (
        f"VisionAuto cannot start because '{missing}' is not installed.\n"
        f"Install the project dependencies with:\n"
        f"  {sys.executable} -m pip install -r requirements.txt"
    )
    logging.getLogger("visionauto.app").error(message, exc_info=exc)
    print(message, file=sys.stderr)
    return 1


def main() -> int:
    paths.setup_logging()
    log = logging.getLogger("visionauto.app")
    try:
        # PySide's shiboken importer can conflict with six.moves when pynput is
        # imported after Torch has patched inspect (EasyOCR loads Torch).
        _preload_input_hooks()
        from PySide6.QtWidgets import QApplication, QMessageBox

        from app.gui.main_window import MainWindow
        from app.gui.theme import stylesheet
        from core import settings
    except ModuleNotFoundError as exc:
        return _dependency_error(exc)

    app = QApplication(sys.argv)
    app.setApplicationName("VisionAuto")
    try:
        theme = settings.load().get("theme", "dark")
    except Exception:  # noqa: BLE001 - a bad settings file must not stop the app starting
        theme = "dark"
    from app.gui import design

    design.set_theme(theme)
    app.setStyleSheet(stylesheet(theme))

    def hook(exc_type, exc, tb):
        log.error("unhandled error", exc_info=(exc_type, exc, tb))
        QMessageBox.critical(None, "VisionAuto", f"{exc_type.__name__}: {exc}\n\nDetails are in workspace/logs/visionauto.log")

    sys.excepthook = hook
    win = MainWindow()
    win.resize(1180, 760)
    win.show()
    from PySide6.QtCore import QTimer
    QTimer.singleShot(1500, win.offer_ai_setup)
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
