"""Window identification: which window does a step operate in?  (pure - the window list is injected)

A *window spec* is stored with every step (``step["window"]``) and may contain::

    title            recorded title (legacy field, always present)
    match            "exact" | "contains" | "regex"      how ``title`` is compared   (default: contains)
    process          "notepad.exe"                       application / process name
    exe              "C:\\Windows\\System32\\notepad.exe"   executable path where known
    pid / hwnd       runtime HINTS only - they are tried first but never trusted alone (a recycled HWND / PID may
                     now belong to another window), so they must also satisfy the other criteria that are set
    main_window      True -> "the primary window of the configured application" instead of a title
    owner_title      title of the owning window (pop-ups, dialogs)
    popup / kind     recorded window kind

``resolve_window`` never guesses: several candidates -> ``status="ambiguous"`` with the list, so the caller can ask.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field

MATCH_MODES = ("exact", "contains", "regex")


@dataclass
class WindowSpec:
    title: str = ""
    match: str = "contains"
    process: str = ""
    exe: str = ""
    pid: int = 0
    hwnd: int = 0
    main_window: bool = False
    owner_title: str = ""
    popup: bool = False
    explicit: bool = False        # True when the user chose match/process/main_window (not just a recorded title)

    @classmethod
    def from_dict(cls, d: dict | None) -> "WindowSpec":
        d = d or {}
        match = str(d.get("match") or "contains").lower()
        if match not in MATCH_MODES:
            raise ValueError(f"window match must be one of {', '.join(MATCH_MODES)} (got {match!r})")
        spec = cls(title=str(d.get("title") or ""), match=match, process=str(d.get("process") or ""),
                   exe=str(d.get("exe") or ""), pid=int(d.get("pid") or 0), hwnd=int(d.get("hwnd") or 0),
                   main_window=bool(d.get("main_window")), owner_title=str(d.get("owner_title") or ""),
                   popup=bool(d.get("popup")),
                   explicit=bool(d.get("match") or d.get("main_window") or d.get("window_target") == "specific"))
        if spec.match == "regex" and spec.title:
            try:
                re.compile(spec.title)
            except re.error as exc:
                raise ValueError(f"window title regular expression is invalid: {exc}") from exc
        return spec

    def describe(self) -> str:
        if self.main_window:
            return f"main window of {self.process or self.exe or 'the configured application'}"
        bits = []
        if self.title:
            bits.append(f"title {self.match} {self.title!r}")
        if self.process:
            bits.append(f"process {self.process}")
        if self.exe:
            bits.append(f"exe {self.exe}")
        return ", ".join(bits) or "any window"


@dataclass
class WindowMatch:
    status: str                       # unique | ambiguous | none
    windows: list = field(default_factory=list)
    reason: str = ""
    how: str = ""

    @property
    def window(self):
        return self.windows[0] if self.status == "unique" else None


def validate_spec(spec: WindowSpec) -> list[str]:
    """Problems that make a window target unusable (shown in the Target Configuration panel)."""
    errs = []
    if spec.main_window and not (spec.process or spec.exe):
        errs.append("Main Window needs an application (process name or executable path)")
    if not spec.main_window and not (spec.title or spec.process or spec.exe or spec.pid or spec.hwnd):
        errs.append("choose a window: title, application or Main Window")
    return errs


def _title_ok(spec: WindowSpec, title: str) -> bool:
    if not spec.title:
        return True
    t = str(title or "")
    if spec.match == "exact":
        return t.casefold() == spec.title.casefold()
    if spec.match == "regex":
        return re.search(spec.title, t, re.IGNORECASE) is not None
    return spec.title.casefold() in t.casefold()


def _proc_ok(spec: WindowSpec, w: dict) -> bool:
    if spec.process and str(w.get("process") or "").casefold() != spec.process.casefold():
        return False
    if spec.exe and w.get("exe") and str(w["exe"]).casefold() != spec.exe.casefold():
        return False
    return True


def is_main_candidate(w: dict) -> bool:
    """A window that can be an application's primary window: visible, titled, not a pop-up/tool window, no owner."""
    return bool(w.get("title")) and not w.get("popup") and not w.get("owner") and not w.get("tool") \
        and w.get("visible", True)


def _area(w: dict) -> int:
    r = w.get("rect")
    return max(0, (r[2] - r[0]) * (r[3] - r[1])) if r and len(r) == 4 else 0


def resolve_window(spec: WindowSpec, windows: list[dict], foreground_hwnd: int = 0) -> WindowMatch:
    """Choose ONE window from ``windows`` (dicts: hwnd, title, process, exe?, pid?, rect?, owner?, popup?, tool?, visible?).

    Order of evidence: hwnd/pid hints (only if the window still satisfies the other criteria) -> criteria -> for
    legacy title-only specs, the already-active window.  Never picks "the first one".
    """
    vis = [w for w in windows if w.get("visible", True)]
    if spec.main_window:
        pool = [w for w in vis if _proc_ok(spec, w) and is_main_candidate(w)]
        if spec.pid:
            narrowed = [w for w in pool if int(w.get("pid") or 0) == spec.pid]
            pool = narrowed or pool
        if not pool:
            return WindowMatch("none", reason=f"no visible primary window for {spec.process or spec.exe}")
        if len(pool) == 1:
            return WindowMatch("unique", pool, how="main window")
        # several top-level windows of the application: prefer the one that is clearly the largest
        pool.sort(key=_area, reverse=True)
        if _area(pool[0]) >= 1.5 * max(1, _area(pool[1])):
            return WindowMatch("unique", [pool[0]], how="main window (largest of several)")
        if foreground_hwnd and any(int(w["hwnd"]) == foreground_hwnd for w in pool):
            fg = [w for w in pool if int(w["hwnd"]) == foreground_hwnd]
            return WindowMatch("unique", fg, how="main window (active one of several)")
        return WindowMatch("ambiguous", pool, reason=f"{len(pool)} top-level windows of {spec.process or spec.exe}; "
                                                      "select which one is the main window")
    pool = [w for w in vis if _title_ok(spec, w.get("title", "")) and _proc_ok(spec, w)]
    if not pool and not spec.explicit and spec.title:        # legacy recording: the process name is a hint, not a rule
        pool = [w for w in vis if _title_ok(spec, w.get("title", ""))]
    if spec.popup is False:
        non_popup = [w for w in pool if not w.get("popup")]
        pool = non_popup or pool
    if not pool:
        return WindowMatch("none", reason=f"no window matches {spec.describe()}")
    # runtime hints: trusted only because the window ALSO satisfies the criteria above
    for key in ("hwnd", "pid"):
        hint = getattr(spec, key)
        if hint:
            hit = [w for w in pool if int(w.get(key) or 0) == hint]
            if len(hit) == 1:
                return WindowMatch("unique", hit, how=f"{key} hint")
    if len(pool) == 1:
        return WindowMatch("unique", pool, how="criteria")
    if spec.owner_title:
        owned = [w for w in pool if spec.owner_title.casefold() in str(w.get("owner_title") or "").casefold()]
        if len(owned) == 1:
            return WindowMatch("unique", owned, how="owner")
    if not spec.explicit and foreground_hwnd:
        fg = [w for w in pool if int(w["hwnd"]) == foreground_hwnd]
        if len(fg) == 1:
            return WindowMatch("unique", fg, how="already active (legacy title match)")
    return WindowMatch("ambiguous", pool, reason=f"{len(pool)} windows match {spec.describe()}; select one or make the "
                                                  "title exact / add the application")


def summarize(w: dict) -> dict:
    return {k: w.get(k) for k in ("hwnd", "title", "process", "pid", "rect") if k in w}
