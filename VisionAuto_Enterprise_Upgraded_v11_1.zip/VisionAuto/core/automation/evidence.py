"""Evidence-based choice between look-alike candidates (pure functions, no UI, fully unit-testable).

A manual tester who sees two identical cells does not give up: he knows WHERE he clicked (the recorded spot, moved
with the window) and WHAT was there (its text). ``choose`` does the same: among candidates it keeps those whose text
does not contradict the recording, then takes the one nearest the recorded spot - but only if it is clearly nearer than
the runner-up. Anything less clear stays ambiguous (the caller refuses; it never guesses).
"""
from __future__ import annotations

import math
from dataclasses import dataclass


@dataclass
class Pick:
    index: int
    distance: float
    runner_up: float | None
    reason: str


def distance(a, b) -> float:
    return math.hypot(a[0] - b[0], a[1] - b[1])


def choose(points, recorded, tolerance: float, verdicts=None, margin: float = 2.0) -> Pick | None:
    """``points``: [(x, y), ...]; ``recorded``: (x, y); ``tolerance`` px; ``verdicts``: per-candidate True (text matches),
    False (text contradicts) or None (unknown). Returns the winner or None when the evidence is not decisive."""
    if recorded is None:
        return None
    ok = [i for i in range(len(points)) if not verdicts or verdicts[i] is not False]
    if not ok:
        return None
    confirmed = [i for i in ok if verdicts and verdicts[i] is True]
    pool = confirmed or ok
    dists = sorted((distance(points[i], recorded), i) for i in pool)
    best_d, best_i = dists[0]
    if best_d > tolerance:
        return None
    others = [d for d, _ in dists[1:]]
    # unknown-text candidates elsewhere still compete when none was positively confirmed
    runner = others[0] if others else None
    if confirmed:
        return Pick(best_i, best_d, runner, "text confirmed at the nearest look-alike" if runner is not None
                    else "the only candidate whose text matches")
    if runner is not None and runner < best_d * margin + 4:
        return None
    return Pick(best_i, best_d, runner, "nearest to the recorded position, clearly closer than the others")


def ring(point, step_x: float, step_y: float, radius: int = 2):
    """Neighbouring probe points around ``point`` (nearest first): one cell/row/button away, then two ..."""
    out = []
    for r in range(1, radius + 1):
        for dy in range(-r, r + 1):
            for dx in range(-r, r + 1):
                if max(abs(dx), abs(dy)) == r:
                    out.append((point[0] + dx * step_x, point[1] + dy * step_y))
    out.sort(key=lambda p: distance(p, point))
    return out
