"""Failure types of the strict execution pipeline.

``AmbiguousTarget`` and ``LowConfidenceTarget`` deliberately do NOT derive from ``ElementNotFound``: the Resolver's
locator tiers must never treat "several matches" as "not found, try the next (fuzzier) tier" - that fall-through is the
classic way an automation tool ends up pressing a different button than the one configured.
"""
from __future__ import annotations


class TargetError(Exception):
    """Base class: carries a machine readable ``detail`` dict for the step log / report."""

    def __init__(self, message: str, detail: dict | None = None):
        super().__init__(message)
        self.detail = dict(detail or {})


class AmbiguousTarget(TargetError):
    """More than one element/window satisfies the locator and nothing in the configuration separates them."""

    def __init__(self, message: str, candidates: list | None = None, detail: dict | None = None):
        super().__init__(message, detail)
        self.candidates = list(candidates or [])
        self.detail.setdefault("candidates", self.candidates)


class LowConfidenceTarget(TargetError):
    """A fuzzy tier (OCR / AI / self-heal / ORB) found something, but not with enough evidence to act on it."""

    def __init__(self, message: str, method: str = "", confidence: float = 0.0, detail: dict | None = None):
        super().__init__(message, detail)
        self.method = method
        self.confidence = confidence
        self.detail.update(method=method, confidence=round(float(confidence), 3))


class WrongTarget(TargetError):
    """The resolved element is not the one that was configured (identity check failed) or cannot be acted on."""


class WindowNotFound(TargetError):
    pass


class PostconditionFailed(TargetError):
    """The action was sent but the expected result did not occur."""
