"""Deterministic targeting layer: window identity, ambiguity guard, position maths, quadrant search, locator testing.

Everything here is pure (the OS is injected) so it is unit-testable on any platform; the Player/Resolver/winenv bind it
to Windows.  See docs/AUTOMATION_IMPLEMENTATION_REPORT.md.
"""
