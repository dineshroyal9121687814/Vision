"""Target guard: step 5/6 of the execution pipeline - *validate that what was resolved is what was configured*.

``vet`` is called with every Resolution.  It rejects (raising a ``TargetError`` subclass with details) rather than
letting a weak or mismatched result become a click.
"""
from __future__ import annotations

from core.automation.errors import LowConfidenceTarget, WrongTarget

# methods that are evidence of identity by themselves (the element itself was read back)
STRONG = ("native", "point", "excel", "xpath", "coordinates", "position", "anchor")
# fuzzy tiers: only acted on above the strict threshold
FUZZY_PREFIXES = ("xpath-heal", "orb", "ocr", "ai", "heal", "neighbour-image", "quadrant", "vision")
DEFAULTS = {"strict_targeting": True, "min_action_confidence": 0.85, "allow_blind_coordinates": False}


def _fuzzy(method: str) -> bool:
    m = str(method or "")
    return any(m == p or m.startswith(p + "(") or m.startswith(p) for p in FUZZY_PREFIXES)


def _norm(s) -> str:
    return " ".join(str(s or "").split()).casefold()


def identity_mismatch(evidence: dict, target: dict) -> str:
    """'' if the element that was found carries the configured identity, else why not.

    Only checked for natively resolved elements and only for the identity fields the user configured, and not when the
    user wrote an explicit XPath (an XPath is the user's own definition of identity)."""
    if not evidence or target.get("xpath") or target.get("rxpath"):
        return ""
    rid, got_id = str(target.get("automation_id") or ""), str(evidence.get("automation_id") or "")
    if rid and got_id and rid != got_id:
        return f"automation id is '{got_id}', configured '{rid}'"
    role, got_role = _norm(target.get("role")), _norm(evidence.get("role"))
    if role and got_role and role != got_role and not rid:
        return f"control type is '{evidence.get('role')}', configured '{target.get('role')}'"
    return ""


def vet(res, target: dict, options: dict, window_rect=None):
    """Return ``res`` if it may be acted on, else raise.  ``res`` is a playback ``Resolution``."""
    if not options.get("strict_targeting", DEFAULTS["strict_targeting"]):
        return res
    method = str(res.method or "")
    explicit_coords = target.get("locator_mode") in ("coordinates", "position")
    if method.startswith("coordinates(fallback)") and not (explicit_coords or options.get("allow_blind_coordinates")):
        raise LowConfidenceTarget(
            "Only the stored screen position was left; VisionAuto will not click a point it cannot tie to an element "
            "(enable 'allow blind coordinates' or use a position locator relative to the window).",
            method, res.confidence)
    if _fuzzy(method):
        need = float(options.get("min_action_confidence", DEFAULTS["min_action_confidence"]))
        if float(res.confidence) < need:
            raise LowConfidenceTarget(
                f"'{method}' found a candidate with confidence {res.confidence:.2f} (< {need:.2f}); not clicking a "
                "guess. Approve the healed locator in the Inspector or improve the locator.", method, res.confidence,
                {"evidence": res.evidence, "x": res.x, "y": res.y})
    why = identity_mismatch(res.evidence, target) if method in ("native", "point", "excel") else ""
    if why:
        raise WrongTarget(f"Resolved element does not match the configured target: {why}",
                          {"evidence": res.evidence, "method": method})
    if window_rect and method not in ("coordinates",) and not target.get("allow_outside_window"):
        l, t, r, b = window_rect
        if not (l - 2 <= res.x <= r + 2 and t - 2 <= res.y <= b + 2) and not target.get("window_is_popup"):
            raise WrongTarget(f"Resolved point ({res.x},{res.y}) is outside the target window {list(window_rect)}",
                              {"method": method})
    return res
