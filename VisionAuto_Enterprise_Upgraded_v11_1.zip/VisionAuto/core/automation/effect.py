"""Before / after evidence for one action: "did something actually happen where I acted?".

A manual tester looks at the spot, clicks, and looks again. ``Observation`` does the same: a small picture of the
region around the action before and after (cheap pixel comparison), and - for typing - OCR of that region to see the
typed text. Pure functions plus a thin wrapper over the player's frame grabber; nothing here sends input.
"""
from __future__ import annotations

import difflib
import re
from dataclasses import dataclass

import cv2
import numpy as np

DEFAULT_SIZE = (320, 200)
CHANGE_THRESHOLD = 0.006          # mean absolute grey difference (0..1) that counts as "the picture changed"


def region_around(point, frame_shape, size=DEFAULT_SIZE, origin=(0, 0)):
    """(x0, y0, x1, y1) in FRAME pixels around a screen point, clipped to the frame."""
    h, w = frame_shape[:2]
    cx, cy = int(point[0]) - origin[0], int(point[1]) - origin[1]
    x0, y0 = max(0, cx - size[0] // 2), max(0, cy - size[1] // 2)
    x1, y1 = min(w, cx + size[0] // 2), min(h, cy + size[1] // 2)
    return x0, y0, x1, y1


def crop(frame, rect):
    x0, y0, x1, y1 = rect
    return None if x1 - x0 < 4 or y1 - y0 < 4 else frame[y0:y1, x0:x1].copy()


def _gray(img):
    return cv2.cvtColor(img, cv2.COLOR_BGR2GRAY) if img.ndim == 3 else img


def difference(a, b) -> float:
    """0 = identical, 1 = completely different. Different sizes are compared after resizing."""
    if a is None or b is None:
        return 0.0
    ga, gb = _gray(a), _gray(b)
    if ga.shape != gb.shape:
        gb = cv2.resize(gb, (ga.shape[1], ga.shape[0]))
    return float(np.mean(np.abs(ga.astype(np.int16) - gb.astype(np.int16))) / 255.0)


def changed(a, b, threshold: float = CHANGE_THRESHOLD) -> bool:
    return difference(a, b) >= threshold


def _norm(s: str) -> str:
    return re.sub(r"[^0-9a-z]+", "", str(s).casefold())


def text_in(seen: str, wanted: str, min_ratio: float = 0.8) -> bool:
    """Is ``wanted`` in the OCR text ``seen``? Tolerates OCR slips (l/1, O/0) via a fuzzy window search."""
    w, s = _norm(wanted), _norm(seen)
    if not w:
        return True
    if w in s:
        return True
    if len(w) < 3 or len(s) < len(w) // 2:
        return False
    n = len(w)
    best = 0.0
    for i in range(0, max(1, len(s) - n + 1)):
        best = max(best, difflib.SequenceMatcher(None, w, s[i:i + n]).ratio())
        if best >= min_ratio:
            return True
    return False


@dataclass
class Effect:
    changed: bool
    difference: float
    retried: bool = False

    def as_dict(self) -> dict:
        return {"changed": self.changed, "difference": round(self.difference, 4), "retried": self.retried}
