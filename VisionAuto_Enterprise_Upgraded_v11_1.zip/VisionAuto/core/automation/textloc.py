"""Text locator: find ALL on-screen occurrences of a text (OCR boxes), with explicit match modes.

modes: exact | contains | startswith | regex | fuzzy        (+ ``case_sensitive`` flag, default insensitive)
``rank``/``unique_candidate`` implement "distinguish identical text in different containers": a container rectangle
filters candidates; when several remain and nothing separates them the answer is *ambiguous*, never "the first".
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from difflib import SequenceMatcher

MODES = ("exact", "contains", "startswith", "regex", "fuzzy")


@dataclass
class TextHit:
    x: int
    y: int
    confidence: float
    text: str
    rect: tuple


def _prep(s: str, cs: bool) -> str:
    s = " ".join(str(s or "").split())
    return s if cs else s.casefold()


def text_matches(candidate: str, wanted: str, mode: str = "contains", case_sensitive: bool = False,
                 fuzzy_ratio: float = 0.85) -> float:
    """0 = no match, else a similarity score in (0, 1]."""
    if mode not in MODES:
        raise ValueError(f"text match mode must be one of {', '.join(MODES)}")
    if mode == "regex":
        try:
            return 1.0 if re.search(wanted, str(candidate or ""), 0 if case_sensitive else re.IGNORECASE) else 0.0
        except re.error as exc:
            raise ValueError(f"invalid regular expression: {exc}") from exc
    c, w = _prep(candidate, case_sensitive), _prep(wanted, case_sensitive)
    if not c or not w:
        return 0.0
    if mode == "exact":
        return 1.0 if c == w else 0.0
    if mode == "startswith":
        return 1.0 if c.startswith(w) else 0.0
    if mode == "contains":
        return 1.0 if w in c else 0.0
    r = SequenceMatcher(None, w, c).ratio()
    return r if r >= fuzzy_ratio else 0.0


def find_all(frame, wanted: str, mode: str = "contains", case_sensitive: bool = False, min_confidence: float = 0.5,
             origin=(0, 0), results_fn=None) -> list[TextHit]:
    """OCR ``frame`` and return every box that matches (absolute coordinates = box centre + ``origin``)."""
    if results_fn is None:
        from core.ocr import ocr_engine
        results_fn = ocr_engine._results
    hits: list[TextHit] = []
    for bbox, text, conf in results_fn(frame):
        if bbox is None or conf < min_confidence:
            continue
        sim = text_matches(text, wanted, mode, case_sensitive)
        if sim <= 0:
            continue
        xs, ys = [p[0] for p in bbox], [p[1] for p in bbox]
        rect = (int(min(xs)) + origin[0], int(min(ys)) + origin[1], int(max(xs)) + origin[0], int(max(ys)) + origin[1])
        hits.append(TextHit((rect[0] + rect[2]) // 2, (rect[1] + rect[3]) // 2, float(conf) * (0.7 + 0.3 * sim), text, rect))
    return _merge(hits)


def _merge(hits: list[TextHit], radius: int = 10) -> list[TextHit]:
    out: list[TextHit] = []
    for h in sorted(hits, key=lambda h: -h.confidence):
        if all(abs(h.x - o.x) > radius or abs(h.y - o.y) > radius for o in out):
            out.append(h)
    return out


def in_rect(hit: TextHit, rect) -> bool:
    return rect[0] <= hit.x <= rect[2] and rect[1] <= hit.y <= rect[3]


def unique_candidate(hits: list[TextHit], container_rect=None):
    """-> (hit|None, candidates).  A container rect narrows the field first; >1 left => (None, candidates)."""
    cands = [h for h in hits if in_rect(h, container_rect)] if container_rect else list(hits)
    if len(cands) == 1:
        return cands[0], cands
    return None, cands
