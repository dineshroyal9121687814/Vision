"""Target Configuration: the per-step settings that make a step deterministic (GUI independent, fully testable).

cfg keys (all optional)::

    window_match        exact | contains | regex          how the window title is compared
    main_window         bool                              "Use Main Window" (needs process or exe)
    exe                 executable path
    container           {"name":..., "automation_id":..., "xpath":...}
    search_quadrant     "" | all | tl | tr | bl | br | "br,tl"      four-quadrant fallback (+ order)
    text_match          exact | contains | startswith | regex | fuzzy
    case_sensitive      bool
    position            {"mode": window|normalized|container|anchor|absolute, ...}   (explicit position locator)
    timeout_s           float
    require_unique      bool (default True)
"""
from __future__ import annotations

import re

from core.automation import position, quadrants, textloc
from core.automation import window_target as wt

WINDOW_MATCH = wt.MATCH_MODES
TEXT_MATCH = textloc.MODES
QUADRANT_CHOICES = ("", "all", "tl", "tr", "bl", "br")


def validate_config(cfg: dict, window: dict | None = None) -> list[str]:
    """Human-readable problems; empty list = usable."""
    errs: list[str] = []
    cfg = cfg or {}
    win = {**(window or {}), "match": cfg.get("window_match") or (window or {}).get("match") or "contains",
           "main_window": bool(cfg.get("main_window")), "exe": cfg.get("exe", (window or {}).get("exe", ""))}
    try:
        errs += wt.validate_spec(wt.WindowSpec.from_dict(win))
    except ValueError as exc:
        errs.append(str(exc))
    if cfg.get("text_match") and cfg["text_match"] not in TEXT_MATCH:
        errs.append(f"text match must be one of {', '.join(TEXT_MATCH)}")
    if cfg.get("text_match") == "regex" and cfg.get("_text"):
        try:
            re.compile(cfg["_text"])
        except re.error as exc:
            errs.append(f"text regular expression is invalid: {exc}")
    if cfg.get("search_quadrant"):
        try:
            quadrants.parse_order(cfg["search_quadrant"])
        except ValueError as exc:
            errs.append(str(exc))
    pos = cfg.get("position")
    if pos:
        if pos.get("mode") not in position.MODES:
            errs.append(f"position mode must be one of {', '.join(position.MODES)}")
        elif pos["mode"] == "container" and not (cfg.get("container") or {}):
            errs.append("a container-relative position needs a container")
        elif pos["mode"] == "anchor" and not pos.get("anchor"):
            errs.append("an anchor-relative position needs an anchor element")
    if cfg.get("timeout_s") is not None:
        try:
            if float(cfg["timeout_s"]) <= 0:
                errs.append("timeout must be positive")
        except (TypeError, ValueError):
            errs.append("timeout must be a number")
    return errs


def apply_config(step: dict, cfg: dict) -> dict:
    """Write the configuration into ``step`` (window context, container, quadrant, text match, position ...)."""
    cfg = cfg or {}
    win = dict(step.get("window") or {})
    if cfg.get("window_match"):
        win["match"] = cfg["window_match"]
    if cfg.get("main_window") is not None:
        if cfg["main_window"]:
            win["main_window"] = True
        else:
            win.pop("main_window", None)
    if cfg.get("exe"):
        win["exe"] = cfg["exe"]
    if win.get("match") or win.get("main_window"):
        win["window_target"] = "main" if win.get("main_window") else "specific"
    step["window"] = win
    tg = step.get("target")
    if isinstance(tg, dict):
        for key in ("container", "search_quadrant", "text_match", "case_sensitive", "position", "timeout_s"):
            if cfg.get(key) not in (None, "", {}):
                tg[key] = cfg[key]
            elif key in cfg:
                tg.pop(key, None)
        if cfg.get("position") and cfg["position"].get("explicit", True):
            tg["locator_mode"] = "position"
        if "require_unique" in cfg:
            tg["require_unique"] = bool(cfg["require_unique"])
    problems = validate_config({**cfg, "_text": (tg or {}).get("text") or (tg or {}).get("name", "")}, win)
    if problems:
        raise ValueError("; ".join(problems))
    return step


def extract_config(step: dict) -> dict:
    """Inverse of apply_config - fills the editor when an existing step is opened."""
    win, tg = step.get("window") or {}, step.get("target") or {}
    return {"window_match": win.get("match", "contains"), "main_window": bool(win.get("main_window")),
            "exe": win.get("exe", ""), "container": tg.get("container") or {}, "search_quadrant": tg.get("search_quadrant", ""),
            "text_match": tg.get("text_match", "contains"), "case_sensitive": bool(tg.get("case_sensitive")),
            "position": tg.get("position") or {}, "timeout_s": tg.get("timeout_s"),
            "require_unique": tg.get("require_unique", True)}
