"""Live locator testing (Inspector / step editor "Test" button): what WOULD this locator click?

Pure over a ``UiaNode`` tree.  Returns match count, every candidate (rect for on-screen highlighting), an ambiguity
warning and the verdict the player would reach - so the user sees "3 matches, not safe" BEFORE saving the step.
"""
from __future__ import annotations

from core.xpath.engine import XPathError, compile_xpath, generate_xpath, query


def test_xpath(root, expr: str, dialect: str = "uia", container_xpath: str = "") -> dict:
    out = {"valid": False, "error": "", "count": 0, "candidates": [], "unique": False, "ambiguous": False,
           "warning": "", "verdict": "invalid"}
    try:
        compile_xpath(expr, dialect)
    except XPathError as exc:
        out["error"] = str(exc)
        return out
    out["valid"] = True
    scope = root
    if container_xpath:
        try:
            boxes = query(root, container_xpath, dialect, visible_only=True)
        except XPathError as exc:
            out.update(valid=False, error=f"container XPath: {exc}", verdict="invalid")
            return out
        if len(boxes) != 1:
            out.update(verdict="container-ambiguous" if boxes else "container-missing",
                       warning=f"container XPath matches {len(boxes)} elements; it must match exactly one")
            return out
        scope = boxes[0]
        from core.xpath.tree import UiaNode
        wrapper = UiaNode(control_type="Desktop", name="Desktop")
        wrapper.children, scope_root = [scope], wrapper    # evaluate relative to the container subtree
        scope = scope_root
    try:
        nodes = query(scope, expr, dialect, visible_only=True)
    except XPathError as exc:
        out.update(valid=False, error=str(exc), verdict="invalid")
        return out
    out["count"] = len(nodes)
    out["candidates"] = [{**n.describe(), "index": i} for i, n in enumerate(nodes[:50])]
    if not nodes:
        out["verdict"] = "not-found"
    elif len(nodes) == 1:
        out.update(unique=True, verdict="ok")
        try:
            out["suggested_xpath"] = generate_xpath(nodes[0], root, dialect)
        except XPathError:
            pass
    else:
        out.update(ambiguous=True, verdict="ambiguous",
                   warning=f"{len(nodes)} elements match - VisionAuto will NOT click any of them. "
                           "Add an attribute, an index or a container to make it unique.")
    return out


def describe_candidates(cands: list[dict]) -> str:
    return "; ".join(f"[{c.get('index', i)}] {c.get('role', '')} '{c.get('name', '')}' id={c.get('automation_id', '')} "
                     f"@{c.get('rect')}" for i, c in enumerate(cands))
