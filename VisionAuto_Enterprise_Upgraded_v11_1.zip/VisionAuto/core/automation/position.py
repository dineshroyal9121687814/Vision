"""Approximate-position locator: coordinates are always RE-DERIVED from the current geometry, never replayed.

modes
  absolute     screen px                      (only valid if the user explicitly accepts it; flagged low confidence)
  window       offset in px from the window's top-left          (window moved -> still right; resized -> offset kept)
  normalized   fractions (0..1) of the window's width/height    (window resized -> scales)
  container    fractions of a container's rect
  anchor       offset in px from the centre of an anchor element (found by another locator)

``compute`` returns (x, y) or raises ``ValueError`` with the reason (never silently falls back to a stale point).
"""
from __future__ import annotations

from core.system import geometry

MODES = ("absolute", "window", "normalized", "container", "anchor")


def _need(rect, what):
    if not geometry.valid(rect):
        raise ValueError(f"position locator needs the current {what} rectangle")
    return rect


def from_screen_point(x, y, mode: str, window_rect=None, container_rect=None, anchor_rect=None) -> dict:
    """Build the stored spec from a point the user picked (used by the Inspector / Recorder)."""
    spec = {"mode": mode}
    if mode == "absolute":
        spec.update(x=int(x), y=int(y))
    elif mode == "window":
        r = _need(window_rect, "window")
        spec.update(dx=int(x - r[0]), dy=int(y - r[1]), ref_window=list(map(int, r)))
    elif mode == "normalized":
        r = _need(window_rect, "window")
        spec.update(fx=round((x - r[0]) / (r[2] - r[0]), 5), fy=round((y - r[1]) / (r[3] - r[1]), 5),
                    ref_window=list(map(int, r)))
    elif mode == "container":
        r = _need(container_rect, "container")
        spec.update(fx=round((x - r[0]) / (r[2] - r[0]), 5), fy=round((y - r[1]) / (r[3] - r[1]), 5),
                    ref_container=list(map(int, r)))
    elif mode == "anchor":
        r = _need(anchor_rect, "anchor")
        spec.update(dx=int(x - (r[0] + r[2]) / 2), dy=int(y - (r[1] + r[3]) / 2))
    else:
        raise ValueError(f"unknown position mode {mode!r}")
    return spec


def compute(spec: dict, window_rect=None, container_rect=None, anchor_rect=None) -> tuple[int, int]:
    mode = spec.get("mode")
    if mode == "absolute":
        return int(spec["x"]), int(spec["y"])
    if mode == "window":
        r = _need(window_rect, "window")
        return int(r[0] + spec["dx"]), int(r[1] + spec["dy"])
    if mode == "normalized":
        r = _need(window_rect, "window")
        return int(r[0] + spec["fx"] * (r[2] - r[0])), int(r[1] + spec["fy"] * (r[3] - r[1]))
    if mode == "container":
        r = _need(container_rect, "container")
        return int(r[0] + spec["fx"] * (r[2] - r[0])), int(r[1] + spec["fy"] * (r[3] - r[1]))
    if mode == "anchor":
        r = _need(anchor_rect, "anchor")
        return int((r[0] + r[2]) / 2 + spec["dx"]), int((r[1] + r[3]) / 2 + spec["dy"])
    raise ValueError(f"unknown position mode {mode!r}")


def inside(point, rect) -> bool:
    return geometry.valid(rect) and rect[0] <= point[0] < rect[2] and rect[1] <= point[1] < rect[3]
