"""Four-quadrant search fallback.

Quadrants are SEARCH REGIONS, never click targets.  ``search`` runs a *finder* (template / OCR / anything) inside the
chosen quadrants (recursively subdividing when nothing is found), collects every candidate, and ``choose`` accepts one
only if it is strong AND clearly better than the runner-up - otherwise the caller gets the candidate list to show to
the user ("target unknown: here are the candidates").
"""
from __future__ import annotations

from dataclasses import dataclass, field

QUADRANTS = ("tl", "tr", "bl", "br")
NAMES = {"tl": "top-left", "tr": "top-right", "bl": "bottom-left", "br": "bottom-right"}
DEFAULT_ORDER = QUADRANTS


@dataclass
class Candidate:
    x: int                    # absolute screen centre of the thing found
    y: int
    confidence: float
    source: str = ""          # "template" | "ocr" | ...
    quadrant: str = ""        # e.g. "tl" or "tl/br" when subdivided
    rect: tuple | None = None  # absolute bounding box if known
    text: str = ""


@dataclass
class QuadrantResult:
    status: str                                   # found | ambiguous | none
    chosen: Candidate | None = None
    candidates: list = field(default_factory=list)
    searched: list = field(default_factory=list)  # quadrant paths actually searched (for the log / preview)
    reason: str = ""


def split(rect) -> dict[str, tuple[int, int, int, int]]:
    l, t, r, b = (int(v) for v in rect)
    mx, my = (l + r) // 2, (t + b) // 2
    return {"tl": (l, t, mx, my), "tr": (mx, t, r, my), "bl": (l, my, mx, b), "br": (mx, my, r, b)}


def parse_order(value) -> list[str]:
    """``"all"`` / ``None`` -> default order; ``"tl"`` / ``["br","tl"]`` / ``"tr,tl"`` -> validated list."""
    if value in (None, "", "all"):
        return list(DEFAULT_ORDER)
    items = value if isinstance(value, (list, tuple)) else str(value).replace(";", ",").split(",")
    out = []
    for it in items:
        k = str(it).strip().lower()
        k = {"top-left": "tl", "top-right": "tr", "bottom-left": "bl", "bottom-right": "br"}.get(k, k)
        if k not in QUADRANTS:
            raise ValueError(f"unknown quadrant {it!r}; use tl, tr, bl, br or all")
        if k not in out:
            out.append(k)
    return out


def _dedupe(cands: list[Candidate], radius: int = 12) -> list[Candidate]:
    out: list[Candidate] = []
    for c in sorted(cands, key=lambda c: -c.confidence):
        if all(abs(c.x - o.x) > radius or abs(c.y - o.y) > radius for o in out):
            out.append(c)
    return out


def search(window_rect, finder, order=None, max_depth: int = 2, min_confidence: float = 0.85,
           margin: float = 0.05, abort=lambda: False) -> QuadrantResult:
    """``finder(rect) -> list[Candidate]`` searches an absolute screen rect and returns absolute-coordinate candidates.

    Runs the quadrants in ``order``.  A quadrant with no candidate at/above ``min_confidence`` is subdivided (down to
    ``max_depth`` extra levels) before moving on.  Search stops at the first quadrant that yields an acceptable result
    ONLY when the caller asked for a single quadrant; with several, all are searched so a look-alike in another
    quadrant is seen (duplicates => ambiguous).
    """
    order = parse_order(order)
    found: list[Candidate] = []
    searched: list[str] = []

    def run(rect, path, depth):
        if abort():
            return
        searched.append(path)
        hits = [c for c in finder(rect) if c.confidence >= min_confidence]
        for c in hits:
            c.quadrant = path
        if hits:
            found.extend(hits)
            return
        if depth < max_depth and (rect[2] - rect[0]) >= 64 and (rect[3] - rect[1]) >= 64:
            for k, sub in split(rect).items():
                run(sub, f"{path}/{k}", depth + 1)

    for q in order:
        run(split(window_rect)[q], q, 0)
    cands = _dedupe(found)
    if not cands:
        return QuadrantResult("none", None, [], searched, "nothing reliable found in " + ", ".join(NAMES.get(q, q) for q in order))
    return choose(cands, searched, min_confidence, margin)


def choose(cands: list[Candidate], searched=None, min_confidence: float = 0.85, margin: float = 0.05) -> QuadrantResult:
    cands = sorted(cands, key=lambda c: -c.confidence)
    if cands[0].confidence < min_confidence:
        return QuadrantResult("none", None, cands, searched or [], f"best candidate {cands[0].confidence:.2f} < {min_confidence:.2f}")
    if len(cands) > 1 and cands[0].confidence - cands[1].confidence < margin:
        return QuadrantResult("ambiguous", None, cands, searched or [],
                              f"{len(cands)} similar candidates ({cands[0].confidence:.2f} vs {cands[1].confidence:.2f}); pick one")
    return QuadrantResult("found", cands[0], cands, searched or [])
