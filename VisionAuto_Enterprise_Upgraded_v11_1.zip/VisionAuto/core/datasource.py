"""Data-driven testing: load rows from CSV / TSV / JSON / XLSX (or inline) and select which to run.

Every column becomes a variable usable as ``${column}`` in any step (typed text, validations, targets...).
Two built-ins are always available: ``${_row}`` (1-based row number in the source) and ``${_iteration}``.

Safety: a data file *stored inside a test* must live in that test's folder (a shared test can never make
VisionAuto read an arbitrary file on your disk); a file you pick yourself on the command line / GUI can be anywhere.
Limits: 5 000 rows, 200 columns, 10 000 characters per cell, 20 MB file.
"""
from __future__ import annotations

import csv
import io
import json
import re
from pathlib import Path

MAX_ROWS, MAX_COLS, MAX_CELL, MAX_BYTES = 5000, 200, 10_000, 20 * 1024 * 1024
_NAME_OK = re.compile(r"^[a-zA-Z0-9_\-]+$")


class DataError(ValueError):
    """The data source cannot be used (message is shown to the user)."""


def _clean_columns(raw: list) -> list[str]:
    cols, seen = [], set()
    for i, c in enumerate(raw):
        name = re.sub(r"[^a-zA-Z0-9_\-]+", "_", str(c if c is not None else "").strip()).strip("_") or f"col{i + 1}"
        base, n = name, 2
        while name.casefold() in seen:
            name, n = f"{base}_{n}", n + 1
        seen.add(name.casefold())
        cols.append(name)
    return cols


def _stringify(v) -> str:
    if v is None:
        return ""
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, float) and v == int(v) and abs(v) < 1e15:
        return str(int(v))
    s = str(v)
    if len(s) > MAX_CELL:
        raise DataError(f"A data cell is longer than {MAX_CELL} characters.")
    return s


def _from_table(header: list, body: list[list]) -> tuple[list[str], list[dict]]:
    if len(header) > MAX_COLS:
        raise DataError(f"The data has more than {MAX_COLS} columns.")
    if len(body) > MAX_ROWS:
        raise DataError(f"The data has more than {MAX_ROWS} rows; split it into several files.")
    cols = _clean_columns(header)
    rows = []
    for r in body:
        if not any(str(c or "").strip() for c in r):
            continue                                   # blank line
        rows.append({cols[i]: _stringify(r[i]) if i < len(r) else "" for i in range(len(cols))})
    return cols, rows


def _read_bytes(path: Path) -> bytes:
    if path.stat().st_size > MAX_BYTES:
        raise DataError("The data file is larger than 20 MB.")
    return path.read_bytes()


def load_file(path: str | Path) -> tuple[list[str], list[dict]]:
    path = Path(path)
    if not path.is_file():
        raise DataError(f"Data file not found: {path}")
    ext = path.suffix.casefold()
    if ext in (".csv", ".tsv", ".txt"):
        text = _read_bytes(path).decode("utf-8-sig", errors="replace")
        delim = "\t" if ext == ".tsv" else (";" if text.split("\n", 1)[0].count(";") > text.split("\n", 1)[0].count(",") else ",")
        table = list(csv.reader(io.StringIO(text), delimiter=delim))
        if not table:
            raise DataError("The data file is empty.")
        return _from_table(table[0], table[1:])
    if ext == ".json":
        try:
            data = json.loads(_read_bytes(path).decode("utf-8-sig"))
        except ValueError as exc:
            raise DataError(f"Invalid JSON data file: {exc}") from exc
        return from_rows(data.get("rows") if isinstance(data, dict) else data)
    if ext in (".xlsx", ".xlsm"):
        try:
            from openpyxl import load_workbook
        except ImportError as exc:
            raise DataError("Reading .xlsx needs openpyxl (pip install openpyxl), or export the sheet to CSV.") from exc
        _read_bytes(path)                                # size check only
        wb = load_workbook(path, read_only=True, data_only=True)
        try:
            ws = wb.worksheets[0]
            table = [list(r) for r in ws.iter_rows(values_only=True, max_row=MAX_ROWS + 2)]
        finally:
            wb.close()
        if not table:
            raise DataError("The workbook's first sheet is empty.")
        return _from_table(table[0], table[1:])
    raise DataError(f"Unsupported data file type '{ext}'. Use .csv, .tsv, .json or .xlsx.")


def from_rows(rows) -> tuple[list[str], list[dict]]:
    """Inline rows: a list of objects, or a list of lists whose first row is the header."""
    if not isinstance(rows, list) or not rows:
        raise DataError("Data must be a non-empty list of rows.")
    if all(isinstance(r, dict) for r in rows):
        header = list(dict.fromkeys(k for r in rows for k in r))
        return _from_table(header, [[r.get(k) for k in header] for r in rows])
    if all(isinstance(r, list) for r in rows):
        return _from_table(rows[0], rows[1:])
    raise DataError("Data rows must all be objects or all be lists.")


def parse_selection(spec, total: int) -> list[int]:
    """'1-3,5,8-' -> [1,2,3,5,8,...] (1-based). Empty / None = every row."""
    if spec in (None, "", "all"):
        return list(range(1, total + 1))
    picked: list[int] = []
    for part in str(spec).replace(" ", "").split(","):
        if not part:
            continue
        m = re.fullmatch(r"(\d*)-(\d*)", part)
        if m:
            lo = int(m.group(1) or 1)
            hi = int(m.group(2) or total)
        elif part.isdigit():
            lo = hi = int(part)
        else:
            raise DataError(f"Invalid row selection '{part}'. Use for example 1-3,5,8-")
        if lo < 1 or hi < lo:
            raise DataError(f"Invalid row range '{part}'.")
        picked.extend(i for i in range(lo, min(hi, total) + 1) if i not in picked)
    return picked


def resolve(test: dict, test_dir: Path | None, override=None, select=None) -> dict | None:
    """Work out the data set for one run. ``override`` (a path or inline rows) beats the test's own data.

    Returns ``{"columns", "rows": [(source_row_no, {col: value})], "on_row_failure", "restart_apps",
    "secret_columns"}`` or ``None`` when the test is not data-driven.
    """
    cfg = test.get("data") if isinstance(test.get("data"), dict) else {}
    if override is not None:
        cols, rows = load_file(override) if isinstance(override, (str, Path)) else from_rows(override)
    elif cfg.get("rows"):
        cols, rows = from_rows(cfg["rows"])
    elif cfg.get("file"):
        if test_dir is None:
            raise DataError("This test's data file cannot be located.")
        base = Path(test_dir).resolve()
        target = (base / str(cfg["file"])).resolve()
        try:
            target.relative_to(base)
        except ValueError:
            raise DataError("A test's own data file must be inside the test's folder.") from None
        cols, rows = load_file(target)
    else:
        return None
    chosen = parse_selection(select if select is not None else cfg.get("select"), len(rows))
    limit = cfg.get("limit")
    if isinstance(limit, int) and not isinstance(limit, bool) and limit > 0:
        chosen = chosen[:limit]
    skip_col = next((c for c in cols if c.casefold() in ("_skip", "skip")), None)
    picked = [(n, rows[n - 1]) for n in chosen
              if not (skip_col and str(rows[n - 1].get(skip_col, "")).strip().casefold() in ("1", "true", "yes", "y"))]
    if not picked:
        raise DataError("No data rows were selected to run.")
    secret = [c for c in (cfg.get("secret_columns") or []) if c in cols]
    return {"columns": cols, "rows": picked, "on_row_failure": cfg.get("on_row_failure", "continue"),
            "restart_apps": bool(cfg.get("restart_apps", False)), "secret_columns": secret}
