"""
Visual neighbours: pictures of what surrounds a click, so the click can be found again by its SURROUNDINGS.

Why: when a cell / field / icon changes (a value was typed, a state flipped) its own picture no longer matches, and many
applications expose no accessibility tree at all. The area around it usually stays the same: the row header to its left,
the column header above, the label next to it. Every click therefore stores up to six small crops of the area around the
click point together with their offset from it, and one annotated overview picture for people to look at.

At playback each crop is searched for in the window; every crop that is found "votes" for the click point
(``crop_centre - offset``). Two crops agreeing within a few pixels is a confident answer.

Pure numpy / OpenCV functions - no OS access.
"""
from __future__ import annotations

import math

import cv2
import numpy as np

SIZE = (72, 36)                                   # crop width, height
OFFSETS = [(-110, 0), (110, 0), (0, -52), (0, 52), (-110, -52), (110, -52), (-110, 52), (110, 52),
           (-190, 0), (190, 0)]                   # nearest first; further ones only used when the near ones are blank
MIN_TEXTURE = 14.0                                # grey-level std below this = blank area, useless to match
MAX_KEEP = 6


def _crop(frame: np.ndarray, cx: int, cy: int, size=SIZE):
    w, h = size
    x0, y0 = int(cx - w // 2), int(cy - h // 2)
    if x0 < 0 or y0 < 0 or x0 + w > frame.shape[1] or y0 + h > frame.shape[0]:
        return None
    return frame[y0:y0 + h, x0:x0 + w]


def _grey(img: np.ndarray) -> np.ndarray:
    return cv2.cvtColor(img, cv2.COLOR_BGR2GRAY) if img.ndim == 3 else img


def capture(frame: np.ndarray, origin, x: int, y: int, bounds=None, keep: int = MAX_KEEP) -> list[dict]:
    """Crops around the click point (screen coordinates ``x, y``; ``frame`` starts at ``origin``).
    ``bounds`` = [l, t, r, b] of the window: crops outside it would show other windows. Returns
    ``[{'img', 'dx', 'dy', 'size'}]`` (dx, dy = crop centre minus click)."""
    out, kept_grey = [], []
    fx, fy = x - origin[0], y - origin[1]
    for dx, dy in OFFSETS:
        sx, sy = x + dx, y + dy
        if bounds and not (bounds[0] <= sx - SIZE[0] // 2 and sx + SIZE[0] // 2 <= bounds[2]
                           and bounds[1] <= sy - SIZE[1] // 2 and sy + SIZE[1] // 2 <= bounds[3]):
            continue
        c = _crop(frame, fx + dx, fy + dy)
        if c is None:
            continue
        g = _grey(c)
        if float(g.std()) < MIN_TEXTURE:
            continue
        if any(float(np.abs(g.astype(np.int16) - k.astype(np.int16)).mean()) < 6.0 for k in kept_grey):
            continue                                        # a look-alike of one already kept (repeating grid lines)
        kept_grey.append(g)
        out.append({"img": c.copy(), "dx": int(dx), "dy": int(dy), "size": list(SIZE)})
        if len(out) >= keep:
            break
    return out


def overview(frame: np.ndarray, origin, x: int, y: int, items: list[dict], radius=(360, 220)) -> np.ndarray:
    """The picture a person looks at: area around the click, a red cross on the click, green boxes on the neighbours."""
    fx, fy = x - origin[0], y - origin[1]
    x0, y0 = max(0, fx - radius[0]), max(0, fy - radius[1])
    x1, y1 = min(frame.shape[1], fx + radius[0]), min(frame.shape[0], fy + radius[1])
    img = frame[y0:y1, x0:x1].copy()
    px, py = fx - x0, fy - y0
    cv2.drawMarker(img, (px, py), (0, 0, 255), cv2.MARKER_CROSS, 22, 2)
    cv2.circle(img, (px, py), 12, (0, 0, 255), 1)
    for k, it in enumerate(items, 1):
        w, h = it["size"]
        cx, cy = px + it["dx"], py + it["dy"]
        cv2.rectangle(img, (cx - w // 2, cy - h // 2), (cx + w // 2, cy + h // 2), (0, 180, 0), 1)
        cv2.putText(img, f"n{k}", (cx - w // 2 + 2, cy - h // 2 + 11), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0, 140, 0), 1, cv2.LINE_AA)
    return img


def vote(found: list[tuple[float, float, float, float]], tolerance: float = 8.0):
    """``found`` = [(crop_centre_x, crop_centre_y, dx, dy)] in screen pixels. Every crop predicts the click point as
    ``centre - (dx, dy)``. Returns ``(x, y, votes, spread)`` for the biggest agreeing group, or None."""
    pts = [(cx - dx, cy - dy) for cx, cy, dx, dy in found]
    if not pts:
        return None
    best: list = []
    for p in pts:
        grp = [q for q in pts if math.hypot(q[0] - p[0], q[1] - p[1]) <= tolerance]
        if len(grp) > len(best):
            best = grp
    mx = sorted(p[0] for p in best)[len(best) // 2]
    my = sorted(p[1] for p in best)[len(best) // 2]
    spread = max(math.hypot(p[0] - mx, p[1] - my) for p in best)
    return int(round(mx)), int(round(my)), len(best), spread
