"""
Mouse-pointer hygiene for screen capture.

A pointer drawn into a screenshot covers the very pixels OCR and template matching need (the click point is the middle of
the element!), and it is never there at the same place twice.  So VisionAuto never lets it into a capture:

  * ``capture_without_cursor``  - tells the screen grabber not to draw it (mss ``with_cursor`` = False)
  * ``park_if_over``            - before reading a region, if the real pointer is over it, move it to a harmless spot
                                  (the window's title bar) - pixels are then exactly what the app drew

Windows-only where it needs the OS; everything is a no-op elsewhere.
"""
from __future__ import annotations

import sys

IS_WINDOWS = sys.platform == "win32"


def capture_without_cursor(sct) -> None:
    """Make sure an mss instance does not paint the pointer into frames (attribute exists in newer mss only)."""
    try:
        if hasattr(sct, "with_cursor"):
            sct.with_cursor = False
    except Exception:
        pass


def position() -> tuple[int, int] | None:
    if not IS_WINDOWS:
        return None
    try:
        import ctypes
        from ctypes import wintypes

        pt = wintypes.POINT()
        ctypes.windll.user32.GetCursorPos(ctypes.byref(pt))
        return int(pt.x), int(pt.y)
    except Exception:
        return None


def is_over(rect, margin: int = 36, pos: tuple[int, int] | None = None) -> bool:
    """Is the pointer (arrow + I-beam/cross extend ~32 px right/down of the hotspot) over ``rect`` [l, t, r, b]?"""
    pos = pos or position()
    if not pos or not rect:
        return False
    x, y = pos
    return rect[0] - margin <= x <= rect[2] + margin and rect[1] - margin <= y <= rect[3] + margin


def safe_spot(window: dict | None, rect) -> tuple[int, int]:
    """Where to rest the pointer: the middle of the window's title bar if it is clear of ``rect``, else a screen corner."""
    wr = (window or {}).get("rect")
    if isinstance(wr, (list, tuple)) and len(wr) >= 4:
        spot = ((int(wr[0]) + int(wr[2])) // 2, int(wr[1]) + 12)
        if not is_over(rect, 24, spot):
            return spot
    return (max(0, int(rect[2]) + 200), max(0, int(rect[1]) - 60)) if rect else (5, 5)


def park_if_over(move, rect, window: dict | None = None) -> bool:
    """``move(x, y)`` the pointer away when it covers ``rect``. True = it was moved."""
    if not is_over(rect):
        return False
    x, y = safe_spot(window, rect)
    try:
        move(x, y)
    except Exception:
        return False
    return True
