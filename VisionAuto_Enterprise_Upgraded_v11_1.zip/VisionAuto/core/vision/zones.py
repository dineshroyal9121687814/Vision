"""Zones: which *part* of a window an element lives in (VS Code: explorer / editor / terminal / status bar ...).

Recorded at recording time, used at playback to search that part FIRST - for templates, OCR and ORB alike - before
widening to the window and finally the whole screen.  Smaller search area = much faster and far fewer look-alike
matches (the "Save" button in the terminal toolbar can no longer be confused with one in the editor).

How a zone is found (best source first):
 1. ``uia``    smallest container (pane / group / tab / toolbar / list ...) around the element reported by UI Automation
 2. ``layout`` recursive split of the window image at straight dividers / colour changes that span a pane
 3. ``grid``   the cell of a 3x3 grid (always available, coarse)
"""
from __future__ import annotations

import numpy as np

CONTAINER_ROLES = {"pane", "group", "tab", "tabitem", "custom", "document", "toolbar", "list", "tree", "table",
                   "statusbar", "menubar", "titlebar", "header", "window"}
MIN_FRAC, MAX_FRAC = 0.015, 0.85         # a zone is 1.5 %..85 % of its window


def _area(r) -> int:
    return max(0, int(r[2] - r[0])) * max(0, int(r[3] - r[1]))


def _contains(r, p) -> bool:
    return r[0] <= p[0] <= r[2] and r[1] <= p[1] <= r[3]


def _label(rect, window_rect) -> str:
    ww, wh = window_rect[2] - window_rect[0], window_rect[3] - window_rect[1]
    cx, cy = (rect[0] + rect[2]) / 2 - window_rect[0], (rect[1] + rect[3]) / 2 - window_rect[1]
    col = "left" if cx < ww / 3 else "right" if cx > 2 * ww / 3 else "center"
    row = "top" if cy < wh / 3 else "bottom" if cy > 2 * wh / 3 else "middle"
    return f"{row}-{col}"


def _zone(rect, window_rect, source, name) -> dict:
    return {"name": name, "source": source, "rect": [int(v) for v in rect], "window_rect": [int(v) for v in window_rect]}


def from_ancestors(point, ancestors, window_rect) -> dict | None:
    """``ancestors``: nearest parent first, each ``{name, role, automation_id, rect}``."""
    wa = _area(window_rect)
    for a in ancestors or []:
        r = a.get("rect")
        if not (isinstance(r, (list, tuple)) and len(r) == 4 and r[2] > r[0] and r[3] > r[1]):
            continue
        if str(a.get("role", "")).casefold() not in CONTAINER_ROLES or not _contains(r, point):
            continue
        frac = _area(r) / wa if wa else 0
        if MIN_FRAC <= frac <= MAX_FRAC:
            name = a.get("name") or a.get("automation_id") or f"{a.get('role', 'pane')} ({_label(r, window_rect)})"
            return _zone(r, window_rect, "uia", str(name)[:80])
    return None


def _best_split(sub: np.ndarray, axis: int, min_cell: int, thresh: int, frac: float):
    """Index of the strongest straight divider across ``sub`` (axis=1: vertical line, axis=0: horizontal), or None."""
    h, w = sub.shape
    if axis == 1:
        if w < 2 * min_cell:
            return None
        d = np.abs(np.diff(sub.astype(np.int16), axis=1)) > thresh      # (h, w-1)
        score = d.mean(axis=0)
        n = w
    else:
        if h < 2 * min_cell:
            return None
        d = np.abs(np.diff(sub.astype(np.int16), axis=0)) > thresh
        score = d.mean(axis=1)
        n = h
    score[:min_cell - 1] = 0
    score[max(0, n - min_cell):] = 0
    i = int(score.argmax())
    return (i + 1, float(score[i])) if score[i] >= frac else None


def layout_cells(gray: np.ndarray, min_cell: int = 14, max_depth: int = 5, thresh: int = 8, frac: float = 0.8) -> list[tuple]:
    """Recursive X-Y cut: split at the strongest full-length divider until none is left. Returns (x0,y0,x1,y1) cells."""
    cells: list[tuple] = []

    def rec(x0, y0, x1, y1, depth):
        sub = gray[y0:y1, x0:x1]
        best = None
        if depth < max_depth:
            for axis in (1, 0):
                s = _best_split(sub, axis, min_cell, thresh, frac)
                if s and (best is None or s[1] > best[2]):
                    best = (axis, s[0], s[1])
        if best is None:
            cells.append((x0, y0, x1, y1))
            return
        axis, at, _ = best
        if axis == 1:
            rec(x0, y0, x0 + at, y1, depth + 1)
            rec(x0 + at, y0, x1, y1, depth + 1)
        else:
            rec(x0, y0, x1, y0 + at, depth + 1)
            rec(x0, y0 + at, x1, y1, depth + 1)

    rec(0, 0, gray.shape[1], gray.shape[0], 0)
    return cells


def from_layout(frame: np.ndarray, origin, point, window_rect) -> dict | None:
    import cv2

    wx0, wy0, wx1, wy1 = (int(v) for v in window_rect)
    fx0, fy0 = max(0, wx0 - origin[0]), max(0, wy0 - origin[1])
    fx1, fy1 = min(frame.shape[1], wx1 - origin[0]), min(frame.shape[0], wy1 - origin[1])
    if fx1 - fx0 < 100 or fy1 - fy0 < 100:
        return None
    crop = frame[fy0:fy1, fx0:fx1]
    scale = min(1.0, 960.0 / crop.shape[1])
    gray = cv2.cvtColor(crop, cv2.COLOR_BGR2GRAY) if crop.ndim == 3 else crop
    if scale < 1.0:
        gray = cv2.resize(gray, (int(gray.shape[1] * scale), int(gray.shape[0] * scale)), interpolation=cv2.INTER_AREA)
    px, py = (point[0] - origin[0] - fx0) * scale, (point[1] - origin[1] - fy0) * scale
    for (x0, y0, x1, y1) in layout_cells(gray, min_cell=max(10, int(16 * scale))):
        if x0 <= px <= x1 and y0 <= py <= y1:
            rect = [fx0 + origin[0] + x0 / scale, fy0 + origin[1] + y0 / scale,
                    fx0 + origin[0] + x1 / scale, fy0 + origin[1] + y1 / scale]
            frac = _area(rect) / max(1, _area(window_rect))
            if MIN_FRAC <= frac <= MAX_FRAC:
                return _zone(rect, window_rect, "layout", f"pane {_label(rect, window_rect)}")
            return None
    return None


def from_grid(point, window_rect, rows: int = 3, cols: int = 3) -> dict:
    ww, wh = window_rect[2] - window_rect[0], window_rect[3] - window_rect[1]
    c = min(cols - 1, max(0, int((point[0] - window_rect[0]) * cols / max(1, ww))))
    r = min(rows - 1, max(0, int((point[1] - window_rect[1]) * rows / max(1, wh))))
    rect = [window_rect[0] + c * ww / cols, window_rect[1] + r * wh / rows,
            window_rect[0] + (c + 1) * ww / cols, window_rect[1] + (r + 1) * wh / rows]
    return _zone(rect, window_rect, "grid", f"area {_label(rect, window_rect)}")


def detect_zone(frame, origin, window_rect, point, ancestors=None) -> dict | None:
    """Best available zone for ``point`` (absolute screen pixels) inside ``window_rect``."""
    if not (isinstance(window_rect, (list, tuple)) and len(window_rect) == 4 and window_rect[2] > window_rect[0]
            and window_rect[3] > window_rect[1]):
        return None
    if not _contains(window_rect, point):
        return None
    z = from_ancestors(point, ancestors, window_rect)
    if z is None and frame is not None:
        try:
            z = from_layout(frame, origin or (0, 0), point, window_rect)
        except Exception:
            z = None
    return z or from_grid(point, window_rect)
