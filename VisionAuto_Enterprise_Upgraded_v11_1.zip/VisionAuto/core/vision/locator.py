"""
OpenCV locator tiers.

  find_by_template        multi-scale normalised template matching
  find_point_by_features  ORB keypoints + RANSAC homography: maps the recorded
                          click point onto the current screen (survives resize,
                          small layout shifts and partial redraws)
"""
from __future__ import annotations

from dataclasses import dataclass

import cv2
import numpy as np


@dataclass
class LocatorResult:
    found: bool
    x: int = 0
    y: int = 0
    confidence: float = 0.0
    method: str = ""
    scale: float = 1.0
    second_confidence: float = 0.0
    ambiguous: bool = False


class Locator:
    TEMPLATE_THRESHOLD = 0.85
    ORB_MIN_GOOD = 12
    ORB_MIN_INLIERS = 8

    def __init__(self):
        self._orb = cv2.ORB_create(nfeatures=1500)
        self._bf = cv2.BFMatcher(cv2.NORM_HAMMING)

    def find_by_template(self, screen: np.ndarray, template: np.ndarray,
                         scales=(1.0, 0.9, 1.1, 0.8, 1.25), threshold: float | None = None) -> LocatorResult:
        thr = threshold if threshold is not None else self.TEMPLATE_THRESHOLD
        gs = cv2.cvtColor(screen, cv2.COLOR_BGR2GRAY) if screen.ndim == 3 else screen
        gt = cv2.cvtColor(template, cv2.COLOR_BGR2GRAY) if template.ndim == 3 else template
        best = LocatorResult(False, method="template")
        for sc in scales:
            h, w = gt.shape
            tpl = gt if sc == 1.0 else cv2.resize(gt, (max(4, int(w * sc)), max(4, int(h * sc))))
            if tpl.shape[0] > gs.shape[0] or tpl.shape[1] > gs.shape[1]:
                continue
            res = cv2.matchTemplate(gs, tpl, cv2.TM_CCOEFF_NORMED)
            _, mx, _, loc = cv2.minMaxLoc(res)
            # Compare against the strongest non-overlapping candidate. A high
            # score alone is insufficient when two controls look alike.
            alternatives = res.copy()
            # Suppress only the immediate neighbourhood of the best peak (the same blob, a few pixels around it). The old
            # window was the whole template size, which hid exactly the look-alikes that matter: the next cell of a
            # spreadsheet grid is 20-30 px away and scores the same, so a wrong row was clicked with 0.99 confidence.
            rad = max(6, min(tpl.shape[0], tpl.shape[1]) // 20)
            x0 = max(0, loc[0] - rad)
            y0 = max(0, loc[1] - rad)
            x1 = min(alternatives.shape[1], loc[0] + rad + 1)
            y1 = min(alternatives.shape[0], loc[1] + rad + 1)
            alternatives[y0:y1, x0:x1] = -1
            second = float(cv2.minMaxLoc(alternatives)[1]) if alternatives.size else 0.0
            ambiguous = mx >= thr and second >= thr and mx - second < 0.025
            if mx > best.confidence:
                best = LocatorResult(mx >= thr and not ambiguous, loc[0] + tpl.shape[1] // 2,
                                     loc[1] + tpl.shape[0] // 2, float(mx), "template", float(sc),
                                     second, ambiguous)
            if sc == 1.0 and mx >= 0.97:
                break  # exact hit, skip the other scales
        return best

    def find_all_by_template(self, screen: np.ndarray, template: np.ndarray, threshold: float | None = None,
                             max_hits: int = 16) -> list[tuple[int, int, float]]:
        """Every non-overlapping place the picture matches (centre x, centre y, score), best first. Used to choose
        between look-alikes with other evidence (nearness to the recorded spot, the text found there)."""
        thr = threshold if threshold is not None else self.TEMPLATE_THRESHOLD
        gs = cv2.cvtColor(screen, cv2.COLOR_BGR2GRAY) if screen.ndim == 3 else screen
        gt = cv2.cvtColor(template, cv2.COLOR_BGR2GRAY) if template.ndim == 3 else template
        if gt.shape[0] > gs.shape[0] or gt.shape[1] > gs.shape[1]:
            return []
        res = cv2.matchTemplate(gs, gt, cv2.TM_CCOEFF_NORMED)
        h, w = gt.shape
        hits: list[tuple[int, int, float]] = []
        while len(hits) < max_hits:
            _, mx, _, loc = cv2.minMaxLoc(res)
            if mx < thr:
                break
            hits.append((loc[0] + w // 2, loc[1] + h // 2, float(mx)))
            rad = max(6, min(h, w) // 20)
            res[max(0, loc[1] - rad):loc[1] + rad + 1, max(0, loc[0] - rad):loc[0] + rad + 1] = -1
        return hits

    def find_point_by_features(self, screen: np.ndarray, template: np.ndarray,
                               point: tuple[float, float]) -> LocatorResult:
        gs = cv2.cvtColor(screen, cv2.COLOR_BGR2GRAY) if screen.ndim == 3 else screen
        gt = cv2.cvtColor(template, cv2.COLOR_BGR2GRAY) if template.ndim == 3 else template
        kp1, d1 = self._orb.detectAndCompute(gt, None)
        kp2, d2 = self._orb.detectAndCompute(gs, None)
        if d1 is None or d2 is None or len(kp1) < self.ORB_MIN_GOOD or len(kp2) < self.ORB_MIN_GOOD:
            return LocatorResult(False, method="orb")
        good = []
        for pair in self._bf.knnMatch(d1, d2, k=2):
            if len(pair) == 2 and pair[0].distance < 0.75 * pair[1].distance:
                good.append(pair[0])
        if len(good) < self.ORB_MIN_GOOD:
            return LocatorResult(False, confidence=len(good) / self.ORB_MIN_GOOD, method="orb")
        src = np.float32([kp1[m.queryIdx].pt for m in good]).reshape(-1, 1, 2)
        dst = np.float32([kp2[m.trainIdx].pt for m in good]).reshape(-1, 1, 2)
        H, mask = cv2.findHomography(src, dst, cv2.RANSAC, 4.0)
        if H is None or mask is None or int(mask.sum()) < self.ORB_MIN_INLIERS:
            return LocatorResult(False, method="orb")
        px, py = cv2.perspectiveTransform(np.float32([[point]]), H)[0][0]
        return LocatorResult(True, int(px), int(py), min(1.0, float(mask.sum()) / 40.0), "orb")
