"""
Neighbour anchors: describe WHERE an element is by what is around it, not only by what it looks like.

Recorded at mouse-down (the UI is still in its "before" state) for every pointer target - click, drag source, drag
destination:  "this control had 'Settings' 40 px to its left and 'Help' 32 px below it".  At playback, if the element
cannot be found by name or picture, any anchor that IS found gives the position again
(``anchor_centre - recorded_offset``), and the offsets between several anchors cross-check each other.  It is what
makes a drop zone with no name of its own ("between item 3 and item 4"), a repeated row in a list, or an unnamed icon
findable, and it survives theme / font / language changes that break pictures.

``container`` = the nearest scrollable ancestor (list, tree, table, grid, document, combo box ...): where the player
scrolls when the element is not on screen.

Pure functions over ``element_at(x, y) -> dict`` - no OS access, testable.
"""
from __future__ import annotations

import math
import time

SCROLL_ROLES = {"list", "listbox", "tree", "table", "datagrid", "document", "combobox", "scrollviewer", "listview",
                "treeview", "datatable"}
LIST_ROLES = {"list", "listbox", "combobox", "listview"}          # keyboard type-ahead is safe here (never in menus)


def _valid(r) -> bool:
    return isinstance(r, (list, tuple)) and len(r) == 4 and r[2] > r[0] and r[3] > r[1]


def _area(r) -> int:
    return max(0, int(r[2] - r[0])) * max(0, int(r[3] - r[1]))


def container_of(point, ancestors, window_rect=None) -> dict | None:
    """Nearest scrollable ancestor that contains ``point`` (and is not the whole window)."""
    wa = _area(window_rect) if _valid(window_rect) else 0
    for a in ancestors or []:
        r = a.get("rect")
        if not _valid(r) or str(a.get("role") or "").casefold() not in SCROLL_ROLES:
            continue
        if not (r[0] <= point[0] <= r[2] and r[1] <= point[1] <= r[3]):
            continue
        if wa and _area(r) > 0.97 * wa:
            continue
        out = {"role": a.get("role", ""), "rect": [int(v) for v in r]}
        for k in ("name", "automation_id"):
            if a.get(k):
                out[k] = a[k]
        return out
    return None


def sample(element_at, x: int, y: int, element: dict | None = None, budget_s: float = 0.35, limit: int = 6,
           clock=time.monotonic) -> list[dict]:
    """Named elements around ``(x, y)``, nearest first: ``[{name, role, automation_id, dx, dy, dist, side}]``.

    ``dx``/``dy`` = neighbour centre minus the click point. A time budget keeps recording snappy in slow UIA apps."""
    el = element or {}
    r = el.get("rect") if _valid(el.get("rect")) else (x - 24, y - 12, x + 24, y + 12)
    w, h = min(max(r[2] - r[0], 24), 300), min(max(r[3] - r[1], 16), 200)
    cx, cy = (r[0] + r[2]) / 2, (r[1] + r[3]) / 2
    probes = [(cx, cy - h), (cx, cy + h), (cx - w, cy), (cx + w, cy),
              (cx - w, cy - h), (cx + w, cy - h), (cx - w, cy + h), (cx + w, cy + h),
              (cx, cy - 2 * h), (cx, cy + 2 * h), (cx - 2 * w, cy), (cx + 2 * w, cy)]
    own_area = max(_area(r), 40000)
    start, seen, out = clock(), set(), []
    for px, py in probes:
        if clock() - start > budget_s:
            break
        try:
            n = element_at(int(px), int(py)) or {}
        except Exception:
            continue
        nr = n.get("rect")
        label = n.get("name") or n.get("automation_id")
        if not label or not _valid(nr) or _area(nr) > 8 * own_area:
            continue
        if list(nr) == list(r) or (n.get("automation_id") and n.get("automation_id") == el.get("automation_id")
                                   and n.get("name") == el.get("name")):
            continue                                                  # that is the element itself
        key = (n.get("name"), n.get("role"), tuple(nr))
        if key in seen:
            continue
        seen.add(key)
        ncx, ncy = (nr[0] + nr[2]) / 2, (nr[1] + nr[3]) / 2
        dx, dy = ncx - x, ncy - y
        item = {"name": n.get("name", ""), "role": n.get("role", ""), "dx": int(round(dx)), "dy": int(round(dy)),
                "dist": int(round(math.hypot(dx, dy))), "side": ("right" if dx > 0 else "left") if abs(dx) >= abs(dy)
                else ("below" if dy > 0 else "above")}
        if n.get("automation_id"):
            item["automation_id"] = n["automation_id"]
        out.append(item)
    out.sort(key=lambda i: i["dist"])
    return out[:limit]


def locate(anchors_found: list[tuple[dict, tuple[float, float]]], tol_floor: int = 14):
    """Combine anchors: ``[(recorded_anchor, (found_cx, found_cy))]`` -> ``(x, y, votes, spread)`` or None.

    Every found anchor implies a position (``found - offset``). The largest group that agrees within a tolerance wins;
    one lone anchor is accepted (votes = 1)."""
    pts = [(fx - a["dx"], fy - a["dy"], a) for a, (fx, fy) in anchors_found]
    if not pts:
        return None
    best: list = []
    for px, py, a in pts:
        tol = max(tol_floor, 0.3 * a.get("dist", 0))
        group = [(qx, qy) for qx, qy, _ in pts if math.hypot(qx - px, qy - py) <= tol]
        if len(group) > len(best):
            best = group
    xs, ys = sorted(p[0] for p in best), sorted(p[1] for p in best)
    mid = len(best) // 2
    spread = max(math.hypot(p[0] - xs[mid], p[1] - ys[mid]) for p in best) if best else 0.0
    return xs[mid], ys[mid], len(best), spread
