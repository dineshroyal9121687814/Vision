"""Custom step library: methods the tester asked the AI to write, stored SEPARATELY from the product code.

    workspace/custom_steps/<name>.py     the method (``def run(ctx, **args)``)
    workspace/custom_steps/<name>.json   description, parameters, status (draft | approved), author, created

Lifecycle: request -> AI drafts the code -> static safety check -> saved as *draft* -> the tester reviews and approves
(or edits) -> approved methods appear in the palette's 'Custom' dropdown and run as ``{"type": "custom"}`` steps.
Drafts only run when ``allow_unreviewed_custom_steps`` is on. Methods get a small ``ctx`` (mouse, keyboard, variables,
waits, verification) - not the whole machine: imports are restricted to a safe allow-list and dangerous names
(``os``, ``subprocess``, ``eval``, ``open`` ...) are rejected before the code is ever saved. This is a guard against
mistakes and against an AI drafting something harmful, NOT a security sandbox - the human review step is the control.
"""
from __future__ import annotations

import ast
import json
import re
import time
from datetime import datetime
from pathlib import Path

from core import paths

NAME_OK = re.compile(r"^[a-z][a-z0-9_]{1,48}$")
ALLOWED_IMPORTS = {"time", "re", "math", "json", "datetime", "random", "string", "decimal", "itertools"}
BANNED_NAMES = {"eval", "exec", "compile", "open", "__import__", "globals", "locals", "vars", "getattr", "setattr",
                "delattr", "input", "breakpoint", "exit", "quit", "memoryview", "os", "sys", "subprocess", "socket",
                "ctypes", "shutil", "pathlib", "importlib", "builtins"}
SAFE_BUILTINS = ("abs all any bool dict enumerate filter float int isinstance len list map max min range reversed round "
                 "set sorted str sum tuple zip print repr ValueError RuntimeError Exception TypeError KeyError").split()


class CustomStepError(ValueError):
    pass


def root() -> Path:
    d = paths.workspace() / "custom_steps"
    d.mkdir(parents=True, exist_ok=True)
    return d


def check_source(source: str) -> list[str]:
    """Static safety / shape check. Returns problems (empty list = acceptable)."""
    try:
        tree = ast.parse(source)
    except SyntaxError as exc:
        return [f"syntax error line {exc.lineno}: {exc.msg}"]
    problems: list[str] = []
    has_run = False
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for a in node.names:
                if a.name.split(".")[0] not in ALLOWED_IMPORTS:
                    problems.append(f"import '{a.name}' is not allowed (allowed: {', '.join(sorted(ALLOWED_IMPORTS))})")
        elif isinstance(node, ast.ImportFrom):
            if (node.module or "").split(".")[0] not in ALLOWED_IMPORTS:
                problems.append(f"import from '{node.module}' is not allowed")
        elif isinstance(node, ast.Name) and node.id in BANNED_NAMES:
            problems.append(f"'{node.id}' is not allowed in a custom step")
        elif isinstance(node, ast.Attribute) and (node.attr.startswith("__") or node.attr in BANNED_NAMES):
            problems.append(f"attribute '{node.attr}' is not allowed")
        elif isinstance(node, ast.FunctionDef) and node.name == "run":
            has_run = True
            if not node.args.args or node.args.args[0].arg != "ctx":
                problems.append("run must take 'ctx' as its first argument: def run(ctx, **args)")
    if not has_run:
        problems.append("the code must define 'def run(ctx, **args)'")
    return sorted(set(problems))


def list_steps() -> list[dict]:
    out = []
    for meta in sorted(root().glob("*.json")):
        try:
            d = json.loads(meta.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            continue
        if meta.with_suffix(".py").exists():
            out.append(d)
    return out


def names(approved_only: bool = False) -> list[str]:
    return [d["name"] for d in list_steps() if not approved_only or d.get("status") == "approved"]


def save(name: str, source: str, description: str = "", params: list | None = None, author: str = "ai",
         status: str = "draft") -> dict:
    if not NAME_OK.match(name or ""):
        raise CustomStepError("Name must be lower-case letters, digits and underscores (2-49 chars), starting with a letter.")
    problems = check_source(source)
    if problems:
        raise CustomStepError("Custom step rejected: " + "; ".join(problems))
    meta = {"name": name, "description": description, "params": params or [], "status": status, "author": author,
            "created": datetime.now().isoformat(timespec="seconds")}
    (root() / f"{name}.py").write_text(source, encoding="utf-8")
    (root() / f"{name}.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")
    return meta


def approve(name: str) -> dict:
    meta = get(name)
    problems = check_source(source_of(name))
    if problems:
        raise CustomStepError("Cannot approve: " + "; ".join(problems))
    meta["status"], meta["approved"] = "approved", datetime.now().isoformat(timespec="seconds")
    (root() / f"{name}.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")
    return meta


def get(name: str) -> dict:
    try:
        return json.loads((root() / f"{name}.json").read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        raise CustomStepError(f"Custom step '{name}' does not exist. Ask the AI to create it (Steps > Ask AI for a new step).") from exc


def source_of(name: str) -> str:
    return (root() / f"{name}.py").read_text(encoding="utf-8")


def delete(name: str) -> bool:
    gone = False
    for ext in (".py", ".json"):
        f = root() / f"{name}{ext}"
        if f.exists():
            f.unlink()
            gone = True
    return gone


class Context:
    """What a custom method may use. Every action goes through the player's own backend / variables."""

    def __init__(self, backend, variables: dict, resolve=None, log=None, dry_run: bool = False):
        self._b, self.vars, self._resolve, self._log, self.dry_run = backend, variables, resolve, log, dry_run
        self.checks: list[dict] = []

    def click(self, x, y, button="left", count=1):
        self._b.click(int(x), int(y), button, count)

    def click_element(self, target: dict, button="left"):
        if not self._resolve:
            raise CustomStepError("This run cannot resolve elements.")
        r = self._resolve(target)
        self._b.click(r.x, r.y, button, 1)
        return {"x": r.x, "y": r.y, "method": r.method}

    def type(self, text):
        self._b.type_text(str(text))

    def hotkey(self, keys):
        self._b.hotkey(str(keys))

    def press(self, key):
        self._b.press(str(key))

    def wait(self, seconds):
        if not self.dry_run:
            time.sleep(max(0.0, min(float(seconds), 60.0)))

    def get(self, name, default=""):
        return self.vars.get(name, default)

    def set(self, name, value):
        self.vars[name] = str(value)

    def log(self, msg):
        if self._log:
            self._log(str(msg))

    def expect(self, condition: bool, message: str):
        """A verification inside the method: raises when false, so the step FAILS instead of passing silently."""
        self.checks.append({"check": message, "ok": bool(condition)})
        if not condition:
            raise CustomStepError(f"Check failed: {message}")


def run(name: str, args: dict, ctx: Context, allow_draft: bool = False) -> dict:
    meta = get(name)
    if meta.get("status") != "approved" and not allow_draft:
        raise CustomStepError(f"Custom step '{name}' is still a draft - review and approve it first (or enable "
                              "'allow_unreviewed_custom_steps').")
    source = source_of(name)
    problems = check_source(source)
    if problems:
        raise CustomStepError(f"Custom step '{name}' no longer passes the safety check: {'; '.join(problems)}")
    import builtins
    safe = {k: getattr(builtins, k) for k in SAFE_BUILTINS if hasattr(builtins, k)}
    safe["__import__"] = _restricted_import
    scope: dict = {"__builtins__": safe, "__name__": f"custom_{name}"}
    exec(compile(source, f"<custom:{name}>", "exec"), scope)          # noqa: S102 - vetted by check_source above
    out = scope["run"](ctx, **{str(k): v for k, v in (args or {}).items()})
    return {"returned": out if isinstance(out, (str, int, float, bool, type(None), list, dict)) else str(out),
            "checks": ctx.checks}


def _restricted_import(name, globals=None, locals=None, fromlist=(), level=0):
    if name.split(".")[0] not in ALLOWED_IMPORTS:
        raise ImportError(f"import '{name}' is not allowed in a custom step")
    return __import__(name, globals, locals, fromlist, level)


PROMPT = """You write ONE Python function for a desktop test-automation tool.
Task: {description}
Rules: define `def run(ctx, **args):`. Use only ctx.click(x,y), ctx.click_element(target_dict), ctx.type(text),
ctx.hotkey('ctrl+s'), ctx.press('enter'), ctx.wait(seconds), ctx.get(name), ctx.set(name, value), ctx.expect(cond, msg),
ctx.log(msg). Imports allowed: {imports}. No file, network or process access. Verify the outcome with ctx.expect.
Return ONLY the code, no explanation."""


def generate(description: str, name: str, llm=None) -> dict:
    """Ask the local AI to draft the method; saves it as a DRAFT. ``llm`` needs ``generate(prompt) -> str|None``."""
    if llm is None:
        from core.ai.llm import OllamaClient
        llm = OllamaClient()
    text = llm.generate(PROMPT.format(description=description, imports=", ".join(sorted(ALLOWED_IMPORTS))))
    if not text:
        raise CustomStepError("The AI model is not available right now (start Ollama, or paste the code written by your AI "
                              "assistant into 'Custom steps > Add code').")
    m = re.search(r"```(?:python)?\s*(.*?)```", text, re.S)
    code = (m.group(1) if m else text).strip() + "\n"
    return save(name, code, description=description, author="ai", status="draft")
