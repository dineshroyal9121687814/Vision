"""Step library: the palette of built-in actions (catalog) and user / AI-written custom steps (custom)."""
