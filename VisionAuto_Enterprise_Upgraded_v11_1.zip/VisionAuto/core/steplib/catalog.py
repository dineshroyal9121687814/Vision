"""The step palette: every action a tester can add, grouped, described and parameterised - no code, no JSON.

Each entry says WHAT the step does, WHICH fields the editor must show (with dropdown choices where the value is one of
a fixed set) and an example. ``build_step`` turns the filled form into a valid step dict; ``suggest`` proposes the
likely next steps after the one just recorded (the 'suggestions' a manual tester expects from Ranorex / UFT).
"""
from __future__ import annotations

import copy

CATEGORIES = ("Mouse", "Keyboard", "Forms & lists", "Windows & apps", "Excel", "Waits & checks", "Flow control", "Data & services", "Custom")

# field kinds: text | number | choice | bool | target | window | target2 (destination) | window2 | file | variable
F = lambda name, label, kind="text", **kw: {"name": name, "label": label, "kind": kind, **kw}    # noqa: E731

_TARGET = F("target", "Element (what to act on)", "target", required=True)
_WINDOW = F("window", "In window", "window")
_MODS = F("modifiers", "Hold keys", "choice", choices=["", "ctrl", "shift", "alt", "ctrl+shift"], where="params")

CATALOG: list[dict] = [
    # ---- mouse
    {"type": "click", "category": "Mouse", "label": "Click", "help": "Left-click an element or button.", "fields": [_TARGET, _WINDOW, _MODS]},
    {"type": "double_click", "category": "Mouse", "label": "Double-click", "fields": [_TARGET, _WINDOW]},
    {"type": "right_click", "category": "Mouse", "label": "Right-click (context menu)", "fields": [_TARGET, _WINDOW]},
    {"type": "middle_click", "category": "Mouse", "label": "Middle-click", "fields": [_TARGET, _WINDOW]},
    {"type": "hover", "category": "Mouse", "label": "Hover (move mouse over)", "fields": [_TARGET, _WINDOW]},
    {"type": "drag_drop", "category": "Mouse", "label": "Drag and drop",
     "help": "Drag from a container / window to another container / window. Pick source and destination separately.",
     "fields": [F("target", "Drag FROM element", "target", required=True), F("window", "From window", "window"),
                F("to", "Drop ON element (container)", "target2", required=True), F("to_window", "To window", "window2"),
                F("hold_ms", "Hold before moving (ms)", "number", where="params", default=150)]},
    {"type": "scroll", "category": "Mouse", "label": "Scroll", "fields": [
        _TARGET, F("direction", "Direction", "choice", choices=["down", "up", "left", "right"], where="params", default="down"),
        F("amount", "Notches", "number", where="params", default=3)]},
    # ---- keyboard
    {"type": "type", "category": "Keyboard", "label": "Type text", "help": "Use ${column} to type test data.",
     "fields": [_TARGET, F("text", "Text", "text", where="params", required=True), _WINDOW]},
    {"type": "key", "category": "Keyboard", "label": "Press a key", "fields": [
        F("key", "Key", "choice", where="params", required=True,
          choices=["enter", "tab", "esc", "space", "backspace", "delete", "up", "down", "left", "right", "home", "end",
                   "page_up", "page_down", "f2", "f5"])]},
    {"type": "hotkey", "category": "Keyboard", "label": "Key combination", "fields": [
        F("keys", "Keys (e.g. ctrl+s)", "text", where="params", required=True)]},
    {"type": "set_clipboard", "category": "Keyboard", "label": "Put text on the clipboard", "fields": [F("text", "Text", "text", where="params")]},
    # ---- forms & lists
    {"type": "set_value", "category": "Forms & lists", "label": "Set field value (verified)", "help": "Types and reads the value back.",
     "fields": [_TARGET, F("value", "Value", "text", where="params", required=True), _WINDOW]},
    {"type": "append_value", "category": "Forms & lists", "label": "Append to field", "fields": [_TARGET, F("value", "Text", "text", where="params")]},
    {"type": "clear_value", "category": "Forms & lists", "label": "Clear field", "fields": [_TARGET]},
    {"type": "read_value", "category": "Forms & lists", "label": "Read value into a variable", "fields": [
        _TARGET, F("save_as", "Save as variable", "variable", where="params", required=True)]},
    {"type": "select_option", "category": "Forms & lists", "label": "Select from dropdown", "help":
     "Opens the list, scrolls to the item (or types it) and checks the selection.",
     "fields": [_TARGET, F("text", "Option text", "text", where="params", required=True), _WINDOW]},
    {"type": "set_state", "category": "Forms & lists", "label": "Check / uncheck / select", "fields": [
        _TARGET, F("state", "State", "choice", choices=["check", "uncheck", "select", "expand", "collapse"], where="params", default="check")]},
    {"type": "upload_file", "category": "Forms & lists", "label": "Choose a file in a file dialog", "fields": [F("path", "File path", "file", where="params")]},
    {"type": "fill_table", "category": "Forms & lists", "label": "Fill a table / grid", "fields": [_TARGET]},
    # ---- windows & apps
    {"type": "open_app", "category": "Windows & apps", "label": "Open application", "fields": [
        F("name", "Application name (e.g. Calculator, Excel)", "text", where="params", required=True),
        F("exe", "…or program path", "file", where="params")]},
    {"type": "launch_app", "category": "Windows & apps", "label": "Launch program path", "fields": [F("path", "Path", "file", where="params")]},
    {"type": "wait_for_window", "category": "Windows & apps", "label": "Wait for window", "fields": [_WINDOW, F("timeout_s", "Timeout (s)", "number", where="params", default=15)]},
    {"type": "window_action", "category": "Windows & apps", "label": "Window: maximize / minimize / close / focus", "fields": [
        _WINDOW, F("action", "Action", "choice", choices=["focus", "maximize", "minimize", "restore", "close"], where="params")]},
    # ---- excel
    {"type": "excel_save", "category": "Excel", "label": "Save workbook", "fields": [F("path", "Workbook", "file", where="params"), F("save_as", "Save as", "file", where="params")]},
    {"type": "excel_close", "category": "Excel", "label": "Close workbook", "fields": [F("path", "Workbook", "file", where="params"), F("save", "Save changes", "bool", where="params")]},
    # ---- waits & checks
    {"type": "wait", "category": "Waits & checks", "label": "Wait (seconds)", "fields": [F("seconds", "Seconds", "number", where="params", default=1)]},
    {"type": "wait_until", "category": "Waits & checks", "label": "Wait until element appears / disappears", "fields": [_TARGET]},
    {"type": "scroll_until", "category": "Waits & checks", "label": "Scroll until element is visible", "fields": [_TARGET]},
    {"type": "validate", "category": "Waits & checks", "label": "Check (assert)", "help": "Pass/fail check: element exists, text equals/contains, image visible.",
     "fields": [F("validation_type", "Check", "choice", where="check", choices=["element_exists", "element_not_exists", "text_equals", "text_contains", "image_visible", "value_check"]),
                _TARGET, F("expected", "Expected", "text", where="check"),
                F("op", "Compare (for value_check)", "choice", where="check", choices=["", "equals", "not_equals", "contains", "not_contains", "starts_with", "ends_with", "regex", "not_empty", "empty", "is_number", "gt", "ge", "lt", "le", "between", "date_before", "date_after", "length_equals", "in_list"]),
                F("expected2", "Upper limit (between)", "text", where="check"),
                F("tolerance", "Tolerance (numbers)", "number", where="check"),
                F("on_fail", "If it fails", "choice", choices=["", "continue"], default="")]},
    # ---- flow
    {"type": "loop_start", "category": "Flow control", "label": "Repeat (start)", "fields": [F("times", "Times", "number", where="params", default=2)]},
    {"type": "loop_end", "category": "Flow control", "label": "Repeat (end)", "fields": []},
    {"type": "if_start", "category": "Flow control", "label": "If (start)", "fields": []},
    {"type": "else", "category": "Flow control", "label": "Else", "fields": []},
    {"type": "if_end", "category": "Flow control", "label": "If (end)", "fields": []},
    {"type": "break_loop", "category": "Flow control", "label": "Break loop", "fields": []},
    # ---- data & services
    {"type": "set_variable", "category": "Data & services", "label": "Set variable / calculate", "help":
     "Store a value. Start with = to calculate: =upper(${name}), =int(${qty})*2, =today(\"%d-%m-%Y\"), =add_days(today(), 7), =random_email().",
     "fields": [F("name", "Variable name", "variable", where="params", required=True), F("value", "Value or =expression", "text", where="params", required=True)]},
    {"type": "call_test", "category": "Data & services", "label": "Call another test (reusable module)", "help":
     "Runs a saved test here, e.g. 'login'. Pass values as name=value lines.",
     "fields": [F("test", "Test name", "text", where="params", required=True), F("args", "Arguments (name=value, one per line)", "text", where="params")]},
    {"type": "run_command", "category": "Data & services", "label": "Run a program / script", "fields": [
        F("command", "Command", "text", where="params", required=True), F("folder", "Run in folder", "file", where="params"),
        F("timeout_s", "Timeout (s)", "number", where="params", default=60), F("expect_exit", "Expected exit code", "number", where="params", default=0),
        F("expect_output", "Output must contain", "text", where="params"), F("save_as", "Save output as variable", "variable", where="params")]},
    {"type": "http_request", "category": "Data & services", "label": "Call a web service (API)", "fields": [
        F("method", "Method", "choice", choices=["GET", "POST", "PUT", "PATCH", "DELETE"], where="params", default="GET"),
        F("url", "Address (https://...)", "text", where="params", required=True), F("headers", "Headers (JSON)", "text", where="params"),
        F("body", "Body", "text", where="params"), F("expect_status", "Expected status (e.g. 200,201)", "text", where="params"),
        F("expect_text", "Answer must contain", "text", where="params"), F("json_path", "Read JSON field (a.b.0.c)", "text", where="params"),
        F("save_as", "Save as variable", "variable", where="params")]},
    {"type": "sql_query", "category": "Data & services", "label": "Query a database (SQLite)", "fields": [
        F("database", "Database file", "file", where="params", required=True), F("sql", "SQL", "text", where="params", required=True),
        F("expect_rows", "Expected row count", "number", where="params"), F("expect_value", "First value must be", "text", where="params"),
        F("save_as", "Save first value as variable", "variable", where="params"), F("allow_changes", "Allow INSERT/UPDATE/DELETE", "bool", where="params")]},
    {"type": "screenshot", "category": "Data & services", "label": "Take a screenshot (evidence)", "fields": [F("name", "Name", "text", where="params")]},
    # ---- custom
    {"type": "custom", "category": "Custom", "label": "Custom step (your / AI-written method)", "help":
     "Runs a method from the custom step library. Missing one? Ask the AI to write it.",
     "fields": [F("method", "Method", "choice", where="params", required=True, choices_from="custom_steps"),
                F("args", "Arguments (name=value, one per line)", "text", where="params")]},
]
BY_TYPE = {e["type"]: e for e in CATALOG}


def entries(category: str | None = None) -> list[dict]:
    return [copy.deepcopy(e) for e in CATALOG if category in (None, e["category"])]


def grouped() -> dict[str, list[dict]]:
    return {c: entries(c) for c in CATEGORIES if entries(c)}


def action_types() -> list[str]:
    return [e["type"] for e in CATALOG]


def build_step(step_type: str, values: dict, step_id: int = 0) -> dict:
    """Form values -> a step dict. Raises ValueError naming the missing required field (shown to the tester)."""
    e = BY_TYPE.get(step_type)
    if e is None:
        raise ValueError(f"Unknown step type '{step_type}'.")
    step: dict = {"id": step_id, "type": step_type}
    params: dict = {}
    check: dict = {}
    for f in e["fields"]:
        v = values.get(f["name"], f.get("default"))
        empty = v is None or v == ""
        if f.get("required") and empty:
            raise ValueError(f"'{f['label']}' is required for '{e['label']}'.")
        if empty:
            continue
        if f["kind"] == "number":
            try:
                v = float(v)
                v = int(v) if v == int(v) else v
            except (TypeError, ValueError) as exc:
                raise ValueError(f"'{f['label']}' must be a number.") from exc
        if isinstance(v, str) and f["kind"] in ("target", "target2"):        # a tester types the element's visible text
            v = {"name": v.strip(), "text": v.strip()}
        elif isinstance(v, str) and f["kind"] in ("window", "window2"):
            v = {"title": v.strip()}
        elif f["kind"] == "bool" and isinstance(v, str):
            v = v.strip().lower() in ("1", "true", "yes", "on")
        where = f.get("where")
        if where == "params":
            params[f["name"]] = v
        elif where == "check":
            check[f["name"]] = v
        elif f["kind"] == "target2":
            step["to"] = v
        elif f["kind"] == "window2":
            step["to_window"] = v
        else:
            step[f["name"]] = v
    if "validation_type" in check:                       # the engine reads check["type"]
        check["type"] = check.pop("validation_type")
        if check.get("op") == "":
            check.pop("op")
    if step_type in ("custom", "call_test"):
        params["args"] = parse_args(params.get("args", ""))
    if params:
        step["params"] = params
    if check:
        step["check"] = check
    return step


def parse_args(text) -> dict:
    if isinstance(text, dict):
        return text
    out = {}
    for line in str(text or "").splitlines():
        if "=" in line:
            k, v = line.split("=", 1)
            out[k.strip()] = v.strip()
    return out


_NEXT = {
    "type": ["key:enter", "key:tab", "validate"],
    "set_value": ["validate", "key:tab"],
    "select_option": ["validate"],
    "click": ["validate", "wait_for_window", "wait"],
    "open_app": ["wait_for_window", "validate"],
    "drag_drop": ["validate"],
    "read_value": ["validate"],
    "hotkey": ["wait", "validate"],
}


def suggest(last_type: str | None, data_columns=()) -> list[dict]:
    """Likely next steps after ``last_type`` (shown as one-click suggestions). Data columns suggest ``${col}`` typing."""
    out = []
    for item in _NEXT.get(last_type or "", ["click", "type", "validate"]):
        t, _, arg = item.partition(":")
        e = BY_TYPE[t]
        out.append({"type": t, "label": e["label"] + (f" ({arg})" if arg else ""), "preset": {"key": arg} if arg else {}})
    for col in list(data_columns)[:3]:
        out.append({"type": "type", "label": f"Type test data ${{{col}}}", "preset": {"text": f"${{{col}}}"}})
    return out
