"""
Secret redaction for run results and reports.

A variable is secret when its name looks like a credential or the test lists it
in `secret_variables`. Secret VALUES are also scrubbed from every string in a
run result (errors, descriptions, saved outputs), so a password typed through
`${password}` cannot leak into run.json, report.html or junit.xml.
"""
from __future__ import annotations

import re
from copy import deepcopy
from typing import Any

REDACTED = "***REDACTED***"
SENSITIVE_NAME = re.compile(r"(pass(word|wd|phrase)?|pwd|secret|token|api[_\-]?key|auth|credential|private[_\-]?key|otp|pin)", re.I)
MIN_SECRET_LEN = 3   # shorter values would scrub innocent text ("1", "ab")


def is_secret_name(name: str, declared=()) -> bool:
    return str(name) in set(declared or ()) or bool(SENSITIVE_NAME.search(str(name)))


def secret_names(variables: dict, declared=()) -> set[str]:
    return {k for k in (variables or {}) if is_secret_name(k, declared)}


def secret_values(variables: dict, declared=()) -> list[str]:
    vals = {str(variables[k]) for k in secret_names(variables, declared) if variables.get(k) is not None}
    # longest first so a secret containing another secret is replaced whole
    return sorted((v for v in vals if len(v) >= MIN_SECRET_LEN), key=len, reverse=True)


def scrub(obj: Any, values: list[str]) -> Any:
    if not values:
        return obj
    if isinstance(obj, str):
        for v in values:
            obj = obj.replace(v, REDACTED)
        return obj
    if isinstance(obj, list):
        return [scrub(x, values) for x in obj]
    if isinstance(obj, dict):
        return {k: scrub(v, values) for k, v in obj.items()}
    return obj


def redact_run(run: dict, variables: dict, declared=()) -> dict:
    """Return a copy of a run result that is safe to write to disk."""
    names = secret_names(variables, declared)
    values = secret_values(variables, declared)
    out = deepcopy(run)
    if isinstance(out.get("variables"), dict):
        out["variables"] = {k: (REDACTED if k in names else v) for k, v in out["variables"].items()}
    for step in out.get("steps", []):
        saved = step.get("saved_as")
        if isinstance(saved, dict):
            step["saved_as"] = {k: (REDACTED if k in names else v) for k, v in saved.items()}
    return scrub(out, values)
