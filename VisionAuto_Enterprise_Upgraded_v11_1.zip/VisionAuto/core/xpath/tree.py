"""Element tree used by the XPath engine.

``UiaNode`` is a plain data holder, so the whole XPath machinery is testable on any OS.
``core.system.uia_tree`` fills it from a live Windows window; tests build it by hand.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field

from lxml import etree

# UI Automation control type -> RanoreXPath role name (the tag Ranorex users write)
RANOREX_ROLES = {
    "window": "form", "button": "button", "edit": "text", "text": "text", "document": "document",
    "checkbox": "checkbox", "radiobutton": "radiobutton", "combobox": "combobox",
    "listitem": "listitem", "list": "list", "menuitem": "menuitem", "menu": "menu",
    "menubar": "menubar", "tabitem": "tabpage", "tab": "tabcontrol", "hyperlink": "link",
    "treeitem": "treeitem", "tree": "tree", "slider": "slider", "image": "image",
    "table": "table", "dataitem": "row", "datagrid": "table", "toolbar": "toolbar",
    "statusbar": "statusbar", "titlebar": "titlebar", "scrollbar": "scrollbar",
    "progressbar": "progressbar", "spinner": "spinner", "pane": "container",
    "group": "container", "custom": "container", "header": "header", "headeritem": "columnheader",
    "splitbutton": "button", "thumb": "thumb", "tooltip": "tooltip", "calendar": "calendar",
}
_TAG_CLEAN = re.compile(r"[^a-z0-9_]+")


def tag_for(control_type: str, dialect: str) -> str:
    base = _TAG_CLEAN.sub("", (control_type or "custom").casefold()) or "custom"
    return RANOREX_ROLES.get(base, "container") if dialect == "ranorex" else base


@dataclass(eq=False)
class UiaNode:
    control_type: str = "Custom"
    name: str = ""
    automation_id: str = ""
    class_name: str = ""
    rect: tuple = (0, 0, 0, 0)            # left, top, right, bottom (screen pixels)
    value: str = ""
    text: str = ""
    enabled: bool = True
    visible: bool = True
    password: bool = False
    process: str = ""
    extra: dict = field(default_factory=dict)
    children: list = field(default_factory=list)
    parent: "UiaNode | None" = field(default=None, repr=False)

    def add(self, *kids: "UiaNode") -> "UiaNode":
        for k in kids:
            k.parent = self
            self.children.append(k)
        return self

    # ------------------------------------------------------------ geometry
    @property
    def width(self) -> int:
        return max(0, int(self.rect[2] - self.rect[0]))

    @property
    def height(self) -> int:
        return max(0, int(self.rect[3] - self.rect[1]))

    @property
    def center(self) -> tuple:
        return ((self.rect[0] + self.rect[2]) // 2, (self.rect[1] + self.rect[3]) // 2)

    def walk(self):
        yield self
        for child in self.children:
            yield from child.walk()

    def describe(self) -> dict:
        """Same shape as ``winenv._describe`` so a node can feed the resolver unchanged."""
        out = {"name": self.name, "role": self.control_type, "automation_id": self.automation_id,
               "class_name": self.class_name, "rect": [int(v) for v in self.rect],
               "is_password": self.password, "is_enabled": self.enabled}
        if self.value and not self.password:
            out["value"] = self.value
        if self.text and not self.password:
            out["text"] = self.text
        return out


def node_from_dict(d: dict) -> UiaNode:
    """Build a tree from nested dicts (``{"control_type":..., "children":[...]}``) - used by tests and fixtures."""
    node = UiaNode(
        control_type=d.get("control_type") or d.get("role") or "Custom", name=d.get("name", ""),
        automation_id=d.get("automation_id", ""), class_name=d.get("class_name", ""),
        rect=tuple(d.get("rect", (0, 0, 0, 0))), value=d.get("value", ""), text=d.get("text", ""),
        enabled=bool(d.get("enabled", True)), visible=bool(d.get("visible", True)),
        password=bool(d.get("password", False)), process=d.get("process", ""),
        extra=dict(d.get("extra", {})))
    for child in d.get("children", []):
        node.add(node_from_dict(child))
    return node


def _bool(value: bool, dialect: str = "uia") -> str:
    # Always lower-case: the engine lower-cases 'True'/'False' literals compared with boolean
    # attributes, so Ranorex-style @enabled='True' and XPath-style @enabled='true' both work.
    return "true" if value else "false"


def to_lxml(root: UiaNode, dialect: str = "uia", max_nodes: int = 20000):
    """Project the tree to lxml. Returns ``(desktop_element, index)``; ``index[i]`` is the UiaNode for ``@_i``.

    The root is wrapped in a synthetic ``<desktop>`` so that absolute Ranorex paths (``/form[...]``) work.
    Password controls never expose a value or text attribute.
    """
    index: list[UiaNode] = []
    desktop = etree.Element("desktop")

    def emit(node: UiaNode, parent) -> None:
        if len(index) >= max_nodes:
            return
        el = etree.SubElement(parent, tag_for(node.control_type, dialect))
        el.set("_i", str(len(index)))
        index.append(node)
        shown_text = "" if node.password else (node.text or node.value or node.name)
        attrs = {
            "name": node.name, "accessiblename": node.name, "automationid": node.automation_id,
            "controlname": node.automation_id, "classname": node.class_name,
            "controltype": node.control_type, "text": shown_text,
            "innertext": shown_text, "value": "" if node.password else node.value,
            "enabled": _bool(node.enabled, dialect), "visible": _bool(node.visible, dialect),
            "password": _bool(node.password, dialect),
            "left": str(int(node.rect[0])), "top": str(int(node.rect[1])),
            "right": str(int(node.rect[2])), "bottom": str(int(node.rect[3])),
            "width": str(node.width), "height": str(node.height),
            "processname": node.process,
        }
        if node.control_type.casefold() == "window":
            attrs["title"] = node.name
            attrs["caption"] = node.name
        for key, val in node.extra.items():
            attrs.setdefault(str(key).casefold(), str(val))
        for key, val in attrs.items():
            if val is not None and val != "":
                el.set(key, str(val))
            elif key in ("name", "text", "value", "automationid", "classname"):
                el.set(key, "")          # always present so @name='' and not(@name) behave predictably
        for child in node.children:
            emit(child, el)

    if root.control_type.casefold() == "desktop":
        for child in root.children:
            emit(child, desktop)
    else:
        emit(root, desktop)
    return desktop, index
