"""
Inspect-style location of a recorded element: *which window, which pane, which tab, which control*.

The recorder already reads the UI Automation parent chain of every clicked element (``ancestors``, nearest first).
From it we build

* ``breadcrumb``  ``Calculator [Window] > Pane > Group > Nine [Button #num9Button]``  - what Microsoft Inspect /
  Accessibility Insights show in their tree, so a tester can see exactly where a step acts;
* ``xpath``       ``/window[@name='Calculator']//button[@automationid='num9Button']`` - the same element anchored in
  its own top-level window, so a look-alike control in another window or pane can never be mistaken for it.

Pure functions; no OS access.
"""
from __future__ import annotations

from core.xpath.engine import _xpath_literal
from core.xpath.tree import tag_for

_DESKTOP_NAMES = ("desktop",)


def _is_desktop(node: dict) -> bool:
    return str(node.get("role") or "").casefold() == "pane" and str(node.get("name") or "").casefold().startswith(_DESKTOP_NAMES)


def _label(node: dict, last: bool = False) -> str:
    role = node.get("role") or "Element"
    name = node.get("name") or ""
    aid = node.get("automation_id") or ""
    if last:
        extra = f" #{aid}" if aid else ""
        return f"{name} [{role}{extra}]" if name else f"[{role}{extra}]"
    return f"{name} [{role}]" if name else role


def _predicate(node: dict) -> str:
    if node.get("automation_id"):
        return f"[@automationid={_xpath_literal(node['automation_id'])}]"
    if node.get("name"):
        return f"[@name={_xpath_literal(node['name'])}]"
    return ""


def element_path(el: dict) -> dict | None:
    """``el`` is a recorder element dict (name/role/automation_id + ``ancestors`` nearest-first). None if too little is known."""
    if not el or not (el.get("name") or el.get("automation_id") or el.get("role")):
        return None
    chain = [a for a in reversed(el.get("ancestors") or []) if not _is_desktop(a)]
    top = next((i for i, a in enumerate(chain) if str(a.get("role") or "").casefold() == "window"), None)
    if top is not None:
        chain = chain[top:]                      # drop anything above the top-level window
    nodes = chain + [el]
    breadcrumb = " > ".join(_label(n, n is el) for n in nodes)
    pred = _predicate(el)
    tag = tag_for(el.get("role") or "custom", "uia")
    if top is not None and chain and (chain[0].get("name") or chain[0].get("automation_id")):
        win = chain[0]
        xp = f"/window{_predicate(win)}//{tag}{pred}" if pred else ""
    else:
        xp = f"//{tag}{pred}" if pred else ""
    return {"breadcrumb": breadcrumb, "xpath": xp}
