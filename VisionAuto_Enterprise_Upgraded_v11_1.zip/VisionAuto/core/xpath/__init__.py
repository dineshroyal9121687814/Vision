"""Real XPath 1.0 / RanoreXPath querying over a UI Automation element tree.

* :mod:`core.xpath.tree`    - pure-Python element tree (``UiaNode``) + lxml projection
* :mod:`core.xpath.engine`  - compile / query / rank / generate XPath, RanoreXPath translation
* :mod:`core.system.uia_tree` - Windows-only snapshot of a live window into a ``UiaNode`` tree
"""
from core.xpath.engine import (XPathError, compile_xpath, find_best, generate_xpath, query,
                               rank_nodes, rxpath_to_xpath)
from core.xpath.tree import UiaNode, node_from_dict

__all__ = ["XPathError", "UiaNode", "compile_xpath", "find_best", "generate_xpath", "node_from_dict",
           "query", "rank_nodes", "rxpath_to_xpath"]
