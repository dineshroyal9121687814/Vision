"""XPath 1.0 + RanoreXPath engine over a ``UiaNode`` tree.

Why this exists: Ranorex and UFT both locate controls with a path language.  VisionAuto previously
parsed a tiny RanoreXPath subset into name/role hints.  This module evaluates *real* XPath 1.0
(every axis, ``and``/``or``, ``contains``, ``starts-with``, ``position()``, ``count()`` ...) plus the
Ranorex ``~`` regex operator against the live UI tree, and can also *generate* a robust XPath for
a recorded element and *rank* candidates by similarity when an exact path no longer matches
(self-healing).

Conventions
-----------
* Attribute and tag names are case-insensitive (everything outside string literals is lower-cased),
  so ``//Button[@Name='Save']`` and ``//button[@name='Save']`` are identical.
* ``dialect="uia"``      tags are UI Automation control types: ``window``, ``button``, ``edit`` ...
  ``dialect="ranorex"``  tags are Ranorex roles: ``form``, ``button``, ``text``, ``container`` ...
* Absolute paths are anchored at a synthetic ``<desktop>`` element, so ``/form[@title='Calc']//button``
  works exactly like in Ranorex.
* Regex operator ``@attr ~ 'pattern'`` (and ``!~``) is translated to the EXSLT ``re:test``.
"""
from __future__ import annotations

import difflib
import re
from dataclasses import dataclass, field

from lxml import etree

from core.xpath.tree import UiaNode, to_lxml

EXSLT_RE = "http://exslt.org/regular-expressions"
MAX_EXPR_LEN = 2000
MAX_RESULTS = 500
_PLACE = "\x00"


class XPathError(ValueError):
    """The expression is not valid XPath / RanoreXPath."""


# --------------------------------------------------------------------------- literal helpers
def _xpath_literal(value: str) -> str:
    if "'" not in value:
        return f"'{value}'"
    if '"' not in value:
        return f'"{value}"'
    parts = value.split("'")
    return "concat(" + ", \"'\", ".join(f"'{p}'" for p in parts) + ")"


def _split_strings(expr: str) -> tuple[str, list[str]]:
    """Replace string literals with placeholders. ``\\'`` / ``\\"`` inside a literal escape the quote
    (RanoreXPath style); every other backslash is kept (so regexes like ``\\d+`` survive)."""
    out: list[str] = []
    strings: list[str] = []
    i, n = 0, len(expr)
    while i < n:
        ch = expr[i]
        if ch in "'\"":
            quote, buf = ch, []
            i += 1
            while True:
                if i >= n:
                    raise XPathError("unterminated string literal")
                c = expr[i]
                if c == "\\" and i + 1 < n and expr[i + 1] == quote:
                    buf.append(quote)
                    i += 2
                    continue
                if c == quote:
                    i += 1
                    break
                buf.append(c)
                i += 1
            strings.append("".join(buf))
            out.append(f"{_PLACE}{len(strings) - 1}{_PLACE}")
        else:
            out.append(ch)
            i += 1
    return "".join(out), strings


_REGEX_OP = re.compile(r"@([\w\-]+)\s*(!~|~)\s*" + _PLACE + r"(\d+)" + _PLACE)
_BOOL_CMP = re.compile(r"(@(?:enabled|visible|password)\s*!?=\s*)" + _PLACE + r"(\d+)" + _PLACE)
_NO_TILDE = re.compile(r"~")


def rxpath_to_xpath(expr: str) -> str:
    """Translate RanoreXPath / loose XPath into strict XPath 1.0 that lxml evaluates."""
    if expr is None or not str(expr).strip():
        raise XPathError("empty XPath")
    expr = str(expr).strip()
    if len(expr) > MAX_EXPR_LEN:
        raise XPathError(f"XPath is longer than {MAX_EXPR_LEN} characters")
    code, strings = _split_strings(expr)
    code = code.casefold()

    def regex_sub(m):
        fn = f"re:test(@{m.group(1)}, {_PLACE}{m.group(3)}{_PLACE})"
        return f"not({fn})" if m.group(2) == "!~" else fn

    code = _REGEX_OP.sub(regex_sub, code)

    def bool_sub(m):
        idx = int(m.group(2))
        if strings[idx].casefold() in ("true", "false"):
            strings[idx] = strings[idx].casefold()
        return m.group(0)

    _BOOL_CMP.sub(bool_sub, code)
    if "~" in code:
        raise XPathError("the '~' regex operator must look like @attribute~'pattern'")
    result = re.sub(_PLACE + r"(\d+)" + _PLACE, lambda m: _xpath_literal(strings[int(m.group(1))]), code)
    return result


def _anchor(xpath: str) -> str:
    """Anchor absolute paths at the synthetic desktop element."""
    stripped = xpath.lstrip()
    if stripped.startswith("//"):
        return "." + stripped
    if stripped.startswith("/") and not stripped.startswith("/desktop"):
        return "." + stripped
    return stripped


@dataclass
class CompiledXPath:
    source: str
    xpath: str
    dialect: str
    _fn: object = field(repr=False, default=None)


_cache: dict = {}


def compile_xpath(expr: str, dialect: str = "uia") -> CompiledXPath:
    """Validate and compile. Raises ``XPathError`` with a readable message on bad syntax."""
    key = (expr, dialect)
    hit = _cache.get(key)
    if hit:
        return hit
    translated = rxpath_to_xpath(expr)
    try:
        fn = etree.XPath(_anchor(translated), namespaces={"re": EXSLT_RE}, smart_strings=False)
    except etree.XPathSyntaxError as exc:
        raise XPathError(f"invalid XPath {expr!r}: {exc}") from exc
    compiled = CompiledXPath(expr, translated, dialect, fn)
    if len(_cache) > 512:
        _cache.clear()
    _cache[key] = compiled
    return compiled


# --------------------------------------------------------------------------- querying
def _run(compiled: CompiledXPath, desktop):
    try:
        return compiled._fn(desktop)
    except (etree.XPathEvalError, etree.XPathResultError) as exc:
        raise XPathError(f"could not evaluate {compiled.source!r}: {exc}") from exc


def query(root: UiaNode, expr: str, dialect: str = "uia", visible_only: bool = False) -> list[UiaNode]:
    """Every node matching ``expr`` in document order."""
    compiled = compile_xpath(expr, dialect)
    desktop, index = to_lxml(root, dialect)
    result = _run(compiled, desktop)
    if not isinstance(result, list):
        return []
    nodes = []
    for el in result[:MAX_RESULTS]:
        if isinstance(el, etree._Element):
            i = el.get("_i")
            if i is not None:
                nodes.append(index[int(i)])
    if visible_only:
        nodes = [n for n in nodes if n.visible and n.width > 0 and n.height > 0]
    return nodes


def evaluate(root: UiaNode, expr: str, dialect: str = "uia"):
    """Raw XPath value - for ``count(//button)``, ``string(//edit/@value)`` and friends."""
    compiled = compile_xpath(expr, dialect)
    desktop, _ = to_lxml(root, dialect)
    result = _run(compiled, desktop)
    if isinstance(result, list):
        return [r if not isinstance(r, etree._Element) else r.get("name", "") for r in result]
    return result


@dataclass
class Match:
    node: UiaNode | None
    candidates: list
    ambiguous: bool = False
    how: str = ""


def find_best(root: UiaNode, expr: str, dialect: str = "uia", near: tuple | None = None,
              min_gap: float = 20.0) -> Match:
    """Resolve an XPath to ONE clickable node, or say why not.

    Hidden / zero-size nodes are ignored.  Several matches are only accepted when ``near`` (the
    recorded centre) separates them by ``min_gap`` px - otherwise ``ambiguous=True`` and ``node=None``
    so the caller falls through to the next locator tier instead of guessing.
    """
    nodes = query(root, expr, dialect, visible_only=True)
    if not nodes:
        return Match(None, [], False, "no match")
    if len(nodes) == 1:
        return Match(nodes[0], nodes, False, "unique")
    if near is not None:
        def dist(n):
            cx, cy = n.center
            return ((cx - near[0]) ** 2 + (cy - near[1]) ** 2) ** 0.5
        ordered = sorted(nodes, key=dist)
        if dist(ordered[1]) - dist(ordered[0]) >= min_gap:
            return Match(ordered[0], ordered, False, "nearest of several")
    return Match(None, nodes, True, f"{len(nodes)} matches")


# --------------------------------------------------------------------------- ranking (healing)
def _sim(a: str, b: str) -> float:
    a, b = (a or "").casefold().strip(), (b or "").casefold().strip()
    if not a or not b:
        return 0.0
    if a == b:
        return 1.0
    return difflib.SequenceMatcher(None, a, b).ratio()


def rank_nodes(root: UiaNode, signature: dict, limit: int = 5) -> list[tuple[float, UiaNode]]:
    """Score every visible node against a recorded element signature (name, automation_id, role,
    class_name, text, rect) and return the best ``limit`` as ``(score 0..1, node)``.

    Only the signature fields that were actually recorded take part, so a sparse signature is not
    penalised for what it never knew.
    """
    weights = {"automation_id": 0.34, "name": 0.26, "role": 0.12, "class_name": 0.06, "text": 0.10, "rect": 0.12}
    sig = {k: signature.get(k) for k in weights if signature.get(k)}
    if not sig:
        return []
    total = sum(weights[k] for k in sig)
    scored = []
    for node in root.walk():
        if node.width <= 0 or node.height <= 0 or not node.visible:
            continue
        s = 0.0
        if "automation_id" in sig:
            s += weights["automation_id"] * (1.0 if node.automation_id == sig["automation_id"] else 0.0)
        if "name" in sig:
            s += weights["name"] * _sim(node.name, sig["name"])
        if "role" in sig:
            s += weights["role"] * (1.0 if node.control_type.casefold() == str(sig["role"]).casefold() else 0.0)
        if "class_name" in sig:
            s += weights["class_name"] * (1.0 if node.class_name == sig["class_name"] else 0.0)
        if "text" in sig:
            s += weights["text"] * max(_sim(node.text, sig["text"]), _sim(node.value, sig["text"]), _sim(node.name, sig["text"]))
        if "rect" in sig:
            r = sig["rect"]
            ox, oy = (r[0] + r[2]) / 2, (r[1] + r[3]) / 2
            cx, cy = node.center
            d = ((cx - ox) ** 2 + (cy - oy) ** 2) ** 0.5
            s += weights["rect"] * max(0.0, 1.0 - d / 400.0)
        score = s / total
        # An exact automation id is the strongest identity signal UI Automation offers: a renamed label or a
        # moved control must not stop it healing (role must still agree when it was recorded).
        if ("automation_id" in sig and node.automation_id == sig["automation_id"]
                and ("role" not in sig or node.control_type.casefold() == str(sig["role"]).casefold())):
            score = max(score, 0.88)
        scored.append((score, node))
    scored.sort(key=lambda t: -t[0])
    return scored[:limit]


# --------------------------------------------------------------------------- generation
def generate_xpath(node: UiaNode, root: UiaNode, dialect: str = "uia") -> str:
    """The shortest *unique* XPath for ``node`` inside ``root``.

    Preference order (most stable first): automation id -> name -> name+class -> text ->
    path anchored at the nearest uniquely identifiable ancestor -> full positional path.
    """
    desktop, index = to_lxml(root, dialect)
    target_i = next((i for i, n in enumerate(index) if n is node), None)
    if target_i is None:
        raise XPathError("node is not part of the supplied tree")
    el = desktop.xpath(f"//*[@_i='{target_i}']")[0]
    tag = el.tag

    def unique(expr: str) -> bool:
        try:
            found = etree.XPath(_anchor(expr), namespaces={"re": EXSLT_RE})(desktop)
        except etree.XPathError:
            return False
        return len(found) == 1 and found[0] is el

    def lit(v):
        return _xpath_literal(v)

    attrs = {k: el.get(k, "") for k in ("automationid", "name", "classname", "text")}
    candidates = []
    if attrs["automationid"]:
        candidates.append(f"//{tag}[@automationid={lit(attrs['automationid'])}]")
    if attrs["name"]:
        candidates.append(f"//{tag}[@name={lit(attrs['name'])}]")
        if attrs["classname"]:
            candidates.append(f"//{tag}[@name={lit(attrs['name'])} and @classname={lit(attrs['classname'])}]")
    if attrs["text"] and attrs["text"] != attrs["name"]:
        candidates.append(f"//{tag}[@text={lit(attrs['text'])}]")
    for c in candidates:
        if unique(c):
            return c

    # anchor at the nearest ancestor that can be identified uniquely
    chain, cur = [], el
    while cur is not None and cur.tag != "desktop":
        chain.append(cur)
        cur = cur.getparent()

    def step(e) -> str:
        siblings = [s for s in e.getparent() if s.tag == e.tag] if e.getparent() is not None else [e]
        pos = siblings.index(e) + 1
        return f"{e.tag}[{pos}]" if len(siblings) > 1 else e.tag

    for depth in range(1, len(chain)):
        anc = chain[depth]
        anchor = None
        for expr in ((f"//{anc.tag}[@automationid={lit(anc.get('automationid'))}]" if anc.get("automationid") else None),
                     (f"//{anc.tag}[@name={lit(anc.get('name'))}]" if anc.get("name") else None)):
            if expr and etree.XPath(_anchor(expr), namespaces={"re": EXSLT_RE})(desktop).__len__() == 1:
                anchor = expr
                break
        if anchor:
            rest = "/".join(step(e) for e in reversed(chain[:depth]))
            full = f"{anchor}/{rest}"
            if unique(full):
                return full
    return "/" + "/".join(step(e) for e in reversed(chain))
