"""Glue between a recorded ``target`` and the XPath engine (OS independent: the snapshot is injected)."""
from __future__ import annotations

import logging

from core.xpath.engine import XPathError, find_best, generate_xpath, rank_nodes

log = logging.getLogger("visionauto.xpath")

HEAL_MIN_SCORE = 0.80
HEAL_MIN_GAP = 0.08


def signature_of(target: dict) -> dict:
    sig = {k: target.get(k) for k in ("automation_id", "name", "role", "class_name", "text") if target.get(k)}
    r = target.get("rect")
    if isinstance(r, (list, tuple)) and len(r) >= 4:
        sig["rect"] = tuple(r[:4])
    return sig


def locate(target: dict, window: dict, snapshot) -> dict | None:
    """Resolve ``target['xpath']`` against ``snapshot()`` (a callable returning a UiaNode root or None).

    1. Evaluate the XPath. One visible match (or one clearly nearest) -> done.
    2. No match (the UI changed): rank every node against the recorded signature and accept the best
       one only if it is both strong (>= 0.80) and clearly ahead of the runner-up (gap >= 0.08).
    Ambiguity is never resolved by guessing - the caller falls through to the visual tiers.
    """
    expr = target.get("xpath") or target.get("rxpath")
    if not expr:
        return None
    dialect = target.get("xpath_dialect") or "uia"
    root = snapshot()
    if root is None:
        return None
    near = None
    if "x" in target and "y" in target and (target.get("x") or target.get("y")):
        near = (target["x"], target["y"])
    strict = bool(target.get("require_unique", True)) and bool(target.get("_strict", True))
    try:
        # strict (default): several visible matches are NEVER resolved by "closest to where it used to be" - that is a
        # guess. The user's XPath must identify one element (or be scoped by a container / index).
        match = find_best(root, expr, dialect, near=None if strict else near)
    except XPathError as exc:
        log.warning("bad XPath %r: %s", expr, exc)
        return None
    if match.node is not None:
        out = match.node.describe()
        out["via"] = "xpath"
        return out
    if match.ambiguous:
        if strict:
            from core.automation.errors import AmbiguousTarget
            raise AmbiguousTarget(
                f"XPath {expr!r} matches {len(match.candidates)} visible elements; refusing to pick one. "
                "Make the XPath unique (attribute, index, container).",
                [n.describe() for n in match.candidates[:8]], {"xpath": expr, "match_count": len(match.candidates)})
        return None
    ranked = rank_nodes(root, signature_of(target), limit=2)
    if ranked and ranked[0][0] >= HEAL_MIN_SCORE and (len(ranked) == 1 or ranked[0][0] - ranked[1][0] >= HEAL_MIN_GAP):
        node = ranked[0][1]
        out = node.describe()
        out["via"] = "xpath-heal"
        out["heal_score"] = round(ranked[0][0], 3)
        try:
            out["suggested_xpath"] = generate_xpath(node, root, dialect)
        except XPathError:
            pass
        return out
    return None
