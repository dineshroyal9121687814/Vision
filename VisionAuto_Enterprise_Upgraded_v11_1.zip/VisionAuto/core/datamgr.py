"""Data Manager: look at a data file, check it against a test, and export it. Loading itself is core.datasource (one parser
for the GUI, the CLI and playback)."""
from __future__ import annotations

import csv
import json
from pathlib import Path

from core import datasource, validation

LIMIT_PREVIEW = 200


def preview(path, limit: int = LIMIT_PREVIEW) -> dict:
    cols, rows = datasource.load_file(path)
    return {"columns": cols, "rows": rows[:limit], "total": len(rows), "truncated": len(rows) > limit,
            "format": Path(path).suffix.lower().lstrip(".")}


def mapping(test: dict, columns: list[str]) -> dict:
    """Which ``${variables}`` the test uses, which data column feeds each, which are missing, which columns are unused."""
    used = sorted(validation.variable_refs(test.get("steps") or []))
    lookup = {c.casefold(): c for c in columns}
    mapped = {v: lookup[v.casefold()] for v in used if v.casefold() in lookup}
    defined = set((test.get("variables") or {}).keys()) if isinstance(test.get("variables"), dict) else set()
    return {"mapped": mapped, "missing": [v for v in used if v not in mapped and v not in defined],
            "unused_columns": [c for c in columns if c not in mapped.values()]}


def check(columns: list[str], rows: list[dict], required: list[str] | None = None, numeric: list[str] | None = None,
          unique: list[str] | None = None) -> list[dict]:
    """Row-level validation. Returns ``[{row, column, problem}]`` (row numbers are 1-based, as in the file body)."""
    problems = []
    for c in (required or []) + (numeric or []) + (unique or []):
        if c not in columns:
            problems.append({"row": 0, "column": c, "problem": "column does not exist in the file"})
    seen: dict[str, dict[str, int]] = {c: {} for c in (unique or [])}
    for n, r in enumerate(rows, 1):
        for c in required or []:
            if c in columns and not str(r.get(c, "")).strip():
                problems.append({"row": n, "column": c, "problem": "required value is empty"})
        for c in numeric or []:
            v = str(r.get(c, "")).strip()
            if v:
                try:
                    float(v.replace(",", ""))
                except ValueError:
                    problems.append({"row": n, "column": c, "problem": f"'{v}' is not a number"})
        for c in unique or []:
            v = str(r.get(c, ""))
            if v in seen[c]:
                problems.append({"row": n, "column": c, "problem": f"duplicate of row {seen[c][v]}"})
            else:
                seen[c][v] = n
    return problems


def export(columns: list[str], rows: list[dict], path) -> Path:
    path = Path(path)
    ext = path.suffix.lower()
    if ext == ".json":
        path.write_text(json.dumps(rows, indent=2, ensure_ascii=False), encoding="utf-8")
    elif ext == ".csv":
        with path.open("w", newline="", encoding="utf-8-sig") as f:
            w = csv.DictWriter(f, fieldnames=columns, extrasaction="ignore")
            w.writeheader()
            w.writerows(rows)
    elif ext == ".xlsx":
        from openpyxl import Workbook

        wb = Workbook(write_only=True)                       # bulk write: one pass, no per-cell calls
        ws = wb.create_sheet("data")
        ws.append(columns)
        for r in rows:
            ws.append([r.get(c, "") for c in columns])
        wb.save(path)
    else:
        raise datasource.DataError(f"Cannot export to '{ext}'. Use .csv, .json or .xlsx.")
    return path


def bulk_edit(rows: list[dict], column: str, find: str, replace: str, only_if_equal: bool = False) -> int:
    """Replace text in one column for all rows. Returns how many cells changed."""
    n = 0
    for r in rows:
        v = str(r.get(column, ""))
        new = replace if (only_if_equal and v == find) else (v if only_if_equal else v.replace(find, replace))
        if new != v:
            r[column] = new
            n += 1
    return n
