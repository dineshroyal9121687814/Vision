"""
OCR engine - a chain of recognisers, lazily imported so everything else works without them:

    RapidOCR (onnxruntime, ~0.4 s, no torch)  ->  EasyOCR (heavy, torch)  ->  Tesseract (fastest on one short line)

OCR is the LAST resort in VisionAuto (native value -> pixel compare -> OCR).  When it is needed for a short value
(a spreadsheet cell, a calculator display) use ``read_small``: it removes cell borders, crops to the ink, upscales and
restricts the alphabet - that is what makes lone digits such as "1" readable (plain detection models skip them).

  find_text(screen, "Login")     -> where is this word on screen?     (locator tier)
  read_text(crop, near=(x, y))   -> what does this small element say?  (auto-labelling)
  read_all_text(img)             -> all text inside a region           (text validations)

First use downloads the recognition model (needs internet once) and takes a few
seconds; the reader is then cached for the whole process.
"""
from __future__ import annotations

import importlib.util
import math
import re
import shutil
import time
import warnings
from difflib import SequenceMatcher
from collections import OrderedDict
from dataclasses import dataclass

import cv2
import numpy as np

_reader = None

# EasyOCR's CPU data loaders currently request pinned CUDA memory. Torch emits
# this harmless warning for every batch; keep the first diagnostic, then stop
# flooding the console/log on CPU-only machines.
warnings.filterwarnings(
    "once",
    message=r"'pin_memory' argument is set as true but no accelerator is found.*",
    category=UserWarning,
    module=r"torch\.utils\.data\.dataloader",
)


ENGINE_PREFERENCE = "auto"     # auto | rapidocr | easyocr | tesseract   (set from the 'ocr_engine' setting)
_rapid = None
_cache: "OrderedDict[tuple, list]" = OrderedDict()
_CACHE_MAX = 64


def configure(engine: str = "auto") -> None:
    global ENGINE_PREFERENCE
    ENGINE_PREFERENCE = engine if engine in ("auto", "rapidocr", "easyocr", "tesseract") else "auto"


def _has_rapid() -> bool:
    return (importlib.util.find_spec("rapidocr_onnxruntime") is not None
            or importlib.util.find_spec("rapidocr") is not None)


def _has_easy() -> bool:
    return importlib.util.find_spec("easyocr") is not None


def _has_tesseract() -> bool:
    return importlib.util.find_spec("pytesseract") is not None and shutil.which("tesseract") is not None


def engines() -> list[str]:
    """Installed engines in the order they are tried."""
    order = ["rapidocr", "easyocr", "tesseract"]
    if ENGINE_PREFERENCE in order:
        order.remove(ENGINE_PREFERENCE)
        order.insert(0, ENGINE_PREFERENCE)
    have = {"rapidocr": _has_rapid, "easyocr": _has_easy, "tesseract": _has_tesseract}
    return [e for e in order if have[e]()]


def available() -> bool:
    # Settings/status checks must not import EasyOCR: that imports Torch and
    # patches inspect, which conflicts with PySide's import hook and pynput.
    return bool(engines())


def _get_reader():
    global _reader
    if _reader is None:
        try:
            import easyocr
        except ImportError as e:
            raise RuntimeError("OCR needs EasyOCR:  pip install easyocr") from e
        _reader = easyocr.Reader(["en"], gpu=False, verbose=False)
    return _reader


def _normalise(text: str) -> str:
    return re.sub(r"\s+", " ", str(text or "").strip().casefold())


def _easy_results(img: np.ndarray):
    return _get_reader().readtext(img)


def _tesseract_results(img: np.ndarray):
    import pytesseract

    data = pytesseract.image_to_data(img, output_type=pytesseract.Output.DICT)
    results = []
    for i, text in enumerate(data.get("text", [])):
        text = text.strip()
        conf = float(data["conf"][i]) / 100.0
        if text and conf >= 0:
            x, y, w, h = (int(data[k][i]) for k in ("left", "top", "width", "height"))
            results.append(([(x, y), (x + w, y), (x + w, y + h), (x, y + h)], text, conf))
    return results


def _variants(img: np.ndarray):
    """Yield cheap OCR-friendly variants without changing the caller's image."""
    yield img
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY) if img.ndim == 3 else img
    scale = cv2.resize(gray, None, fx=2.0, fy=2.0, interpolation=cv2.INTER_CUBIC)
    yield cv2.threshold(scale, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)[1]
    yield cv2.adaptiveThreshold(scale, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                                cv2.THRESH_BINARY, 31, 11)


def _get_rapid():
    global _rapid
    if _rapid is None:
        try:
            from rapidocr_onnxruntime import RapidOCR
        except ImportError:
            from rapidocr import RapidOCR  # newer package name
        _rapid = RapidOCR()
    return _rapid


def _rapid_unpack(raw) -> list[tuple]:
    """Normalise every RapidOCR output shape to ``[(box | None, text, confidence)]``.

    Shapes seen across versions: ``(items, elapsed)``; items of ``[box, text, score]`` (detect+recognise) or
    ``[text, score]`` (recognition only - here item[1] is the SCORE, which once got read as the text);
    and the newer result object with ``.txts`` / ``.scores`` / ``.boxes``."""
    out = raw[0] if isinstance(raw, tuple) else raw
    if out is None:
        return []
    if hasattr(out, "txts"):
        txts = list(getattr(out, "txts", None) or [])
        scores = list(getattr(out, "scores", None) or [1.0] * len(txts))
        boxes = getattr(out, "boxes", None)
        boxes = list(boxes) if boxes is not None else [None] * len(txts)
        return [(boxes[i] if i < len(boxes) else None, str(t), float(scores[i])) for i, t in enumerate(txts)]
    res = []
    for item in out:
        if isinstance(item, str):
            res.append((None, item, 1.0))
        elif len(item) == 2 and isinstance(item[0], str):
            res.append((None, item[0], float(item[1])))
        elif len(item) >= 3:
            res.append((item[0], str(item[1]), float(item[2])))
    return res


def _rapid_results(img: np.ndarray):
    raw = _get_rapid()(img if img.ndim == 3 else cv2.cvtColor(img, cv2.COLOR_GRAY2BGR))
    return [([tuple(p) for p in (box if box is not None else [(0, 0)] * 4)], text, conf)
            for box, text, conf in _rapid_unpack(raw)]


_RUNNERS = {"rapidocr": _rapid_results, "easyocr": _easy_results, "tesseract": _tesseract_results}


def _results(img: np.ndarray):
    """Boxes/text/confidence from the first installed engine that reads something; a failing engine is skipped."""
    errors, any_ran = [], False
    for name in engines():
        try:
            res = _RUNNERS[name](img)
        except Exception as e:                    # model missing, no internet for first download, bad install ...
            errors.append(f"{name}: {type(e).__name__}")
            continue
        any_ran = True
        if res:
            return res
    if any_ran:
        return []
    raise RuntimeError("OCR needs RapidOCR, EasyOCR or Tesseract (pip install rapidocr-onnxruntime)"
                       + (f" [{'; '.join(errors)}]" if errors else ""))


@dataclass
class OcrMatch:
    found: bool
    x: int = 0
    y: int = 0
    confidence: float = 0.0
    matched_text: str = ""


def _center(bbox) -> tuple[int, int]:
    return int(sum(p[0] for p in bbox) / 4), int(sum(p[1] for p in bbox) / 4)


def find_text(screen: np.ndarray, target_text: str, min_confidence: float = 0.45,
              near: tuple[int, int] | None = None) -> OcrMatch:
    if not target_text:
        return OcrMatch(found=False)
    wanted = _normalise(target_text)
    best = OcrMatch(found=False)
    best_rank = float("-inf")
    for variant in _variants(screen):
        for bbox, text, conf in _results(variant):
            t = _normalise(text)
            similarity = SequenceMatcher(None, wanted, t).ratio()
            if conf >= min_confidence and (wanted == t or wanted in t or similarity >= 0.82):
                confidence = float(conf) * (0.7 + 0.3 * similarity)
                x, y = _center(bbox)
                scale = screen.shape[1] / variant.shape[1]
                x, y = int(x * scale), int(y * scale)
                # Favor proximity when duplicate labels appear, while still
                # requiring the same confidence threshold for every candidate.
                distance = math.hypot(x - near[0], y - near[1]) if near else 0.0
                rank = confidence - (min(distance, 1000) / 1000 * 0.20)
                if rank > best_rank:
                    best_rank = rank
                    best = OcrMatch(True, x, y, confidence, text)
        if best.found and best.confidence >= 0.8:
            break           # a clear hit on this variant: the extra (slower) preprocessed passes are not needed
    return best


def read_text(img: np.ndarray, near: tuple[int, int] | None = None, max_dist: int = 70, min_confidence: float = 0.4) -> str:
    """Text closest to `near` (default: image centre) within max_dist pixels."""
    h, w = img.shape[:2]
    cx, cy = near if near else (w // 2, h // 2)
    best, best_d = "", 1e9
    for bbox, text, conf in _results(img):
        if conf < min_confidence or not text.strip():
            continue
        x, y = _center(bbox)
        d = math.hypot(x - cx, y - cy)
        if d < best_d and d <= max_dist:
            best, best_d = text.strip(), d
    return best


def enhanced_variants(img: np.ndarray):
    """Retry images for small or low-contrast text (calculator displays, status bars): 3x upscale, Otsu, and inverted
    (light-on-dark). Cheap to build; each is OCR'd only if the plain read did not satisfy the validation."""
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY) if img.ndim == 3 else img
    big = cv2.resize(gray, None, fx=3.0, fy=3.0, interpolation=cv2.INTER_CUBIC)
    otsu = cv2.threshold(big, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)[1]
    yield cv2.copyMakeBorder(otsu, 20, 20, 20, 20, cv2.BORDER_REPLICATE)
    yield cv2.copyMakeBorder(255 - otsu, 20, 20, 20, 20, cv2.BORDER_REPLICATE)


def read_all_text(img: np.ndarray, min_confidence: float = 0.4) -> str:
    parts = [(bbox, t) for bbox, t, c in _results(img) if c >= min_confidence and t.strip()]
    parts.sort(key=lambda p: (round(_center(p[0])[1] / 12), _center(p[0])[0]))  # reading order
    return " ".join(t.strip() for _, t in parts)


# ----------------------------------------------------------------------------------------------------------------
# Short values (spreadsheet cells, displays, status fields): border strip -> ink crop -> upscale -> allow-listed read
# ----------------------------------------------------------------------------------------------------------------
DIGITS = "0123456789.,-+%$()/:"


def allowlist_for(expected) -> str | None:
    """Restrict the alphabet only when the expected value is numeric-looking; free text keeps every character."""
    e = str(expected or "")
    return DIGITS if e and all(c in DIGITS + " €£¥₹" for c in e) else None


def _gray(img: np.ndarray) -> np.ndarray:
    return cv2.cvtColor(img, cv2.COLOR_BGR2GRAY) if img.ndim == 3 else img.copy()


def ink_crop(img: np.ndarray, pad: int = 3) -> np.ndarray | None:
    """Dark-on-light grayscale crop of just the characters: polarity normalised, long straight lines (cell borders,
    selection frame, underlines) removed, bounding box of what is left plus ``pad``. None = nothing readable."""
    g = _gray(img)
    if g.size == 0:
        return None
    if g.mean() < 127:
        g = 255 - g
    # ink = clearly darker than the background. A relative threshold (not Otsu) keeps thin, anti-aliased strokes
    # such as a minus sign or a decimal point, which Otsu throws away when a coloured frame is in the crop.
    bg = float(np.median(g))
    bw = (g < bg - 25).astype(np.uint8) * 255
    h, w = bw.shape
    hl = cv2.morphologyEx(bw, cv2.MORPH_OPEN, cv2.getStructuringElement(cv2.MORPH_RECT, (max(15, w // 3), 1)))
    vl = cv2.morphologyEx(bw, cv2.MORPH_OPEN, cv2.getStructuringElement(cv2.MORPH_RECT, (1, max(15, h // 2))))
    lines = cv2.dilate(cv2.bitwise_or(hl, vl), np.ones((3, 3), np.uint8))
    bw = cv2.bitwise_and(bw, cv2.bitwise_not(lines))
    ys, xs = np.nonzero(bw)
    if len(xs) == 0:
        return None
    x0, x1, y0, y1 = int(xs.min()), int(xs.max()) + 1, int(ys.min()), int(ys.max()) + 1
    out = g[max(0, y0 - pad):y1 + pad, max(0, x0 - pad):x1 + pad].copy()
    return out if out.shape[0] >= 3 and out.shape[1] >= 3 else None


def leading_minus(img: np.ndarray) -> bool:
    """Is there a minus sign in front of the digits? Recognisers drop or misread a lone thin dash, so it is looked for
    in the picture itself: a flat, wide, short mark left of the first digit, level with the middle of the digits.
    A sign that is missing from the text but present in the picture turns a "7" into the "-7" that is really there."""
    c = ink_crop(img, pad=1)
    if c is None:
        return False
    bg = float(np.median(c))
    bw = (c < bg - 25).astype(np.uint8)
    n, _, stats, _ = cv2.connectedComponentsWithStats(bw, connectivity=8)
    comps = [tuple(int(v) for v in stats[i][:4]) for i in range(1, n) if stats[i][4] >= 2]   # x, y, w, h
    if len(comps) < 2:
        return False
    comps.sort()
    max_h = max(h for _, _, _, h in comps)
    if max_h < 6:
        return False
    digits = [k for k in comps if k[3] >= 0.55 * max_h]
    if not digits:
        return False
    first = min(digits, key=lambda k: k[0])
    top = min(k[1] for k in digits)
    bottom = max(k[1] + k[3] for k in digits)
    for x, y, w, h in comps:
        if x >= first[0] or (x, y, w, h) in digits:
            continue
        mid = y + h / 2
        flat = w >= 1.4 * h and h <= 0.3 * max_h and w <= 0.85 * max_h
        level = top + 0.3 * (bottom - top) <= mid <= top + 0.72 * (bottom - top)
        near = first[0] - (x + w) <= max_h
        if flat and level and near:
            return True
    return False


def prepare_line(img: np.ndarray, target_h: int = 48) -> np.ndarray | None:
    """Ink crop scaled so the text is ~``target_h`` px tall, on a white margin (what recognisers are trained on)."""
    c = ink_crop(img)
    if c is None:
        return None
    scale = min(8.0, max(1.0, target_h / c.shape[0]))
    c = cv2.resize(c, None, fx=scale, fy=scale, interpolation=cv2.INTER_CUBIC)
    return cv2.copyMakeBorder(c, 24, 24, 24, 24, cv2.BORDER_CONSTANT, value=255)


def _tesseract_line(img: np.ndarray, allow: str | None) -> str:
    import pytesseract

    out = []
    for psm in (7, 10) if img.shape[1] < img.shape[0] * 1.4 else (7,):   # 10 = one character
        cfg = f"--psm {psm}" + (f" -c tessedit_char_whitelist={allow}" if allow else "")
        text = pytesseract.image_to_string(img, config=cfg).strip()
        if text:
            out.append(text)
            break
    return out[0] if out else ""


def _rapid_line(img: np.ndarray) -> str:
    raw = _get_rapid()(cv2.cvtColor(img, cv2.COLOR_GRAY2BGR), use_det=False, use_cls=False, use_rec=True)
    return " ".join(t for _, t, _ in _rapid_unpack(raw) if t).strip()


def _only(text: str, allow: str | None) -> str:
    return "".join(c for c in text if c in allow or c == " ").strip() if allow else text


def read_small(img: np.ndarray, expected=None, allow: str | None = None, budget_s: float = 6.0) -> list[str]:
    """Candidate readings of a short value, cheapest first, de-duplicated and cached by pixel content.

    Tesseract on a prepared line (~0.1 s) -> RapidOCR recognition-only (~0.1 s) -> the normal detect+recognise chain
    on the prepared line. Stops at ``budget_s``. Never raises: [] = nothing could be read."""
    allow = allow if allow is not None else allowlist_for(expected)
    key = (hash(img.tobytes()), img.shape, allow)
    if key in _cache:
        _cache.move_to_end(key)
        return list(_cache[key])
    prepared = prepare_line(img)
    out: list[str] = []
    if prepared is not None:
        deadline = time.monotonic() + max(0.5, budget_s)
        steps = []
        names = engines()
        if "tesseract" in names:
            steps.append(lambda: _tesseract_line(prepared, allow))
        if "rapidocr" in names:
            steps.append(lambda: _rapid_line(prepared))
        steps.append(lambda: read_all_text(cv2.cvtColor(prepared, cv2.COLOR_GRAY2BGR)))
        for step in steps:
            if time.monotonic() >= deadline:
                break
            try:
                text = _only(step() or "", allow)
            except Exception:
                continue
            if allow and expected and len(str(expected)) <= 8 and len(text) > max(12, 3 * len(str(expected))):
                continue            # a 16-digit "number" for a 1-digit cell is a confidence score / noise, never a value
            if text and text not in out:
                out.append(text)
    if out and allow and not any(t.startswith("-") for t in out):
        try:
            if leading_minus(img):
                out = ["-" + t.lstrip() for t in out]          # the picture shows a sign: never answer with the unsigned value
        except Exception:
            pass
    _cache[key] = list(out)
    while len(_cache) > _CACHE_MAX:
        _cache.popitem(last=False)
    return out
