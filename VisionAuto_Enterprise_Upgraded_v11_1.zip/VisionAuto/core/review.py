"""
Review-after-recording logic (no GUI imports, so it is unit-tested).

After the user stops recording they see every step in plain English and decide
which validation points to keep:

  * AI suggestions (core.ai.analyze) arrive on each step as `suggestions`
  * `validation_options(step)` lists what else can be checked for a step
  * "use as validation" turns the item the user clicked/selected into a check
    that runs right after that step during playback
"""
from __future__ import annotations

from core import testfile
from core.ai.analyze import SELECTABLE
from core.ai.describe import describe_step, describe_validation, element_phrase, label_of


def _with_desc(v: dict) -> dict:
    v = dict(v)
    v["description"] = describe_validation(v)
    return v


def validation_options(step: dict) -> list[dict]:
    """[{"label": str, "validation": dict}] - ready-made checks for this step."""
    t = step.get("type")
    if t == "validate":
        return []
    tgt = step.get("target") or {}
    opts: list[dict] = []

    def add(v: dict):
        v = _with_desc(v)
        desc = v.get("description") or ""
        label = (desc[0].upper() + desc[1:]) if desc else "Validation point"
        opts.append({"label": label, "validation": v})

    if tgt:
        role = (tgt.get("role") or "").replace(" ", "").lower()
        toggle = (tgt.get("state") or {}).get("toggle")
        if t in ("click", "double_click") and role == "checkbox" and toggle in ("on", "off"):
            add({"type": "state", "expected": "off" if toggle == "on" else "on", "target": tgt})
        elif t in ("click", "double_click") and role in SELECTABLE and label_of(tgt):
            add({"type": "state", "expected": "selected", "target": tgt})
        text = tgt.get("value") or tgt.get("text") or tgt.get("name")
        if text and t != "type":
            add({"type": "text_equals", "expected": str(text), "target": tgt})
        add({"type": "element_exists", "target": tgt})
        if (tgt.get("templates") or {}).get("crop100"):
            add({"type": "image_visible", "target": tgt})
    if t == "type" and (step.get("params") or {}).get("text"):
        add({"type": "text_contains", "expected": step["params"]["text"], "target": tgt})
    title = (step.get("window") or {}).get("title")
    if title:
        add({"type": "window_title_contains", "expected": title})
    return opts


def default_validation(step: dict) -> dict | None:
    opts = validation_options(step)
    return opts[0]["validation"] if opts else None


def _key(v: dict):
    tg = v.get("target") or {}
    return (v.get("type"), str(v.get("expected", "")), tg.get("name"), tg.get("automation_id"), tg.get("x"), tg.get("y"))


def add_validation(step: dict, v: dict) -> bool:
    """Attach a validation to a step. False if an identical one is already there."""
    clean = {k: val for k, val in v.items() if k not in ("confidence", "reason")}
    clean["description"] = describe_validation(clean)
    existing = step.setdefault("validations", [])
    if any(_key(e) == _key(clean) for e in existing):
        return False
    existing.append(clean)
    return True


def remove_validation(step: dict, index: int) -> None:
    vals = step.get("validations", [])
    if 0 <= index < len(vals):
        vals.pop(index)


def use_steps_as_validation(test: dict, step_ids) -> int:
    """'Use the selected items as validation points'. Returns how many steps got one."""
    ids, n = set(step_ids), 0
    for s in test.get("steps", []):
        if s["id"] in ids:
            v = default_validation(s)
            if v and add_validation(s, v):
                n += 1
    return n


def delete_steps(test: dict, step_ids) -> None:
    ids = set(step_ids)
    test["steps"] = [s for s in test.get("steps", []) if s["id"] not in ids]
    testfile.renumber(test)


def accept_suggestions(test: dict, accepted: dict) -> None:
    """accepted: {step_id: [suggestion indexes]}; the rest of the suggestions are dropped."""
    for s in test.get("steps", []):
        sugg = s.pop("suggestions", [])
        for idx in accepted.get(s["id"], []):
            if 0 <= idx < len(sugg):
                add_validation(s, sugg[idx])


def finalize(test: dict, directory, accepted: dict | None = None, title: str | None = None) -> None:
    """Apply the user's decisions and write test.json."""
    if accepted is not None:
        accept_suggestions(test, accepted)
    else:
        for s in test.get("steps", []):
            s.pop("suggestions", None)
    if title:
        test["title"] = title
    for s in test.get("steps", []):
        s["description"] = describe_step(s)
    testfile.renumber(test)
    testfile.save_test(test, directory)


def rows(test: dict) -> list[dict]:
    """Flat data for the review table."""
    return [{
        "id": s["id"], "type": s["type"], "text": s.get("description") or describe_step(s),
        "window": (s.get("window") or {}).get("title", ""),
        "validations": len(s.get("validations", [])), "suggestions": len(s.get("suggestions", [])),
    } for s in test.get("steps", [])]


def target_summary(step: dict) -> list[tuple[str, str]]:
    """Key/value lines for the detail pane."""
    tgt = step.get("target") or {}
    out = [("Action", step.get("description", "")), ("Window", (step.get("window") or {}).get("title", ""))]
    if tgt:
        out.append(("Element", element_phrase(tgt)))
        for key, label in (("role", "Control type"), ("automation_id", "Automation ID"), ("class_name", "Class")):
            if tgt.get(key):
                out.append((label, str(tgt[key])))
        if tgt.get("text_source") == "ocr":
            out.append(("Label source", "read from the screen (OCR)"))
    return out
