"""
Cross-application locator repository.

A locator belongs to ONE application scope (an application id or test alias).
Resolution always names the scope, so a "Save" button recorded in the desktop
app can never be returned for the browser. Recovered (self-healed) locators are
stored next to, never over, the original.

    repo = LocatorRepository()
    repo.add(Locator(name="Login button", scope="browser", strategy="role", value="button[name=Login]"))
    repo.resolve("Login button", scope="browser")       # -> Locator
    repo.resolve("Login button", scope="desktop")       # -> LocatorError (not found in that scope)
"""
from __future__ import annotations

import json
import re
import uuid
from dataclasses import asdict, dataclass, field
from pathlib import Path

from core import paths
from core.testfile import write_json_atomic

SCHEMA_VERSION = 1
STRATEGIES = ("automation_id", "name", "role", "css", "xpath", "text", "test_id", "image", "ocr_text", "coordinates")
# Strongest identification first; used to pick the best locator from inspector output.
STRATEGY_STRENGTH = ("automation_id", "test_id", "role", "name", "css", "xpath", "text", "image", "ocr_text", "coordinates")


class LocatorError(ValueError):
    pass


@dataclass
class Locator:
    name: str
    scope: str                       # application id or alias this locator is valid for
    strategy: str
    value: str
    id: str = ""
    context: str = ""                # window / page / frame the locator lives in
    control_type: str = ""
    attributes: dict = field(default_factory=dict)
    min_confidence: float = 0.8
    fallbacks: list = field(default_factory=list)       # [{"strategy":..., "value":...}] same scope only
    recovered: list = field(default_factory=list)       # evidence of accepted self-heals, original kept intact
    version: int = SCHEMA_VERSION

    def validate(self) -> list[str]:
        errs = []
        if not self.name.strip():
            errs.append("Locator needs a name.")
        if not self.scope.strip():
            errs.append("Locator needs an application scope.")
        if self.strategy not in STRATEGIES:
            errs.append(f"Unknown locator strategy '{self.strategy}'.")
        if not str(self.value).strip() and self.strategy != "coordinates":
            errs.append("Locator value is empty.")
        if not 0.0 <= float(self.min_confidence) <= 1.0:
            errs.append("min_confidence must be between 0 and 1.")
        for fb in self.fallbacks:
            if not isinstance(fb, dict) or fb.get("strategy") not in STRATEGIES:
                errs.append("Every fallback needs a valid strategy.")
        return errs


def best_strategy(candidates: dict[str, str]) -> tuple[str, str] | None:
    """Pick the strongest available identification from inspector output {strategy: value}."""
    for s in STRATEGY_STRENGTH:
        if candidates.get(s):
            return s, str(candidates[s])
    return None


class LocatorRepository:
    def __init__(self, path: Path | None = None):
        self.path = Path(path) if path else paths.workspace() / "locators.json"

    # ---- persistence
    def _load(self) -> dict[str, dict]:
        if not self.path.exists():
            return {}
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
        except ValueError as e:
            raise LocatorError(f"Locator repository {self.path} is corrupt: {e}") from e
        if not isinstance(data, dict) or not isinstance(data.get("locators"), dict):
            raise LocatorError(f"Locator repository {self.path} has an invalid format.")
        return data["locators"]

    def _save(self, items: dict[str, dict]) -> None:
        write_json_atomic(self.path, {"schema": "visionauto.locators/1", "locators": items})

    # ---- CRUD
    def add(self, loc: Locator) -> Locator:
        errs = loc.validate()
        if errs:
            raise LocatorError("; ".join(errs))
        items = self._load()
        for other in items.values():
            if other["scope"] == loc.scope and other["name"].lower() == loc.name.lower() and other["id"] != loc.id:
                raise LocatorError(f"A locator named '{loc.name}' already exists for '{loc.scope}'.")
        loc.id = loc.id or "loc_" + uuid.uuid4().hex[:8]
        items[loc.id] = asdict(loc)
        self._save(items)
        return loc

    def remove(self, loc_id: str) -> bool:
        items = self._load()
        if loc_id not in items:
            return False
        del items[loc_id]
        self._save(items)
        return True

    def list(self, scope: str | None = None) -> list[Locator]:
        out = [Locator(**v) for v in self._load().values() if scope is None or v["scope"] == scope]
        return sorted(out, key=lambda l: (l.scope, l.name.lower()))

    # ---- resolution
    def resolve(self, name: str, scope: str) -> Locator:
        """Locator by name, in EXACTLY the given application scope."""
        if not scope:
            raise LocatorError(f"Resolving '{name}' needs an application scope; refusing to search all applications.")
        hits = [l for l in self.list(scope) if l.name.lower() == name.strip().lower()]
        if not hits:
            elsewhere = sorted({l.scope for l in self.list() if l.name.lower() == name.strip().lower()})
            hint = f" It exists only in: {', '.join(elsewhere)}." if elsewhere else ""
            raise LocatorError(f"No locator '{name}' in application '{scope}'.{hint}")
        if len(hits) > 1:
            raise LocatorError(f"Locator '{name}' is ambiguous in '{scope}' ({len(hits)} matches).")
        return hits[0]

    def record_recovery(self, loc_id: str, new_strategy: str, new_value: str, confidence: float, evidence: dict,
                        accept_threshold: float | None = None) -> bool:
        """Store a healed locator beside the original. Returns False (and stores nothing) if confidence is too low."""
        items = self._load()
        if loc_id not in items:
            raise LocatorError(f"Unknown locator id '{loc_id}'.")
        entry = items[loc_id]
        threshold = entry.get("min_confidence", 0.8) if accept_threshold is None else accept_threshold
        if confidence < threshold:
            return False
        entry.setdefault("recovered", []).append(
            {"strategy": new_strategy, "value": new_value, "confidence": confidence, "evidence": evidence})
        self._save(items)
        return True


def sanitize_for_filename(name: str) -> str:
    return re.sub(r"[^\w\-.]+", "_", name).strip("._") or "locator"
