"""
Portable project export / import.

Export writes a zip with the chosen tests, the application definitions they use
(machine paths and credentials removed, replaced by a hint), and the locators
scoped to those applications. Import validates every member, never overwrites an
existing test without keeping a backup, never executes anything, and reports
which applications still need an executable path on this machine.
"""
from __future__ import annotations

import io
import json
import shutil
import zipfile
from pathlib import Path, PurePosixPath

from core import applications, paths, testfile
from core.locators import LocatorRepository
from core.redaction import SENSITIVE_NAME
from core.validation import errors_only, validate_test

FORMAT = "visionauto.project/1"
MAX_MEMBER_BYTES = 50 * 1024 * 1024
MAX_MEMBERS = 5000
PATH_KEYS = ("exe_path", "working_dir")


def portable_app(defn: dict) -> dict:
    """Application definition with machine-specific and secret data removed."""
    out = {k: v for k, v in defn.items() if not SENSITIVE_NAME.search(k)}
    exe = str(out.pop("exe_path", "") or "")
    out.pop("working_dir", None)
    if exe:
        out["exe_hint"] = Path(exe.replace("\\", "/")).name
    out["needs_path"] = bool(exe) or out.get("type") == "desktop"
    return out


def export_project(test_names: list[str], out_zip: Path, registry_path: Path | None = None) -> Path:
    out_zip = Path(out_zip)
    registry = applications.load_registry(registry_path)
    apps: dict[str, dict] = {}
    scopes: set[str] = set()
    manifest_tests = []
    out_zip.parent.mkdir(parents=True, exist_ok=True)
    tmp = out_zip.with_suffix(out_zip.suffix + ".tmp")
    with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as z:
        for name in test_names:
            test, directory = testfile.load_test(name)
            for entry in test.get("applications", []):
                ref = entry.get("app_id")
                base = registry.get(ref) or applications.get_app(ref, registry_path) if ref else None
                merged = {**(base or {}), **entry}
                key = merged.get("id") or merged.get("alias")
                apps[key] = portable_app(merged)
                scopes.update({merged.get("alias", ""), key})
            safe = testfile.safe_name(test["name"])
            z.writestr(f"tests/{safe}/test.json", json.dumps(test, indent=2, ensure_ascii=False))
            assets = Path(directory) / "assets"
            if assets.is_dir():
                for f in sorted(assets.rglob("*")):
                    if f.is_file():
                        z.write(f, f"tests/{safe}/assets/{f.relative_to(assets).as_posix()}")
            manifest_tests.append(safe)
        z.writestr("applications.json", json.dumps({"applications": apps}, indent=2, ensure_ascii=False))
        try:
            locs = [l for l in LocatorRepository().list() if l.scope in scopes]
        except Exception:
            locs = []
        from dataclasses import asdict
        z.writestr("locators.json", json.dumps({"locators": [asdict(l) for l in locs]}, indent=2, ensure_ascii=False))
        z.writestr("manifest.json", json.dumps({"format": FORMAT, "tests": manifest_tests}, indent=2))
    tmp.replace(out_zip)
    return out_zip


def _safe_member(name: str) -> PurePosixPath | None:
    p = PurePosixPath(name)
    if p.is_absolute() or ".." in p.parts or not p.parts or "\\" in name or ":" in p.parts[0]:
        return None
    return p


def import_project(zip_path: Path, path_overrides: dict[str, str] | None = None, overwrite: bool = False,
                   registry_path: Path | None = None) -> dict:
    """Import a project zip. Returns {tests, applications, needs_path, skipped, problems}."""
    overrides = path_overrides or {}
    report = {"tests": [], "applications": [], "needs_path": [], "skipped": [], "problems": []}
    with zipfile.ZipFile(zip_path) as z:
        infos = z.infolist()
        if len(infos) > MAX_MEMBERS:
            raise ValueError("Project archive has too many files.")
        for info in infos:
            if _safe_member(info.filename) is None:
                raise ValueError(f"Unsafe path in project archive: {info.filename!r}")
            if info.file_size > MAX_MEMBER_BYTES:
                raise ValueError(f"Archive member too large: {info.filename}")
        try:
            manifest = json.loads(z.read("manifest.json"))
        except KeyError as e:
            raise ValueError("Not a VisionAuto project: manifest.json is missing.") from e
        if manifest.get("format") != FORMAT:
            raise ValueError(f"Unsupported project format {manifest.get('format')!r}.")

        # applications first, so test validation sees them
        reg = applications.load_registry(registry_path)
        for key, defn in (json.loads(z.read("applications.json")).get("applications", {}).items() if "applications.json" in z.namelist() else []):
            defn = dict(defn)
            hint = defn.pop("exe_hint", "")
            defn.pop("needs_path", None)
            exe = overrides.get(key) or overrides.get(defn.get("alias", ""))
            if not exe and hint:
                exe = shutil.which(hint) or ""
            if exe:
                defn["exe_path"] = exe
            elif defn.get("type") == "desktop":
                report["needs_path"].append({"id": key, "alias": defn.get("alias"), "exe_hint": hint})
            defn.setdefault("id", key)
            if defn["id"] in reg:
                report["skipped"].append(f"application {defn['id']} already registered; kept your existing one")
                continue
            reg[defn["id"]] = defn
            report["applications"].append(defn["id"])
        applications.save_registry(reg, registry_path) if report["applications"] else None

        for name in manifest.get("tests", []):
            if _safe_member(f"tests/{name}") is None:
                raise ValueError(f"Unsafe test name in manifest: {name!r}")
            test = json.loads(z.read(f"tests/{name}/test.json"))
            if not isinstance(test, dict) or not isinstance(test.get("steps"), list):
                report["problems"].append(f"{name}: invalid test file; not imported")
                continue
            test = testfile._normalize_test(test)
            issues = errors_only(validate_test(test, reg))
            if issues:
                report["problems"].extend(f"{name}: {i['message']}" for i in issues)
            dest = paths.tests_dir() / testfile.safe_name(name)
            if dest.exists():
                if not overwrite:
                    report["skipped"].append(f"test {name} already exists; not overwritten")
                    continue
                testfile.backup_test(dest)
            testfile.save_test(test, dest)
            prefix = f"tests/{name}/assets/"
            for member in z.namelist():
                if member.startswith(prefix) and not member.endswith("/"):
                    target = dest / "assets" / PurePosixPath(member).relative_to(prefix)
                    target.parent.mkdir(parents=True, exist_ok=True)
                    target.write_bytes(z.read(member))
            report["tests"].append(name)
    return report
