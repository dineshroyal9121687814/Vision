"""Edit a saved test without recording it again.

Every locator kind a user may want to change - XPath, text (OCR label), image, stored coordinates, the OCR search
region, the locator order - is *merged* into the element's target: editing the XPath never throws away the recorded
image crops, so the resolver still has fallbacks.  Data sources, loops and if/else blocks can be added the same way.

    from core import editing
    test, directory = testfile.load_test("MyTest")
    editing.set_locator(test, 3, "xpath", "//button[@name='Save']")
    editing.set_locator(test, 3, "ocr_region", x=400, y=300, w=300, h=80)
    editing.set_locator_order(test, 3, ["xpath", "uia", "image", "ocr", "coordinates"])
    editing.set_data(test, directory, file="users.csv", on_row_failure="continue")
    editing.wrap_in_loop(test, 2, 5, times=3)
    editing.save(test, directory)

Command line: ``python -m core.cli edit ...`` (see ``python -m core.cli edit --help``).
"""
from __future__ import annotations

import shutil
from pathlib import Path

from core import datasource, testfile, validation
from core.ai.describe import describe_step
from core.playback.resolver import Resolver
from core.xpath import XPathError, compile_xpath

LOCATOR_KINDS = ("xpath", "text", "name", "automation_id", "role", "class_name", "image", "coordinates",
                 "ocr_region", "ocr_search", "ocr_radius")
POINTER_STEPS = ("click", "double_click", "right_click", "middle_click", "drag_drop", "scroll", "validate", "hover")


def _step(test: dict, step_id: int) -> dict:
    for s in test.get("steps", []):
        if s.get("id") == step_id:
            return s
    raise ValueError(f"Step {step_id} does not exist.")


def _target(step: dict, which: str) -> dict:
    if which not in ("target", "to"):
        raise ValueError("'which' must be 'target' or 'to'.")
    t = step.get(which)
    if t is None:
        if step.get("type") not in POINTER_STEPS:
            raise ValueError(f"A '{step.get('type')}' step has no on-screen element to locate.")
        t = step[which] = {"x": 0, "y": 0}
    return t


def _int(v, name: str, lo: int, hi: int) -> int:
    if isinstance(v, bool) or not isinstance(v, (int, float, str)):
        raise ValueError(f"{name} must be a whole number.")
    try:
        n = int(float(v))
    except ValueError:
        raise ValueError(f"{name} must be a whole number.") from None
    if not lo <= n <= hi:
        raise ValueError(f"{name} must be between {lo} and {hi}.")
    return n


def set_locator(test: dict, step_id: int, kind: str, value=None, *, which: str = "target", directory: Path | None = None,
                x=None, y=None, w=None, h=None, dialect: str = "uia", exact: bool = False) -> dict:
    """Change ONE locator of a step's element; every other locator is kept. Returns the updated target."""
    if kind not in LOCATOR_KINDS:
        raise ValueError(f"Unknown locator kind '{kind}'. Choose from: {', '.join(LOCATOR_KINDS)}.")
    step = _step(test, step_id)
    t = _target(step, which)
    if kind == "xpath":
        expr = str(value or "").strip()
        if dialect not in ("uia", "ranorex"):
            raise ValueError("dialect must be 'uia' or 'ranorex'.")
        try:
            compile_xpath(expr, dialect)
        except XPathError as exc:
            raise ValueError(str(exc)) from exc
        t["xpath"], t["xpath_dialect"] = expr, dialect
    elif kind in ("text", "name", "automation_id", "role", "class_name"):
        text = str(value or "").strip()
        if not text or len(text) > 500:
            raise ValueError(f"A {kind} locator must be 1-500 characters.")
        t[kind] = text
    elif kind == "coordinates":
        t["x"], t["y"] = _int(x if x is not None else value[0] if value else None, "x", -32768, 32767), \
            _int(y if y is not None else value[1] if value else None, "y", -32768, 32767)
        t.pop("rel", None)             # the old relative offset no longer describes the new point
        if exact:
            t["locator_mode"] = "coordinates"
        elif t.get("locator_mode") == "coordinates":
            t.pop("locator_mode")
    elif kind == "ocr_region":
        t["ocr_region"] = [_int(x, "x", -32768, 32767), _int(y, "y", -32768, 32767),
                           _int(w, "w", 8, 16000), _int(h, "h", 8, 16000)]
    elif kind == "ocr_search":
        if value not in ("local_then_screen", "local_only", "screen_only"):
            raise ValueError("ocr_search must be local_then_screen, local_only or screen_only.")
        t["ocr_search"] = value
    elif kind == "ocr_radius":
        t["ocr_radius"] = _int(value, "ocr_radius", 20, 1000)
    elif kind == "image":
        _set_image(t, step_id, Path(str(value)), directory)
    step["description"] = describe_step(step)
    return t


def _set_image(target: dict, step_id: int, src: Path, directory: Path | None) -> None:
    if directory is None:
        raise ValueError("Setting an image needs the test's folder.")
    from core.system.imageio import imread, imwrite

    if not src.is_file() or src.suffix.casefold() not in (".png", ".jpg", ".jpeg", ".bmp"):
        raise ValueError("The image must be an existing .png/.jpg/.bmp file.")
    if src.stat().st_size > 5 * 1024 * 1024:
        raise ValueError("The image is larger than 5 MB.")
    img = imread(src)
    if img is None:
        raise ValueError("The image could not be read.")
    h, w = img.shape[:2]
    if not (8 <= w <= 2000 and 8 <= h <= 2000):
        raise ValueError("The image must be between 8 and 2000 pixels on each side.")
    import hashlib

    rel = f"assets/edit_s{step_id:03d}_{hashlib.md5(src.read_bytes()).hexdigest()[:8]}.png"
    imwrite(Path(directory) / rel, img)
    entry = {"path": rel, "click": [w // 2, h // 2], "size": [w, h]}
    target["templates"] = {"crop300": dict(entry), "crop100": dict(entry)}


def clear_locator(test: dict, step_id: int, field: str, which: str = "target") -> None:
    allowed = ("xpath", "xpath_dialect", "text", "name", "automation_id", "role", "class_name", "templates",
               "ocr_region", "ocr_search", "ocr_radius", "locator_order", "locator_mode")
    if field not in allowed:
        raise ValueError(f"Cannot clear '{field}'. Choose from: {', '.join(allowed)}.")
    step = _step(test, step_id)
    _target(step, which).pop(field, None)
    step["description"] = describe_step(step)


def set_locator_order(test: dict, step_id: int, order: list, which: str = "target") -> list:
    """Choose which locators run, and in what order, for one element."""
    if not isinstance(order, (list, tuple)) or not order:
        raise ValueError("The locator order must be a non-empty list.")
    bad = [o for o in order if o not in Resolver.ALL_TIERS]
    if bad:
        raise ValueError(f"Unknown locator tier(s): {', '.join(map(str, bad))}. Choose from: {', '.join(Resolver.ALL_TIERS)}.")
    cleaned = list(dict.fromkeys(order))
    _target(_step(test, step_id), which)["locator_order"] = cleaned
    return cleaned


def show_locators(test: dict, step_id: int, which: str = "target") -> dict:
    """What the resolver will use for this element (for the editor UI / CLI)."""
    t = dict(_target(_step(test, step_id), which))
    r = Resolver.__new__(Resolver)
    return {"order": r.tier_order(t), "xpath": t.get("xpath"), "text": t.get("text"), "name": t.get("name"),
            "automation_id": t.get("automation_id"), "role": t.get("role"),
            "stored_location": [t.get("x"), t.get("y")], "ocr_region": t.get("ocr_region"),
            "ocr_search": t.get("ocr_search", "local_then_screen"), "ocr_radius": t.get("ocr_radius"),
            "images": sorted((t.get("templates") or {}).keys()), "locator_mode": t.get("locator_mode", "auto")}


# --------------------------------------------------------------------------- scenario options
def set_zone(test: dict, step_id: int, rect, name: str = "custom", which: str = "target") -> dict:
    """Tell the resolver which part of the window (absolute [left, top, right, bottom]) to search first."""
    from core.system import geometry

    if not geometry.valid(rect):
        raise ValueError("zone must be [left, top, right, bottom] with right > left and bottom > top.")
    t = _target(_step(test, step_id), which)
    wr = (_step(test, step_id).get("window") or {}).get("rect")
    t["zone"] = {"name": str(name)[:80], "source": "user", "rect": [int(v) for v in rect],
                 "window_rect": list(wr) if geometry.valid(wr) else [int(v) for v in rect]}
    return t["zone"]


def set_drag_options(test: dict, step_id: int, *, steps=None, hold_ms=None, hover_ms=None, step_delay_ms=None,
                     drop_mode=None, modifiers=None) -> dict:
    """Tune a drag_drop step: slower/faster glide, longer hold or hover (apps that ignore quick drops),
    'relative' (same distance) or 'position' (same place in the destination window) drop, Ctrl/Shift while dragging."""
    st = _step(test, step_id)
    if st.get("type") != "drag_drop":
        raise ValueError(f"Step {step_id} is not a drag_drop step.")
    p = st.setdefault("params", {})
    for key, val, lo, hi in (("steps", steps, 1, 200), ("hold_ms", hold_ms, 0, 5000), ("hover_ms", hover_ms, 0, 5000),
                             ("step_delay_ms", step_delay_ms, 0, 500)):
        if val is not None:
            p[key] = _int(val, key, lo, hi)
    if drop_mode is not None:
        if drop_mode not in ("relative", "position"):
            raise ValueError("drop_mode must be 'relative' or 'position'.")
        p["drop_mode"] = drop_mode
    if modifiers is not None:
        _check_modifiers(modifiers)
        p["modifiers"] = list(modifiers)
    st["description"] = describe_step(st)
    return p


def _check_modifiers(mods) -> None:
    if not isinstance(mods, (list, tuple)) or any(m not in ("ctrl", "shift", "alt", "cmd", "win") for m in mods):
        raise ValueError("modifiers must be a list of: ctrl, shift, alt, cmd, win.")


def set_click_modifiers(test: dict, step_id: int, modifiers) -> None:
    st = _step(test, step_id)
    if st.get("type") not in ("click", "double_click", "right_click", "middle_click"):
        raise ValueError(f"Step {step_id} is not a click step.")
    _check_modifiers(modifiers)
    st.setdefault("params", {})["modifiers"] = list(modifiers)


def set_max_duration(test: dict, step_id: int, ms) -> None:
    """Fail the step if it (action + screen settling) takes longer than ``ms`` - a response-time check. None removes it."""
    st = _step(test, step_id)
    if ms is None:
        st.pop("max_duration_ms", None)
    else:
        st["max_duration_ms"] = _int(ms, "max_duration_ms", 1, 3_600_000)


def set_recovery(test: dict, rules: list) -> list:
    """Rules that dismiss unexpected pop-ups so a failed step can be retried:
    ``[{"window": "Update available", "action": "click_text", "value": "Later"}]``."""
    had, old = "recovery" in test, test.get("recovery")
    test["recovery"] = list(rules)
    errors = [i for i in validation.validate_test(test) if i["code"] == "recovery"]
    if errors:
        if had:
            test["recovery"] = old            # a rejected edit must leave the existing rules untouched
        else:
            test.pop("recovery")
        raise ValueError("; ".join(i["message"] for i in errors))
    return test["recovery"]


def add_step_after(test: dict, after_id: int, step: dict) -> int:
    """Insert a ready-made step (wait_until, scroll_until, window_action, set_clipboard, validate ...) after a step."""
    ids = [s.get("id") for s in test["steps"]]
    if after_id not in ids:
        raise ValueError("Step does not exist.")
    new = {"id": 0, "t_ms": 0, "window": {}, "validations": [], **step}
    if new.get("type") not in validation.KNOWN_STEP_TYPES:
        raise ValueError(f"Unknown step type '{new.get('type')}'.")
    new["description"] = describe_step(new)
    test["steps"].insert(ids.index(after_id) + 1, new)
    testfile.renumber(test)
    errors = [i for i in validation.validate_test(test) if i["level"] == "error"]
    if errors:
        del test["steps"][ids.index(after_id) + 1]
        testfile.renumber(test)
        raise ValueError("; ".join(i["message"] for i in errors))
    return ids.index(after_id) + 2


# --------------------------------------------------------------------------- data
def set_data(test: dict, directory: Path | None = None, *, file=None, rows=None, select=None,
             on_row_failure: str = "continue", restart_apps: bool = False, secret_columns=None, limit=None) -> dict:
    """Make the test data-driven. A file is copied into the test folder (``data/``) so the test stays portable."""
    if (file is None) == (rows is None):
        raise ValueError("Give exactly one of: file, rows.")
    if on_row_failure not in ("continue", "stop"):
        raise ValueError("on_row_failure must be 'continue' or 'stop'.")
    cfg: dict = {"on_row_failure": on_row_failure, "restart_apps": bool(restart_apps)}
    if file is not None:
        if directory is None:
            raise ValueError("Adding a data file needs the test's folder.")
        src = Path(str(file))
        cols, data_rows = datasource.load_file(src)             # validates type / size / content
        dest_dir = Path(directory) / "data"
        dest_dir.mkdir(parents=True, exist_ok=True)
        dest = dest_dir / src.name
        if src.resolve() != dest.resolve():
            shutil.copy2(src, dest)
        cfg["file"] = f"data/{src.name}"
    else:
        cols, data_rows = datasource.from_rows(rows)
        cfg["rows"] = rows
    cfg["columns"] = cols
    if select:
        datasource.parse_selection(select, len(data_rows))
        cfg["select"] = str(select)
    if limit:
        cfg["limit"] = _int(limit, "limit", 1, datasource.MAX_ROWS)
    sc = [c for c in (secret_columns or []) if c in cols]
    unknown = [c for c in (secret_columns or []) if c not in cols]
    if unknown:
        raise ValueError(f"Secret column(s) not in the data: {', '.join(unknown)}. Columns are: {', '.join(cols)}.")
    if sc:
        cfg["secret_columns"] = sc
    test["data"] = cfg
    return cfg


def clear_data(test: dict) -> None:
    test.pop("data", None)


# --------------------------------------------------------------------------- blocks
def _index_range(test: dict, first_id: int, last_id: int) -> tuple[int, int]:
    steps = test["steps"]
    ids = [s.get("id") for s in steps]
    if first_id not in ids or last_id not in ids:
        raise ValueError("Both step ids must exist.")
    a, b = ids.index(first_id), ids.index(last_id)
    if a > b:
        raise ValueError("first step must come before last step.")
    return a, b


def _control(stype: str, **fields) -> dict:
    s = {"id": 0, "type": stype, "t_ms": 0, "window": {}, "validations": [], **fields}
    s["description"] = describe_step(s)
    return s


def wrap_in_loop(test: dict, first_id: int, last_id: int, *, times=None, while_cond=None, max_iterations: int = 100) -> None:
    """Repeat steps first_id..last_id ``times`` times, or while a condition holds (never more than max_iterations)."""
    if (times is None) == (while_cond is None):
        raise ValueError("Give exactly one of: times, while_cond.")
    a, b = _index_range(test, first_id, last_id)
    params = {"times": times} if times is not None else {"while": while_cond, "max": max_iterations}
    steps = test["steps"]
    steps.insert(b + 1, _control("loop_end"))
    steps.insert(a, _control("loop_start", params=params))
    _finish(test)


def wrap_in_if(test: dict, first_id: int, last_id: int, condition: dict, *, else_first_id: int | None = None) -> None:
    """Run first_id..last_id only if ``condition`` holds. With else_first_id, steps from there to last_id are the else branch."""
    a, b = _index_range(test, first_id, last_id)
    steps = test["steps"]
    if else_first_id is not None:
        ids = [s.get("id") for s in steps]
        if else_first_id not in ids:
            raise ValueError("else_first_id does not exist.")
        e = ids.index(else_first_id)
        if not a < e <= b:
            raise ValueError("else_first_id must be after first_id and not after last_id.")
        steps.insert(e, _control("else"))
        b += 1
    steps.insert(b + 1, _control("if_end"))
    steps.insert(a, _control("if_start", condition=condition))
    _finish(test)


def insert_break(test: dict, after_id: int) -> None:
    ids = [s.get("id") for s in test["steps"]]
    if after_id not in ids:
        raise ValueError("Step does not exist.")
    test["steps"].insert(ids.index(after_id) + 1, _control("break_loop"))
    _finish(test)


def _finish(test: dict) -> None:
    testfile.renumber(test)
    bad = [i for i in validation.validate_test(test) if i["level"] == "error" and i["code"] in ("loop", "block", "condition")]
    if bad:
        raise ValueError("; ".join(i["message"] for i in bad))


def validate(test: dict) -> list[dict]:
    return validation.validate_test(test)


def save(test: dict, directory: Path | None = None) -> Path:
    errors = [i for i in validation.validate_test(test) if i["level"] == "error"]
    if errors:
        raise ValueError("Not saved - the test has errors: " + validation.format_issues(errors))
    return testfile.save_test(test, directory)
