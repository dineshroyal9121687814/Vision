"""
Windows environment layer: DPI, windows, UI Automation, screen capture.

Everything that touches the OS lives here so the rest of VisionAuto stays
testable. Every function degrades to an empty/neutral result when the OS
feature is unavailable (Linux CI, missing pywinauto, ...) instead of raising.

Lessons baked in (found on a real Windows run):
  * DPI awareness MUST be enabled before any coordinates are read, otherwise
    mouse coordinates (scaled) and screenshots (physical pixels) disagree and
    every recorded template is cropped from the wrong place.
  * The foreground window comes from user32 directly; pywinauto's
    Desktop().top_window() is not a "foreground window" API.
"""
from __future__ import annotations

import logging
import re
import sys
import threading
import time

import numpy as np

log = logging.getLogger("visionauto.winenv")
IS_WINDOWS = sys.platform == "win32"

_EMPTY_WINDOW = {"title": "", "process": "", "pid": 0, "hwnd": 0, "rect": None, "state": ""}
_dpi_done = False
_proc_cache: dict[int, str] = {}
_tls = threading.local()


def _native_candidates_ambiguous(distances, minimum_gap: float = 20.0) -> bool:
    """Return true when the two closest exact UIA matches cannot be distinguished by proximity."""
    ordered = sorted(float(d) for d in distances)
    return len(ordered) > 1 and ordered[1] - ordered[0] < minimum_gap


# --------------------------------------------------------------------- DPI / COM
def enable_dpi_awareness() -> None:
    global _dpi_done
    if _dpi_done or not IS_WINDOWS:
        return
    _dpi_done = True
    import ctypes

    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(2)  # per-monitor
    except Exception:
        try:
            ctypes.windll.user32.SetProcessDPIAware()
        except Exception:
            log.debug("could not set DPI awareness", exc_info=True)


def window_dpi_scale(hwnd) -> float:
    """Display scaling of the monitor a window is on (1.0 = 100 %, 1.25 = 125 %)."""
    if not IS_WINDOWS:
        return 1.0
    import ctypes

    try:
        return max(0.5, ctypes.windll.user32.GetDpiForWindow(hwnd) / 96.0)
    except Exception:
        return max(0.5, dpi_scale_percent() / 100.0)


def dpi_scale_percent() -> int:
    if not IS_WINDOWS:
        return 100
    import ctypes

    try:
        return int(ctypes.windll.shcore.GetScaleFactorForDevice(0))
    except Exception:
        return 100


def init_com() -> None:
    """Call at the start of every thread that uses UI Automation."""
    if not IS_WINDOWS:
        return
    try:
        import comtypes

        comtypes.CoInitialize()
    except Exception:
        pass


# --------------------------------------------------------------------- windows
def _wintext(hwnd) -> str:
    import ctypes

    u = ctypes.windll.user32
    n = u.GetWindowTextLengthW(hwnd)
    buf = ctypes.create_unicode_buffer(n + 1)
    u.GetWindowTextW(hwnd, buf, n + 1)
    return buf.value


def _process_name(pid: int) -> str:
    if pid in _proc_cache:
        return _proc_cache[pid]
    name = ""
    try:
        import psutil

        name = psutil.Process(pid).name()
    except Exception:
        pass
    _proc_cache[pid] = name
    return name


POPUP_CLASSES = ("combolbox", "#32768", "comboboxexdropdown", "drop-down", "popuphost", "tooltips_class32",
                 "xamlpopuphost", "windows.ui.core.corewindow", "bosa_sdm_xl9", "nuihwnd")


def popup_info(hwnd) -> tuple[bool, str, int]:
    """(is a pop-up, owner window title, owner hwnd). A drop-down list / menu / flyout is its own top-level window that
    is owned by the window it dropped from, has no caption, and disappears after the click."""
    if not IS_WINDOWS or not hwnd:
        return False, "", 0
    import ctypes

    u = ctypes.windll.user32
    owner = int(u.GetWindow(hwnd, 4) or 0)                       # GW_OWNER
    style = ctypes.c_long(u.GetWindowLongW(hwnd, -16)).value & 0xFFFFFFFF
    no_caption = not (style & 0x00C00000)
    is_popup = bool(style & 0x80000000) and no_caption and (bool(owner) or window_class(hwnd).casefold() in POPUP_CLASSES)
    if window_class(hwnd).casefold() in ("combolbox", "#32768", "comboboxexdropdown"):
        is_popup = True
    return is_popup, (_wintext(owner) if owner else ""), owner


def window_info(hwnd) -> dict:
    if not IS_WINDOWS or not hwnd:
        return dict(_EMPTY_WINDOW)
    import ctypes

    pid = ctypes.c_ulong(0)
    ctypes.windll.user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
    popup, owner_title, owner = popup_info(hwnd)
    return {"title": _wintext(hwnd), "process": _process_name(pid.value), "pid": int(pid.value), "hwnd": int(hwnd),
            "rect": window_rect(hwnd), "state": window_state(hwnd), "class": window_class(hwnd),
            "popup": popup, "owner_title": owner_title, "owner": owner, "kind": window_kind(hwnd)}


def window_rect(hwnd) -> list | None:
    """Outer window rectangle [left, top, right, bottom] in screen pixels (None if unavailable)."""
    if not IS_WINDOWS or not hwnd:
        return None
    import ctypes
    from ctypes import wintypes

    r = wintypes.RECT()
    if not ctypes.windll.user32.GetWindowRect(hwnd, ctypes.byref(r)):
        return None
    return [int(r.left), int(r.top), int(r.right), int(r.bottom)]


def window_state(hwnd) -> str:
    """'normal' | 'maximized' | 'minimized'"""
    if not IS_WINDOWS or not hwnd:
        return ""
    import ctypes

    u = ctypes.windll.user32
    if u.IsIconic(hwnd):
        return "minimized"
    return "maximized" if u.IsZoomed(hwnd) else "normal"


def virtual_screen() -> list:
    """Bounding box of all monitors [left, top, right, bottom]."""
    if not IS_WINDOWS:
        return [0, 0, 1920, 1080]
    import ctypes

    m = ctypes.windll.user32.GetSystemMetrics
    left, top, w, h = m(76), m(77), m(78), m(79)       # SM_XVIRTUALSCREEN .. SM_CYVIRTUALSCREEN
    return [int(left), int(top), int(left + w), int(top + h)]


def set_window_rect(hwnd, rect) -> bool:
    """Move/resize a window to ``rect`` without stealing focus. Restores it first if minimised/maximised."""
    if not IS_WINDOWS or not hwnd:
        return False
    import ctypes

    u = ctypes.windll.user32
    if u.IsIconic(hwnd) or u.IsZoomed(hwnd):
        u.ShowWindow(hwnd, 9)                        # SW_RESTORE
    x, y, r, b = (int(v) for v in rect)
    # SWP_NOZORDER (0x4) | SWP_NOACTIVATE (0x10)
    return bool(u.SetWindowPos(hwnd, 0, x, y, max(1, r - x), max(1, b - y), 0x0004 | 0x0010))


def set_window_state(hwnd, state: str) -> bool:
    if not IS_WINDOWS or not hwnd:
        return False
    import ctypes

    code = {"maximized": 3, "minimized": 6, "normal": 9}.get(state)
    return bool(code and ctypes.windll.user32.ShowWindow(hwnd, code) is not None)


def raise_window(hwnd) -> bool:
    """Bring a window to the top of the z-order WITHOUT taking the keyboard focus (restores it if minimised)."""
    if not IS_WINDOWS or not hwnd:
        return False
    import ctypes

    u = ctypes.windll.user32
    if u.IsIconic(hwnd):
        u.ShowWindow(hwnd, 9)
    # HWND_TOP (0), SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE
    return bool(u.SetWindowPos(hwnd, 0, 0, 0, 0, 0, 0x0002 | 0x0001 | 0x0010))


def close_window(hwnd) -> bool:
    """Politely ask a window to close (WM_CLOSE) - the same as clicking its X."""
    if not IS_WINDOWS or not hwnd:
        return False
    import ctypes

    return bool(ctypes.windll.user32.PostMessageW(hwnd, 0x0010, 0, 0))


def foreground_window() -> dict:
    if not IS_WINDOWS:
        return dict(_EMPTY_WINDOW)
    import ctypes

    return window_info(ctypes.windll.user32.GetForegroundWindow())


def is_transient_of(fg: dict, title_part: str) -> bool:
    """True when ``fg`` is a caption-less transient window (right-click mini toolbar, context menu, drop-down list, flyout)
    that belongs to the application whose window title contains ``title_part``. While such a window is in front the
    recorded application window is, for every practical purpose, still the active one."""
    fg = fg or {}
    if str(fg.get("title") or "").strip() and not fg.get("popup"):
        return False
    want = str(title_part or "").strip().casefold()
    if not want:
        return False
    if want in str(fg.get("owner_title") or "").casefold():
        return True
    pid = int(fg.get("pid") or 0)
    if not pid:
        return False
    try:
        for h in _find_windows(title_part):
            if int(window_info(h).get("pid") or 0) == pid:
                return True
    except Exception:                                   # noqa: BLE001
        return False
    return False


def window_at(x: int, y: int) -> dict:
    """Top-level window under a screen point (what the user actually clicked)."""
    if not IS_WINDOWS:
        return dict(_EMPTY_WINDOW)
    import ctypes
    from ctypes import wintypes

    u = ctypes.windll.user32
    hwnd = u.WindowFromPoint(wintypes.POINT(int(x), int(y)))
    root = u.GetAncestor(hwnd, 2) if hwnd else 0  # GA_ROOT
    return window_info(root or hwnd)


def window_exists(title_part: str) -> bool:
    return bool(_find_windows(title_part))


def find_windows(title_part: str) -> list[int]:
    """Find visible top-level windows matching title_part."""
    if not IS_WINDOWS or not title_part:
        return []
    import ctypes

    u = ctypes.windll.user32
    found: list[int] = []
    proc_t = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p)

    def cb(hwnd, _):
        if u.IsWindowVisible(hwnd):
            t = _wintext(hwnd)
            if t and title_part.lower() in t.lower():
                found.append(hwnd)
        return True

    u.EnumWindows(proc_t(cb), 0)
    return found


_find_windows = find_windows


def window_class(hwnd) -> str:
    if not IS_WINDOWS or not hwnd:
        return ""
    import ctypes

    buf = ctypes.create_unicode_buffer(256)
    ctypes.windll.user32.GetClassNameW(hwnd, buf, 256)
    return buf.value


def hide_window(hwnd) -> bool:
    """SW_HIDE: gone from the screen and the taskbar, the process keeps running."""
    if not IS_WINDOWS or not hwnd:
        return False
    import ctypes

    return bool(ctypes.windll.user32.ShowWindow(hwnd, 0) is not None)


def focus_hwnd(hwnd) -> bool:
    """Give the keyboard focus back to a specific window."""
    if not IS_WINDOWS or not hwnd:
        return False
    import ctypes

    u = ctypes.windll.user32
    if u.IsIconic(hwnd):
        u.ShowWindow(hwnd, 9)
    u.SetForegroundWindow(hwnd)
    if u.GetForegroundWindow() != hwnd:
        u.keybd_event(0x12, 0, 0, 0)
        u.keybd_event(0x12, 0, 2, 0)
        u.SetForegroundWindow(hwnd)
    return u.GetForegroundWindow() == hwnd


def list_windows(with_class: bool = False) -> list[dict]:
    """Visible, titled top-level windows: ``[{'hwnd', 'title', 'process'}]`` (the Inspector's window picker).
    ``with_class`` also returns console windows (which have no title text sometimes) with their window class."""
    if not IS_WINDOWS:
        return []
    import ctypes

    u = ctypes.windll.user32
    out: list[dict] = []
    proc_t = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p)

    def cb(hwnd, _):
        if u.IsWindowVisible(hwnd):
            t = _wintext(hwnd)
            if t or with_class:
                info = window_info(hwnd)
                row = {"hwnd": int(hwnd), "title": t, "process": info.get("process", "")}
                if with_class:
                    row["class"] = window_class(hwnd)
                out.append(row)
        return True

    u.EnumWindows(proc_t(cb), 0)
    return out


def is_window(hwnd) -> bool:
    """False for a stale handle (window closed, handle possibly recycled)."""
    if not IS_WINDOWS or not hwnd:
        return False
    import ctypes

    return bool(ctypes.windll.user32.IsWindow(hwnd))


def _exe_path(pid: int) -> str:
    try:
        import psutil

        return psutil.Process(pid).exe()
    except Exception:
        return ""


def enumerate_windows() -> list[dict]:
    """Every visible top-level window with the facts window targeting needs (title, process, exe, pid, rect, owner,
    pop-up / tool-window flags). Unlike ``list_windows`` it keeps untitled pop-ups so dropdown/menu windows can be
    attributed to their owner."""
    if not IS_WINDOWS:
        return []
    import ctypes

    u = ctypes.windll.user32
    out: list[dict] = []
    proc_t = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p)

    def cb(hwnd, _):
        if u.IsWindowVisible(hwnd):
            info = window_info(hwnd)
            ex = ctypes.c_long(u.GetWindowLongW(hwnd, -20)).value & 0xFFFFFFFF
            info["tool"] = bool(ex & 0x00000080)                    # WS_EX_TOOLWINDOW
            info["visible"] = True
            info["exe"] = _exe_path(info.get("pid", 0))
            out.append(info)
        return True

    u.EnumWindows(proc_t(cb), 0)
    return out


def activate_window(title_part: str) -> bool:
    """Bring a window whose title contains `title_part` to the foreground."""
    hwnds = _find_windows(title_part)
    if not hwnds:
        return False
    import ctypes

    u = ctypes.windll.user32
    hwnd = hwnds[0]
    if u.IsIconic(hwnd):
        u.ShowWindow(hwnd, 9)  # SW_RESTORE
    u.SetForegroundWindow(hwnd)
    if u.GetForegroundWindow() != hwnd:  # foreground-lock workaround
        u.keybd_event(0x12, 0, 0, 0)
        u.keybd_event(0x12, 0, 2, 0)
        u.SetForegroundWindow(hwnd)
    return u.GetForegroundWindow() == hwnd


# --------------------------------------------------------------------- screen
def _mss():
    import mss

    inst = getattr(_tls, "sct", None)
    if inst is None:
        cls = getattr(mss, "MSS", None) or mss.mss  # mss.mss is deprecated in new releases
        inst = cls()
        from core.vision import pointer

        pointer.capture_without_cursor(inst)      # the pointer must never be painted into a template / OCR picture
        _tls.sct = inst
    return inst


def grab_screen() -> tuple[np.ndarray, tuple[int, int]]:
    """Whole virtual desktop as BGR + (left, top) origin of that image in screen coords."""
    sct = _mss()
    mon = sct.monitors[0]
    shot = sct.grab(mon)
    frame = np.ascontiguousarray(np.asarray(shot)[:, :, :3])
    return frame, (int(mon["left"]), int(mon["top"]))


def grab_region(rect) -> tuple[np.ndarray, tuple[int, int]]:
    """Just ``rect`` [l, t, r, b] (screen coords) as BGR + its origin: far cheaper than the whole virtual desktop."""
    sct = _mss()
    full = sct.monitors[0]
    l, t = max(int(rect[0]), full["left"]), max(int(rect[1]), full["top"])
    r, b = min(int(rect[2]), full["left"] + full["width"]), min(int(rect[3]), full["top"] + full["height"])
    if r - l < 8 or b - t < 8:
        return grab_screen()
    shot = sct.grab({"left": l, "top": t, "width": r - l, "height": b - t})
    return np.ascontiguousarray(np.asarray(shot)[:, :, :3]), (l, t)


def crop_around(frame: np.ndarray, origin: tuple[int, int], x: int, y: int, size: int):
    """Square crop centred on a screen point (shifted, not shrunk, at the edges).
    Returns (crop, (click_x, click_y) inside the crop)."""
    h, w = frame.shape[:2]
    cx, cy = int(x - origin[0]), int(y - origin[1])
    half = size // 2
    x0 = min(max(cx - half, 0), max(w - size, 0))
    y0 = min(max(cy - half, 0), max(h - size, 0))
    crop = frame[y0:y0 + size, x0:x0 + size]
    return crop, (cx - x0, cy - y0)


# --------------------------------------------------------------------- UI Automation
def _describe(el) -> dict:
    info = el.element_info
    r = info.rectangle
    try:
        is_password = bool(info.is_password)
    except Exception:
        # Some UIA providers do not expose this property. Class-name fallback
        # covers common controls that identify themselves as password fields.
        is_password = "password" in str(getattr(info, "class_name", "")).casefold()
    out = {
        "name": info.name or "",
        "role": info.control_type or "",
        "automation_id": info.automation_id or "",
        "class_name": info.class_name or "",
        "rect": [int(r.left), int(r.top), int(r.right), int(r.bottom)],
        "is_password": is_password,
    }
    try:
        out["is_enabled"] = bool(info.enabled)
    except Exception:
        pass
    # UIA value/text providers may return the actual credential even when the
    # control renders bullets. Never ask a password control for its value.
    if not is_password:
        for key, getter in (("value", "get_value"), ("text", "window_text")):
            fn = getattr(el, getter, None)
            if fn:
                try:
                    v = fn()
                    if v:
                        out[key] = str(v)
                except Exception:
                    pass
    try:
        h = str(info.element.CurrentHelpText or "").strip()
        if h:
            out["help"] = h[:200]                    # the tooltip / help text UI Automation knows for this control
    except Exception:
        pass
    state = {}
    fn = getattr(el, "get_toggle_state", None)
    if fn:
        try:
            state["toggle"] = {0: "off", 1: "on", 2: "indeterminate"}.get(int(fn()), "")
        except Exception:
            pass
    fn = getattr(el, "is_selected", None)
    if fn:
        try:
            state["selected"] = bool(fn())
        except Exception:
            pass
    if state:
        out["state"] = state
    return out


def _ancestors(el, limit: int = 8) -> list[dict]:
    """Parent chain (nearest first) used to work out which pane of the window an element lives in."""
    out: list[dict] = []
    cur = el
    for _ in range(limit):
        try:
            cur = cur.parent()
            if cur is None:
                break
            info = cur.element_info
            r = info.rectangle
            out.append({"name": info.name or "", "role": info.control_type or "", "automation_id": info.automation_id or "",
                        "rect": [int(r.left), int(r.top), int(r.right), int(r.bottom)]})
        except Exception:
            break
    return out


def element_at(x: int, y: int) -> dict:
    """UI Automation element under a screen point ({} if unavailable)."""
    if not IS_WINDOWS:
        return {}
    try:
        from pywinauto import Desktop

        el = Desktop(backend="uia").from_point(int(x), int(y))
        if el is None:
            return {}
        d = _describe(el)
        d["ancestors"] = _ancestors(el)
        return d
    except Exception:
        log.debug("element_at failed", exc_info=True)
        return {}


def scroll_into_view(window_title="", name="", role="", automation_id="") -> bool:
    """Ask the app to scroll a list item / grid cell into view (UIA ScrollItemPattern). True = the call was made.
    Exact and side-effect free, but only works for items the app has already created (virtualised lists may not have)."""
    if not IS_WINDOWS or not (name or automation_id):
        return False
    try:
        from pywinauto import Desktop

        fg = foreground_window()
        if not fg["hwnd"]:
            return False
        win = Desktop(backend="uia").window(handle=fg["hwnd"])
        crit = {"auto_id": automation_id} if automation_id else {"title": name}
        if role:
            crit["control_type"] = role
        for c in win.descendants(**crit)[:3]:
            try:
                c.iface_scroll_item.ScrollIntoView()
                return True
            except Exception:
                continue
    except Exception:
        log.debug("scroll_into_view failed", exc_info=True)
    return False


def focused_element() -> dict:
    """Describe the keyboard-focused control without reading password values."""
    if not IS_WINDOWS:
        return {}
    try:
        from pywinauto import Desktop

        el = Desktop(backend="uia").get_focus()
        return _describe(el) if el is not None else {}
    except Exception:
        log.debug("focused_element failed", exc_info=True)
        return {}


def find_native(window_title="", name="", role="", automation_id="", near=None, hwnd=0) -> dict | None:
    """Find a control through UI Automation. Returns the element description
    (with its live `rect`) or None. `near` = recorded centre, used to pick
    between several controls with the same name."""
    if not IS_WINDOWS or not (name or automation_id):
        return None
    try:
        from pywinauto import Desktop

        d = Desktop(backend="uia")
        if hwnd and is_window(hwnd):
            # The Player already resolved THE window (strict window targeting): search exactly there, foreground or not.
            wins = [d.window(handle=int(hwnd))]
            fg = {"hwnd": int(hwnd)}
        else:
            wins = d.windows(title_re=".*" + re.escape(window_title) + ".*") if window_title else []
            if window_title and not wins:
                return None
            # A missing recorded window must not silently redirect semantic
            # resolution to an unrelated foreground application.
            fg = foreground_window()
            if not fg["hwnd"]:
                return None
        if hwnd and is_window(hwnd):
            pass
        elif window_title:
            # Restrict UIA hits to the actual foreground HWND. A matching
            # title in a background window is not a safe mouse-click target.
            wins = [w for w in wins if int(getattr(w, "handle", 0)) == int(fg["hwnd"])]
        else:
            wins = [d.window(handle=fg["hwnd"])]
        if not wins:
            return None
        crit = {"auto_id": automation_id} if automation_id else {"title": name}
        if role:
            crit["control_type"] = role
        cands = []
        for w in wins[:3]:
            for c in w.descendants(**crit):
                try:
                    r = c.rectangle()
                    if c.is_visible() and r.width() > 0 and r.height() > 0:
                        cands.append(c)
                except Exception:
                    continue
            if cands:
                break
        if not cands:
            return None
        if len(cands) > 1 and not near:
            from core.automation.errors import AmbiguousTarget
            raise AmbiguousTarget(f"{len(cands)} controls match {name or automation_id!r} and no recorded position separates them",
                                  [_describe(c) for c in cands[:8]])
        if near and len(cands) > 1:
            def dist(c):
                r = c.rectangle()
                return ((r.left + r.right) / 2 - near[0]) ** 2 + ((r.top + r.bottom) / 2 - near[1]) ** 2
            cands.sort(key=dist)
            if _native_candidates_ambiguous([dist(c) ** 0.5 for c in cands]):
                from core.automation.errors import AmbiguousTarget
                raise AmbiguousTarget(f"{len(cands)} controls match {name or automation_id!r} at similar distances from the "
                                      "recorded position; give a container or an exact XPath", [_describe(c) for c in cands[:8]])
        return _describe(cands[0])
    except Exception as exc:
        if exc.__class__.__name__ == "AmbiguousTarget":
            raise
        log.debug("find_native failed", exc_info=True)
        return None


def win32_text_at(x: int, y: int) -> str:
    """Text of the classic Windows control under a point (Edit, ComboBox, Static, Delphi/MFC/WinForms fields ...) through
    WM_GETTEXT - works where UI Automation exposes nothing. Password boxes are never read. '' when not applicable."""
    if not IS_WINDOWS:
        return ""
    try:
        import ctypes
        from ctypes import wintypes

        u = ctypes.windll.user32
        hwnd = u.WindowFromPoint(wintypes.POINT(int(x), int(y)))
        if not hwnd:
            return ""
        if ctypes.c_long(u.GetWindowLongW(hwnd, -16)).value & 0x20 and window_class(hwnd).casefold() == "edit":
            return ""                                                 # ES_PASSWORD
        buf = ctypes.create_unicode_buffer(4096)
        n = ctypes.c_size_t(0)
        ok = u.SendMessageTimeoutW(hwnd, 0x000D, 4096, buf, 0x0002, 250, ctypes.byref(n))     # WM_GETTEXT, SMTO_ABORTIFHUNG
        return buf.value if ok else ""
    except Exception:
        log.debug("win32_text_at failed", exc_info=True)
        return ""


def excel_formula_bar(window_title: str) -> tuple[str, str] | None:
    """(Name Box text, Formula Bar text) of an Excel window through UI Automation: which cell is active and what it holds.
    Needs no COM, so it works when Excel is not registered for automation. None when unavailable."""
    if not IS_WINDOWS:
        return None
    try:
        from pywinauto import Desktop

        w = Desktop(backend="uia").window(title_re=".*" + re.escape(window_title) + ".*") if window_title else \
            Desktop(backend="uia").window(handle=foreground_window()["hwnd"])
        box = w.child_window(auto_id="NameBox", control_type="ComboBox").wrapper_object()
        bar = w.child_window(auto_id="FormulaBar", control_type="Edit").wrapper_object()
        name = str(box.get_value() if hasattr(box, "get_value") else box.window_text())
        return name.strip(), str(bar.get_value())
    except Exception:
        log.debug("excel_formula_bar failed", exc_info=True)
        return None


TOOLTIP_CLASSES = ("tooltips_class32", "windows.forms10.tooltips_class32", "tooltip")


def window_kind(hwnd) -> str:
    """main | dialog | menu | popup | tooltip - what sort of window this is (a drop-down list is not a dialog is not a menu)."""
    if not IS_WINDOWS or not hwnd:
        return "main"
    cls = window_class(hwnd).casefold()
    if any(t in cls for t in TOOLTIP_CLASSES):
        return "tooltip"
    if cls == "#32768":
        return "menu"
    popup, _, owner = popup_info(hwnd)
    if popup:
        return "popup"
    if cls == "#32770" or owner:
        return "dialog"
    return "main"


def tooltip_text() -> str:
    """Text of a tooltip that is showing right now (empty if none). Checked cheaply first; UI Automation only if one exists."""
    if not IS_WINDOWS:
        return ""
    try:
        if not any(window_kind(w["hwnd"]) == "tooltip" for w in list_windows(with_class=True) if w.get("class")):
            return ""
        from pywinauto import Desktop

        for t in Desktop(backend="uia").windows(control_type="ToolTip"):
            txt = t.window_text()
            if txt:
                return str(txt)[:200]
    except Exception:
        log.debug("tooltip_text failed", exc_info=True)
    return ""


def find_by_help(window_title="", help_text="", role="", near=None) -> dict | None:
    """Find an UNNAMED control (typical toolbar icon) by its UI Automation help text / tooltip."""
    if not IS_WINDOWS or not help_text:
        return None
    try:
        from pywinauto import Desktop

        d = Desktop(backend="uia")
        fg = foreground_window()
        w = d.window(handle=fg["hwnd"])
        want = help_text.strip().casefold()
        cands = []
        crit = {"control_type": role} if role else {}
        for c in w.descendants(**crit):
            try:
                if str(c.element_info.element.CurrentHelpText or "").strip().casefold() == want and c.is_visible():
                    cands.append(c)
            except Exception:
                continue
        if not cands:
            return None
        if near and len(cands) > 1:
            def dist(c):
                r = c.rectangle()
                return ((r.left + r.right) / 2 - near[0]) ** 2 + ((r.top + r.bottom) / 2 - near[1]) ** 2
            cands.sort(key=dist)
        return _describe(cands[0])
    except Exception:
        log.debug("find_by_help failed", exc_info=True)
        return None


def _scroll_iface(x: int, y: int):
    """The nearest UI Automation ancestor at a screen point that can scroll (ScrollPattern), or None."""
    from pywinauto import Desktop

    el = Desktop(backend="uia").from_point(int(x), int(y))
    for _ in range(9):
        if el is None:
            return None
        try:
            sc = el.iface_scroll
            if sc.CurrentVerticallyScrollable or sc.CurrentHorizontallyScrollable:
                return sc
        except Exception:
            pass
        try:
            el = el.parent()
        except Exception:
            return None
    return None


def scroll_percent_at(x: int, y: int) -> dict | None:
    """How far the scrollable thing under a point is scrolled: ``{'v': 0-100, 'h': 0-100}`` (None = unknown / not scrollable).
    Recorded with every click inside a scrollable container, so playback can jump straight back to that position."""
    if not IS_WINDOWS:
        return None
    try:
        sc = _scroll_iface(x, y)
        if sc is None:
            return None
        v, h = float(sc.CurrentVerticalScrollPercent), float(sc.CurrentHorizontalScrollPercent)
        return {"v": round(v, 2) if v >= 0 else -1, "h": round(h, 2) if h >= 0 else -1}
    except Exception:
        log.debug("scroll_percent_at failed", exc_info=True)
        return None


def set_scroll_percent_at(x: int, y: int, v: float = -1, h: float = -1) -> bool:
    """Jump the scrollable thing under a point to a scroll position (-1 = leave that axis). Exact, no mouse wheel."""
    if not IS_WINDOWS:
        return False
    try:
        sc = _scroll_iface(x, y)
        if sc is None:
            return False
        sc.SetScrollPercent(float(h), float(v))          # (horizontal, vertical); -1 = NoScroll
        return True
    except Exception:
        log.debug("set_scroll_percent_at failed", exc_info=True)
        return False


class SystemProbe:
    """Everything the recorder needs from the OS in one swappable object (tests use a fake)."""

    def grab(self):
        return grab_screen()

    def window_at(self, x, y):
        return window_at(x, y)

    def foreground(self):
        return foreground_window()

    def element_at(self, x, y):
        return element_at(x, y)

    def focused_element(self):
        return focused_element()

    def scroll_percent(self, x, y):
        return scroll_percent_at(x, y)
