"""
Keep helper processes (Ollama and the console windows it can open) out of the test's way.

Problem: while a local model loads or answers, Windows can flash a console ("cmd prompt opening and closing"). That window
steals the keyboard focus, so the next typed text goes to the wrong window, and a recording captures clicks / keys that
the user never meant as test steps.

What this module does:
  * ``NO_WINDOW`` / ``popen`` / ``run``   every helper process VisionAuto starts is started without a console.
  * ``is_noise(info)``                    true for Ollama's own windows and for console windows that appeared while a
                                          helper was running. The recorder ignores them.
  * ``FocusGuard``                        while a helper runs: any *new* console / Ollama window is hidden at once and the
                                          window that had the focus gets it back. Used around every model call, and
                                          around the model warm-up that happens before a run starts.
Everything takes a ``probe`` so it is unit-tested without Windows.
"""
from __future__ import annotations

import logging
import subprocess
import threading
import time

from core.system import winenv

log = logging.getLogger("visionauto.quiet")

NO_WINDOW = 0x08000000                    # CREATE_NO_WINDOW
DETACHED = 0x00000008                     # DETACHED_PROCESS
NOISE_PROCESSES = ("ollama", "ollama app", "ollama_llama_server", "conhost", "openconsole")
CONSOLE_CLASSES = ("consolewindowclass", "cascadia_hosting_window_class", "pseudoconsolewindow")


def flags(detached: bool = False) -> int:
    return (NO_WINDOW | (DETACHED if detached else 0)) if winenv.IS_WINDOWS else 0


def popen(args, **kw):
    """subprocess.Popen without a console window."""
    kw.setdefault("creationflags", flags(kw.pop("detached", False)))
    return subprocess.Popen(args, **kw)


def run(args, **kw):
    kw.setdefault("creationflags", flags())
    return subprocess.run(args, **kw)


def is_noise(info: dict | None, known: set | None = None, consoles: bool = False) -> bool:
    """A window VisionAuto should never treat as part of the application under test.
    Ollama's own windows always count. Other console windows count only with ``consoles=True`` (used while a helper
    is running, and only for windows that were not open before) - a console app under test is NOT noise."""
    info = info or {}
    proc = str(info.get("process") or "").casefold().removesuffix(".exe")
    title = str(info.get("title") or "").casefold()
    if proc in NOISE_PROCESSES or "ollama" in title:
        return True
    cls = str(info.get("class") or "").casefold()
    if consoles and cls in CONSOLE_CLASSES:
        return not (known and info.get("hwnd") in known)        # a console that was already open is the user's own
    return False


class _Probe:
    """The few window calls the guard needs (real implementation; tests pass a fake)."""
    def windows(self) -> list[dict]:
        return winenv.list_windows(with_class=True)

    def foreground(self) -> dict:
        return winenv.foreground_window()

    def hide(self, hwnd: int) -> None:
        winenv.hide_window(hwnd)

    def focus(self, hwnd: int) -> None:
        winenv.focus_hwnd(hwnd)


class FocusGuard:
    """``with FocusGuard(): <call the model>`` - new console / Ollama windows are hidden, the focus goes back."""

    def __init__(self, probe=None, interval_s: float = 0.08, sleep=time.sleep):
        self.probe, self.interval, self.sleep = probe or _Probe(), interval_s, sleep
        self.hidden: list[int] = []
        self._known: set = set()
        self._focus: int = 0
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None

    def sweep(self) -> int:
        """One pass: hide every new noise window, restore the focus if a noise window took it. Returns how many hidden."""
        n = 0
        try:
            for w in self.probe.windows():
                if w.get("hwnd") in self._known:
                    continue
                if is_noise(w, self._known, consoles=True):
                    self.probe.hide(w["hwnd"])
                    self.hidden.append(w["hwnd"])
                    self._known.add(w["hwnd"])
                    n += 1
            fg = self.probe.foreground()
            if self._focus and fg.get("hwnd") != self._focus and (is_noise(fg, self._known, consoles=True) or n):
                self.probe.focus(self._focus)
        except Exception:
            log.debug("focus guard sweep failed", exc_info=True)
        return n

    def _loop(self):
        while not self._stop.is_set():
            self.sweep()
            self.sleep(self.interval)

    def __enter__(self):
        try:
            self._known = {w.get("hwnd") for w in self.probe.windows()}
            self._focus = int(self.probe.foreground().get("hwnd") or 0)
        except Exception:
            self._known, self._focus = set(), 0
        self._thread = threading.Thread(target=self._loop, name="focus-guard", daemon=True)
        self._thread.start()
        return self

    def __exit__(self, *exc):
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=1.0)
        self.sweep()                                   # catch a window that appeared in the last interval
        return False
