"""Native UI Automation *patterns* (Value, SelectionItem, ExpandCollapse, Toggle, Invoke) applied to the element under a
screen point that the strict resolver already vetted.  Windows only; every function returns None/False elsewhere so the
Player can fall back to (verified) keyboard/mouse input.

Pattern use is preferred over coordinates: ValuePattern.SetValue does not depend on focus, window position or timing.
Password controls are never read.
"""
from __future__ import annotations

import logging
import time

from core.system import winenv

log = logging.getLogger("visionauto.uia_actions")


def _wrapper(x: int, y: int):
    if not winenv.IS_WINDOWS:
        return None
    try:
        from pywinauto import Desktop

        return Desktop(backend="uia").from_point(int(x), int(y))
    except Exception:
        log.debug("from_point failed", exc_info=True)
        return None


def _is_password(w) -> bool:
    try:
        return bool(w.element_info.is_password)
    except Exception:
        return False


def read_value(x: int, y: int) -> str | None:
    """Current text/value of the control at (x, y); None if it cannot be read (never for password controls)."""
    w = _wrapper(x, y)
    if w is None or _is_password(w):
        return None
    for getter in ("get_value", "window_text"):
        try:
            v = getattr(w, getter)()
            if v is not None:
                return str(v)
        except Exception:
            continue
    return None


def set_value(x: int, y: int, text: str, append: bool = False) -> bool:
    """ValuePattern.SetValue.  True only if the pattern call was made on a writable control."""
    w = _wrapper(x, y)
    if w is None or _is_password(w):
        return False
    try:
        iface = w.iface_value
        if iface.CurrentIsReadOnly:
            return False
        new = (str(w.get_value() or "") + text) if append else text
        iface.SetValue(new)
        return True
    except Exception:
        log.debug("ValuePattern failed", exc_info=True)
        return False


def select_option(x: int, y: int, text: str = "", index: int | None = None) -> bool:
    """Native ComboBox/List: expand, select the item whose name EQUALS ``text`` (or the ``index``-th), collapse."""
    w = _wrapper(x, y)
    if w is None:
        return False
    try:
        try:
            w.expand()
        except Exception:
            pass
        items = w.descendants(control_type="ListItem")
        if not items:
            try:
                from pywinauto import Desktop
                items = Desktop(backend="uia").window(handle=winenv.foreground_window()["hwnd"]).descendants(control_type="ListItem")
            except Exception:
                items = []
        if index is not None:
            pick = items[index] if 0 <= index < len(items) else None
        else:
            exact = [i for i in items if (i.window_text() or "").strip() == text.strip()]
            if len(exact) > 1:
                raise RuntimeError(f"{len(exact)} options are named {text!r}")
            pick = exact[0] if exact else None
        if pick is None:
            return False
        try:
            pick.select()
        except Exception:
            pick.invoke()
        try:
            w.collapse()
        except Exception:
            pass
        return True
    except RuntimeError:
        raise
    except Exception:
        log.debug("select_option failed", exc_info=True)
        return False


def list_options(x: int, y: int) -> list[str]:
    w = _wrapper(x, y)
    if w is None:
        return []
    try:
        try:
            w.expand()
        except Exception:
            pass
        names = [(i.window_text() or "").strip() for i in w.descendants(control_type="ListItem")]
        try:
            w.collapse()
        except Exception:
            pass
        return names
    except Exception:
        return []


def set_toggle(x: int, y: int, want: str) -> bool:
    """Drive a checkbox to 'on' / 'off' with the Toggle pattern (state-based, never a blind click)."""
    w = _wrapper(x, y)
    if w is None:
        return False
    try:
        for _ in range(3):
            cur = {0: "off", 1: "on", 2: "indeterminate"}.get(int(w.get_toggle_state()), "")
            if cur == want:
                return True
            w.toggle()
            time.sleep(0.05)
        return {0: "off", 1: "on"}.get(int(w.get_toggle_state())) == want
    except Exception:
        return False


def select_item(x: int, y: int) -> bool:
    """SelectionItem.Select (radio button, list item, tab)."""
    w = _wrapper(x, y)
    if w is None:
        return False
    try:
        w.select()
        return True
    except Exception:
        return False


def submit_file_dialog(hwnd: int, paths: list[str]) -> bool:
    """Native Open/Save dialog: type the full path(s) into the 'File name' edit (automation id 1148) with ValuePattern and
    press its default button (id 1).  Works on dialog UI elements - never types into whatever window has focus."""
    if not winenv.IS_WINDOWS or not hwnd:
        return False
    try:
        from pywinauto import Desktop

        dlg = Desktop(backend="uia").window(handle=int(hwnd))
        edit = dlg.child_window(auto_id="1148", control_type="Edit")
        text = paths[0] if len(paths) == 1 else " ".join(f'"{p}"' for p in paths)
        edit.iface_value.SetValue(text)
        dlg.child_window(auto_id="1", control_type="Button").invoke()
        return True
    except Exception:
        log.debug("file dialog submit failed", exc_info=True)
        return False
