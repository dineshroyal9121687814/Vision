"""
Read what a spreadsheet cell really holds, straight from Excel (COM) - no pixels, no OCR.

UI Automation exposes an Excel cell's *name* as its address ("G8"), which is a label, not the value; and a screenshot of an
80x24 px cell is the worst possible OCR input.  Excel's own object model answers exactly, instantly.

Returns None whenever the answer is not available (not Windows, pywin32 missing, Excel closed, or the cell is being
edited - Excel rejects COM calls while a cell is in edit mode), so callers fall through to the next source.
"""
from __future__ import annotations

import re
import sys

last_error = ""            # why the last COM call failed (shown in validation details: "Excel COM unavailable: ...")

ADDRESS = re.compile(r"^\$?[A-Za-z]{1,3}\$?\d{1,7}$")


def looks_like_address(text) -> bool:
    return bool(ADDRESS.match(str(text or "").strip()))


def _app():
    import pythoncom
    import win32com.client

    pythoncom.CoInitialize()
    return win32com.client.GetActiveObject("Excel.Application")


def active_cell() -> str | None:
    """Address ("G8") of the cell that is active right now - i.e. where typing will land. None if unknown / editing."""
    if sys.platform != "win32":
        return None
    global last_error
    try:
        return str(_app().ActiveCell.Address).replace("$", "")
    except Exception as exc:
        last_error = f"{type(exc).__name__}: {exc}"[:160]
        return None


def read_cell(address: str, workbook_hint: str = "") -> str | None:
    if sys.platform != "win32" or not looks_like_address(address):
        return None
    try:
        app = _app()
        if not workbook_hint:
            sheet = app.ActiveSheet
        else:
            sheet = None
            for wb in app.Workbooks:
                if str(wb.Name).casefold() in workbook_hint.casefold():
                    sheet = wb.ActiveSheet
                    break
            sheet = sheet or app.ActiveSheet
        cell = sheet.Range(address.replace("$", ""))
        text = cell.Text            # what is drawn (formatted), like the screen shows
        return None if text is None else str(text)
    except Exception:
        return None


def _inside(rect, outer, tol: int = 6) -> bool:
    return (rect[0] >= outer[0] - tol and rect[1] >= outer[1] - tol
            and rect[2] <= outer[2] + tol and rect[3] <= outer[3] + tol)


def fit_to_window(rect, window_rect, scale: float):
    """Excel answers in its own DPI context. When it is not the same as ours (125 % / 150 % scaling, Excel DPI-unaware or
    system-aware) the answer is too small or too large by exactly the scaling factor. Check the rectangle against the real
    window rectangle; if it falls outside, try the factor, then its inverse. None = cannot be trusted: the caller then
    uses another locator rather than clicking somewhere wrong."""
    if not window_rect or len(window_rect) != 4:
        return list(rect)                                   # nothing to check against: trust the answer
    if _inside(rect, window_rect):
        return list(rect)
    if abs(scale - 1.0) > 0.01:
        for k in (scale, 1.0 / scale):
            cand = [int(round(v * k)) for v in rect]
            if _inside(cand, window_rect):
                return cand
    return None


def _scroll_minimally(win, cell) -> None:
    """Bring an off-screen cell into view with the SMALLEST scroll: only the axis that is needed, and only as far as the
    cell just becomes visible (never 'put the cell at the top-left', which throws the whole sheet away)."""
    try:
        vr = win.VisibleRange
        top, bottom = int(vr.Row), int(vr.Row) + int(vr.Rows.Count) - 1
        left, right = int(vr.Column), int(vr.Column) + int(vr.Columns.Count) - 1
        r, c = int(cell.Row), int(cell.Column)
        if r < top:
            win.ScrollRow = r
        elif r > bottom:
            win.ScrollRow = int(win.ScrollRow) + (r - bottom)
        if c < left:
            win.ScrollColumn = c
        elif c > right:
            win.ScrollColumn = int(win.ScrollColumn) + (c - right)
    except Exception:
        win.ScrollRow, win.ScrollColumn = int(cell.Row), int(cell.Column)


def cell_screen_rect(address: str, workbook_hint: str = "") -> list[int] | None:
    """Where a cell (or the merged area it belongs to) is on the screen right now: [left, top, right, bottom] in pixels.

    Exact and independent of UI Automation (slow in Excel) and of pictures (empty cells all look alike). Scrolls only as little as
    needed, and only when the cell is off-screen. None when it cannot be answered (not Windows, Excel closed / editing a cell)."""
    if sys.platform != "win32" or not looks_like_address(address):
        return None
    try:
        app = _app()
        win = app.ActiveWindow
        sheet = app.ActiveSheet
        if workbook_hint:
            for wb in app.Workbooks:
                if str(wb.Name).casefold() in workbook_hint.casefold():
                    sheet = wb.ActiveSheet
                    break
        cell = sheet.Range(address.replace("$", "")).MergeArea
        try:
            visible = app.Intersect(cell.Cells(1, 1), win.VisibleRange) is not None
        except Exception:
            visible = True
        if not visible:
            _scroll_minimally(win, cell)
        left, top = float(cell.Left), float(cell.Top)
        width, height = float(cell.Width), float(cell.Height)
        x0, y0 = win.PointsToScreenPixelsX(left), win.PointsToScreenPixelsY(top)
        x1, y1 = win.PointsToScreenPixelsX(left + width), win.PointsToScreenPixelsY(top + height)
        if x1 - x0 < 2 or y1 - y0 < 2:
            return None
        rect = [int(x0), int(y0), int(x1), int(y1)]
        try:
            from core.system import winenv
            hwnd = int(win.Hwnd) if hasattr(win, "Hwnd") else int(app.Hwnd)
            return fit_to_window(rect, winenv.window_rect(hwnd), winenv.window_dpi_scale(hwnd))
        except Exception:
            return rect
    except Exception:
        return None
