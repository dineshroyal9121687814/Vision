"""Snapshot of a live Windows window into a ``core.xpath.tree.UiaNode`` tree (pywinauto / UI Automation).

Windows only; on any other platform, or when pywinauto is missing, every function returns ``None``.
Caps on depth and node count keep a runaway tree (huge grids, web views) from stalling a run.
Password controls are never asked for a value.
"""
from __future__ import annotations

import logging

from core.system import winenv
from core.xpath.tree import UiaNode

log = logging.getLogger("visionauto.uiatree")

MAX_DEPTH = 28
MAX_NODES = 6000
_VALUE_TYPES = {"edit", "combobox", "document", "spinner", "slider"}


def _read(info, name, default=""):
    try:
        v = getattr(info, name)
        return v() if callable(v) else v
    except Exception:
        return default


def _to_node(info, counter: list, depth: int, process: str) -> UiaNode:
    counter[0] += 1
    r = _read(info, "rectangle", None)
    rect = (int(r.left), int(r.top), int(r.right), int(r.bottom)) if r is not None else (0, 0, 0, 0)
    ctype = str(_read(info, "control_type") or "Custom")
    password = bool(_read(info, "is_password", False)) or "password" in str(_read(info, "class_name")).casefold()
    node = UiaNode(
        control_type=ctype, name=str(_read(info, "name") or ""),
        automation_id=str(_read(info, "automation_id") or ""),
        class_name=str(_read(info, "class_name") or ""), rect=rect,
        enabled=bool(_read(info, "enabled", True)), visible=bool(_read(info, "visible", True)),
        password=password, process=process)
    if not password and ctype.casefold() in _VALUE_TYPES:
        try:
            wrapper = info  # element_info has no value; fall back to the rich wrapper when we can
            from pywinauto.controls.uiawrapper import UIAWrapper

            node.value = str(UIAWrapper(wrapper).get_value() or "")
        except Exception:
            pass
    if depth < MAX_DEPTH:
        try:
            kids = info.children()
        except Exception:
            kids = []
        for kid in kids:
            if counter[0] >= MAX_NODES:
                break
            node.add(_to_node(kid, counter, depth + 1, process))
    return node


def snapshot_window(title_part: str = "", hwnd: int = 0) -> UiaNode | None:
    """Tree of the window matching ``hwnd`` or (case-insensitive substring of) ``title_part``.
    With neither, the foreground window is used. Returns a synthetic ``Desktop`` root."""
    if not winenv.IS_WINDOWS:
        return None
    try:
        from pywinauto import Desktop

        d = Desktop(backend="uia")
        if not hwnd:
            if title_part:
                wins = winenv.find_windows(title_part)
                hwnd = wins[0] if wins else 0
            else:
                hwnd = winenv.foreground_window().get("hwnd", 0)
        if not hwnd:
            return None
        win = d.window(handle=hwnd)
        process = winenv.window_info(hwnd).get("process", "")
        root = UiaNode(control_type="Desktop", name="Desktop")
        root.add(_to_node(win.element_info, [0], 0, process))
        return root
    except Exception:
        log.debug("snapshot_window failed", exc_info=True)
        return None
