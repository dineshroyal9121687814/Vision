"""Clipboard text (Windows, ctypes - no extra dependency). Tests swap ``_backend`` for a fake."""
from __future__ import annotations

import time

from core.system import winenv

MAX_CHARS = 1_000_000
_backend = None          # object with get() / set(text); None = the real clipboard


def _open(u):
    for _ in range(20):
        if u.OpenClipboard(None):
            return
        time.sleep(0.025)
    raise RuntimeError("The clipboard is in use by another program.")


def _win_get() -> str:
    import ctypes
    from ctypes import wintypes

    u, k = ctypes.windll.user32, ctypes.windll.kernel32
    u.GetClipboardData.restype = ctypes.c_void_p
    k.GlobalLock.argtypes, k.GlobalLock.restype = [ctypes.c_void_p], ctypes.c_void_p
    k.GlobalUnlock.argtypes = [ctypes.c_void_p]
    _open(u)
    try:
        handle = u.GetClipboardData(13)                       # CF_UNICODETEXT
        if not handle:
            return ""
        ptr = k.GlobalLock(handle)
        try:
            return ctypes.wstring_at(ptr)[:MAX_CHARS] if ptr else ""
        finally:
            k.GlobalUnlock(handle)
    finally:
        u.CloseClipboard()


def _win_set(text: str) -> None:
    import ctypes

    u, k = ctypes.windll.user32, ctypes.windll.kernel32
    data = (text + "\0").encode("utf-16-le")
    k.GlobalAlloc.argtypes, k.GlobalAlloc.restype = [ctypes.c_uint, ctypes.c_size_t], ctypes.c_void_p
    k.GlobalLock.argtypes, k.GlobalLock.restype = [ctypes.c_void_p], ctypes.c_void_p
    k.GlobalUnlock.argtypes = [ctypes.c_void_p]
    u.SetClipboardData.argtypes = [ctypes.c_uint, ctypes.c_void_p]
    handle = k.GlobalAlloc(0x0002, len(data))                 # GMEM_MOVEABLE
    ptr = k.GlobalLock(handle)
    ctypes.memmove(ptr, data, len(data))
    k.GlobalUnlock(handle)
    _open(u)
    try:
        u.EmptyClipboard()
        u.SetClipboardData(13, handle)
    finally:
        u.CloseClipboard()


def get_text() -> str:
    if _backend is not None:
        return str(_backend.get())
    if not winenv.IS_WINDOWS:
        raise NotImplementedError("Clipboard access is only available on Windows.")
    return _win_get()


def set_text(text: str) -> None:
    text = str(text)
    if len(text) > MAX_CHARS:
        raise ValueError(f"Clipboard text is longer than {MAX_CHARS} characters.")
    if _backend is not None:
        _backend.set(text)
        return
    if not winenv.IS_WINDOWS:
        raise NotImplementedError("Clipboard access is only available on Windows.")
    _win_set(text)
