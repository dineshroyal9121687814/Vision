"""Opening Excel (and a workbook) reliably - and only reporting success when Excel is actually ready.

Root causes this module removes (see docs/EXCEL_AND_ACCURACY_FIX_REPORT.md):
  1. ``subprocess.Popen(value.split())`` broke any executable path containing a space
     (``C:\\Program Files\\Microsoft Office\\root\\Office16\\EXCEL.EXE`` -> ``C:\\Program``).
  2. ``Popen(["excel.exe"])`` uses CreateProcess, which does NOT read the *App Paths* registry key that Office installs
     itself under - so a bare ``excel.exe`` only worked when Office happened to be on PATH.
  3. "Success" meant "a window whose title contains 'Excel' exists" - which is also true for the Start screen, the splash
     screen, an unrelated "Excel ... - Chrome" tab, or another instance, long before a workbook can be edited.
  4. An already running Excel was never reused, and the chosen workbook window was matched by title only.

Strategy: attach to a running instance through COM (``GetActiveObject``) -> otherwise start Excel -> wait until COM answers
AND ``Application.Ready`` -> open / find the workbook by FULL PATH -> take the workbook window's own HWND from Excel
(``Window.Hwnd``) -> activate it and prove it is in front.  Everything OS-specific is injected, so this logic is unit-tested
off Windows; the Windows calls themselves are NOT verified here (see KNOWN_LIMITATIONS.md).
"""
from __future__ import annotations

import glob
import logging
import ntpath
import os
import subprocess
import time

from core.system import winenv

log = logging.getLogger("visionauto.excel")

EXCEL_EXTS = (".xlsx", ".xlsm", ".xlsb", ".xls", ".xltx", ".xltm", ".csv")


def is_excel_request(name: str = "", exe: str = "", path: str = "") -> bool:
    base = ntpath.basename((exe or "").strip('"').split('"')[0].strip().split(" /")[0]).casefold()
    return name.strip().casefold() in ("excel", "microsoft excel") or base == "excel.exe" or \
        (bool(path) and os.path.splitext(path)[1].casefold() in EXCEL_EXTS)


# ---------------------------------------------------------------- executable discovery
def _registry_app_path() -> str:
    if not winenv.IS_WINDOWS:
        return ""
    try:
        import winreg

        for hive in (winreg.HKEY_LOCAL_MACHINE, winreg.HKEY_CURRENT_USER):
            for view in (winreg.KEY_WOW64_64KEY, winreg.KEY_WOW64_32KEY):
                try:
                    with winreg.OpenKey(hive, r"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\excel.exe", 0,
                                        winreg.KEY_READ | view) as k:
                        return str(winreg.QueryValueEx(k, "")[0]).strip('"')
                except OSError:
                    continue
    except Exception:
        log.debug("App Paths lookup failed", exc_info=True)
    return ""


def find_excel_exe(registry=_registry_app_path, exists=os.path.isfile, globber=glob.glob, env=None) -> str:
    """Full path of EXCEL.EXE or '' - App Paths registry first (what Windows itself uses), then the usual folders."""
    env = os.environ if env is None else env
    p = registry()
    if p and exists(p):
        return p
    roots = [env.get("ProgramFiles", r"C:\Program Files"), env.get("ProgramFiles(x86)", r"C:\Program Files (x86)")]
    for root in roots:
        for pattern in (r"Microsoft Office\root\Office*\EXCEL.EXE", r"Microsoft Office\Office*\EXCEL.EXE"):
            hits = sorted(globber(os.path.join(root, pattern)), reverse=True)   # newest Office folder first
            for h in hits:
                if exists(h):
                    return h
    return ""


# ---------------------------------------------------------------- COM helpers
def _attach():
    if not winenv.IS_WINDOWS:
        return None
    try:
        import pythoncom
        import win32com.client

        pythoncom.CoInitialize()
        return win32com.client.GetActiveObject("Excel.Application")
    except Exception:
        return None


def _ready(app) -> bool:
    try:
        return bool(app.Ready)
    except Exception:
        return False                      # COM busy / modal dialog / still starting


def _workbooks(app) -> list:
    try:
        return [app.Workbooks.Item(i) for i in range(1, int(app.Workbooks.Count) + 1)]
    except Exception:
        return []


def _same_path(a: str, b: str) -> bool:
    return os.path.normcase(os.path.abspath(str(a))) == os.path.normcase(os.path.abspath(str(b)))


def find_workbook(app, path: str):
    for wb in _workbooks(app):
        try:
            if _same_path(wb.FullName, path):
                return wb
        except Exception:
            continue
    return None


def _workbook_hwnd(app, wb) -> int:
    for getter in (lambda: wb.Windows(1).Hwnd, lambda: app.Hwnd):
        try:
            h = int(getter())
            if h:
                return h
        except Exception:
            continue
    return 0


# ---------------------------------------------------------------- the launch
def open_excel(path: str = "", *, timeout_s: float = 30.0, mode: str = "attach_or_launch", enable_editing: bool = False,
               should_stop=lambda: False, attach=_attach, find_exe=find_excel_exe, popen=subprocess.Popen,
               startfile=None, sleep=time.sleep, clock=time.monotonic, focus=None, foreground=None, is_window=None) -> dict:
    """Open Excel (and ``path``) and return ``{'method','hwnd','workbook','path','launched'}`` once it is READY.
    Raises ValueError with every step tried when it is not ready within ``timeout_s``."""
    focus = focus or winenv.focus_hwnd
    foreground = foreground or (lambda: int(winenv.foreground_window().get("hwnd") or 0))
    is_window = is_window or winenv.is_window
    startfile = startfile or getattr(os, "startfile", None)
    tried: list[str] = []
    if path:
        path = os.path.abspath(path)
        if not os.path.isfile(path):
            raise ValueError(f"Workbook not found: {path}")
        if os.path.splitext(path)[1].casefold() not in EXCEL_EXTS:
            raise ValueError(f"'{os.path.basename(path)}' is not an Excel file type ({', '.join(EXCEL_EXTS)}).")
    end = clock() + max(1.0, timeout_s)
    app, launched = (attach() if mode != "launch" else None), False
    if app is not None:
        tried.append("attach:running instance")
    else:
        exe = find_exe()
        try:
            if exe:
                tried.append(f"exe:{exe}")
                popen([exe] + ([path] if path else []))              # list form: spaces in the path are safe
            elif startfile is not None:
                tried.append("shell:excel.exe" + (f" {os.path.basename(path)}" if path else ""))
                startfile(path or "excel.exe")                       # ShellExecute understands App Paths + file association
            else:
                raise ValueError("Excel is not installed (no EXCEL.EXE found in App Paths or Program Files).")
        except (OSError, FileNotFoundError) as exc:
            raise ValueError(f"Could not start Excel ({exc}). Tried: {', '.join(tried)}") from exc
        launched = True
        while app is None:
            if should_stop():
                raise ValueError("Cancelled while waiting for Excel.")
            if clock() >= end:
                raise ValueError(f"Excel did not become available within {timeout_s:g}s (tried: {', '.join(tried)}).")
            sleep(0.3)
            app = attach()
    while not _ready(app):                                            # COM answers before Excel can take input
        if should_stop():
            raise ValueError("Cancelled while waiting for Excel.")
        if clock() >= end:
            raise ValueError(f"Excel started but never became ready (a dialog may be open) within {timeout_s:g}s.")
        sleep(0.3)
    try:
        app.Visible = True
    except Exception:
        pass
    wb = None
    if path:
        wb = find_workbook(app, path)
        while wb is None and launched and clock() < end:              # Excel was started WITH the file: let it finish loading
            if should_stop():
                raise ValueError("Cancelled while waiting for the workbook.")
            sleep(0.3)
            wb = find_workbook(app, path)
            if wb is None and _protected(app, path):
                break
        if wb is None:
            pv = _protected(app, path)
            if pv is not None and not enable_editing:
                raise ValueError(f"'{os.path.basename(path)}' opened in Protected View. Enable editing in Excel or set "
                                 "enable_editing=true on the step; VisionAuto will not bypass it silently.")
            if pv is not None:
                pv.Edit()                                              # explicit user opt-in
                sleep(0.5)
            else:
                tried.append(f"open:{os.path.basename(path)}")
                try:
                    app.Workbooks.Open(path)                           # attach case: the file is not open yet
                except Exception as exc:
                    raise ValueError(f"Excel could not open '{path}': {exc}") from exc
            wb = find_workbook(app, path)
            if wb is None:
                raise ValueError(f"'{os.path.basename(path)}' did not open in Excel (tried: {', '.join(tried)}).")
        try:
            wb.Activate()
        except Exception:
            pass
    else:
        books = _workbooks(app)
        wb = books[0] if len(books) == 1 else None                    # several workbooks and no path: do not guess
    hwnd = _workbook_hwnd(app, wb) if wb is not None else _workbook_hwnd(app, None)
    if not hwnd or not is_window(hwnd):
        raise ValueError("Excel is running but its window could not be identified.")
    for _ in range(10):                                               # bring it to the front and PROVE it
        focus(hwnd)
        if foreground() == hwnd:
            break
        sleep(0.15)
    else:
        raise ValueError("Excel is open but could not be brought to the front (another window is taking focus).")
    name = ""
    try:
        name = str(wb.Name) if wb is not None else ""
    except Exception:
        pass
    return {"method": "attach" if not launched else "launch", "hwnd": hwnd, "workbook": name, "path": path,
            "launched": launched, "tried": tried}


def _protected(app, path: str):
    try:
        for i in range(1, int(app.ProtectedViewWindows.Count) + 1):
            pv = app.ProtectedViewWindows.Item(i)
            if _same_path(pv.Workbook.FullName, path):
                return pv
    except Exception:
        return None
    return None


# ---------------------------------------------------------------- save / close (verified)
def save_workbook(path: str = "", save_as: str = "", *, attach=_attach) -> dict:
    app = attach()
    if app is None:
        raise ValueError("Excel is not running.")
    wb = find_workbook(app, path) if path else app.ActiveWorkbook
    if wb is None:
        raise ValueError("The workbook to save is not open in Excel.")
    if save_as:
        target = os.path.abspath(save_as)
        wb.SaveAs(target)
        saved = target
    else:
        wb.Save()
        saved = str(wb.FullName)
    if not bool(wb.Saved):
        raise ValueError("Excel reports unsaved changes after saving.")
    return {"saved": saved, "verified": True}


def close_workbook(path: str = "", save: bool = False, *, attach=_attach) -> dict:
    app = attach()
    if app is None:
        raise ValueError("Excel is not running.")
    wb = find_workbook(app, path) if path else app.ActiveWorkbook
    if wb is None:
        raise ValueError("The workbook to close is not open in Excel.")
    name = str(wb.FullName)
    wb.Close(SaveChanges=bool(save))                                   # explicit: never leave a 'Save changes?' dialog behind
    if find_workbook(app, name) is not None:
        raise ValueError("The workbook is still open after Close.")
    return {"closed": name, "saved": bool(save), "verified": True}
