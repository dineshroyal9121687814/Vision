"""
Opening an application the way a person would - but reliably.

Why this exists: a recorded "Start -> type 'cal' -> click the first result" sequence replays as a *blind click at
a pixel inside the search pane*. Windows Search renders its results a moment after the keystrokes, and the top
result differs between machines/users, so the click lands on nothing or on the wrong app. ``open_app`` replaces that
whole sequence with one semantic step:

    {"type": "open_app", "params": {"name": "Calculator", "window_title": "Calculator", "timeout_s": 15}}

Launch strategies, tried in order until the expected window appears (never a fixed sleep):

 1. ``exe``      explicit executable / protocol given in params (``notepad.exe``, ``ms-settings:``)
 2. ``known``    built-in table of common Windows apps (Calculator, Notepad, Paint ...)
 3. ``startapp`` the real Start-menu catalogue (``Get-StartApps``) fuzzy-matched on the name -> launched through
                 ``explorer.exe shell:AppsFolder\\<AppID>`` (this is how Start itself launches UWP/Store apps)
 4. ``keyboard`` last resort: Win key -> type the name -> wait -> **Enter** (opens the best match; no pixel clicks)

Everything that talks to the OS is injectable, so the planning / matching logic is unit-tested on any platform.
"""
from __future__ import annotations

import difflib
import ntpath
import json
import logging
import os
import subprocess
import time
from dataclasses import dataclass

from core.system import winenv

log = logging.getLogger("visionauto.launcher")

# name (lower-case, as users type it) -> how to start it and what its window is called
KNOWN_APPS: dict[str, dict] = {
    "calculator": {"exe": "calc.exe", "aumid": "Microsoft.WindowsCalculator_8wekyb3d8bbwe!App", "title": "Calculator"},
    "notepad": {"exe": "notepad.exe", "title": "Notepad"},
    "paint": {"exe": "mspaint.exe", "title": "Paint"},
    "snipping tool": {"exe": "snippingtool.exe", "title": "Snipping Tool"},
    "task manager": {"exe": "taskmgr.exe", "title": "Task Manager"},
    "character map": {"exe": "charmap.exe", "title": "Character Map"},
    "settings": {"exe": "ms-settings:", "title": "Settings"},
    "file explorer": {"exe": "explorer.exe", "title": "File Explorer"},
    "excel": {"exe": "excel.exe", "title": "Excel"},
}
_ALIAS = {"microsoft excel": "excel", "calc": "calculator", "mspaint": "paint", "explorer": "file explorer",
          "snippingtool": "snipping tool", "taskmgr": "task manager", "charmap": "character map"}

# Windows hosts of the Start / Search flyout - a step recorded inside one of these is "using Start".
SEARCH_PROCESSES = frozenset({"searchhost.exe", "searchapp.exe", "startmenuexperiencehost.exe",
                              "shellexperiencehost.exe", "searchui.exe"})

# Programs a test must never start through ``open_app`` (same policy as ``launch_app``).
FORBIDDEN_EXES = frozenset({"cmd", "cmd.exe", "powershell", "powershell.exe", "pwsh", "pwsh.exe", "bash", "sh",
                            "wscript", "wscript.exe", "cscript", "cscript.exe", "mshta", "mshta.exe"})


@dataclass
class Method:
    kind: str          # exe | aumid | keyboard
    value: str
    label: str         # shown in the report: "known:calc.exe", "startapp:Calculator" ...


def canonical(name: str) -> str:
    n = " ".join(str(name or "").split()).casefold()
    return _ALIAS.get(n, n)


def match_start_app(name: str, apps: list[dict], cutoff: float = 0.72) -> list[dict]:
    """Rank Start-menu entries (``[{'Name':..., 'AppID':...}]``) against what the user called the app.
    Returns candidates best-first; an empty list when nothing is close enough. Exact > prefix > word > fuzzy."""
    want = canonical(name)
    if not want:
        return []
    scored: list[tuple[float, dict]] = []
    for a in apps:
        label = str(a.get("Name") or a.get("name") or "")
        have = label.casefold()
        if not have or not (a.get("AppID") or a.get("appid")):
            continue
        if have == want:
            s = 1.0
        elif have.startswith(want):
            s = 0.95 - min(0.2, (len(have) - len(want)) / 100)
        elif want in have.split() or want in have:
            s = 0.85 - min(0.2, (len(have) - len(want)) / 100)
        else:
            s = difflib.SequenceMatcher(None, want, have).ratio() * 0.9
        if s >= cutoff:
            scored.append((s, {"name": label, "appid": a.get("AppID") or a.get("appid"), "score": round(s, 3)}))
    scored.sort(key=lambda t: -t[0])
    return [d for _, d in scored]


def split_command(value: str) -> list[str]:
    """Command line -> argv WITHOUT breaking a path that contains spaces.
    ``C:\\Program Files\\X\\app.exe`` stays one token; ``"C:\\Program Files\\X\\app.exe" /safe`` and ``app.exe /safe`` split properly.
    (The old ``value.split()`` turned the first form into ``C:\\Program`` + ``Files\\X\\app.exe`` -> FileNotFoundError.)"""
    v = str(value or "").strip()
    if not v:
        return []
    if os.path.exists(v) or (os.path.splitext(v)[1].lower() in (".exe", ".bat", ".lnk") and " /" not in v and " -" not in v):
        return [v.strip('"')]
    if v.startswith('"') and v.count('"') >= 2:
        end = v.index('"', 1)
        return [v[1:end]] + v[end + 1:].split()
    import re
    m = re.match(r"^(.+?\.(?:exe|bat|lnk))(\s+.*)?$", v, re.IGNORECASE)      # path with spaces, then switches
    if m:
        return [m.group(1)] + (m.group(2) or "").split()
    return v.split()


def plan(name: str = "", exe: str = "", aumid: str = "", start_apps: list[dict] | None = None,
         allow_keyboard: bool = True, chooser=None) -> list[Method]:
    """Ordered launch strategies for one application (pure function)."""
    out: list[Method] = []
    if exe:
        argv = split_command(exe)
        base = ntpath.basename(argv[0]).casefold() if argv else ""
        if base in FORBIDDEN_EXES or any(c in exe for c in ";&|`$"):
            raise ValueError(f"open_app will not start '{exe}': shells and command chains are restricted.")
        out.append(Method("exe", exe, f"exe:{exe}"))
    if aumid:
        out.append(Method("aumid", aumid, f"aumid:{aumid}"))
    known = KNOWN_APPS.get(canonical(name))
    if known:
        if known.get("exe"):
            out.append(Method("exe", known["exe"], f"known:{known['exe']}"))
        if known.get("aumid"):
            out.append(Method("aumid", known["aumid"], f"known:{known['aumid']}"))
    if start_apps and name:
        cands = match_start_app(name, start_apps)
        if len(cands) > 1 and chooser and cands[0]["score"] - cands[1]["score"] < 0.1:
            picked = chooser(name, [c["name"] for c in cands[:6]])      # optional local-AI tie-break
            cands.sort(key=lambda c: 0 if c["name"] == picked else 1)
        for c in cands[:2]:
            out.append(Method("aumid", c["appid"], f"startapp:{c['name']}"))
    if allow_keyboard and name:
        out.append(Method("keyboard", name, f"keyboard:Start search '{name}'"))
    seen, uniq = set(), []
    for m in out:
        if (m.kind, m.value) not in seen:
            seen.add((m.kind, m.value))
            uniq.append(m)
    return uniq


def window_title_for(name: str, explicit: str = "") -> str:
    if explicit:
        return explicit
    known = KNOWN_APPS.get(canonical(name))
    return (known or {}).get("title") or name


# ------------------------------------------------------------------ OS side
def start_apps() -> list[dict]:
    """The Start-menu app catalogue. ``[]`` off Windows or if PowerShell is unavailable."""
    if not winenv.IS_WINDOWS:
        return []
    try:
        cp = subprocess.run(
            ["powershell", "-NoProfile", "-NonInteractive", "-Command", "Get-StartApps | ConvertTo-Json -Compress"],
            capture_output=True, text=True, timeout=20, creationflags=0x08000000)   # CREATE_NO_WINDOW
        data = json.loads(cp.stdout or "[]")
        return [data] if isinstance(data, dict) else list(data)
    except Exception:
        log.info("Get-StartApps failed", exc_info=True)
        return []


def start_method(m: Method, backend=None) -> None:
    """Fire one launch strategy (does not wait for the window)."""
    if m.kind == "exe":
        if m.value.endswith(":") and " " not in m.value:          # protocol such as ms-settings:
            os.startfile(m.value)                                  # type: ignore[attr-defined]  (Windows only)
        else:
            argv = split_command(m.value)
            try:
                subprocess.Popen(argv)
            except FileNotFoundError:
                if len(argv) == 1 and os.path.dirname(argv[0]) == "" and hasattr(os, "startfile"):
                    os.startfile(argv[0])                          # type: ignore[attr-defined]  ShellExecute honours App Paths
                else:
                    raise
    elif m.kind == "aumid":
        subprocess.Popen(["explorer.exe", "shell:AppsFolder\\" + m.value])
    elif m.kind == "keyboard":
        if backend is None:
            raise ValueError("keyboard launch needs an input backend")
        backend.press("win")
        time.sleep(0.9)                    # let the Start flyout take focus
        backend.type_text(m.value, 20)
        time.sleep(1.4)                    # results are rendered asynchronously - this is the wait a blind click lacks
        backend.press("enter")             # Enter = best match; no dependence on where a result is drawn
    else:
        raise ValueError(f"unknown launch method {m.kind}")


def wait_for_window(title: str, timeout: float, process: str = "", should_stop=None, finder=None,
                    info=None, poll: float = 0.2) -> int:
    """Poll until a visible window whose title contains ``title`` exists. Returns its handle, or 0."""
    finder = finder or winenv.find_windows
    info = info or winenv.window_info
    end = time.monotonic() + max(0.0, timeout)
    while True:
        if should_stop and should_stop():
            return 0
        for h in finder(title):
            if not process or str(info(h).get("process", "")).casefold() == process.casefold():
                return h
        if time.monotonic() >= end:
            return 0
        time.sleep(poll)


def open_application(name: str = "", *, exe: str = "", aumid: str = "", window_title: str = "", process: str = "",
                     timeout_s: float = 15.0, mode: str = "attach_or_launch", backend=None, should_stop=None,
                     apps_provider=None, chooser=None) -> dict:
    """Open an application and wait for its window. Returns ``{'method': ..., 'hwnd': ..., 'tried': [...]}``.
    Raises ValueError (with every strategy tried) when the window never appears."""
    title = window_title_for(name, window_title) or name
    if not title and not exe and not aumid:
        raise ValueError("open_app needs a 'name' (or 'exe' / 'aumid').")
    if mode != "launch":
        h = wait_for_window(title, 0.0, process)
        if h:
            winenv.activate_window(title)
            return {"method": "attach", "hwnd": h, "tried": []}
    # the Start catalogue is only read when the cheap strategies might not be enough
    methods = plan(name, exe, aumid, None, allow_keyboard=False)
    cheap = bool(methods)
    tried: list[str] = []
    budget_end = time.monotonic() + max(1.0, timeout_s)

    def attempt(ms: list[Method]) -> dict | None:
        for i, m in enumerate(ms):
            if should_stop and should_stop():
                return None
            left = budget_end - time.monotonic()
            if left <= 0:
                return None
            tried.append(m.label)
            try:
                start_method(m, backend)
            except Exception as e:                              # launch itself failed -> try the next strategy
                log.info("launch %s failed: %s", m.label, e)
                tried[-1] += f" (error: {type(e).__name__})"
                continue
            slice_s = left if i == len(ms) - 1 else min(left, max(3.0, timeout_s / 3))
            h = wait_for_window(title, slice_s, process, should_stop)
            if h:
                winenv.activate_window(title)
                return {"method": m.label, "hwnd": h, "tried": list(tried)}
        return None

    hit = attempt(methods) if cheap else None
    if hit:
        return hit
    apps = (apps_provider or start_apps)() if name else []
    rest = [m for m in plan(name, exe, aumid, apps, allow_keyboard=True, chooser=chooser) if m.label not in tried
            and not any(m.label == t or t.startswith(m.label) for t in tried)]
    hit = attempt(rest)
    if hit:
        return hit
    raise ValueError(f"Could not open '{name or exe}': no window titled '{title}' appeared within {timeout_s:g}s "
                     f"(tried: {', '.join(tried) or 'nothing'}).")
