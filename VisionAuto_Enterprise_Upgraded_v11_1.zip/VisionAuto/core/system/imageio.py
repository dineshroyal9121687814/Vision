"""Unicode-path-safe image IO (cv2.imread/imwrite fail on non-ASCII Windows paths)."""
from __future__ import annotations

from pathlib import Path

import cv2
import numpy as np


def imread(path) -> np.ndarray | None:
    try:
        data = np.fromfile(str(path), dtype=np.uint8)
        if data.size == 0:
            return None
        return cv2.imdecode(data, cv2.IMREAD_COLOR)
    except OSError:
        return None


import os

def imwrite(path, img: np.ndarray, quality: int = 80) -> bool:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    ext = p.suffix.lower() or ".png"
    params = [cv2.IMWRITE_JPEG_QUALITY, quality] if ext in (".jpg", ".jpeg") else []
    ok, buf = cv2.imencode(ext, img, params)
    if not ok:
        return False
    tmp = p.with_suffix(p.suffix + ".tmp")
    try:
        buf.tofile(str(tmp))
        os.replace(tmp, p)
        return True
    except Exception:
        if tmp.exists():
            try:
                tmp.unlink()
            except OSError:
                pass
        return False
