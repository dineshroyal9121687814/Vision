"""Window geometry maths (pure functions - no OS calls, fully unit-tested).

Used to (a) put a window back to the size/position it had when the test was recorded, (b) clamp it onto the
visible screen, and (c) translate recorded coordinates / zones when a window could not be restored (fixed-size
dialog, different monitor, different DPI).  Rects are ``[left, top, right, bottom]`` in screen pixels.
"""
from __future__ import annotations

from copy import deepcopy

MIN_W, MIN_H = 120, 80


def valid(r) -> bool:
    return (isinstance(r, (list, tuple)) and len(r) == 4 and all(isinstance(v, (int, float)) and not isinstance(v, bool) for v in r)
            and r[2] > r[0] and r[3] > r[1])


def size(r) -> tuple[int, int]:
    return int(r[2] - r[0]), int(r[3] - r[1])


def differs(a, b, tol: int = 8) -> bool:
    """True when position OR size differ by more than ``tol`` pixels."""
    return any(abs(x - y) > tol for x, y in zip(a, b))


def size_differs(a, b, tol: int = 8) -> bool:
    (aw, ah), (bw, bh) = size(a), size(b)
    return abs(aw - bw) > tol or abs(ah - bh) > tol


def clamp_to_screen(rect, screen) -> list[int]:
    """Keep the window fully on screen: shrink it if it is larger than the screen, then slide it inside."""
    w, h = size(rect)
    sw, sh = size(screen)
    w, h = min(w, sw), min(h, sh)
    left = min(max(int(rect[0]), screen[0]), screen[2] - w)
    top = min(max(int(rect[1]), screen[1]), screen[3] - h)
    return [left, top, left + w, top + h]


def plan(recorded_rect, recorded_state, current_rect, current_state, screen, tol: int = 8) -> dict:
    """Decide what to do to make the current window match what was recorded.

    Returns ``{"action": "none"}`` or ``{"action": "state", "state": ...}`` or ``{"action": "rect", "rect": [...]}``.
    """
    if recorded_state == "maximized":
        return {"action": "none"} if current_state == "maximized" else {"action": "state", "state": "maximized"}
    if not valid(recorded_rect):
        return {"action": "none"}
    target = clamp_to_screen(recorded_rect, screen) if valid(screen) else [int(v) for v in recorded_rect]
    if current_state in ("maximized", "minimized") or not valid(current_rect) or differs(target, current_rect, tol):
        return {"action": "rect", "rect": target}
    return {"action": "none"}


def map_point(point, from_rect, to_rect) -> tuple[int, int]:
    """Where a point inside ``from_rect`` lands after the window became ``to_rect`` (same relative position)."""
    fw, fh = size(from_rect)
    tw, th = size(to_rect)
    fx, fy = (point[0] - from_rect[0]) / fw, (point[1] - from_rect[1]) / fh
    return int(round(to_rect[0] + fx * tw)), int(round(to_rect[1] + fy * th))


def map_rect(rect, from_rect, to_rect) -> list[int]:
    x0, y0 = map_point((rect[0], rect[1]), from_rect, to_rect)
    x1, y1 = map_point((rect[2], rect[3]), from_rect, to_rect)
    return [x0, y0, x1, y1]


def rebase_target(target: dict, from_rect, to_rect) -> dict:
    """Translate every recorded position in a target (point, element rect, OCR region, zone) from the window's
    recorded rect to its current rect. Pure move = exact; resize = proportional (a search hint, not a guarantee)."""
    if not (valid(from_rect) and valid(to_rect)) or list(from_rect) == list(to_rect):
        return target
    t = deepcopy(target)
    if "x" in t and "y" in t:
        t["x"], t["y"] = map_point((t["x"], t["y"]), from_rect, to_rect)
    if valid(t.get("rect")):
        t["rect"] = map_rect(t["rect"], from_rect, to_rect)
    reg = t.get("ocr_region")
    if isinstance(reg, (list, tuple)) and len(reg) == 4:
        x0, y0, x1, y1 = map_rect((reg[0], reg[1], reg[0] + reg[2], reg[1] + reg[3]), from_rect, to_rect)
        t["ocr_region"] = [x0, y0, max(1, x1 - x0), max(1, y1 - y0)]
    z = t.get("zone")
    if isinstance(z, dict) and valid(z.get("rect")):
        z["rect"] = map_rect(z["rect"], from_rect, to_rect)
    c = t.get("container")
    if isinstance(c, dict) and valid(c.get("rect")):
        c["rect"] = map_rect(c["rect"], from_rect, to_rect)
    return t
