"""User settings, persisted to workspace/settings.json and shared by GUI + CLI."""
from __future__ import annotations

import json
import logging
import math
import os
import tempfile
from urllib.parse import urlsplit

from core import paths

log = logging.getLogger("visionauto.settings")

# Two engine profiles.
#   classic (default) - the click path of the build that worked best in the field (VisionAuto v10): UI Automation -> picture
#                       -> ORB -> OCR -> AI -> self-heal; no extra checks, no refusals, no repeated clicks. Improvements that
#                       cannot change WHERE a click lands (data rows, step palette, custom steps, reports) are always on.
#   strict            - the full verification pipeline (ladder, before/after check, repeat-previous, AI vision, refusals).
STRICT_VALUES = {"ensure_focus": True, "ensure_state": True, "scroll_jump": True, "strict_targeting": True, "probe_neighbours": True, "record_ocr_label": True, "use_vision_ai": True,
                 "verify_effect": True, "retry_no_effect": True, "ocr_verify_typing": True, "repeat_previous_policy": "safe"}

DEFAULTS = {
    "engine_profile": "classic",      # classic | strict  (see above)
    "timeout_s": 10.0,            # max wait for an element / validation
    "use_native": True,           # UI Automation tier
    "use_ocr": True,              # OCR tier (needs easyocr)
    "use_ai": True,               # AI-similarity tier
    "input_backend": "auto",      # auto, pynput, or pyautogui
    "settle_wait": True,          # wait for the screen to stop changing after each action
    "auto_heal_update": True,     # write healed locators back to the test (backup kept)
    "min_recovery_confidence": 0.72,  # minimum normalized score for visual recovery tiers
    "continue_on_failure": False,
    "type_interval_ms": 15,
    "use_llm": False,             # optional local model via Ollama (summaries / Ranorex fallback)
    "llm_model": "qwen2.5-coder:1.5b",
    "llm_base_url": "http://localhost:11434",
    "strict_targeting": False,         # never click an ambiguous / low-confidence / mismatched target (see docs/AUTOMATION_ENGINE_AUDIT.md)
    "min_action_confidence": 0.85,    # fuzzy tiers (OCR / AI / heal / ORB / quadrant) below this are refused, not clicked
    "disambiguate_by_position": True,   # look-alike pictures: choose by recorded position + text instead of refusing
    "disambiguation_radius_px": 0,      # 0 = automatic (1.5 x picture size, at least 40 px)
    "scroll_jump": False,               # replay a recorded scroll as an exact jump to its recorded position (classic: wheel notches)
    "layout_coordinates": True,         # look-alike pictures + window at its recorded geometry: use the recorded coordinate
    "probe_neighbours": False,           # identity not at the recorded spot: probe 1-2 cells/rows around it (unique match only)
    "neighbour_radius": 2,
    "allow_unreviewed_custom_steps": False,   # AI-written custom steps must be approved by the tester before they run
    "record_ocr_label": False,          # recording: OCR the label under the click when UI Automation gives no name (feeds the ladder)
    "use_vision_ai": False,             # when everything else failed, let a local vision model look at the screen (result is verified by text)
    "verify_effect": False,             # compare the screen around every click before / after
    "retry_no_effect": False,           # a click that changed nothing is repeated once
    "strict_effect": False,            # True: a click that still changed nothing FAILS the step
    "ocr_verify_typing": False,         # read typed text back with OCR when UI Automation cannot
    "repeat_previous_policy": "never",  # when the next element is missing: repeat the previous step - safe | always | never
    "allow_blind_coordinates": False,  # last-resort stored-coordinate click; off = fail with an explanation instead
    "verify_typing": True,            # read the field back after typing when UI Automation can
    "require_postcondition": False,   # True: an action with no validation / read-back fails as 'unverified'
    "ensure_focus": False,         # before typing, make sure the field the user clicked still has the keyboard focus
    "scroll_notch_ms": 12,        # pause between wheel notches when replaying a scroll (one notch at a time, like a person)
    "ocr_short_mismatch": "warn",   # warn = a short value that only OCR could read and OCR disagrees -> "not verified" (never a fail)
    "ensure_state": False,         # check boxes / radio buttons: reach the recorded state instead of blindly clicking
    "llm_warmup": True,           # load the local model once before the first step (no console flash mid-test)
    "record_video": False,        # save a low-rate screen video of the run next to the report
    "video_fps": 4,
    "ocr_labels_after_record": True,
    "ocr_engine": "auto",         # auto | rapidocr | easyocr | tesseract   (auto = fastest installed first)
    "record_neighbors": True,     # record the elements around every click / drag point (anchors for playback)
    "scroll_mode": "exact",       # exact = replay every recorded scroll (default: nothing recorded is silently skipped); adaptive = opt-in: skip a scroll when the next target is already visible (reported as skipped)
    "scroll_find": True,          # scroll to find an element that is not on screen (native -> type-ahead -> wheel)
    "scroll_find_steps": 30,      # max wheel steps while searching
    "scroll_find_budget_s": 15.0, # max seconds for one scroll search
    "typeahead": True,            # in lists / combo boxes, type the item text to jump to it before scrolling
    "keyboard_option_fallback": True,   # a list option that cannot be found after scrolling the whole list: type its text + Enter (warned)
    "ocr_budget_s": 8.0,          # one OCR locate may take at most this long; then OCR location is off for the run
    "park_pointer": True,         # move the real mouse pointer off a region before reading it (never in screenshots)
    "ocr_search": "local_then_screen",   # local_then_screen | local_only | screen_only
    "ocr_radius": 220,            # px around the stored location searched first (then 2.4x, then the whole screen)
    "restore_window_geometry": True,   # put a window back to its recorded size/position before acting
    "geometry_tolerance_px": 8,        # ignore size/position differences up to this many pixels
    "native_policy": "auto",           # auto | always | never   (UI Automation lookups)
    "native_budget_s": 1.5,            # one UI Automation lookup may take at most this long, then it is skipped
    "settle_max_s": 1.5,               # longest wait for the screen to stop changing after an action
    "drag_steps": 18,                  # intermediate mouse positions while dragging
    "drag_hold_ms": 150,               # hold the button on the source before moving
    "drag_hover_ms": 250,              # hover over the destination before releasing (apps need this to accept a drop)
    "drag_step_delay_ms": 12,
    "collect_training_data": True,     # keep a local, privacy-reduced record of every recording / run (workspace/dataset)
    "dataset_include_text": False,     # also store typed text (off: only its length)
    "dataset_include_images": False,   # also keep 300px crops of failed / healed targets
    "dataset_max_mb": 500,             # stop writing past this size
    "ai_setup_prompted": False,        # the one-time "set up local AI?" question has been asked
    "ai_auto_start": True,             # start an installed Ollama automatically when AI features need it
    # --- speed: consecutive type/key/hotkey steps do not wait for the screen to settle between them
    "fast_entry": True,
    # --- failure recovery (core/retry.py)
    "retry_enabled": True,             # diagnose a failed step and retry it according to the policy below
    "retry_max_attempts": 2,           # extra attempts per failed step (0 = never retry)
    "retry_delay_s": 1.0,              # pause before each retry
    "retry_timeout_s": 30.0,           # how long the "retry?" question waits for the user
    "retry_ask_before": True,          # ask the user before retrying
    "retry_auto": False,               # retry without asking (only used when retry_ask_before is off)
    "retry_mode": "retry_step",        # retry_step | restart_test | stop
    "retry_timeout_action": "retry",   # no answer in time: retry | skip | stop
    "retry_allow_after_input": False,  # allow blind retries of steps that already sent input (may repeat a click)
    "retry_stop_after_failures": 0,    # stop the run after N steps failed for good in a row (0 = off)
    # --- storage / appearance
    "testcases_dir": "",               # "" = workspace/testcases
    "theme": "dark",                   # dark | light
    "report_keep_days": 30,            # "delete old reports" default age
}

OPTIONAL_STR = {"testcases_dir"}
INT_LIMITS = {"retry_max_attempts": (0, 10), "retry_stop_after_failures": (0, 50), "report_keep_days": (1, 3650)}


def _file():
    return paths.workspace() / "settings.json"


def validate(data: dict) -> dict:
    """Merge defaults and validate persisted or user-edited options."""
    if not isinstance(data, dict):
        raise ValueError("Settings must be a JSON object.")
    merged = dict(DEFAULTS)
    merged.update(data)

    for key, default in DEFAULTS.items():
        value = merged[key]
        if isinstance(default, bool):
            if not isinstance(value, bool):
                raise ValueError(f"Setting '{key}' must be true or false.")
        elif isinstance(default, float):
            if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
                raise ValueError(f"Setting '{key}' must be a finite number.")
            if key == "timeout_s" and not 0.5 <= value <= 120:
                raise ValueError("Setting 'timeout_s' must be between 0.5 and 120 seconds.")
            if key == "native_budget_s" and not 0.2 <= value <= 30:
                raise ValueError("Setting 'native_budget_s' must be between 0.2 and 30 seconds.")
            if key == "retry_delay_s" and not 0 <= value <= 300:
                raise ValueError("Setting 'retry_delay_s' must be between 0 and 300 seconds.")
            if key == "retry_timeout_s" and not 1 <= value <= 3600:
                raise ValueError("Setting 'retry_timeout_s' must be between 1 and 3600 seconds.")
            if key == "ocr_budget_s" and not 1 <= value <= 120:
                raise ValueError("Setting 'ocr_budget_s' must be between 1 and 120 seconds.")
            if key == "settle_max_s" and not 0.1 <= value <= 10:
                raise ValueError("Setting 'settle_max_s' must be between 0.1 and 10 seconds.")
            if key == "min_action_confidence" and not 0 <= value <= 1:
                raise ValueError("Setting 'min_action_confidence' must be between 0 and 1.")
            if key == "min_recovery_confidence" and not 0 <= value <= 1:
                raise ValueError("Setting 'min_recovery_confidence' must be between 0 and 1.")
            merged[key] = float(value)
        elif isinstance(default, int):
            lo, hi = INT_LIMITS.get(key, (0, 1000))
            if isinstance(value, bool) or not isinstance(value, int) or not lo <= value <= hi:
                raise ValueError(f"Setting '{key}' must be an integer between {lo} and {hi}.")
        elif not isinstance(value, str) or (not value.strip() and key not in OPTIONAL_STR):
            raise ValueError(f"Setting '{key}' must be a non-empty string.")

    if merged["input_backend"] not in {"auto", "pynput", "pyautogui"}:
        raise ValueError("Setting 'input_backend' must be auto, pynput, or pyautogui.")
    if merged["ocr_search"] not in {"local_then_screen", "local_only", "screen_only"}:
        raise ValueError("Setting 'ocr_search' must be local_then_screen, local_only, or screen_only.")
    if merged["ocr_short_mismatch"] not in {"warn", "fail"}:
        merged["ocr_short_mismatch"] = "warn"
    if merged["repeat_previous_policy"] not in {"safe", "always", "never"}:
        raise ValueError("Setting 'repeat_previous_policy' must be safe, always or never.")
    if merged["engine_profile"] not in {"classic", "strict"}:
        raise ValueError("Setting 'engine_profile' must be classic or strict.")
    if merged["engine_profile"] == "strict":
        for k, v in STRICT_VALUES.items():          # a value the user set explicitly always wins over the profile
            if k not in data:
                merged[k] = v
    if merged["scroll_mode"] not in {"adaptive", "exact"}:
        raise ValueError("Setting 'scroll_mode' must be adaptive or exact.")
    if merged["ocr_engine"] not in {"auto", "rapidocr", "easyocr", "tesseract"}:
        raise ValueError("Setting 'ocr_engine' must be auto, rapidocr, easyocr, or tesseract.")
    if merged["native_policy"] not in {"auto", "always", "never"}:
        raise ValueError("Setting 'native_policy' must be auto, always, or never.")
    if merged["retry_mode"] not in {"retry_step", "restart_test", "stop"}:
        raise ValueError("Setting 'retry_mode' must be retry_step, restart_test or stop.")
    if merged["retry_timeout_action"] not in {"retry", "skip", "stop"}:
        raise ValueError("Setting 'retry_timeout_action' must be retry, skip or stop.")
    if merged["theme"] not in {"dark", "light"}:
        raise ValueError("Setting 'theme' must be dark or light.")
    if not 20 <= merged["ocr_radius"] <= 1000:
        raise ValueError("Setting 'ocr_radius' must be between 20 and 1000 pixels.")
    if len(merged["llm_model"]) > 256:
        raise ValueError("Setting 'llm_model' is too long.")

    parsed = urlsplit(merged["llm_base_url"].strip())
    if parsed.scheme not in {"http", "https"} or not parsed.hostname:
        raise ValueError("Setting 'llm_base_url' must be an absolute http(s) URL.")
    if parsed.username or parsed.password:
        raise ValueError("Do not put credentials in 'llm_base_url'.")
    try:
        parsed.port  # force validation of malformed ports
    except ValueError as exc:
        raise ValueError("Setting 'llm_base_url' has an invalid port.") from exc
    if parsed.scheme == "http" and parsed.hostname.casefold() not in {"localhost", "127.0.0.1", "::1"}:
        raise ValueError("Use HTTPS for a non-local 'llm_base_url'.")
    return merged


def load() -> dict:
    try:
        raw = json.loads(_file().read_text(encoding="utf-8"))
    except FileNotFoundError:
        return dict(DEFAULTS)
    except (OSError, ValueError) as exc:
        log.warning("Could not read settings; defaults are active: %s", exc)
        return dict(DEFAULTS)
    try:
        return validate(raw)
    except ValueError as exc:
        log.warning("Some settings are invalid and were reset to their defaults: %s", exc)
    if not isinstance(raw, dict):
        return dict(DEFAULTS)
    good = {}                                   # keep every setting that is valid on its own
    for key, value in raw.items():
        try:
            validate({key: value})
            good[key] = value
        except ValueError:
            log.warning("Setting '%s' is invalid and was reset to its default.", key)
    try:
        return validate(good)
    except ValueError:
        return dict(DEFAULTS)


def save(data: dict) -> None:
    paths.ensure_dirs()
    merged = validate(data)
    path = _file()
    temp_path = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="w", encoding="utf-8", dir=path.parent,
            prefix=".settings-", suffix=".tmp", delete=False,
        ) as handle:
            temp_path = handle.name
            json.dump(merged, handle, indent=2, ensure_ascii=False, allow_nan=False)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp_path, path)
    except OSError:
        if temp_path:
            try:
                os.unlink(temp_path)
            except OSError:
                log.warning("Could not remove incomplete settings file %s", temp_path)
        raise
