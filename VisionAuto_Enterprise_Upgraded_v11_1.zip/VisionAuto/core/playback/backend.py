"""
Input backends: how VisionAuto actually moves the mouse / presses keys.
pynput is used for both recording and playback so both live in the same
coordinate system. DryRunBackend just logs (previews, CI on machines without a display).
"""
from __future__ import annotations

import sys
import time


import abc


class InputBackend(abc.ABC):
    @abc.abstractmethod
    def move(self, x, y): ...

    @abc.abstractmethod
    def click(self, x, y, button="left", count=1, modifiers=()): ...

    @abc.abstractmethod
    def drag(self, x1, y1, x2, y2, button="left", steps=14, hold_ms=150, hover_ms=100, step_delay_ms=12,
             modifiers=()): ...

    @abc.abstractmethod
    def scroll(self, x, y, dx, dy): ...

    @abc.abstractmethod
    def type_text(self, text, interval_ms=0): ...

    @abc.abstractmethod
    def hotkey(self, keys: str): ...

    @abc.abstractmethod
    def press(self, key: str): ...

    @abc.abstractmethod
    def key_down(self, key: str): ...

    @abc.abstractmethod
    def key_up(self, key: str): ...


    def release_all(self):
        """Release every key / mouse button this backend still holds (called after a failure, stop or cancel)."""

    # Low-level mouse primitives (drag with auto-scroll needs to hold the button while scrolling). Optional.
    def mouse_down(self, x, y, button="left"):
        raise NotImplementedError("this input backend cannot hold the mouse button")

    def mouse_move(self, x, y):
        self.move(x, y)

    def mouse_up(self, button="left"):
        raise NotImplementedError("this input backend cannot hold the mouse button")


class DryRunBackend(InputBackend):
    def __init__(self):
        self.actions: list[tuple] = []

    def move(self, x, y): self.actions.append(("move", x, y))
    def release_all(self): self.actions.append(("release_all",))
    def click(self, x, y, button="left", count=1, modifiers=()):
        self.actions.append(("click", x, y, button, count) + ((tuple(modifiers),) if modifiers else ()))

    def drag(self, x1, y1, x2, y2, button="left", steps=14, hold_ms=150, hover_ms=100, step_delay_ms=12, modifiers=()):
        self.actions.append(("drag", x1, y1, x2, y2, button) + ((tuple(modifiers),) if modifiers else ()))
        self.drag_params = {"steps": steps, "hold_ms": hold_ms, "hover_ms": hover_ms, "step_delay_ms": step_delay_ms}
    def scroll(self, x, y, dx, dy): self.actions.append(("scroll", x, y, dx, dy))
    def mouse_down(self, x, y, button="left"): self.actions.append(("mouse_down", x, y, button))
    def mouse_move(self, x, y): self.actions.append(("mouse_move", x, y))
    def mouse_up(self, button="left"): self.actions.append(("mouse_up", button))
    def type_text(self, text, interval_ms=0): self.actions.append(("type", text))
    def hotkey(self, keys): self.actions.append(("hotkey", keys))
    def press(self, key): self.actions.append(("press", key))
    def key_down(self, key): self.actions.append(("key_down", key))
    def key_up(self, key): self.actions.append(("key_up", key))


_ALIASES = {"win": "cmd", "pageup": "page_up", "pagedown": "page_down", "return": "enter", "back": "backspace"}


class PynputBackend(InputBackend):
    def __init__(self):
        from pynput import keyboard, mouse

        self._kb, self._ms = keyboard, mouse
        self.m = mouse.Controller()
        self.k = keyboard.Controller()
        self._held_keys: list = []
        self._held_buttons: list = []

    def release_all(self):
        for b in list(self._held_buttons):
            try:
                self.m.release(b)
            except Exception:
                pass
        for k in list(self._held_keys):
            try:
                self.k.release(k)
            except Exception:
                pass
        self._held_buttons.clear()
        self._held_keys.clear()

    # -- helpers
    def _button(self, name):
        return {"left": self._ms.Button.left, "right": self._ms.Button.right,
                "middle": self._ms.Button.middle}.get(name, self._ms.Button.left)

    def _key(self, name: str):
        Key, KeyCode = self._kb.Key, self._kb.KeyCode
        if len(name) == 1:
            return name
        if name.startswith("vk") and name[2:].isdigit():
            return KeyCode.from_vk(int(name[2:]))
        key = getattr(Key, _ALIASES.get(name, name), None)
        if key is None:
            raise ValueError(f"Unknown key '{name}'")
        return key

    # -- actions
    def move(self, x, y):
        self.m.position = (int(x), int(y))
        time.sleep(0.03)

    def click(self, x, y, button="left", count=1, modifiers=()):
        self.move(x, y)
        keys = [self._key(m) for m in modifiers]
        try:
            for k in keys:
                self.k.press(k)
            self.m.click(self._button(button), count)
        finally:
            for k in reversed(keys):
                self.k.release(k)

    def drag(self, x1, y1, x2, y2, button="left", steps=14, hold_ms=150, hover_ms=100, step_delay_ms=12, modifiers=()):
        """Press, wait, glide in ``steps`` moves, wiggle over the destination, hover, release.

        The hold and the hover are what make real applications (Explorer, Electron apps, web views, Office) accept
        the drop - an instant press-move-release is often ignored.  The button and modifiers are ALWAYS released.
        """
        b = self._button(button)
        keys = [self._key(m) for m in modifiers]
        self.move(x1, y1)
        pressed = False
        try:
            for k in keys:
                self.k.press(k)
            self.m.press(b)
            pressed = True
            time.sleep(max(0, hold_ms) / 1000.0)
            n = max(1, int(steps))
            for i in range(1, n + 1):
                self.m.position = (int(x1 + (x2 - x1) * i / n), int(y1 + (y2 - y1) * i / n))
                time.sleep(max(0, step_delay_ms) / 1000.0)
            for dx, dy in ((3, 0), (-3, 0), (0, 3), (0, 0)):          # tiny wiggle raises 'drag over' in the target app
                self.m.position = (int(x2 + dx), int(y2 + dy))
                time.sleep(0.02)
            time.sleep(max(0, hover_ms) / 1000.0)
        finally:
            if pressed:
                self.m.release(b)
            for k in reversed(keys):
                self.k.release(k)

    def scroll(self, x, y, dx, dy):
        self.move(x, y)
        if dx or dy:
            self.m.scroll(int(dx), int(dy))

    def mouse_down(self, x, y, button="left"):
        self.move(x, y)
        self.m.press(self._button(button))
        self._held_buttons.append(self._button(button))

    def mouse_move(self, x, y):
        self.m.position = (int(x), int(y))

    def mouse_up(self, button="left"):
        self.m.release(self._button(button))
        b = self._button(button)
        if b in self._held_buttons:
            self._held_buttons.remove(b)

    def type_text(self, text, interval_ms=0):
        if interval_ms <= 0:
            self.k.type(text)
            return
        for ch in text:
            self.k.type(ch)
            time.sleep(interval_ms / 1000.0)

    def hotkey(self, keys: str):
        parts = [self._key(p) for p in keys.split("+") if p]
        for k in parts:
            self.k.press(k)
        time.sleep(0.03)
        for k in reversed(parts):
            self.k.release(k)

    def press(self, key: str):
        k = self._key(key)
        self.k.press(k)
        self.k.release(k)

    def key_down(self, key: str):
        k = self._key(key)
        self.k.press(k)
        self._held_keys.append(k)

    def key_up(self, key: str):
        k = self._key(key)
        self.k.release(k)
        if k in self._held_keys:
            self._held_keys.remove(k)


class PyAutoGUIBackend(InputBackend):
    """PyAutoGUI backend for desktops where pynput hooks are restricted."""

    def __init__(self):
        import pyautogui

        self.pyautogui = pyautogui

    def move(self, x, y):
        self.pyautogui.moveTo(int(x), int(y), duration=0.03)

    def click(self, x, y, button="left", count=1, modifiers=()):
        self.move(x, y)
        try:
            for m in modifiers:
                self.pyautogui.keyDown(m)
            self.pyautogui.click(button=button, clicks=count, interval=0.05)
        finally:
            for m in reversed(modifiers):
                self.pyautogui.keyUp(m)

    def drag(self, x1, y1, x2, y2, button="left", steps=14, hold_ms=150, hover_ms=100, step_delay_ms=12, modifiers=()):
        g = self.pyautogui
        self.move(x1, y1)
        pressed = False
        try:
            for m in modifiers:
                g.keyDown(m)
            g.mouseDown(button=button)
            pressed = True
            time.sleep(max(0, hold_ms) / 1000.0)
            n = max(1, int(steps))
            for i in range(1, n + 1):
                g.moveTo(int(x1 + (x2 - x1) * i / n), int(y1 + (y2 - y1) * i / n))
                time.sleep(max(0, step_delay_ms) / 1000.0)
            g.moveTo(int(x2) + 3, int(y2))
            g.moveTo(int(x2), int(y2))
            time.sleep(max(0, hover_ms) / 1000.0)
        finally:
            if pressed:
                g.mouseUp(button=button)
            for m in reversed(modifiers):
                g.keyUp(m)

    def scroll(self, x, y, dx, dy):
        self.move(x, y)
        unit = 120 if sys.platform == "win32" else 1             # pyautogui passes the raw wheel delta on Windows: 120 = one notch
        if dx:
            self.pyautogui.hscroll(int(dx) * unit)
        if dy:
            self.pyautogui.scroll(int(dy) * unit)

    def mouse_down(self, x, y, button="left"):
        self.move(x, y)
        self.pyautogui.mouseDown(button=button)

    def mouse_move(self, x, y):
        self.pyautogui.moveTo(int(x), int(y))

    def mouse_up(self, button="left"):
        self.pyautogui.mouseUp(button=button)

    def type_text(self, text, interval_ms=0):
        self.pyautogui.write(text, interval=max(0, interval_ms) / 1000.0)

    def hotkey(self, keys):
        self.pyautogui.hotkey(*[k.strip() for k in keys.split("+") if k.strip()])

    def press(self, key):
        self.pyautogui.press(key)

    def key_down(self, key):
        self.pyautogui.keyDown(key)

    def key_up(self, key):
        self.pyautogui.keyUp(key)


def create_backend(name: str = "auto") -> InputBackend:
    """Create the requested input backend, falling back safely in auto mode."""
    if name == "pynput":
        return PynputBackend()
    if name == "pyautogui":
        return PyAutoGUIBackend()
    try:
        return PynputBackend()
    except Exception:
        return PyAutoGUIBackend()
