"""Safe expressions for ``set_variable`` and data generation - no ``eval``, only a whitelisted syntax tree.

A tester writes  ``=upper(${first}) + "-" + today("%Y%m%d")``  or  ``=int(${qty}) * 2``.  Anything that is not a
literal, arithmetic / comparison / boolean operator or a call to a function listed in ``FUNCTIONS`` is refused.
"""
from __future__ import annotations

import ast
import operator
import os
import random
import re
import string
import uuid
from datetime import datetime, timedelta

MAX_LEN = 2000


class ExpressionError(ValueError):
    pass


def _num(x):
    try:
        f = float(str(x).replace(",", "").strip())
        return int(f) if f == int(f) else f
    except (TypeError, ValueError) as e:
        raise ExpressionError(f"'{x}' is not a number") from e


def _date(s, fmt="%Y-%m-%d"):
    try:
        return datetime.strptime(str(s), fmt)
    except ValueError as e:
        raise ExpressionError(f"'{s}' does not match date format {fmt}") from e


def _regex(pattern, text, group=0):
    m = re.search(str(pattern), str(text))
    if not m:
        return ""
    try:
        return m.group(int(group)) or ""
    except (IndexError, re.error) as e:
        raise ExpressionError(f"regex group {group} does not exist") from e


def _item(lst, i):
    """item('["a","b"]', 2) -> 'b' (1-based, like the loop counter ${_loop})."""
    import json
    try:
        data = json.loads(str(lst))
        return str(data[int(_num(i)) - 1])
    except (ValueError, IndexError, TypeError) as e:
        raise ExpressionError(f"item {i} does not exist in the list") from e


FUNCTIONS = {
    "upper": lambda s: str(s).upper(), "lower": lambda s: str(s).lower(), "trim": lambda s: str(s).strip(),
    "title": lambda s: str(s).title(), "len": lambda s: len(str(s)), "str": str,
    "int": lambda x: int(_num(x)), "float": lambda x: float(_num(x)), "abs": lambda x: abs(_num(x)),
    "round": lambda x, n=0: round(_num(x), int(n)), "min": lambda *a: min(_num(x) for x in a),
    "max": lambda *a: max(_num(x) for x in a),
    "substr": lambda s, a, b=None: str(s)[int(a):(None if b is None else int(b))],
    "replace": lambda s, a, b: str(s).replace(str(a), str(b)),
    "concat": lambda *a: "".join(str(x) for x in a), "contains": lambda s, sub: str(sub) in str(s),
    "startswith": lambda s, p: str(s).startswith(str(p)), "endswith": lambda s, p: str(s).endswith(str(p)),
    "regex": _regex, "digits": lambda s: re.sub(r"\D", "", str(s)),
    "pad": lambda s, n, ch="0": str(s).rjust(int(n), str(ch)[:1] or "0"),
    "today": lambda fmt="%Y-%m-%d": datetime.now().strftime(fmt),
    "now": lambda fmt="%Y-%m-%d %H:%M:%S": datetime.now().strftime(fmt),
    "add_days": lambda s, n, fmt="%Y-%m-%d": (_date(s, fmt) + timedelta(days=int(_num(n)))).strftime(fmt),
    "days_between": lambda a, b, fmt="%Y-%m-%d": (_date(b, fmt) - _date(a, fmt)).days,
    "random_int": lambda a=0, b=999999: random.randint(int(a), int(b)),
    "random_text": lambda n=8: "".join(random.choice(string.ascii_lowercase) for _ in range(min(int(n), 200))),
    "random_email": lambda domain="example.com": f"user{random.randint(1000, 999999)}@{domain}",
    "item": lambda lst, i: _item(lst, i),
    "uuid": lambda: str(uuid.uuid4()), "env": lambda name, default="": os.environ.get(str(name), str(default)),
}
_BIN = {ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul, ast.Div: operator.truediv,
        ast.Mod: operator.mod, ast.FloorDiv: operator.floordiv}
_CMP = {ast.Eq: operator.eq, ast.NotEq: operator.ne, ast.Lt: operator.lt, ast.LtE: operator.le,
        ast.Gt: operator.gt, ast.GtE: operator.ge}


def _eval(node):
    if isinstance(node, ast.Constant) and isinstance(node.value, (str, int, float, bool, type(None))):
        return node.value
    if isinstance(node, ast.BinOp) and type(node.op) in _BIN:
        a, b = _eval(node.left), _eval(node.right)
        if isinstance(node.op, ast.Add) and (isinstance(a, str) or isinstance(b, str)):
            return f"{a}{b}"                                    # "-" + 5  -> "-5": a tester expects text joining
        if isinstance(a, str):
            a = _num(a)
        if isinstance(b, str):
            b = _num(b)
        try:
            return _BIN[type(node.op)](a, b)
        except ZeroDivisionError as e:
            raise ExpressionError("division by zero") from e
    if isinstance(node, ast.UnaryOp) and isinstance(node.op, (ast.USub, ast.UAdd, ast.Not)):
        v = _eval(node.operand)
        return (not v) if isinstance(node.op, ast.Not) else (-_num(v) if isinstance(node.op, ast.USub) else _num(v))
    if isinstance(node, ast.BoolOp):
        vals = [_eval(v) for v in node.values]
        return all(vals) if isinstance(node.op, ast.And) else any(vals)
    if isinstance(node, ast.Compare):
        left = _eval(node.left)
        for op, comp in zip(node.ops, node.comparators):
            right = _eval(comp)
            if type(op) not in _CMP:
                raise ExpressionError("unsupported comparison")
            try:
                a, b = (_num(left), _num(right)) if not isinstance(op, (ast.Eq, ast.NotEq)) or (
                    _looks_num(left) and _looks_num(right)) else (left, right)
            except ExpressionError:
                a, b = str(left), str(right)
            if not _CMP[type(op)](a, b):
                return False
            left = right
        return True
    if isinstance(node, ast.IfExp):
        return _eval(node.body) if _eval(node.test) else _eval(node.orelse)
    if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and not node.keywords:
        fn = FUNCTIONS.get(node.func.id)
        if fn is None:
            raise ExpressionError(f"unknown function '{node.func.id}' (allowed: {', '.join(sorted(FUNCTIONS))})")
        return fn(*[_eval(a) for a in node.args])
    raise ExpressionError("this expression uses syntax that is not allowed")


def _looks_num(x) -> bool:
    try:
        float(str(x).replace(",", "").strip())
        return not isinstance(x, bool)
    except ValueError:
        return False


def evaluate(text: str):
    """``=...`` -> the computed value; anything else is returned as plain text."""
    s = str(text)
    if not s.startswith("="):
        return s
    src = s[1:].strip()
    if not src or len(src) > MAX_LEN:
        raise ExpressionError("empty or too long expression")
    try:
        tree = ast.parse(src, mode="eval")
    except SyntaxError as e:
        raise ExpressionError(f"cannot read the expression: {e.msg}") from e
    return _eval(tree.body)


def bind(text: str, variables: dict) -> str:
    """For an ``=expression``: put each ``${name}`` in as a typed literal (text quoted, numbers bare) so that a value
    containing spaces or quotes can never change the meaning of the expression. Unknown names are an error."""
    def one(m):
        name = m.group(1)
        if name not in variables:
            raise ExpressionError(f"Variable '${{{name}}}' is not defined.")
        v = variables[name]
        return repr(v if isinstance(v, (int, float)) and not isinstance(v, bool) else str(v))
    return re.sub(r"\$\{([a-zA-Z0-9_\-]+)\}", one, str(text))
