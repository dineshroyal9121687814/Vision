"""
Resolver: turns a recorded target into a live screen coordinate.

Locator priority (first success wins, each tier is independent evidence; OCR is deliberately late - pixels first):

    native UI Automation  ->  template (300px, then 100px)  ->  ORB homography
    ->  OCR text  ->  AI similarity  ->  self-heal ring search  ->  not found

The resolver keeps polling until `timeout` (a wait-until-visible, never a fixed
sleep). Anything found by a tier other than native/template is flagged
`healed=True` and carries fresh template crops so the Player can write the new
appearance back into the test.
"""
from __future__ import annotations

import logging
import math
import time
from dataclasses import dataclass, field
from pathlib import Path

from core.automation import effect, evidence, guard, position, quadrants
from core.automation.errors import AmbiguousTarget, LowConfidenceTarget
from core.plugins.plugin_manager import PluginManager
from core.self_healing.healer import SelfHealer
from core.system import excel_com, geometry, winenv
from core.system.imageio import imread
from core.vision import neighbors as nb_mod
from core.vision import visual_neighbors as nb_visual
from core.vision.locator import Locator

log = logging.getLogger("visionauto.resolver")


class ElementNotFound(Exception):
    pass


class NativeGovernor:
    """Keeps the UI Automation tier from making every click slow.

    A UI Automation tree walk can take many seconds in big or Chromium/Electron apps (VS Code, Chrome, Teams ...)
    and used to be repeated on every retry.  Now one lookup is time-boxed (``native_budget_s``); an app whose lookup
    blew the budget is switched to the visual tiers (zone -> window -> screen) for the rest of the run, and apps known
    to expose a sparse tree start with the visual tiers.  Explicit user intent always wins: a target with an ``xpath``
    or ``locator_order`` that lists ``uia``/``xpath`` is still tried (but still time-boxed).
    """

    ELECTRON = frozenset({"code.exe", "code - insiders.exe", "cursor.exe", "windsurf.exe", "chrome.exe", "msedge.exe",
                          "brave.exe", "firefox.exe", "slack.exe", "teams.exe", "ms-teams.exe", "discord.exe",
                          "spotify.exe", "notion.exe", "obsidian.exe", "postman.exe", "figma.exe", "whatsapp.exe"})

    def __init__(self, options: dict):
        self.o = options
        self.slow: set[str] = set()
        self._pool = None

    @staticmethod
    def key(window: dict) -> str:
        w = window or {}
        return (str(w.get("process") or "") or str(w.get("title") or "")).casefold()

    def allowed(self, window: dict, target: dict) -> bool:
        policy = self.o.get("native_policy", "auto")
        if policy == "never":
            return False
        if policy == "always":
            return True
        key = self.key(window)
        if key in self.slow:
            return False
        order = target.get("locator_order") or []
        explicit = bool(target.get("xpath") or target.get("rxpath") or "uia" in order or "xpath" in order)
        return explicit or key not in self.ELECTRON

    def call(self, window: dict, fn):
        """Run ``fn`` with the time budget. Returns its result, or None when it timed out / failed."""
        if self.o.get("native_policy") == "always":
            return fn()
        import concurrent.futures as cf

        if self._pool is None:
            self._pool = cf.ThreadPoolExecutor(max_workers=1, thread_name_prefix="va-native")

        def run():
            winenv.init_com()
            return fn()

        budget = float(self.o.get("native_budget_s", 1.5))
        t0 = time.monotonic()
        fut = self._pool.submit(run)
        try:
            result = fut.result(timeout=budget)
        except AmbiguousTarget:
            raise                                  # several matches is an answer, not a failure to fall through on
        except cf.TimeoutError:
            log.info("UI Automation lookup exceeded %.1fs for %s - using visual locators for this app from now on",
                     budget, self.key(window))
            self.slow.add(self.key(window))
            self._pool = None            # abandon the stuck worker; never run two UIA calls at once
            return None
        except Exception:
            log.debug("native lookup failed", exc_info=True)
            return None
        if time.monotonic() - t0 > budget:
            self.slow.add(self.key(window))
        return result


class Aborted(Exception):
    pass


@dataclass
class Resolution:
    x: int
    y: int
    method: str
    confidence: float = 1.0
    healed: bool = False
    crops: dict = field(default_factory=dict)   # size -> (image, click_in_crop), only when healed
    evidence: dict = field(default_factory=dict)


class Resolver:
    AI_CLASSICAL_MAX_DIST = 250   # px from the recorded position

    def __init__(self, test_dir, options: dict, abort_check=None, grab=None):
        self.dir = Path(test_dir) if test_dir else None
        self.o = options
        self.locator = Locator()
        self.healer = SelfHealer(self.locator)
        self._ai = None
        self.plugins = PluginManager()
        self.abort_check = abort_check or (lambda: False)
        self.grab = grab or winenv.grab_screen
        self._cache: dict = {}
        self._last_ocr = 0.0
        self._ocr_broken = False
        self._ai_full = False
        self.governor = NativeGovernor(options)
        self.scrollfinder = None          # set by the Player (needs the input backend)
        self._scrolled = False
        self.rect_provider = self._default_rect_provider
        self._win_rect = None
        self.vision_advisor = None        # an object with locate(frame, what, hint) (see core/ai/vision_advisor.py)
        self._vision_tried = False
        self._layout_same = False
        self._last_ocr_by: dict = {}

    @property
    def ai(self):
        if self._ai is None:
            from core.ai.ai_engine import AIMatcher
            self._ai = AIMatcher()
        return self._ai

    def _recovery_threshold(self) -> float:
        try:
            return max(0.0, min(1.0, float(self.o.get("min_recovery_confidence", 0.72))))
        except (TypeError, ValueError):
            return 0.72

    @staticmethod
    def _default_rect_provider(window: dict):
        """Current outer rect of the recorded window (the foreground one if it matches, else look it up by title)."""
        title = str((window or {}).get("title") or "").strip().casefold()
        try:
            hw = (window or {}).get("_hwnd")
            if hw and winenv.is_window(hw):
                return winenv.window_rect(hw)
            fg = winenv.foreground_window()
            if fg.get("rect") and (not title or title in str(fg.get("title", "")).casefold()):
                return fg["rect"]
            if title:
                for hwnd in winenv.find_windows(title)[:1]:
                    return winenv.window_rect(hwnd)
        except Exception:
            log.debug("window rect lookup failed", exc_info=True)
        return None

    def _prepare(self, target: dict, window: dict) -> dict:
        """If the window is not where/how big it was when recorded, translate the recorded positions so every
        'search near the stored place' stage still looks in the right place."""
        rec = (window or {}).get("rect")
        self._win_rect = None
        self._layout_same = False
        if not geometry.valid(rec):
            return target
        cur = self.rect_provider(window)
        if not geometry.valid(cur):
            self._win_rect = list(rec)
            return target
        self._win_rect = list(cur)
        tol = int(self.o.get("geometry_tolerance_px", 8))
        if geometry.differs(rec, cur, tol):
            return geometry.rebase_target(target, rec, cur)
        self._layout_same = True                      # window is where / as big as when recorded: coordinates are exact
        return target

    # ------------------------------------------------------------ public
    def resolve(self, target: dict, window: dict, timeout: float | None = None) -> Resolution:
        timeout = self.o.get("timeout_s", 10.0) if timeout is None else timeout
        if isinstance(timeout, bool):
            raise ValueError("Locator timeout must be a finite number between 0 and 120 seconds.")
        try:
            timeout = float(timeout)
        except (TypeError, ValueError, OverflowError) as exc:
            raise ValueError("Locator timeout must be a finite number between 0 and 120 seconds.") from exc
        if not math.isfinite(timeout) or not 0 <= timeout <= 120:
            raise ValueError("Locator timeout must be a finite number between 0 and 120 seconds.")
        deadline = time.monotonic() + timeout
        attempt = 0
        self._scrolled = False
        self._vision_tried = False
        target = self._prepare(target, window)
        while True:
            if self.abort_check():
                raise Aborted()
            r = self.resolve_once(target, window, attempt)
            if r:
                wr = self._win_rect if not (window or {}).get("popup") else None
                return guard.vet(r, target, self.o, wr)
            attempt += 1
            # The first pass deliberately limits itself to the cheap locator
            # tiers.  Always allow one recovery pass (AI similarity and the
            # bounded ring search) before enforcing the timeout: a single
            # expensive fast-tier call must not starve those recovery tiers.
            if time.monotonic() >= deadline and attempt >= 2:
                raise ElementNotFound(self._explain(target, window, timeout))
            remaining = deadline - time.monotonic()
            if remaining > 0:
                time.sleep(min(0.3, remaining))

    # point = "is the recorded element still at the recorded place?" (one cheap UI Automation query, text + location);
    # uia = search the tree by name / id; image = template match (pyautogui-style); then ORB, OCR, AI, self-heal.
    # anchor = neighbours (what surrounds it, recorded at click time); scroll = bring it into view, last, because it moves the UI
    # Ladder (what a careful tester does): identity (Excel / UIA / XPath / neighbours) -> text seen near the recorded spot
    # (ocr_local) -> the recorded coordinate, accepted only if the required text is really there (coordtext) -> pictures
    # -> text anywhere in the window / on the whole screen (ocr_wide) -> an AI looking at the screenshot (vision, verified)
    CLASSIC_ORDER = ("uia", "image", "orb", "ocr", "ai", "heal", "scroll", "layout_local")      # the build that worked best in the field (v10)
    DEFAULT_ORDER = ("excel", "point", "uia", "anchor", "ocr_local", "coordtext", "image", "orb", "nbimg", "ocr_wide",
                     "vision", "ai", "heal", "scroll")
    ALL_TIERS = ("excel", "point", "uia", "anchor", "scroll", "xpath", "image", "orb", "nbimg", "ocr", "ai", "heal", "layout_local", "coordinates",
                 "position", "quadrant", "ocr_local", "ocr_wide", "coordtext", "vision")

    def tier_order(self, target: dict) -> list[str]:
        """The user-editable locator order for one element (``target['locator_order']``).

        Default: UI Automation (incl. XPath) -> image template -> ORB features -> OCR -> AI -> self-heal.
        Put ``"xpath"`` in the list to run XPath as its own tier; add ``"coordinates"`` to allow the stored
        screen position as a last-resort blind click (opt-in, guarded by the foreground window check).
        """
        order = target.get("locator_order")
        if isinstance(order, (list, tuple)):
            cleaned = []
            for t in order:
                if t in self.ALL_TIERS and t not in cleaned:
                    cleaned.append(t)
            if cleaned:
                return self._with_quadrant(target, cleaned)
        base = self.CLASSIC_ORDER if self.o.get("engine_profile") == "classic" else self.DEFAULT_ORDER
        return self._with_quadrant(target, list(base))

    @staticmethod
    def _with_quadrant(target: dict, order: list) -> list:
        """A target that asks for a quadrant search gets it as the LAST tier (search regions, never click targets)."""
        if target.get("search_quadrant") and "quadrant" not in order:
            at = order.index("image") + 1 if "image" in order else len(order)      # explicit restriction beats fuzzy tiers
            order = list(order[:at]) + ["quadrant"] + list(order[at:])
        return order

    def resolve_once(self, target: dict, window: dict, attempt: int = 1, only=None) -> Resolution | None:
        """One pass over the tiers. ``only`` restricts it to the named tiers (scroll search, visibility probes)."""
        if target.get("locator_mode") == "coordinates" and "x" in target and "y" in target:
            return Resolution(int(target["x"]), int(target["y"]), "coordinates", 0.5,
                              evidence={"mode": "explicit user coordinate"})
        if target.get("locator_mode") == "position" and isinstance(target.get("position"), dict):
            return self._t_position(target, window, {"attempt": attempt})
        order = self.tier_order(target)
        if only is not None:
            order = [t for t in order if t in only] or [t for t in self.DEFAULT_ORDER if t in only]
        st = {"frame": None, "origin": (0, 0), "attempt": attempt, "template_ambiguous": False,
              "c300": self._tpl(target, "crop300"), "c100": self._tpl(target, "crop100"),
              "split_xpath": "xpath" in order}
        tiers = {"anchor": self._t_anchor, "scroll": self._t_scroll, "excel": self._t_excel, "point": self._t_point, "uia": self._t_uia, "xpath": self._t_xpath, "image": self._t_image, "orb": self._t_orb, "nbimg": self._t_nbimg,
                 "ocr": self._t_ocr, "ocr_local": self._t_ocr_local, "ocr_wide": self._t_ocr_wide,
                 "coordtext": self._t_coordtext, "vision": self._t_vision, "ai": self._t_ai, "heal": self._t_heal, "layout_local": self._t_layout_local, "coordinates": self._t_coordinates,
                 "position": self._t_position, "quadrant": self._t_quadrant}
        for name in order:
            r = tiers[name](target, window, st)
            if r:
                return r
        return None

    def _frame(self, st: dict):
        if st["frame"] is None:
            st["frame"], st["origin"] = self.grab()
        return st["frame"], st["origin"]

    # ---- tiers -------------------------------------------------------------
    def _native_turn(self, st, window, target) -> bool:
        """UI Automation is retried with back-off (attempts 0,1,4,8...) instead of on every 0.3 s poll."""
        if not self.o.get("use_native", True) or not self.governor.allowed(window, target):
            return False
        return st["attempt"] <= 1 or st["attempt"] % 4 == 0

    def _t_anchor(self, target, window, st):
        """Neighbour anchors: find what surrounded the element when it was recorded, then apply the recorded offsets.
        Needs no name and no picture of the element itself - works for drop zones, repeated rows, unnamed icons."""
        nbs = target.get("neighbors")
        if not nbs or st["attempt"] > 2 or not self.o.get("use_native", True) or not self.governor.allowed(window, target):
            return None
        found = []
        for nb in nbs[:4]:
            crit = {k: nb[k] for k in ("name", "role", "automation_id") if nb.get(k)}
            if not crit:
                continue
            el = self.governor.call(window, lambda c=crit: self.plugins.get_plugin_for(window).find_element_native(c, window))
            if el and geometry.valid(el.get("rect")):
                r = el["rect"]
                found.append((nb, ((r[0] + r[2]) / 2, (r[1] + r[3]) / 2)))
        loc = nb_mod.locate(found)
        if not loc:
            return None
        x, y, votes, spread = loc
        confidence = 0.85 if votes >= 2 else 0.7
        if target.get("automation_id") or target.get("name"):
            el = self.governor.call(window, lambda: winenv.element_at(int(x), int(y)))
            if el and self._same_element(el, target):
                confidence = 0.97                                  # the element itself is where the anchors say
            elif votes < 2:
                return None                                        # one anchor, and something else is there
        return Resolution(int(x), int(y), "anchor", confidence,
                          evidence={"anchors": [a["name"] or a.get("automation_id", "") for a, _ in found], "votes": votes,
                                    "spread_px": round(spread, 1)})

    def _t_nbimg(self, target, window, st):
        """Find the click by the PICTURES of what surrounded it (header to the left, label above ...). Works when the
        element itself looks different now (a value was typed, a state changed) or has no accessibility tree. Each crop
        found votes for the click point; two crops agreeing, or one strong unique match, is an answer."""
        items = target.get("visual_neighbors")
        if not items or st["attempt"] > 3 or not self.dir:
            return None
        frame, origin = self._frame(st)
        loaded = []
        for it in items[:6]:
            path = self.dir / it["path"]
            if path not in self._cache:
                self._cache[path] = imread(path)
            if self._cache[path] is not None:
                loaded.append((it, self._cache[path]))
        if not loaded:
            return None
        for stage, (x0, y0, x1, y1) in self.search_stages(target, frame, origin):
            region = frame[y0:y1, x0:x1]
            found, confs = [], []
            for it, img in loaded:
                if img.shape[0] > region.shape[0] or img.shape[1] > region.shape[1]:
                    continue
                r = self.locator.find_by_template(region, img, scales=(1.0,), threshold=0.9)
                if r.found:
                    found.append((r.x + x0 + origin[0], r.y + y0 + origin[1], it["dx"], it["dy"]))
                    confs.append(r.confidence)
            v = nb_visual.vote(found)
            if not v:
                continue
            x, y, votes, spread = v
            if votes >= 2 or (votes == 1 and len(loaded) == 1 and confs and confs[0] >= 0.95):
                return Resolution(x, y, "neighbour-image", 0.88 if votes >= 2 else 0.8,
                                  evidence={"votes": votes, "of": len(loaded), "spread_px": round(spread, 1), "stage": stage})
        return None

    def _t_scroll(self, target, window, st):
        """Last tier: the element is not on screen - scroll its container until it is (native -> type-ahead -> wheel)."""
        finder = getattr(self, "scrollfinder", None)
        if (finder is None or not self.o.get("scroll_find", True) or st["attempt"] < 1 or self._scrolled
                or not target.get("container")):
            return None
        role = str((target.get("container") or {}).get("role") or "").casefold()
        if self.o.get("engine_profile") == "classic" and not (target.get("intent") == "pick_option"
                                                              or role in ("list", "listbox", "combobox", "listview")):
            return None                                            # classic: only drop-down / list options are searched by scrolling
        if not (getattr(self, "recording_scrolls", True) or role in ("list", "listbox", "combobox", "listview")
                or target.get("intent") == "pick_option"):
            return None                                            # the user never scrolled here: do not scroll on our own
        self._scrolled = True                                      # one search per resolve(), not one per 0.3 s poll
        return finder.find(target, window)

    def _t_excel(self, target, window, st):
        """A spreadsheet cell is addressed ("G14"): ask Excel where that cell is on the screen. Exact, millisecond-fast,
        needs neither UI Automation (slow in Excel, so it gets switched off) nor a picture (empty cells look identical,
        which is why 'click G14' could not be found by image). Falls through when Excel cannot answer."""
        addr = target.get("automation_id") or target.get("name")
        w = window or {}
        if (not excel_com.looks_like_address(addr) or st["attempt"] > 2
                or "excel" not in (str(w.get("process") or "") + " " + str(w.get("title") or "")).casefold()
                or not (str(target.get("role") or "") == "DataItem" or "spreadsheetcell" in str(target.get("class_name") or "").casefold())):
            return None
        rect = excel_com.cell_screen_rect(str(addr), str(w.get("title") or ""))
        if not geometry.valid(rect):
            return None
        res = self._from_native({"rect": rect, "name": str(addr), "role": "DataItem"}, target)
        res.method = "excel"
        return res

    @staticmethod
    def _same_element(el: dict, target: dict) -> bool:
        """Does the element found at the recorded spot carry the recorded identity (id, else name + role)?"""
        rid, rname = str(target.get("automation_id") or ""), str(target.get("name") or "").strip()
        if rid:
            return str(el.get("automation_id") or "") == rid and (
                not rname or str(el.get("name") or "").strip().casefold() == rname.casefold()
                or el.get("class_name") == target.get("class_name"))
        if not rname:
            return False
        same_name = str(el.get("name") or "").strip().casefold() == rname.casefold()
        role = str(target.get("role") or "")
        return same_name and (not role or str(el.get("role") or "") == role)

    def _t_point(self, target, window, st):
        """Text + location first: ask UI Automation what is at the recorded place. One query (milliseconds) instead of
        a tree search; it also proves the element is really there, not just that something looks similar."""
        if not (target.get("automation_id") or target.get("name")) or st["attempt"] > 1:
            return None
        if target.get("xpath") or target.get("rxpath"):
            return None                                   # explicit user path: the uia tier honours it
        x, y = target.get("x"), target.get("y")
        if x is None or y is None:
            rect, rel = target.get("rect"), target.get("rel")
            if not geometry.valid(rect):
                return None
            rel = rel if isinstance(rel, (list, tuple)) and len(rel) >= 2 else (0.5, 0.5)
            x, y = rect[0] + (rect[2] - rect[0]) * rel[0], rect[1] + (rect[3] - rect[1]) * rel[1]
        if not self.o.get("use_native", True) or not self.governor.allowed(window, target):
            return None
        el = self.governor.call(window, lambda: winenv.element_at(int(x), int(y)))
        if el and geometry.valid(el.get("rect")) and self._same_element(el, target):
            res = self._from_native(el, target)
            res.method = "point"
            return res
        return self._probe_neighbours(target, window, float(x), float(y))

    def _probe_neighbours(self, target, window, x, y):
        """Nothing with the recorded identity at the recorded spot: look one or two cells / rows / buttons around it.
        Accepts only a UNIQUE neighbour that carries the recorded name (never 'whatever is nearby')."""
        if not self.o.get("probe_neighbours", True):
            return None
        r = target.get("rect")
        sx, sy = ((r[2] - r[0]), (r[3] - r[1])) if geometry.valid(r) else (40, 24)
        sx, sy = max(8, sx), max(8, sy)
        found = []
        for px, py in evidence.ring((x, y), sx, sy, int(self.o.get("neighbour_radius", 2))):
            el = self.governor.call(window, lambda a=px, b=py: winenv.element_at(int(a), int(b)))
            if el and geometry.valid(el.get("rect")) and self._same_element(el, target):
                key = tuple(el["rect"])
                if all(key != k for k, _ in found):
                    found.append((key, el))
        if len(found) != 1:
            return None
        res = self._from_native(found[0][1], target)
        res.method = "point"
        res.confidence = 0.9
        res.evidence["neighbour_probe"] = True
        return res

    def _t_uia(self, target, window, st):
        if not self._native_turn(st, window, target):
            return None
        probe = target
        if st["split_xpath"] and (target.get("xpath") or target.get("rxpath")):
            probe = {k: v for k, v in target.items() if k not in ("xpath", "rxpath")}
        el = self.governor.call(window, lambda: self.plugins.get_plugin_for(window).find_element_native(probe, window))
        if not el and target.get("inspect_xpath") and not (target.get("xpath") or target.get("rxpath")):
            # second chance: the window-scoped path captured at record time (Window > Pane > ... > Control)
            hint = {**target, "xpath": target["inspect_xpath"], "_xpath_only": True}
            el = self.governor.call(window, lambda: self.plugins.get_plugin_for(window).find_element_native(hint, window))
        return self._from_native(el, target) if el else None

    def _t_xpath(self, target, window, st):
        if not (target.get("xpath") or target.get("rxpath")) or not self._native_turn(st, window, target):
            return None
        el = self.governor.call(window, lambda: self.plugins.get_plugin_for(window).find_element_native(
            {**target, "_xpath_only": True}, window))
        return self._from_native(el, target) if el else None

    def _t_image(self, target, window, st):
        frame, origin = self._frame(st)
        stages = self.search_stages(target, frame, origin)
        tpls = [(key, tp) for key, tp in (("300", st["c300"]), ("100", st["c100"])) if tp]
        # Stage-major: both pictures are tried in the SMALL area around the stored spot before any larger area is
        # scanned. (Was picture-major: the 300 px picture was searched across the whole screen first, ~1 s per click
        # whenever the surroundings had changed and only the 100 px picture still matched.)
        for stage, (x0, y0, x1, y1) in stages:
            for key, (img, click) in tpls:
                r = self.locator.find_by_template(frame[y0:y1, x0:x1], img)
                if r.found:
                    x, y = self._template_target(r.x + x0, r.y + y0, click, img.shape[:2], r.scale, origin)
                    return Resolution(x, y, f"template({key})", r.confidence,
                                      evidence={"scale": r.scale, "second_confidence": r.second_confidence, "stage": stage})
                if r.ambiguous:                        # two look-alikes: a bigger area cannot make this clearer
                    st["template_ambiguous"] = True
                    break
            if st["template_ambiguous"]:
                break
        if st["template_ambiguous"]:
            picked = (self._layout_point(target) or self._disambiguate_image(target, window, st, frame, origin, tpls)
                      or (None if self.o.get("strict_targeting", True) else self._nearest_look_alike(target, frame, origin, tpls)))
            if picked:
                return picked
        if st["template_ambiguous"] and self.o.get("strict_targeting", True) and not target.get("allow_ambiguous_image") \
                and not target.get("search_quadrant"):          # a chosen quadrant is the user's way to tell look-alikes apart
            raise AmbiguousTarget("The picture of the target matches two or more places on screen with almost the same "
                                  "score; refusing to click one of them. Add a container/search region or a larger picture.",
                                  detail={"tier": "image"})
        return None

    def _recorded_point(self, target):
        """The recorded click spot, already moved with the window by ``_prepare`` (None when nothing was recorded)."""
        x, y = target.get("x"), target.get("y")
        if x is not None and y is not None:
            return float(x), float(y)
        rect = target.get("rect")
        if geometry.valid(rect):
            rel = target.get("rel")
            rel = rel if isinstance(rel, (list, tuple)) and len(rel) >= 2 else (0.5, 0.5)
            return rect[0] + (rect[2] - rect[0]) * rel[0], rect[1] + (rect[3] - rect[1]) * rel[1]
        return None

    def _text_verdict(self, target, window, x, y):
        """True = the element at (x, y) carries the recorded text/name; False = it carries different text; None = unknown."""
        want = str(target.get("name") or target.get("text") or "").strip()
        if not want or not self.o.get("use_native", True) or not self.governor.allowed(window, target):
            return None
        el = self.governor.call(window, lambda: winenv.element_at(int(x), int(y)))
        got = str((el or {}).get("name") or "").strip()
        if not got:
            return None
        return got.casefold() == want.casefold()

    def _layout_point(self, target):
        """Identical-looking cells / rows (an empty spreadsheet grid): the picture cannot tell them apart, but the window
        is exactly where and as big as when recorded, so the recorded coordinate IS that element. The coordinate wins
        over a coin toss between look-alikes (and over 'the nearest look-alike', which is the neighbouring cell)."""
        if not (self._layout_same and self.o.get("layout_coordinates", True)):
            return None
        rec = self._recorded_point(target)
        if rec is None:
            return None
        return Resolution(int(rec[0]), int(rec[1]), "coordinates(layout)", 0.9,
                          evidence={"verified_by": "window at its recorded position and size; the picture matches several "
                                                   "identical places, so the recorded coordinate decides"})

    def _nearest_look_alike(self, target, frame, origin, tpls):
        """Classic profile, nothing else decides: of the look-alikes, the one nearest the recorded spot (never the first
        one in scan order, which is what a plain best-score pick gives)."""
        rec = self._recorded_point(target)
        if rec is None or not tpls:
            return None
        (key, (img, click)) = tpls[0]
        hits = self.locator.find_all_by_template(frame, img, threshold=self.locator.TEMPLATE_THRESHOLD)
        if not hits:
            return None
        top = hits[0][2]
        h, w = img.shape[:2]
        pts = [(self._template_target(cx, cy, click, (h, w), 1.0, origin), sc) for cx, cy, sc in hits if sc >= top - 0.03]
        (x, y), sc = min(pts, key=lambda p: evidence.distance(p[0], rec))
        return Resolution(int(x), int(y), f"template({key})", float(sc),
                          evidence={"disambiguated_by": "nearest look-alike to the recorded position", "candidates": len(pts)})

    def _disambiguate_image(self, target, window, st, frame, origin, tpls):
        """Look-alike pictures (cells, rows, icons): choose by recorded position + text instead of refusing."""
        if not self.o.get("disambiguate_by_position", True) or not tpls:
            return None
        rec = self._recorded_point(target)
        if rec is None:
            return None
        (key, (img, click)) = tpls[0]
        hits = self.locator.find_all_by_template(frame, img, threshold=self.locator.TEMPLATE_THRESHOLD)
        if len(hits) < 2:
            return None
        h, w = img.shape[:2]
        pts = [self._template_target(cx, cy, click, (h, w), 1.0, origin) for cx, cy, _ in hits]
        tol = max(float(self.o.get("disambiguation_radius_px", 0)) or 0.0, 1.5 * math.hypot(w, h), 40.0)
        verdicts = [self._text_verdict(target, window, px, py) for px, py in pts]
        pick = evidence.choose(pts, rec, tol, verdicts)
        if not pick:
            return None
        x, y = pts[pick.index]
        conf = max(float(self.o.get("min_action_confidence", 0.85)), min(0.95, hits[pick.index][2]))
        return Resolution(int(x), int(y), f"template({key})", conf, evidence={
            "disambiguated_by": "recorded position" + (" + text" if verdicts[pick.index] else ""),
            "candidates": len(pts), "distance_px": round(pick.distance, 1), "reason": pick.reason,
            "text_verified": bool(verdicts[pick.index])})

    def _ocr_text_at(self, frame, origin, point, size):
        from core.ocr import ocr_engine
        img = effect.crop(frame, effect.region_around(point, frame.shape, size, origin))
        return ocr_engine.read_all_text(img) if img is not None else ""

    def _t_coordtext(self, target, window, st):
        """The recorded coordinate (moved with the window), accepted ONLY when the required text is really there.
        Coordinates alone are never trusted: the same spot may now hold a different control."""
        label = self._label(target)
        rec = self._recorded_point(target)
        if not label or rec is None or st["attempt"] > 2 or self._ocr_broken or not self.o.get("use_ocr", True):
            return None
        frame, origin = self._frame(st)
        r = target.get("rect")
        w, h = ((r[2] - r[0]), (r[3] - r[1])) if geometry.valid(r) else (120, 40)
        try:
            seen = self._ocr_text_at(frame, origin, rec, (max(140, int(w) + 60), max(70, int(h) + 40)))
        except Exception as exc:
            log.info("coordinate text check disabled for this run: %s", exc)
            self._ocr_broken = True
            return None
        if not effect.text_in(seen, label):
            return None
        return Resolution(int(rec[0]), int(rec[1]), "coordinates(verified)", 0.9,
                          evidence={"verified_by": "text at the recorded point", "ocr_text": seen[:60]})

    @staticmethod
    def _what(target: dict, window: dict) -> str:
        from core.ai import describe
        phrase = describe.element_phrase(target) or "the element"
        title = (window or {}).get("title")
        return f"{phrase}" + (f" in the window '{title}'" if title else "")

    def _t_vision(self, target, window, st):
        """An AI looks at the screenshot. Its answer is a CANDIDATE: acted on only when the required text is read at
        that point (UI Automation or OCR). A target without text cannot be verified, so it is not clicked."""
        adv = self.vision_advisor
        if adv is None and self.o.get("use_vision_ai", True):
            from core.ai.vision_advisor import VisionAdvisor
            adv = self.vision_advisor = VisionAdvisor()
        label = self._label(target)
        if adv is None or not label or st["attempt"] < 1 or self._vision_tried or not self.o.get("use_vision_ai", True):
            return None
        self._vision_tried = True
        frame, origin = self._frame(st)
        rec = self._recorded_point(target)
        try:
            ans = adv.locate(frame, self._what(target, window), (rec[0] - origin[0], rec[1] - origin[1]) if rec else None)
        except Exception as exc:
            log.info("vision advisor failed: %s", exc)
            return None
        if not ans:
            return None
        x, y = ans["x"] + origin[0], ans["y"] + origin[1]
        verdict = self._text_verdict(target, window, x, y)
        if verdict is None:
            try:
                verdict = effect.text_in(self._ocr_text_at(frame, origin, (x, y), (200, 90)), label)
            except Exception:
                verdict = False
        if not verdict:
            return None
        return Resolution(int(x), int(y), "vision(verified)", 0.88,
                          evidence={"verified_by": "text at the point the AI chose", "ai_text": ans.get("text", "")})

    def _t_orb(self, target, window, st):
        # ORB is visual-only: it cannot choose between duplicate template matches.
        if not st["c300"] or st["template_ambiguous"]:
            return None
        frame, origin = self._frame(st)
        img, click = st["c300"]
        for stage, (x0, y0, x1, y1) in self.search_stages(target, frame, origin):
            r = self.locator.find_point_by_features(frame[y0:y1, x0:x1], img, click)
            if r.found and r.confidence >= self._recovery_threshold():
                return self._healed(frame, origin, r.x + x0 + origin[0], r.y + y0 + origin[1], "orb", r.confidence,
                                    {"score": r.confidence, "stage": stage})
        return None

    def _scope(self, target: dict) -> str:
        return target.get("search_scope") or target.get("ocr_search") or self.o.get("ocr_search", "local_then_screen")

    def search_stages(self, target: dict, frame, origin) -> list[tuple[str, tuple[int, int, int, int]]]:
        """Where to look, smallest first: your explicit region -> around the stored spot -> the zone (pane) it lives in
        -> the whole window -> the whole screen. Used by image, ORB and OCR tiers alike (smaller area = faster and
        fewer look-alikes). ``search_scope``: local_then_screen (default) | local_only | screen_only."""
        h, w = frame.shape[:2]
        mode = self._scope(target)
        full = ("screen", (0, 0, w, h))
        if mode == "screen_only":
            return [full]

        def clip(x0, y0, x1, y1):
            return max(0, int(x0)), max(0, int(y0)), min(w, int(x1)), min(h, int(y1))

        def ok(rect):
            return rect[2] - rect[0] >= 8 and rect[3] - rect[1] >= 8

        fixed: list[tuple[str, tuple]] = []
        reg = target.get("search_region") or target.get("ocr_region")
        if isinstance(reg, (list, tuple)) and len(reg) == 4 and all(isinstance(v, (int, float)) for v in reg):
            rect = clip(reg[0] - origin[0], reg[1] - origin[1], reg[0] + reg[2] - origin[0], reg[1] + reg[3] - origin[1])
            if ok(rect):
                fixed.append(("region", rect))
        auto: list[tuple[str, tuple]] = []
        zone = target.get("zone") if isinstance(target.get("zone"), dict) else None
        has_context = False
        if zone and geometry.valid(zone.get("rect")):
            zr = zone["rect"]
            rect = clip(zr[0] - origin[0] - 12, zr[1] - origin[1] - 12, zr[2] - origin[0] + 12, zr[3] - origin[1] + 12)
            if ok(rect):
                auto.append(("zone", rect))
                has_context = True
        if geometry.valid(self._win_rect):
            wr = self._win_rect
            rect = clip(wr[0] - origin[0], wr[1] - origin[1], wr[2] - origin[0], wr[3] - origin[1])
            if ok(rect):
                auto.append(("window", rect))
                has_context = True
        if "x" in target and "y" in target and (target.get("x") or target.get("y")):
            cx, cy = int(target["x"]) - origin[0], int(target["y"]) - origin[1]
            r = int(target.get("ocr_radius") or self.o.get("ocr_radius", 220))
            auto.append(("near", clip(cx - r, cy - r, cx + r, cy + r)))
            if not has_context:
                auto.append(("wider", clip(cx - int(r * 2.4), cy - int(r * 2.4), cx + int(r * 2.4), cy + int(r * 2.4))))
        stages = list(fixed)
        prev_area = 0
        for name, rect in sorted(auto, key=lambda s: (s[1][2] - s[1][0]) * (s[1][3] - s[1][1])):
            area = (rect[2] - rect[0]) * (rect[3] - rect[1])
            if area >= 0.85 * w * h or area < 1.15 * prev_area or any(rect == f[1] for f in stages):
                continue                                   # nearly the same as a smaller stage already scheduled
            stages.append((name, rect))
            prev_area = area
        if mode != "local_only" or not stages:
            stages.append(full)
        return stages

    # kept for callers/tests that only care about OCR
    def ocr_stages(self, target: dict, frame, origin) -> list[tuple[str, tuple[int, int, int, int]]]:
        return self.search_stages(target, frame, origin)

    @staticmethod
    def _label(target: dict) -> str:
        """The text to look for: the control's text/name, else the label OCR read at record time (noisy -> only used by
        the local / coordinate / vision rungs, never for a whole-screen search)."""
        return str(target.get("text") or target.get("name") or target.get("ocr_label") or "").strip()

    LOCAL_STAGES = ("region", "zone", "near", "wider")        # beside the recorded spot / in its pane
    WIDE_STAGES = ("window", "screen")                       # the whole window, then the whole screen

    def _t_ocr_local(self, target, window, st):
        return self._t_ocr(target, window, st, stages=self.LOCAL_STAGES, phase="local")

    def _t_ocr_wide(self, target, window, st):
        return self._t_ocr(target, window, st, stages=self.WIDE_STAGES, phase="wide")

    def _t_ocr(self, target, window, st, stages=None, phase="all"):
        label = (target.get("text") or target.get("name")) if phase in ("all", "wide") else self._label(target)
        now = time.monotonic()
        if not (self.o.get("use_ocr", True) and label and not self._ocr_broken
                and now - self._last_ocr_by.get(phase, 0.0) > (0.4 if stages else 1.5)):
            return None
        if (stages is None and st.get("attempt", 1) < 1 and (st.get("c300") or st.get("c100"))
                and "ocr" not in (target.get("locator_order") or [])[:1]):
            return None     # recorded pictures exist: give the image tiers one more poll before paying for OCR
        self._last_ocr_by[phase] = now
        self._last_ocr = now
        frame, origin = self._frame(st)
        try:
            from core.ocr import ocr_engine

            has_xy = "x" in target and "y" in target
            t_start = time.monotonic()
            budget = float(self.o.get("ocr_budget_s", 8.0))
            for name, (x0, y0, x1, y1) in self.search_stages(target, frame, origin):
                if stages is not None and name not in stages:
                    continue
                if time.monotonic() - t_start > budget:
                    log.info("OCR locate exceeded %.0fs - OCR location is off for the rest of this run", budget)
                    self._ocr_broken = True          # a slow engine must not make every later step slow too
                    break
                near = (int(target["x"] - origin[0]) - x0, int(target["y"] - origin[1]) - y0) if has_xy else None
                m = ocr_engine.find_text(frame[y0:y1, x0:x1], label, min_confidence=self._recovery_threshold(), near=near)
                if m.found:
                    return self._healed(frame, origin, m.x + x0 + origin[0], m.y + y0 + origin[1], "ocr", m.confidence,
                                        {"matched_text": m.matched_text, "ocr_stage": name, "ladder": phase})
        except Exception as e:
            log.info("OCR tier disabled for this run: %s", e)
            self._ocr_broken = True
        return None

    def _t_ai(self, target, window, st):
        if st["attempt"] < 1 or not st["c100"] or not self.o.get("use_ai", True):
            return None   # slow tier: only after the cheap ones failed once
        frame, origin = self._frame(st)
        img, click = st["c100"]
        h, w = img.shape[:2]
        tx, ty = target.get("x", 0) - origin[0], target.get("y", 0) - origin[1]
        if self._ai_full:
            region, off, stride = frame, (0, 0), 64
        else:
            region, off = self._region(frame, tx, ty, 500)
            stride = 24
        self._ai_full = not self._ai_full
        m = self.ai.find_similar(region, img, stride=stride, threshold=max(0.90, self._recovery_threshold()))
        if m.found and m.backend == "classical":
            # the classical embedding is coarse: only trust matches near where the element used to be
            if abs(m.x + off[0] - tx) > self.AI_CLASSICAL_MAX_DIST or abs(m.y + off[1] - ty) > self.AI_CLASSICAL_MAX_DIST:
                m.found = False
        if m.found:
            return self._healed(frame, origin, m.x + off[0] + click[0] - w // 2 + origin[0],
                                m.y + off[1] + click[1] - h // 2 + origin[1], "ai", m.score,
                                {"backend": m.backend, "score": m.score})
        return None

    def _t_heal(self, target, window, st):
        if st["attempt"] < 1 or not st["c100"] or st["template_ambiguous"]:
            return None
        frame, origin = self._frame(st)
        img, click = st["c100"]
        tx, ty = target.get("x", 0) - origin[0], target.get("y", 0) - origin[1]
        hr = self.healer.heal(frame, img, int(tx), int(ty), threshold=self._recovery_threshold())
        if hr.healed:
            x, y = self._template_target(hr.x, hr.y, click, img.shape[:2], hr.scale, origin)
            return self._healed(frame, origin, x, y, f"heal(r={hr.radius_used})", hr.confidence,
                                {"radius": hr.radius_used, "scale": hr.scale})
        return None

    def _t_layout_local(self, target, window, st):
        """Last resort for plain UI that has no name and no distinctive picture (a column header, a blank cell): the window
        is exactly where and as big as when recorded, so the recorded point is where the element is. Accepted only when the
        recorded picture still looks at least roughly like what is on screen there (0.6 correlation inside a small box) -
        never a blind click, and never when the layout moved."""
        if st["attempt"] < 1 or not self.o.get("layout_coordinates", True):
            return None
        rec = self._recorded_point(target)
        if rec is None:
            return None
        cell = self._merged_cell_point(target, window, rec) if st["attempt"] >= 3 else None
        if cell:
            return cell
        tp = st["c100"] or st["c300"]
        if not self._layout_same or not tp:
            return None
        frame, origin = self._frame(st)
        img, _click = tp
        h, w = img.shape[:2]
        cx, cy = int(rec[0] - origin[0]), int(rec[1] - origin[1])
        pad = 24
        x0, y0 = max(0, cx - w // 2 - pad), max(0, cy - h // 2 - pad)
        x1, y1 = min(frame.shape[1], cx + w // 2 + pad), min(frame.shape[0], cy + h // 2 + pad)
        if x1 - x0 < w or y1 - y0 < h:
            return None
        r = self.locator.find_by_template(frame[y0:y1, x0:x1], img, scales=(1.0,), threshold=0.6)
        if r.confidence < 0.6:
            return None
        return Resolution(int(rec[0]), int(rec[1]), "coordinates(layout+picture)", min(0.88, max(0.6, r.confidence)),
                          evidence={"verified_by": "window at recorded position/size and the recorded picture is there",
                                    "picture_score": round(r.confidence, 3)})

    def _merged_cell_point(self, target, window, rec):
        """A cell (M9) merged with others after recording: UI Automation has no cell called 'M9' any more and its picture
        changed. The recorded point (moved with the window) is still inside the merged block. Accepted only when what is
        under that point is a cell / merged block; without UI Automation only if the window is exactly as recorded."""
        want = str(target.get("name") or target.get("automation_id") or target.get("text") or "").strip()
        if not excel_com.looks_like_address(want):
            return None
        el = None
        if self.o.get("use_native", True) and self.governor.allowed(window, target):
            try:
                el = self.governor.call(window, lambda: winenv.element_at(int(rec[0]), int(rec[1])))
            except Exception:                                 # noqa: BLE001
                el = None
        if el and (el.get("name") or el.get("role")):
            role = str(el.get("role") or "").casefold()
            cls = str(el.get("class_name") or "").casefold()
            nm = str(el.get("name") or "")
            cellish = (role in ("dataitem", "cell", "custom", "pane", "") or "spreadsheet" in cls or "excel" in cls
                       or excel_com.looks_like_address(nm.split(":")[0].strip()) or ":" in nm)
            if not cellish or role in ("button", "menuitem", "tabitem", "edit"):
                return None
        elif not self._layout_same:
            return None
        return Resolution(int(rec[0]), int(rec[1]), "coordinates(layout+cell)", 0.86,
                          evidence={"verified_by": "recorded point is inside a cell / merged block", "cell": want,
                                    "under_point": (el or {}).get("name", "")})

    def _t_coordinates(self, target, window, st):
        """Opt-in blind fallback: click the stored position, but only if the expected window is in front."""
        if "x" not in target or "y" not in target or st["attempt"] < 1:
            return None
        title = (window or {}).get("title", "")
        if title:
            try:
                fg = winenv.foreground_window()
            except Exception:
                return None
            if title.casefold() not in str(fg.get("title", "")).casefold():
                return None
            r = fg.get("rect")
            if r and not (r[0] <= target["x"] <= r[2] and r[1] <= target["y"] <= r[3]):
                return None
        return Resolution(int(target["x"]), int(target["y"]), "coordinates(fallback)", 0.3,
                          evidence={"warning": "blind stored-position fallback; no element was verified"})


    # ---- explicit position + four-quadrant search -------------------------------------------------------------------
    def _live_rect(self, spec, window: dict):
        """Current rect of a container / anchor described by name or automation id (None if it cannot be found)."""
        if not isinstance(spec, dict):
            return None
        crit = {k: spec[k] for k in ("name", "role", "automation_id") if spec.get(k)}
        if crit:
            el = self.governor.call(window, lambda c=crit: self.plugins.get_plugin_for(window).find_element_native(c, window))
            if el and geometry.valid(el.get("rect")):
                return el["rect"]
        return None

    def _t_position(self, target, window, st):
        """Explicit coordinates relative to the CURRENT window / container / anchor (never stale screen points)."""
        spec = target.get("position")
        if not isinstance(spec, dict):
            return None
        mode = spec.get("mode")
        win_rect = self._win_rect
        cont = self._live_rect(target.get("container"), window) if mode == "container" else None
        anchor = self._live_rect(spec.get("anchor"), window) if mode == "anchor" else None
        try:
            x, y = position.compute(spec, win_rect, cont, anchor)
        except (ValueError, KeyError) as exc:
            raise LowConfidenceTarget(f"position locator cannot be evaluated: {exc}", "position", 0.0) from exc
        bounds = {"window": win_rect, "container": cont}.get(mode) or (win_rect if mode in ("normalized",) else None)
        if bounds and not position.inside((x, y), bounds):
            raise LowConfidenceTarget(f"position ({x},{y}) falls outside the {mode} rectangle {list(bounds)}", "position", 0.0)
        conf = 0.55 if mode == "absolute" else 0.8
        return Resolution(x, y, "position", conf, evidence={"mode": mode, "window_rect": list(win_rect) if win_rect else None})

    def _t_quadrant(self, target, window, st):
        spec = target.get("search_quadrant")
        if not spec or st.get("attempt", 1) > 3:
            return None
        win_rect = self._win_rect
        if not geometry.valid(win_rect):
            return None
        frame, origin = self._frame(st)
        label = target.get("text") or target.get("name")
        tpls = [tp for tp in (st.get("c300"), st.get("c100")) if tp]
        mode = target.get("text_match", "contains")
        thr = max(self._recovery_threshold(), float(self.o.get("min_action_confidence", 0.85)))

        def finder(rect):
            # grow the region by the picture's size so a target straddling a quadrant border is still seen whole
            mh, mw = (tpls[0][0].shape[:2]) if tpls else (0, 0)
            x0, y0 = max(0, rect[0] - origin[0] - mw), max(0, rect[1] - origin[1] - mh)
            x1, y1 = min(frame.shape[1], rect[2] - origin[0] + mw), min(frame.shape[0], rect[3] - origin[1] + mh)
            if x1 - x0 < 8 or y1 - y0 < 8:
                return []
            region, out = frame[y0:y1, x0:x1], []
            for img, click in tpls[:1]:
                r = self.locator.find_by_template(region, img)
                if r.found:
                    px, py = self._template_target(r.x + x0, r.y + y0, click, img.shape[:2], r.scale, origin)
                    out.append(quadrants.Candidate(px, py, r.confidence, "template"))
                elif r.ambiguous:
                    raise AmbiguousTarget("Two look-alikes inside the searched quadrant; narrow the search or the picture.",
                                          detail={"tier": "quadrant"})
            if label and self.o.get("use_ocr", True) and not self._ocr_broken:
                from core.automation import textloc
                try:
                    for h in textloc.find_all(region, str(label), mode, bool(target.get("case_sensitive")),
                                              origin=(x0 + origin[0], y0 + origin[1])):
                        out.append(quadrants.Candidate(h.x, h.y, h.confidence, "ocr", rect=h.rect, text=h.text))
                except Exception as exc:
                    log.info("quadrant OCR unavailable: %s", exc)
                    self._ocr_broken = True
            return out

        result = quadrants.search(win_rect, finder, spec, int(target.get("quadrant_depth", 2)), thr, abort=self.abort_check)
        if result.status == "found":
            c = result.chosen
            return Resolution(c.x, c.y, f"quadrant({c.source})", c.confidence, evidence={
                "quadrant": c.quadrant, "searched": result.searched, "text": c.text})
        if result.status == "ambiguous":
            raise AmbiguousTarget(f"Quadrant search: {result.reason}",
                                  [{"x": c.x, "y": c.y, "confidence": round(c.confidence, 3), "source": c.source,
                                    "quadrant": c.quadrant} for c in result.candidates[:8]],
                                  {"searched": result.searched})
        return None

    # ------------------------------------------------------------ helpers
    @staticmethod
    def _from_native(el: dict, target: dict) -> Resolution:
        l, t, r, b = el["rect"]
        rel = target.get("rel")
        has_rel = isinstance(rel, (list, tuple)) and len(rel) >= 2
        x = l + (r - l) * rel[0] if has_rel else (l + r) / 2
        y = t + (b - t) * rel[1] if has_rel else (t + b) / 2
        evidence = {k: el[k] for k in ("name", "role", "automation_id", "class_name") if el.get(k)}
        if el.get("via") == "xpath-heal":      # the XPath itself no longer matched: this is a guess, say so
            evidence.update(suggested_xpath=el.get("suggested_xpath", ""), heal_score=el.get("heal_score", 0))
            return Resolution(int(x), int(y), "xpath-heal", float(el.get("heal_score", 0.8)), healed=False, evidence=evidence)
        if el.get("is_enabled") is False or el.get("enabled") is False:
            evidence["disabled"] = True
        return Resolution(int(x), int(y), "native", 1.0, evidence=evidence)

    @staticmethod
    def _template_target(center_x: int, center_y: int, click: tuple[float, float],
                         template_shape: tuple[int, int], scale: float,
                         origin: tuple[int, int]) -> tuple[int, int]:
        """Map the recorded click offset through the selected template scale."""
        height, width = template_shape
        scaled_w = max(4, int(width * scale))
        scaled_h = max(4, int(height * scale))
        x = center_x + round(click[0] * scale) - scaled_w // 2 + origin[0]
        y = center_y + round(click[1] * scale) - scaled_h // 2 + origin[1]
        return int(x), int(y)

    @staticmethod
    def _region(frame, cx: int, cy: int, radius: int):
        h, w = frame.shape[:2]
        x0, y0 = max(0, int(cx) - radius), max(0, int(cy) - radius)
        x1, y1 = min(w, int(cx) + radius), min(h, int(cy) + radius)
        return frame[y0:y1, x0:x1], (x0, y0)

    def _healed(self, frame, origin, x, y, method, conf, evidence=None) -> Resolution:
        crops = {}
        for size in (100, 300):
            crop, click = winenv.crop_around(frame, origin, x, y, size)
            crops[size] = (crop.copy(), click)
        return Resolution(int(x), int(y), method, float(conf), healed=True, crops=crops,
                          evidence=dict(evidence or {}))

    def _tpl(self, target: dict, key: str):
        info = (target.get("templates") or {}).get(key)
        if not info or not self.dir:
            return None
        path = self.dir / info["path"]
        if path not in self._cache:
            self._cache[path] = imread(path)
        img = self._cache[path]
        return (img, tuple(info["click"])) if img is not None else None

    def _explain(self, target: dict, window: dict, timeout: float) -> str:
        from core.ai.describe import element_phrase

        tiers = ["template", "ORB"]
        if self.o.get("use_native", True):
            tiers.insert(0, "UI Automation (element at the recorded place, then by name)")
        if self.o.get("use_ocr", True) and not self._ocr_broken:
            tiers.append("OCR")
        if self.o.get("use_ai", True):
            tiers.append("AI similarity")
        tiers.append("self-heal")
        title = window.get("title", "")
        return (f"Could not find {element_phrase(target)}" + (f" in '{title}'" if title else "")
                + f" within {timeout:g}s (tried: {', '.join(tiers)})")
