"""
Application Context and Lifecycle Manager for VisionAuto.

Coordinates multi-application test runs, application switching, window activation,
safe variable interpolation (${var_name}), cross-application data flow,
and isolated process lifecycle management.
"""
from __future__ import annotations

import logging
import os
import re
import subprocess
import time
from copy import deepcopy
from datetime import datetime
from pathlib import Path
from typing import Any

from core import applications
from core.playback.resolver import ElementNotFound
from core.system import winenv

log = logging.getLogger("visionauto.app_context")

DANGEROUS_BINARIES = {
    "cmd", "cmd.exe", "powershell", "powershell.exe", "pwsh", "pwsh.exe",
    "bash", "sh", "wscript", "cscript", "mshta", "regsvr32", "rundll32",
}

VAR_PATTERN = re.compile(r"\$\{([a-zA-Z0-9_\-]+)\}")


class UnknownApplication(ValueError):
    """A step names an application alias the test does not define."""


class AmbiguousTarget(ValueError):
    """More than one window/process matches; refuse to guess."""


class ApplicationLost(RuntimeError):
    """The application exited or its window disappeared while the test was running."""


class UndefinedVariable(ValueError):
    pass


class ApplicationInstance:
    """Represents a live or simulated application instance in a test execution session."""

    def __init__(self, alias: str, definition: dict, mode: str = "attach_or_launch"):
        self.alias = alias
        self.definition = deepcopy(definition)
        self.app_id = definition.get("id", alias)
        self.app_type = definition.get("type", "desktop")
        self.mode = mode  # "launch", "attach", "attach_or_launch"
        self.process: subprocess.Popen | None = None
        self.pid: int | None = None
        self.hwnd: int | None = None
        self.title: str = definition.get("window_title", "")
        self.launched_by_test: bool = False
        self.status: str = "initialized"  # "initialized", "running", "attached", "stopped", "failed"
        self.switch_count: int = 0
        self.started_at: str = ""
        self.ready_at: str = ""
        self.last_activity: str = ""
        self.error: str = ""
        self.startup_ms: int = 0

    def to_dict(self) -> dict:
        return {
            "alias": self.alias,
            "app_id": self.app_id,
            "type": self.app_type,
            "mode": self.mode,
            "pid": self.pid,
            "hwnd": self.hwnd,
            "title": self.title,
            "launched_by_test": self.launched_by_test,
            "status": self.status,
            "switch_count": self.switch_count,
            "started_at": self.started_at,
            "ready_at": self.ready_at,
            "last_activity": self.last_activity,
            "startup_ms": self.startup_ms,
            "error": self.error,
        }


class AppContextManager:
    """Manages multi-application execution lifecycle, switching, and variable exchange."""

    def __init__(self, app_defs: list[dict] | None = None, variables: dict | None = None,
                 dry_run: bool = False, opts: dict | None = None):
        self.dry_run = dry_run
        self.opts = opts or {}
        self.definitions: dict[str, dict] = {}
        self.instances: dict[str, ApplicationInstance] = {}
        self.variables: dict[str, Any] = deepcopy(variables or {})
        self.active_alias: str | None = None
        self.switch_history: list[dict] = []

        if app_defs:
            for d in app_defs:
                alias = d.get("alias") or d.get("id") or "default"
                self.definitions[alias] = deepcopy(d)

    @classmethod
    def from_test(cls, test_data: dict, dry_run: bool = False, opts: dict | None = None) -> AppContextManager:
        """Create an AppContextManager initialized from a test definition dictionary."""
        variables = test_data.get("variables") or {}
        raw_apps = test_data.get("applications") or []
        app_defs = []

        if raw_apps:
            for item in raw_apps:
                alias = item.get("alias") or "default"
                # If app specifies an app_id, try to pull configuration from registry
                app_id = item.get("app_id")
                registered = applications.get_app(app_id) if app_id else None
                combined = deepcopy(registered) if registered else {}
                combined.update(item)
                combined["alias"] = alias
                app_defs.append(combined)
        elif test_data.get("app"):
            # Legacy test with single app definition
            legacy_app = test_data["app"]
            app_defs.append({
                "alias": "default",
                "id": "default",
                "name": legacy_app.get("title") or legacy_app.get("process") or "Default App",
                "type": "desktop",
                "process_name": legacy_app.get("process", ""),
                "window_title": legacy_app.get("title", ""),
                "mode": "attach_or_launch",
            })

        return cls(app_defs=app_defs, variables=variables, dry_run=dry_run, opts=opts)

    # ----------------------------------------------------------------- Variables
    def get_variable(self, name: str, default: Any = None) -> Any:
        return self.variables.get(name, default)

    def set_variable(self, name: str, value: Any) -> None:
        clean_name = str(name).strip()
        if not clean_name:
            raise ValueError("Variable name cannot be empty.")
        self.variables[clean_name] = value
        log.info("Variable set: %s = %r", clean_name, value)

    def substitute_variables(self, val: Any, strict: bool = False) -> Any:
        """Substitute ${var_name} placeholders in strings, lists and dicts. Never uses eval.

        strict=True raises UndefinedVariable instead of leaving the placeholder in place,
        so a typo cannot silently type the literal text '${usre}' into an application.
        """
        if isinstance(val, str):
            def replacer(match):
                var_name = match.group(1)
                if var_name in self.variables:
                    return str(self.variables[var_name])
                if strict:
                    raise UndefinedVariable(f"Variable '${{{var_name}}}' is not defined.")
                return match.group(0)  # Preserve placeholder if not found

            return VAR_PATTERN.sub(replacer, val)
        elif isinstance(val, list):
            return [self.substitute_variables(item, strict) for item in val]
        elif isinstance(val, dict):
            return {k: self.substitute_variables(v, strict) for k, v in val.items()}
        return val

    # ----------------------------------------------------------------- Lifecycle
    def startup_order(self) -> list[str]:
        from core.validation import startup_order

        return startup_order(list(self.definitions.values()))

    def start_all(self) -> None:
        """Bring up every application marked startup='start', dependencies first."""
        for alias in self.startup_order():
            if self.definitions[alias].get("startup", "lazy") == "start":
                self.ensure_app(alias)

    def _is_lost(self, inst: ApplicationInstance) -> str:
        """Reason string if a running instance has gone away, else ''."""
        if self.dry_run:
            return ""
        title = inst.title or inst.definition.get("window_title", "")
        exited = inst.process is not None and inst.process.poll() is not None
        window_gone = bool(title) and not winenv.window_exists(title)
        if exited and window_gone:
            return f"process exited (code {inst.process.returncode}) and its window '{title}' is gone"
        if inst.hwnd and window_gone and inst.status == "attached":
            return f"window '{title}' is no longer present"
        return ""

    def ensure_app(self, alias: str, _trail: tuple = ()) -> ApplicationInstance:
        """Ensure the specified application is running and tracked. Unknown aliases are an error, never guessed."""
        alias = alias.strip()
        existing = self.instances.get(alias)
        if existing and existing.status in ("running", "attached"):
            lost = self._is_lost(existing)
            if lost:
                existing.status = "failed"
                existing.error = f"Application lost: {lost}"
                raise ApplicationLost(f"Application '{alias}' was lost during the test: {lost}.")
            return existing
        if existing and existing.status == "failed":
            raise ApplicationLost(f"Application '{alias}' failed earlier in this test: {existing.error}")

        defn = self.definitions.get(alias)
        if not defn:
            reg_app = applications.get_app(alias)
            if not reg_app:
                known = ", ".join(sorted(self.definitions)) or "none"
                raise UnknownApplication(
                    f"Application '{alias}' is not defined in this test (defined: {known}); refusing to act on an unrelated window.")
            defn = reg_app
            defn["alias"] = alias
            self.definitions[alias] = defn

        if alias in _trail:
            raise ValueError("Application startup dependencies form a cycle: " + " -> ".join(_trail + (alias,)))
        for dep in defn.get("depends_on") or []:
            self.ensure_app(dep, _trail + (alias,))

        mode = defn.get("mode", "attach_or_launch")
        inst = ApplicationInstance(alias, defn, mode=mode)
        inst.started_at = datetime.now().isoformat(timespec="seconds")
        t0 = time.monotonic()
        self.instances[alias] = inst   # recorded before launching so failures appear in the report

        if self.dry_run:
            inst.status = "attached" if mode == "attach" else "running"
            inst.pid = None
            return inst

        try:
            if mode == "attach":
                self._attach_application(inst)
            elif mode == "launch":
                self._launch_application(inst)
            elif mode == "attach_or_launch":
                try:
                    self._attach_application(inst)
                except AmbiguousTarget:
                    raise
                except Exception:
                    log.info("Application '%s' not currently running to attach; attempting launch.", alias)
                    self._launch_application(inst)
            else:
                raise ValueError(f"Unknown application mode '{mode}' for '{alias}'.")
        except Exception as e:
            inst.status = "failed"
            inst.error = f"{type(e).__name__}: {e}"
            raise
        inst.ready_at = datetime.now().isoformat(timespec="seconds")
        inst.startup_ms = int((time.monotonic() - t0) * 1000)
        return inst

    def _launch_application(self, inst: ApplicationInstance) -> None:
        defn = inst.definition
        app_type = defn.get("type", "desktop")
        exe = str(defn.get("exe_path", "")).strip()
        args = defn.get("args") or []
        timeout = float(defn.get("timeout_s", 15.0))

        if app_type == "web":
            # Launch browser with URL
            browser = str(defn.get("browser", "chrome")).strip().lower()
            url = str(defn.get("url") or defn.get("base_url") or "").strip()
            url = self.substitute_variables(url)
            cmd = self._get_browser_command(browser, url)
            log.info("Launching browser: %s", cmd)
            proc = subprocess.Popen(cmd)
            inst.process = proc
            inst.pid = proc.pid
            inst.launched_by_test = True
            inst.status = "running"
        else:
            if not exe:
                # If no exe_path is given, try running target
                proc_name = defn.get("process_name", "")
                if proc_name:
                    exe = proc_name
                else:
                    raise ValueError(f"Application '{inst.alias}' requires 'exe_path' for launch.")

            base_exe = Path(exe).name.lower()
            if base_exe in DANGEROUS_BINARIES or any(char in exe for char in [";", "&", "|", "`", "$"]):
                raise ValueError(f"Restricted executable or command chain in application '{inst.alias}': {exe}")

            cmd = [exe]
            if isinstance(args, list):
                cmd.extend(str(self.substitute_variables(a)) for a in args)
            elif isinstance(args, str) and args.strip():
                cmd.extend(str(self.substitute_variables(a)) for a in args.split())

            working_dir = defn.get("working_dir") or None
            log.info("Launching desktop application: %s in %s", cmd, working_dir)
            proc = subprocess.Popen(cmd, cwd=working_dir)
            inst.process = proc
            inst.pid = proc.pid
            inst.launched_by_test = True
            inst.status = "running"

        # Wait for window readiness if title is specified
        expected_title = defn.get("window_title", "").strip()
        if expected_title:
            inst.title = expected_title
            deadline = time.monotonic() + timeout
            found = False
            while time.monotonic() < deadline:
                if winenv.window_exists(expected_title):
                    found = True
                    break
                time.sleep(0.2)
            if not found:
                # We started this process, so we own it: stop it rather than leave an orphan, then fail the step.
                self._stop_owned(inst)
                raise TimeoutError(
                    f"Application '{inst.alias}' did not show a window titled '{expected_title}' within {timeout:g}s after launch.")

    def _attach_application(self, inst: ApplicationInstance) -> None:
        defn = inst.definition
        title = str(defn.get("window_title", "")).strip()
        process_name = str(defn.get("process_name", "")).strip().lower()

        if not title and not process_name:
            raise ValueError(f"Cannot attach to application '{inst.alias}': neither window_title nor process_name specified.")

        hwnds = winenv.find_windows(title) if title else []
        if len(hwnds) > 1 and not defn.get("allow_ambiguous"):
            listing = "; ".join(f"hwnd {h} pid {winenv.window_info(h).get('pid')} '{winenv.window_info(h).get('title')}'" for h in hwnds[:6])
            raise AmbiguousTarget(
                f"{len(hwnds)} windows match title '{title}' for application '{inst.alias}': {listing}. "
                "Use a more specific window title or set allow_ambiguous to accept the first.")
        if hwnds:
            inst.hwnd = hwnds[0]
            info = winenv.window_info(inst.hwnd)
            inst.pid = info.get("pid")
            inst.title = info.get("title", title)
            inst.launched_by_test = False
            inst.status = "attached"
            log.info("Attached to application '%s' (HWND: %s, PID: %s)", inst.alias, inst.hwnd, inst.pid)
            return

        # Title did not find it: match by EXACT process name (a substring match could pick an unrelated app).
        if process_name:
            wanted = process_name[:-4] if process_name.endswith(".exe") else process_name
            matches = []
            for cand in applications.discover_running_apps():
                cand_proc = (cand.get("process") or "").strip().lower()
                cand_proc = cand_proc[:-4] if cand_proc.endswith(".exe") else cand_proc
                if cand_proc and cand_proc == wanted:
                    matches.append(cand)
            if len(matches) > 1 and not defn.get("allow_ambiguous"):
                raise AmbiguousTarget(
                    f"{len(matches)} running windows belong to process '{process_name}' for application '{inst.alias}': "
                    + "; ".join(f"pid {m.get('pid')} '{m.get('title')}'" for m in matches[:6])
                    + ". Set a window_title to pick one, or allow_ambiguous to accept the first.")
            if matches:
                cand = matches[0]
                inst.hwnd = cand.get("hwnd")
                inst.pid = cand.get("pid")
                inst.title = cand.get("title", "")
                inst.launched_by_test = False
                inst.status = "attached"
                log.info("Attached to application '%s' by process %s (HWND: %s)", inst.alias, process_name, inst.hwnd)
                return

        raise ElementNotFound(f"Could not attach to application '{inst.alias}': matching window or process not found.")

    def _stop_owned(self, inst: ApplicationInstance) -> None:
        """Stop a process THIS run started. Never used on attached applications."""
        if inst.process is None or not inst.launched_by_test:
            return
        try:
            inst.process.terminate()
            try:
                inst.process.wait(timeout=2.0)
            except subprocess.TimeoutExpired:
                inst.process.kill()
        except Exception:
            log.exception("could not stop %s", inst.alias)

    def _get_browser_command(self, browser: str, url: str) -> list[str]:
        # On Windows, try known default browser paths or standard commands
        url_arg = url or "about:blank"
        if browser in ("chrome", "google-chrome"):
            candidates = [
                os.path.expandvars(r"%ProgramFiles%\Google\Chrome\Application\chrome.exe"),
                os.path.expandvars(r"%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"),
                os.path.expandvars(r"%LocalAppData%\Google\Chrome\Application\chrome.exe"),
            ]
            for p in candidates:
                if Path(p).exists():
                    return [p, url_arg]
            return ["chrome", url_arg]
        elif browser in ("msedge", "edge"):
            candidates = [
                os.path.expandvars(r"%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"),
                os.path.expandvars(r"%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"),
            ]
            for p in candidates:
                if Path(p).exists():
                    return [p, url_arg]
            return ["msedge", url_arg]
        elif browser == "firefox":
            candidates = [
                os.path.expandvars(r"%ProgramFiles%\Mozilla Firefox\firefox.exe"),
                os.path.expandvars(r"%ProgramFiles(x86)%\Mozilla Firefox\firefox.exe"),
            ]
            for p in candidates:
                if Path(p).exists():
                    return [p, url_arg]
            return ["firefox", url_arg]
        return ["cmd", "/c", "start", url_arg]

    # ----------------------------------------------------------------- Switching
    def switch_to(self, alias: str) -> ApplicationInstance:
        """Switch active application focus to the specified alias."""
        clean_alias = alias.strip()
        inst = self.ensure_app(clean_alias)

        if self.active_alias != clean_alias:
            self.switch_history.append({
                "from": self.active_alias,
                "to": clean_alias,
                "timestamp": datetime.now().isoformat(timespec="seconds"),
            })
            inst.switch_count += 1
            self.active_alias = clean_alias
        inst.last_activity = datetime.now().isoformat(timespec="seconds")

        # Re-activate the target's own window on EVERY step, not only on a switch, so input never goes to
        # whatever happens to be focused (another app, or VisionAuto itself).
        if not self.dry_run:
            target_title = inst.title or inst.definition.get("window_title", "")
            if target_title and not winenv.activate_window(target_title):
                inst.error = f"window '{target_title}' could not be activated"
                raise ApplicationLost(f"Could not bring application '{clean_alias}' to the front: window '{target_title}' not found.")
        return inst

    # ----------------------------------------------------------------- Cleanup
    def cleanup(self, policy: str = "close_test_launched") -> list[dict]:
        """
        Safely clean up applications.
        policy:
            'close_test_launched' (default): only terminates processes explicitly launched by the test.
            'close_all': terminates all managed instances.
            'leave_open': leaves all processes running.
        """
        results = []
        if policy == "leave_open" or self.dry_run:
            return results

        for alias, inst in self.instances.items():
            if inst.status in ("stopped", "failed"):
                continue

            should_close = (policy == "close_all") or (policy == "close_test_launched" and inst.launched_by_test)
            # Check definition override
            if not inst.definition.get("close_on_exit", True):
                should_close = False

            if should_close and inst.process:
                try:
                    log.info("Closing test-launched application '%s' (PID %s)", alias, inst.pid)
                    inst.process.terminate()
                    try:
                        inst.process.wait(timeout=2.0)
                    except subprocess.TimeoutExpired:
                        inst.process.kill()
                    inst.status = "stopped"
                    results.append({"alias": alias, "action": "terminated", "pid": inst.pid})
                except Exception as e:
                    log.warning("Failed to close application '%s': %s", alias, e)
                    results.append({"alias": alias, "action": "error", "error": str(e)})

        return results

    def get_telemetry(self) -> dict:
        """Return execution summary and telemetry of all applications."""
        return {
            "applications": [inst.to_dict() for inst in self.instances.values()],
            "active_application": self.active_alias,
            "total_switches": len(self.switch_history),
            "switch_history": self.switch_history,
        }

