"""
Text comparison for validation points - tolerant of how the text was *obtained*, strict about what it *says*.

The bug this fixes: a validation recorded from UI Automation holds the accessibility name (``Display is 9,801``), but
when UI Automation cannot read the control the validator falls back to OCR, which sees only what is drawn (``9,801``) -
and OCR adds its own noise (``9.801``, ``9 801``, ``9,8O1``). Exact comparison then reports FAILED although the value is
the same. Now the comparison goes through these levels (first hit wins, and the report says which one):

 1. exact          after trimming, collapsing spaces, case-folding
 2. label-stripped accessibility prefixes ("Display is ", "Value is ", ...) are not part of what is drawn
 3. loose          ignoring spaces / punctuation
 4. OCR-only       look-alike characters (O/0, l/1, S/5, B/8) when the expected text contains digits;
                   numbers compared by their digits ("9,801" == "9.801" == "9 801"); near-identical long text (>= 0.92)

A different value never matches: "9,801" vs "9,802" / "9,80" / "19,801" all FAIL. ``match: "strict"`` on a validation
turns levels 2-4 off. Pure functions - no OS access.
"""
from __future__ import annotations

import re
import unicodedata
from difflib import SequenceMatcher

LABEL_PREFIXES = ("display is", "value is", "result is", "text is", "the value is", "current value is", "total is")
_CONFUSABLE = str.maketrans({"o": "0", "O": "0", "l": "1", "I": "1", "|": "1", "S": "5", "B": "8", "Z": "2", "z": "2"})
_NUMBERISH = re.compile(r"^[\s\-+$€£¥₹%.,0-9]+$")


def norm(s) -> str:
    return " ".join(unicodedata.normalize("NFKC", str(s or "")).split()).casefold()


_NEG = re.compile(r"(?<![\w])[-−](?=\d)")


def loose(s) -> str:
    """Letters and digits only - but a leading minus is a sign, not punctuation ('-9,801' must not equal '9,801')."""
    return "".join(ch for ch in _NEG.sub("neg", norm(s)) if ch.isalnum())


def variants(expected) -> list[str]:
    """The expected text, plus what is actually *drawn* when it starts with an accessibility label."""
    e = norm(expected)
    out = [e]
    for p in LABEL_PREFIXES:
        if e.startswith(p + " "):
            out.append(e[len(p) + 1:])
    return out


def _digits(s: str) -> str:
    return re.sub(r"\D", "", s)


def _sign(s: str) -> str:
    return "-" if s.strip().startswith(("-", "−")) else ""


def match(actual, expected, kind: str = "text_equals", source: str = "UI Automation", strict: bool = False) -> tuple[bool, str]:
    """-> (matched, note). ``note`` says which tolerance was needed ('' for an exact match)."""
    contains = kind in ("text_contains", "contains")
    a = norm(actual)
    exp_variants = variants(expected)
    if (exp_variants[0] in a) if contains else (a == exp_variants[0]):
        return True, ""
    if strict:
        return False, ""
    ocr = str(source).upper().startswith("OCR")
    la = loose(actual)
    for i, v in enumerate(exp_variants):
        if (v in a) if contains else (a == v):
            return True, "ignoring the accessibility label (only the drawn value is compared)"
        lv = loose(v)
        if lv and ((lv in la) if contains else (lv == la)):
            return True, ("ignoring the accessibility label and " if i else "") + "ignoring spaces/punctuation/case"
    if not ocr:
        return False, ""
    for v in exp_variants:
        lv = loose(v)
        if not lv:
            continue
        has_digit = any(c.isdigit() for c in lv)
        if has_digit:
            fa, fv = la.translate(_CONFUSABLE).casefold(), lv.translate(_CONFUSABLE).casefold()
            if (fv in fa) if contains else (fv == fa):
                return True, f"OCR look-alike characters tolerated (read '{str(actual).strip()}')"
        if not contains and _NUMBERISH.match(v) and _NUMBERISH.match(str(actual or "")):
            if _digits(v) and _digits(v) == _digits(str(actual)) and _sign(v) == _sign(str(actual)):
                return True, f"same number, OCR read the separators differently ('{str(actual).strip()}')"
        if not contains and len(lv) >= 7 and not has_digit and SequenceMatcher(None, lv, la).ratio() >= 0.92:
            return True, f"OCR read '{str(actual).strip()}' (>= 92% identical)"
    return False, ""
