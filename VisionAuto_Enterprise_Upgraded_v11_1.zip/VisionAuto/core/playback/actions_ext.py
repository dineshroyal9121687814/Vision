"""Verified, state-based actions added to the Player: set/append/clear/read value, select option, set check/radio state,
file upload through the native dialog, wait for window.

Rules shared by all of them (the strict pipeline):
  * the target is resolved by the strict Resolver (window context, uniqueness, confidence) - never "the focused field";
  * a native UI Automation pattern is preferred over mouse/keyboard emulation;
  * every action READS BACK the result.  A value that cannot be read back is reported as ``unverified`` (never as
    verified); a value that reads back wrong raises ``PostconditionFailed``.
"""
from __future__ import annotations

import os
import re
import time

from core.automation.errors import AmbiguousTarget, PostconditionFailed, WrongTarget
from core.automation import window_target as wt
from core.system import excel_launch, uia_actions, winenv


def _norm(s) -> str:
    return re.sub(r"\s+", " ", str(s or "").replace("\r\n", "\n").replace("\r", "\n")).strip()


class ExtendedActions:
    uia = uia_actions                      # injectable (tests, other platforms)

    # ---- helpers -----------------------------------------------------------------------------------------------------
    def _resolve_enabled(self, step: dict, tag: str = "src"):
        r = self._resolve(step["target"], step, tag)
        if r.evidence.get("disabled"):
            raise WrongTarget(f"Target '{step['target'].get('name') or step['target'].get('automation_id')}' is disabled; "
                              "no input was sent.", {"evidence": r.evidence})
        return r

    def _note_result(self, res: dict, r) -> None:
        res.update(method=r.method, x=r.x, y=r.y, locator_confidence=r.confidence, locator_evidence=r.evidence)

    def _verified(self, res: dict, **info) -> None:
        res.setdefault("verified_by", []).append(info)

    def _assert_focus_on(self, target: dict) -> None:
        """Refuse to type unless the keyboard focus is on the configured control (not 'whatever has focus')."""
        from core.playback.validators import Validator
        fe = winenv.focused_element() or {}
        if fe and not Validator._same_control(fe, target):
            raise WrongTarget(f"Keyboard focus is on '{fe.get('name') or fe.get('role')}', not on the configured field "
                              f"'{target.get('name') or target.get('automation_id')}'; nothing was typed.",
                              {"focused": {k: fe.get(k) for k in ("name", "role", "automation_id")}})

    # ---- value actions -------------------------------------------------------------------------------------------------
    def _act_value(self, step: dict, res: dict) -> None:
        t, p = step["type"], step.get("params") or {}
        if p.get("redacted"):
            raise ValueError("Sensitive input was redacted while recording; supply it through a secret input first.")
        text = "" if t == "clear_value" else str(p.get("text", p.get("value", "")))
        append = t == "append_value" or bool(p.get("append"))
        r = self._resolve_enabled(step)
        self._note_result(res, r)
        if self.dry_run:
            return
        before = self.uia.read_value(r.x, r.y) if append else ""
        expected = (before or "") + text if append else text
        if self.uia.set_value(r.x, r.y, text, append):
            res["input_method"] = "ValuePattern"
        else:                                                   # keyboard path, but only after proving the focus
            self.backend.click(r.x, r.y, "left", 1)
            time.sleep(0.08)
            self._assert_focus_on(step["target"])
            if append:
                self.backend.hotkey("ctrl+end")
            else:
                self.backend.hotkey("ctrl+a")
            if text:
                if p.get("paste", len(text) > 40) or "\n" in text:
                    self._paste_text(text)
                else:
                    self.backend.type_text(text, self.opts.get("type_interval_ms", 15))
            else:
                self.backend.press("delete")
            res["input_method"] = "keyboard"
        self._check_value(res, r, expected, p)

    def _check_value(self, res: dict, r, expected: str, p: dict) -> None:
        if p.get("verify", True) is False:
            return
        time.sleep(0.05)
        actual = self.uia.read_value(r.x, r.y)
        if actual is None:
            res["verify_note"] = "value could not be read back from this control; result is unverified"
            return
        if _norm(actual) != _norm(expected):
            raise PostconditionFailed(f"Field contains {_norm(actual)[:80]!r}, expected {_norm(expected)[:80]!r}.",
                                      {"expected": expected, "actual": actual})
        self._verified(res, type="value", expected=_norm(expected)[:80])

    def _act_read_value(self, step: dict, res: dict) -> None:
        r = self._resolve_enabled(step)
        self._note_result(res, r)
        if self.dry_run:
            val = step.get("mock_value", "")
        else:
            if (r.evidence or {}).get("is_password"):
                raise WrongTarget("Refusing to read a password field.")
            val = self.uia.read_value(r.x, r.y)
            if val is None:
                raise PostconditionFailed("The value of this control cannot be read.")
        res["value"] = val
        var = (step.get("params") or {}).get("save_as") or step.get("save_as")
        if var:
            self.app_context.set_variable(str(var), val)
            res["saved_as"] = {str(var): val}
        want = (step.get("params") or {}).get("expect")
        if want is not None and not self.dry_run:
            if _norm(val) != _norm(want):
                raise PostconditionFailed(f"Value is {_norm(val)!r}, expected {_norm(want)!r}.", {"actual": val})
            self._verified(res, type="value", expected=_norm(want))

    # ---- dropdown -----------------------------------------------------------------------------------------------------
    def _act_select_option(self, step: dict, res: dict) -> None:
        p = step.get("params") or {}
        text, index = str(p.get("text") or p.get("option") or ""), p.get("index")
        if not text and index is None:
            raise ValueError("select_option needs the option text or an index")
        r = self._resolve_enabled(step)
        self._note_result(res, r)
        if self.dry_run:
            return
        try:
            ok = self.uia.select_option(r.x, r.y, text, None if index is None else int(index))
        except RuntimeError as exc:
            raise AmbiguousTarget(str(exc)) from exc
        if ok:
            res["input_method"] = "SelectionItemPattern"
        else:
            if not text:
                raise ValueError("this dropdown is not a native list: select it by option text")
            self._pick_custom_option(step, r, text, p, res)
        if p.get("verify", True) is not False:
            time.sleep(0.1)
            now = self.uia.read_value(r.x, r.y)
            want = text or ""
            if now is None:
                res["verify_note"] = "selected option could not be read back; unverified"
            elif want and _norm(now).casefold() != _norm(want).casefold():
                raise PostconditionFailed(f"Dropdown shows {_norm(now)!r}, expected {_norm(want)!r}.", {"actual": now})
            else:
                self._verified(res, type="selected_option", expected=want or f"#{index}")

    def _pick_custom_option(self, step: dict, field, text: str, p: dict, res: dict) -> None:
        """Custom / pop-up dropdown, the way a person does it:
        open it -> look for THE option (exact text, inside the pop-up that belongs to this window) -> if it is not visible
        scroll the list a notch at a time and look again -> if it still is not there, type-ahead + Enter.
        The option's position is always re-derived from the screen; the recorded coordinate is never used."""
        from core.automation.errors import AmbiguousTarget as _Amb
        from core.playback.resolver import ElementNotFound
        self.backend.click(field.x, field.y, "left", 1)
        time.sleep(float(p.get("open_wait_s", 0.25)))
        popup_step = {**step, "window": {"popup": True, "owner_title": (step.get("window") or {}).get("title", "")}}
        opt_target = {"name": text, "text": text, "role": "ListItem", "text_match": "exact"}
        scrolls = 0
        for attempt in range(int(p.get("max_scrolls", 8)) + 1):
            try:
                opt = self._resolve(opt_target, popup_step, "option", timeout=1.0)
            except ElementNotFound:
                opt = None
            except _Amb:
                raise                                              # two options with the same text: never pick one
            if opt is not None:
                self.backend.click(opt.x, opt.y, "left", 1)
                res["input_method"] = f"popup list ({opt.method}), scrolled {scrolls}x"
                res["scrolled"] = scrolls
                return
            if attempt >= int(p.get("max_scrolls", 8)) or self.should_stop():
                break
            self._scroll_notches(field.x, field.y + int(p.get("list_offset_px", 90)), 0, -int(p.get("scroll_step", 3)))
            scrolls += 1
            time.sleep(0.15)
        # keyboard: the control may support type-to-search even when its items are virtualised / not exposed
        self.backend.type_text(text, 30)
        time.sleep(0.2)
        self.backend.press("enter")
        res["input_method"] = f"keyboard type-ahead after {scrolls} scrolls"
        res["scrolled"] = scrolls

    # ---- check / radio ------------------------------------------------------------------------------------------------
    STATE_WORDS = {"check": "on", "on": "on", "uncheck": "off", "off": "off", "select": "selected", "selected": "selected"}

    def _act_set_state(self, step: dict, res: dict) -> None:
        p = step.get("params") or {}
        action = str(p.get("state") or p.get("action") or "check").lower()
        r = self._resolve_enabled(step)
        self._note_result(res, r)
        if self.dry_run:
            return
        now = self._read_state(r.x, r.y)
        if action == "toggle":
            want = {"on": "off", "off": "on"}.get(now, "")
            if not want:
                raise PostconditionFailed("Cannot toggle: the current state of this control is unreadable.")
        else:
            want = self.STATE_WORDS.get(action)
            if not want:
                raise ValueError(f"set_state action must be check, uncheck, toggle or select (got {action!r})")
        if now == want:
            res["state_check"] = f"already {want}: nothing clicked"
        else:
            if not (want in ("on", "off") and self.uia.set_toggle(r.x, r.y, want)) and \
                    not (want == "selected" and self.uia.select_item(r.x, r.y)):
                self.backend.click(r.x, r.y, "left", 1)
            time.sleep(0.15)
        final = self._read_state(r.x, r.y)
        if not final:
            res["verify_note"] = "state could not be read back; unverified"
        elif final != want:
            raise PostconditionFailed(f"State is '{final}', expected '{want}'.", {"actual": final})
        else:
            self._verified(res, type="state", expected=want)

    # ---- file upload --------------------------------------------------------------------------------------------------
    DIALOG_TITLE = r"(?i)^(open|save|save as|choose|select|upload|browse|insert|attach|import)\b"

    def _act_upload_file(self, step: dict, res: dict) -> None:
        """Click Browse (the step target), find THE file dialog that belongs to the target's application, fill its
        'File name' edit with the path (UI element, not blind typing), confirm, and prove the dialog closed."""
        p = step.get("params") or {}
        paths = [str(x) for x in (p.get("paths") or ([p["path"]] if p.get("path") else []))]
        if not paths:
            raise ValueError("upload_file needs the full path of the file")
        missing = [x for x in paths if not os.path.isfile(x)]
        if missing:
            raise ValueError(f"File to upload does not exist: {missing[0]}")
        allowed = p.get("extensions")
        if allowed:
            bad = [x for x in paths if os.path.splitext(x)[1].lower() not in [e.lower() for e in allowed]]
            if bad:
                raise ValueError(f"Unsupported file type for upload: {os.path.basename(bad[0])} (allowed: {', '.join(allowed)})")
        res["upload"] = {"files": [os.path.basename(x) for x in paths]}
        if self.dry_run:
            return
        owner_pid = 0
        if step.get("target"):
            r = self._resolve_enabled(step)
            self._note_result(res, r)
            self.backend.click(r.x, r.y, "left", 1)
            owner_pid = int(winenv.window_info(int((step.get("window") or {}).get("_hwnd") or 0)).get("pid") or 0)
        spec = wt.WindowSpec.from_dict({"title": p.get("dialog_title") or self.DIALOG_TITLE, "match": "regex",
                                        "pid": 0, "window_target": "specific"})
        deadline = time.monotonic() + float(p.get("dialog_timeout_s", self.opts.get("timeout_s", 10.0)))
        dlg = None
        while time.monotonic() < deadline:
            if self.should_stop():
                from core.playback.player import Aborted
                raise Aborted()
            wins = [w for w in self._enumerate_windows() if str(w.get("class") or "") == "#32770" or p.get("dialog_title")]
            if owner_pid:
                same = [w for w in wins if int(w.get("pid") or 0) == owner_pid]
                wins = same or wins
            m = wt.resolve_window(spec, wins, 0)
            if m.status == "unique":
                dlg = m.window
                break
            if m.status == "ambiguous":
                raise AmbiguousTarget("More than one file dialog is open; close the others.",
                                      [wt.summarize(w) for w in m.windows], {"kind": "file_dialog"})
            time.sleep(0.15)
        if dlg is None:
            raise WrongTarget("No file dialog appeared after clicking the Browse control; nothing was typed.")
        hwnd = int(dlg["hwnd"])
        if not self.uia.submit_file_dialog(hwnd, paths):
            raise WrongTarget("The file dialog's 'File name' box / Open button could not be driven through UI Automation; "
                              "nothing was typed into other windows.")
        end = time.monotonic() + float(p.get("close_timeout_s", 5.0))
        while winenv.is_window(hwnd) and time.monotonic() < end:
            time.sleep(0.1)
        if winenv.is_window(hwnd):
            raise PostconditionFailed("The file dialog stayed open after confirming (bad path, unsupported format or an "
                                      "error message appeared).", {"dialog": dlg.get("title")})
        self._verified(res, type="file_dialog_closed", files=res["upload"]["files"])

    # ---- waits --------------------------------------------------------------------------------------------------------
    def _act_wait_for_window(self, step: dict, res: dict) -> None:
        p = step.get("params") or {}
        win = dict(p.get("window") or step.get("window") or {})
        if self.dry_run:
            return
        timeout = float(p.get("timeout_s", self.opts.get("timeout_s", 10.0)))
        hwnd = self._resolve_window(win, timeout)
        res["waited_for_hwnd"] = hwnd
        self._verified(res, type="window_present", window=win.get("title") or win.get("process"))

    # ---- custom (AI-written) steps ------------------------------------------------------------------------------------
    def _act_custom(self, step: dict, res: dict) -> None:
        from core.steplib import custom
        p = step.get("params") or {}
        name = str(p.get("method") or "").strip()
        if not name:
            raise ValueError("custom step needs a 'method' (pick one from the Custom dropdown).")
        args = {k: (self.app_context.substitute_variables(v) if isinstance(v, str) else v)
                for k, v in (p.get("args") or {}).items()}
        if self.dry_run:
            custom.get(name)                                  # at least prove the method exists
            res["custom"] = {"method": name, "dry_run": True}
            return
        ctx = custom.Context(self.backend, self.app_context.variables, resolve=lambda t: self._resolve(t, step, "src"),
                             log=lambda m: res.setdefault("custom_log", []).append(m))
        out = custom.run(name, args, ctx, allow_draft=bool(self.opts.get("allow_unreviewed_custom_steps", False)))
        res["custom"] = {"method": name, **out}
        self._verified(res, type="custom_step", method=name, checks=len(out["checks"]))

    # ---- Excel files --------------------------------------------------------------------------------------------------
    def _act_excel_file(self, step: dict, res: dict) -> None:
        """Save / close a workbook through Excel itself and read the result back (Saved flag / workbook list)."""
        p = step.get("params") or {}
        if self.dry_run:
            return
        if step["type"] == "excel_save":
            out = excel_launch.save_workbook(str(p.get("path") or ""), str(p.get("save_as") or ""))
        else:
            out = excel_launch.close_workbook(str(p.get("path") or ""), bool(p.get("save", False)))
        res["excel"] = out
        self._verified(res, type=step["type"], **{k: v for k, v in out.items() if k != "verified"})
