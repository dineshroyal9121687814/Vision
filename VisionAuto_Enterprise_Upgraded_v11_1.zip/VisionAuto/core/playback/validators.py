"""
Validation points. A validation is evaluated like a wait: it is polled until it
passes or its timeout expires (UI updates are asynchronous), never checked once.

  window_title_contains   a visible window title contains the text
  element_exists          the recorded element can be located
  text_equals/contains    the element's text. Order: UI Automation value -> Excel cell value (COM) -> OCR of its area
                          (OCR is the LAST resort: a short-value reader with border strip, ink crop, upscale and an
                          allow-list, a pointer parked away from the pixels, and results cached per picture)
  state                   on/off (checkbox) or selected - needs UI Automation
  image_visible           the recorded appearance is on screen

When a check cannot be evaluated on this app (e.g. text on a canvas with no OCR
installed) it is reported as SKIPPED with the reason - never silently passed.
"""
from __future__ import annotations

import time
import math

from core.ai.describe import describe_validation
from core.playback import textmatch
from core.system import excel_com, winenv


def _norm(s) -> str:
    return " ".join(str(s or "").split()).casefold()


class Validator:
    def __init__(self, resolver, options: dict, dry_run: bool = False):
        self.resolver = resolver
        self.o = options
        self.dry_run = dry_run
        self.park_pointer = None      # callable(rect, window) set by the Player: move the real pointer off the pixels
        self._expected = None         # the value being checked: lets OCR restrict its alphabet (digits only, ...)

    def evaluate(self, v: dict, window: dict) -> dict:
        res = {"type": v.get("type"), "description": describe_validation(v), "status": "skipped", "detail": ""}
        if "expected" in v:
            res["expected"] = v["expected"]
        if self.dry_run:
            res["detail"] = "dry run"
            return res
        raw_timeout = v.get("timeout_s")
        if raw_timeout is None:
            try:
                raw_timeout = min(float(self.o.get("timeout_s", 10.0)), 8.0)
            except (TypeError, ValueError, OverflowError):
                raw_timeout = None
        try:
            if isinstance(raw_timeout, bool):
                raise ValueError
            timeout = float(raw_timeout)
        except (TypeError, ValueError, OverflowError):
            res["status"] = "failed"
            res["detail"] = "invalid validation timeout; expected a finite number from 0 to 120 seconds"
            return res
        if not math.isfinite(timeout) or not 0 <= timeout <= 120:
            res["status"] = "failed"
            res["detail"] = "invalid validation timeout; expected a finite number from 0 to 120 seconds"
            return res
        deadline = time.monotonic() + timeout
        while True:
            try:
                status, detail, actual = self._once(v, window)
            except Exception as e:  # a validation must never crash the run
                status, detail, actual = "failed", f"{type(e).__name__}: {e}", None
            if status != "failed" or time.monotonic() >= deadline or self.resolver.abort_check():
                break
            remaining = deadline - time.monotonic()
            if remaining > 0:
                time.sleep(min(0.1, remaining))
        res["status"], res["detail"] = status, detail
        if actual is not None:
            res["actual"] = actual
        return res

    # ------------------------------------------------------------------
    def _native(self, tgt: dict, window: dict):
        """UI Automation lookup through the resolver's time-boxed governor (a tree walk in Excel / Electron / big apps
        takes seconds; unbounded it used to run on EVERY validation). None = not available or too slow for this app."""
        plugin = self.resolver.plugins.get_plugin_for(window)
        gov = getattr(self.resolver, "governor", None)
        if gov is None:
            return plugin.find_element_native(tgt, window)
        if not self.o.get("use_native", True) or not gov.allowed(window, tgt):
            return None
        return gov.call(window, lambda: plugin.find_element_native(tgt, window))

    def _focused(self, window: dict) -> dict:
        gov = getattr(self.resolver, "governor", None)
        if gov is None:
            return winenv.focused_element()
        if not gov.allowed(window, {}):
            return {}
        return gov.call(window, winenv.focused_element) or {}

    def _once(self, v: dict, window: dict) -> tuple[str, str, object | None]:
        kind, exp, tgt = v.get("type"), v.get("expected", ""), v.get("target") or {}

        if kind == "window_title_contains":
            fg = winenv.foreground_window()
            # Validate the active window only. A matching background window
            # must not make a foreground-window assertion pass.
            if _norm(exp) in _norm(fg.get("title")):
                return "passed", "", fg.get("title", "")
            if winenv.is_transient_of(fg, exp):           # right-click mini toolbar / context menu of that very app
                return "passed", "", fg.get("title", "")
            return "failed", f"active window is '{fg.get('title', '')}'", fg.get("title", "")

        if kind in ("element_exists", "image_visible"):
            r = self.resolver.resolve_once(tgt, window)
            return ("passed", f"found via {r.method}", True) if r else ("failed", "element not found", False)

        if kind == "element_not_exists":
            r = self.resolver.resolve_once(tgt, window)
            return ("failed", f"still visible (found via {r.method})", True) if r else ("passed", "", False)

        if kind in ("text_equals", "text_contains"):
            strict = v.get("match") == "strict"
            self._expected = exp
            seen: list[tuple[str, str]] = []
            for actual, how in self._text_candidates(tgt, window):
                if actual is None:
                    if not seen:
                        return "skipped", how, None
                    break
                if any(actual == s for s, _ in seen):
                    continue
                seen.append((actual, how))
                ok, note = textmatch.match(actual, exp, kind, how, strict)
                if ok:
                    return "passed", f"read via {how}" + (f"; matched {note}" if note else ""), actual
            first, how0 = seen[0]
            if (self.o.get("ocr_short_mismatch", "warn") != "fail" and all(h.startswith("OCR") for _, h in seen)
                    and len(str(exp).strip()) <= 4):
                # A 1-4 character value read from pixels is a coin toss ('2' read as '1'). A wrong guess must not fail
                # a correct test, and a right one must not pass a wrong test: report it as NOT VERIFIED.
                why = excel_com.last_error
                return ("skipped", f"not verified: only OCR could read this value and it read '{first}' (unreliable for short "
                        f"values){'; Excel COM unavailable: ' + why if why else ''}", first)
            # A plain control (not a spreadsheet cell / row) whose only answers came from "whatever is at the located point":
            # after type+Enter the control may be gone (Excel mini toolbar) and that point now belongs to another control
            # (Name Box). Such a read is not evidence against the typed value -> NOT VERIFIED, not failed. Cells / rows keep
            # the original strict behaviour.
            addr = str(tgt.get("automation_id") or tgt.get("name") or tgt.get("text") or "").split(":")[0].strip()
            cellish = excel_com.looks_like_address(addr) or str(tgt.get("role") or "").casefold() in ("dataitem", "cell", "row")
            if (not cellish and all(h in ("UI Automation at point", "Windows control text") for _, h in seen)
                    and str(first).strip().casefold() not in ("", str(exp).strip().casefold())
                    and not self._same_control({"name": first}, tgt)
                    and str(tgt.get("role") or "").casefold() in ("edit", "text", "textbox", "text box", "combobox", "")):
                return ("skipped", f"not verified: the located point now shows another control ('{first}'), the typed field is "
                        f"no longer on screen", first)
            more = f"; other reads: {', '.join(repr(s) for s, _ in seen[1:4])}" if len(seen) > 1 else ""
            return "failed", f"found '{first}' (via {how0}){more}", first

        if kind == "value_check":
            from core.playback.compare import check as _cmp
            self._expected = exp
            first = None
            for actual, how in self._text_candidates(tgt, window):
                if actual is None:
                    return "skipped", how, None
                if first is None:
                    first = (actual, how)
                ok, why = _cmp(actual, v.get("op", "equals"), exp, v.get("expected2", ""), float(v.get("tolerance") or 0),
                               v.get("format") or "%Y-%m-%d", bool(v.get("ignore_case")))
                if ok:
                    return "passed", f"{why} (read via {how})", actual
            if first is None:
                return "failed", "the value could not be read", None
            ok, why = _cmp(first[0], v.get("op", "equals"), exp, v.get("expected2", ""), float(v.get("tolerance") or 0),
                           v.get("format") or "%Y-%m-%d", bool(v.get("ignore_case")))
            return "failed", f"{why} (read via {first[1]})", first[0]

        if kind == "state":
            el = self._native(tgt, window)
            if not el or not el.get("state"):
                return "skipped", "state check needs UI Automation on this control", None
            st = el["state"]
            actual = st.get("toggle") or ("selected" if st.get("selected") else "not selected")
            return (("passed", "", actual) if _norm(actual) == _norm(exp)
                    else ("failed", f"state is '{actual}'", actual))

        if kind == "window_exists":
            found = winenv.window_exists(str(exp))
            return ("passed", f"window matching '{exp}' exists", True) if found else ("failed", f"window matching '{exp}' does not exist", False)

        if kind in ("element_enabled", "element_disabled"):
            el = self._native(tgt, window)
            if not el:
                return "failed", "element not found for enabled/disabled check", None
            is_enabled = bool(el.get("is_enabled", True))
            expected_enabled = (kind == "element_enabled")
            if is_enabled == expected_enabled:
                return "passed", f"element is {'enabled' if is_enabled else 'disabled'}", is_enabled
            return "failed", f"expected {'enabled' if expected_enabled else 'disabled'} but element was {'enabled' if is_enabled else 'disabled'}", is_enabled

        if kind == "attribute_equals":
            attr_name = str(v.get("attribute") or "value")
            el = self._native(tgt, window)
            if not el:
                return "failed", "element not found for attribute check", None
            actual_val = str(el.get(attr_name, ""))
            if _norm(actual_val) == _norm(exp):
                return "passed", f"attribute '{attr_name}' matches", actual_val
            return "failed", f"attribute '{attr_name}' is '{actual_val}', expected '{exp}'", actual_val

        if kind in ("text_in_region", "region_matches_baseline"):
            return self._region_check(kind, v, tgt, window)

        if kind in ("clipboard_equals", "clipboard_contains"):
            from core.system import clipboard
            try:
                actual = clipboard.get_text()
            except NotImplementedError as e:
                return "skipped", str(e), None
            ok = _norm(actual) == _norm(exp) if kind == "clipboard_equals" else _norm(exp) in _norm(actual)
            return ("passed", "", actual[:200]) if ok else ("failed", f"clipboard holds '{actual[:80]}'", actual[:200])

        if kind in ("file_exists", "file_contains"):
            return self._file_check(kind, v, exp)

        if kind in ("process_running", "process_not_running"):
            try:
                import psutil
            except ImportError:
                return "skipped", "process checks need psutil (pip install psutil)", None
            want = str(exp).casefold()
            running = any(str(pr.info.get("name") or "").casefold() == want for pr in psutil.process_iter(["name"]))
            if running == (kind == "process_running"):
                return "passed", "", running
            return "failed", f"process '{exp}' is {'running' if running else 'not running'}", running

        return "skipped", f"unknown validation type '{kind}'", None

    # ------------------------------------------------------------------ regions (zones) and baselines
    def _region_rect(self, v: dict, tgt: dict, window: dict):
        """Absolute [l, t, r, b] to inspect: an explicit ``region`` [x, y, w, h], else the target's zone/rect,
        translated to where the window is *now* (it may have moved or been resized)."""
        probe = {}
        if isinstance(v.get("region"), (list, tuple)) and len(v["region"]) == 4:
            probe["ocr_region"] = list(v["region"])
        if isinstance(tgt.get("zone"), dict):
            probe["zone"] = dict(tgt["zone"])
        if isinstance(tgt.get("rect"), (list, tuple)):
            probe["rect"] = list(tgt["rect"])
        if not probe:
            return None
        probe = self.resolver._prepare(probe, window)
        if "ocr_region" in probe:
            x, y, w, h = probe["ocr_region"]
            return [x, y, x + w, y + h]
        if "zone" in probe:
            return probe["zone"]["rect"]
        return probe.get("rect")

    def _crop(self, rect):
        frame, origin = self.resolver.grab()
        x0, y0 = max(0, int(rect[0] - origin[0])), max(0, int(rect[1] - origin[1]))
        x1, y1 = min(frame.shape[1], int(rect[2] - origin[0])), min(frame.shape[0], int(rect[3] - origin[1]))
        if x1 - x0 < 4 or y1 - y0 < 4:
            return None
        return frame[y0:y1, x0:x1]

    def _region_check(self, kind: str, v: dict, tgt: dict, window: dict):
        rect = self._region_rect(v, tgt, window)
        if rect is None:
            return "skipped", "no region: give validation.region [x, y, w, h] or a target with a zone", None
        crop = self._crop(rect)
        if crop is None:
            return "failed", "the region is outside the screen", None
        if kind == "text_in_region":
            try:
                from core.ocr import ocr_engine

                reads = self._ocr_reads(crop, ocr_engine)
                first = next(reads)
            except Exception as e:
                return "skipped", f"cannot read text here (needs EasyOCR or Tesseract): {type(e).__name__}", None
            exp = v.get("expected", "")
            texts = [first]
            import itertools
            for text in itertools.chain([first], self._lazy(reads)):
                if text not in texts:
                    texts.append(text)
                if v.get("match") == "regex":
                    import re
                    try:
                        ok = re.search(str(exp), text) is not None
                    except re.error:
                        return "failed", "invalid regular expression", None
                    note = ""
                else:
                    ok, note = textmatch.match(text, exp, "text_equals" if v.get("match") == "equals" else "text_contains",
                                               "OCR", v.get("match") == "strict")
                if ok:
                    return "passed", "read via OCR" + (f"; matched {note}" if note else ""), text[:300]
            return "failed", f"region text was '{first[:120]}'", first[:300]
        # region_matches_baseline: same picture within a tolerance (visual regression)
        import cv2
        from core.system.imageio import imread

        base_dir = getattr(self.resolver, "dir", None)
        rel = str(v.get("baseline") or "")
        if base_dir is None or not rel:
            return "skipped", "no baseline image", None
        path = (base_dir / rel).resolve()
        try:
            path.relative_to(base_dir.resolve())
        except ValueError:
            return "failed", "baseline must be inside the test folder", None
        base = imread(path)
        if base is None:
            return "failed", f"baseline image {rel} could not be read", None
        cur = cv2.resize(crop, (base.shape[1], base.shape[0]), interpolation=cv2.INTER_AREA)
        diff = float(cv2.absdiff(cv2.cvtColor(cur, cv2.COLOR_BGR2GRAY), cv2.cvtColor(base, cv2.COLOR_BGR2GRAY)).mean())
        tol = float(v.get("tolerance", 6.0))
        return (("passed", f"difference {diff:.1f} <= {tol:g}", round(diff, 2)) if diff <= tol
                else ("failed", f"picture differs by {diff:.1f} (allowed {tol:g})", round(diff, 2)))

    def _file_check(self, kind: str, v: dict, exp):
        """Existence / content checks for files a test produces (exports, logs). Only under the home folder, the
        workspace or the temp folder - a shared test cannot probe the rest of your disk. Content is never echoed."""
        import tempfile
        from pathlib import Path

        from core import paths

        raw = str(v.get("path") or "")
        if not raw:
            return "failed", "no path", None
        path = Path(raw).expanduser().resolve()
        roots = [Path.home().resolve(), paths.workspace().resolve(), Path(tempfile.gettempdir()).resolve()]
        if not any(path == r or r in path.parents for r in roots):
            return "failed", "file checks are limited to your home folder, the workspace and the temp folder", None
        if not path.is_file():
            return "failed", "file does not exist", False
        size = path.stat().st_size
        if size < int(v.get("min_bytes", 0)):
            return "failed", f"file is only {size} bytes (expected at least {int(v.get('min_bytes', 0))})", size
        if kind == "file_exists":
            return "passed", f"{size} bytes", size
        if size > 5 * 1024 * 1024:
            return "failed", "file is larger than 5 MB; content check refused", size
        text = path.read_text(encoding="utf-8", errors="replace")
        return ("passed", "text found", size) if _norm(exp) in _norm(text) else ("failed", "text not found in file", size)

    @staticmethod
    def _lazy(gen):
        """Drain the rest of an OCR generator, stopping quietly if a retry variant fails."""
        try:
            yield from gen
        except Exception:
            return

    @staticmethod
    def _ocr_reads(crop, ocr_engine, expected=None, small=False):
        """Reads of one picture, cheapest first. ``small`` (a short value such as a cell or a display) uses the
        short-value reader: border strip -> ink crop -> upscale -> allow-listed read, cached per picture.
        Otherwise: the plain read, then the enhanced (upscaled / inverted) reads only when asked for."""
        if small and isinstance(getattr(ocr_engine, "__file__", None), str) and hasattr(ocr_engine, "read_small"):
            seen_any = False
            for text in ocr_engine.read_small(crop, expected=expected):
                seen_any = True
                yield text
            if seen_any:
                return
            yield ""                                   # nothing readable: report an empty read, not a crash
            return
        yield ocr_engine.read_all_text(crop)
        for variant in ocr_engine.enhanced_variants(crop):
            yield ocr_engine.read_all_text(variant)

    INPUT_ROLES = {"edit", "combobox", "document", "spinner", "slider", "textbox", "text box"}

    @classmethod
    def _input_role(cls, el: dict) -> bool:
        return str(el.get("role") or "").replace(" ", "").casefold() in cls.INPUT_ROLES

    @staticmethod
    def _same_control(fe: dict, tgt: dict) -> bool:
        """Is the focused element the control the check is about? Same id / name, or its rectangle covers the recorded one."""
        aid, nm = str(tgt.get("automation_id") or ""), str(tgt.get("name") or "").strip().casefold()
        if aid and str(fe.get("automation_id") or "") == aid:
            return True
        if nm and str(fe.get("name") or "").strip().casefold() == nm and str(fe.get("role") or "") == str(tgt.get("role") or fe.get("role") or ""):
            return True
        a, b = fe.get("rect"), tgt.get("rect")
        if isinstance(a, (list, tuple)) and isinstance(b, (list, tuple)) and len(a) == len(b) == 4:
            ix = max(0, min(a[2], b[2]) - max(a[0], b[0]))
            iy = max(0, min(a[3], b[3]) - max(a[1], b[1]))
            area = max(1, (b[2] - b[0]) * (b[3] - b[1]))
            return ix * iy / area >= 0.6
        return False

    @staticmethod
    def _is_sheet_cell(el) -> bool:
        """A worksheet cell (or merged block / in-cell editor) - not the Name Box, Formula Bar, ribbon or window frame."""
        el = el or {}
        name = str(el.get("name") or "").strip()
        role = str(el.get("role") or "").casefold()
        cls = str(el.get("class_name") or "").casefold()
        if name.casefold() in ("name box", "formula bar", "insert function", "expand formula bar") or role in ("button", "menuitem", "tabitem", "titlebar"):
            return False
        return (role in ("dataitem", "cell") or "spreadsheet" in cls or "excel7" in cls or "xlcell" in cls
                or excel_com.looks_like_address(name.split(":")[0].strip()) or ":" in name)

    @staticmethod
    def _label_only(el: dict) -> bool:
        """True when UI Automation's *name* is just the control's address ("G8"), i.e. a label and not its content."""
        name = str(el.get("name") or "")
        if not excel_com.looks_like_address(name):
            return False
        cellish = str(el.get("role") or "").casefold() in ("dataitem", "cell") or "spreadsheetcell" in str(
            el.get("class_name") or "").casefold()
        return cellish or name == str(el.get("automation_id") or "")

    def _text_candidates(self, tgt: dict, window: dict):
        """Yield ``(text, how)`` from the most reliable source that can answer, best first:

          1. UI Automation value / text          (exact)
          2. Excel cell value through COM        (exact; cells are addressed "G8" - the UIA *name* is not the value)
          3. OCR of the element's own rectangle  (last resort: pointer parked away, short-value reader, cached)

        ``(None, reason)`` means the text cannot be read at all (reported as SKIPPED, never as passed)."""
        win = window or {}
        address = tgt.get("automation_id") or tgt.get("name") or tgt.get("text")
        in_excel = "excel" in (str(win.get("process") or "") + " " + str(win.get("title") or "")).casefold()
        if in_excel and excel_com.looks_like_address(address):
            value = excel_com.read_cell(str(address), str(win.get("title") or ""))      # exact and instant
            if value is not None:
                yield value, "Excel"
                return
        el = self._native(tgt, window)
        if el:
            txt = el.get("value") or el.get("text")
            if txt is None and not self._label_only(el) and not self._input_role(el):
                txt = el.get("name")          # a static label's name IS its text; an input's name is only its caption
            if txt is not None:
                yield str(txt), "UI Automation"
                return
        if in_excel and excel_com.looks_like_address(address):
            # Excel refuses COM calls while a cell is being edited (typed, Enter not pressed yet). Then the keyboard
            # focus IS the in-cell editor, and UI Automation gives its exact text.
            fe = self._focused(window)
            typed = fe.get("value") or fe.get("text")
            if typed and not excel_com.looks_like_address(typed) and not self._label_only(fe):
                yield str(typed), "Excel cell editor"
                return
        # Any application: the control that has the keyboard focus IS the field the user typed into (a text box, a cell
        # editor, a combo's edit part). If it is the recorded control, its exact text answers - no pixels.
        fe = self._focused(window)
        ftxt = fe.get("value") if fe.get("value") is not None else fe.get("text")
        if ftxt and not fe.get("is_password") and self._same_control(fe, tgt) and not self._label_only(fe):
            yield str(ftxt), "focused field"
            return
        if in_excel and excel_com.looks_like_address(address):
            # No COM (Excel not registered for automation) and not editing: Excel's Name Box + Formula Bar are ordinary
            # controls. If the Name Box names our cell, the Formula Bar holds its content - exact, no pixels.
            read_bar = lambda: winenv.excel_formula_bar(str(win.get("title") or ""))  # noqa: E731
            gov = getattr(self.resolver, "governor", None)
            bar = gov.call(window, read_bar) if gov else read_bar()
            if bar and bar[0].replace("$", "").upper() == str(address).replace("$", "").upper():
                yield bar[1], "Excel formula bar"
                return
        if not self.o.get("use_ocr", True):
            yield None, "cannot read this control without OCR, and OCR is turned off in Settings"
            return
        r = self.resolver.resolve_once(tgt, window)
        if not r:
            yield None, "element not found"
            return
        rec_pt = None
        # The control is located (by picture / position) but UI Automation did not find it by name: ask what is AT that
        # spot - UI Automation first, then the classic Win32 control text - before any pixel reading.
        try:
            at = self.resolver.governor.call(window, lambda: winenv.element_at(int(r.x), int(r.y))) if hasattr(
                self.resolver, "governor") else winenv.element_at(int(r.x), int(r.y))
            cell_target = in_excel and excel_com.looks_like_address(address)
            if cell_target and not self._is_sheet_cell(at):
                # The point that was located is not a worksheet cell (Name Box, Formula Bar, ribbon ...): its text says nothing
                # about this cell. The window is unchanged, so ask the cell where the recording put it.
                at = None
                rp = getattr(self.resolver, "_recorded_point", None)
                rec = rp(tgt) if callable(rp) and getattr(self.resolver, "_layout_same", False) else None
                if rec is not None:
                    rec_pt = (int(rec[0]), int(rec[1]))
                    at2 = self.resolver.governor.call(window, lambda: winenv.element_at(int(rec[0]), int(rec[1]))) if hasattr(
                        self.resolver, "governor") else winenv.element_at(int(rec[0]), int(rec[1]))
                    if self._is_sheet_cell(at2):
                        at = at2
            atxt = (at or {}).get("value") or (at or {}).get("text")
            if at and self._label_only(at):
                atxt = (at or {}).get("value")          # a cell's NAME is its address; only its VALUE is its content
            if atxt and not (at or {}).get("is_password") and (not self._label_only(at) or (at or {}).get("value")):
                yield str(atxt), "UI Automation at point"
                return
            wtxt = winenv.win32_text_at(int(r.x), int(r.y))
            if wtxt and in_excel and excel_com.looks_like_address(address):
                wtxt = ""                       # a worksheet cell has no Windows control text: this is the window caption
            if wtxt and str(win.get("title") or "").strip().casefold().startswith(str(wtxt).strip().casefold()) \
                    and len(str(wtxt).strip()) >= 3:
                wtxt = ""                       # the caption of the top-level window is not the content of a control in it
            if wtxt:
                yield wtxt, "Windows control text"
                return
        except Exception:
            pass
        try:
            from core.ocr import ocr_engine

            rect, rel = tgt.get("rect"), tgt.get("rel")
            if isinstance(rect, (list, tuple)) and len(rect) >= 4:
                w, h = max(rect[2] - rect[0], 60) + 24, max(rect[3] - rect[1], 24) + 16
                # r is the click point inside the element (rel); centre the crop on the element itself
                cx = r.x + (0.5 - rel[0]) * (rect[2] - rect[0]) if isinstance(rel, (list, tuple)) and len(rel) >= 2 else r.x
                cy = r.y + (0.5 - rel[1]) * (rect[3] - rect[1]) if isinstance(rel, (list, tuple)) and len(rel) >= 2 else r.y
            else:
                w, h, cx, cy = 260, 60, r.x, r.y
            if rec_pt:                                    # an Excel cell whose located point was not a cell: read WHERE IT WAS RECORDED
                cx, cy = rec_pt
            if self.park_pointer and self.o.get("park_pointer", True):
                self.park_pointer([cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2], window)
            frame, origin = self.resolver.grab()           # grabbed AFTER the pointer moved away
            x0, y0 = max(0, int(cx - origin[0] - w / 2)), max(0, int(cy - origin[1] - h / 2))
            crop = frame[y0:y0 + int(h), x0:x0 + int(w)]
            reads = self._ocr_reads(crop, ocr_engine, expected=self._expected, small=True)
            yield next(reads), "OCR"
            for text in self._lazy(reads):
                yield text, "OCR (enhanced)"
        except Exception as e:
            yield None, f"cannot read text here (needs UI Automation or an OCR engine): {type(e).__name__}"

    def _read_text(self, tgt: dict, window: dict) -> tuple[str | None, str]:
        """First available reading (used by if/loop conditions)."""
        return next(self._text_candidates(tgt, window))
