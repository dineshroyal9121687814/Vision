"""Extra step types that a Ranorex / UFT / TestComplete user expects next to the UI actions:

  set_variable   compute / copy a value (``=upper(${a})``, dates, random data, regex, arithmetic)
  run_command    run a program or script, check its exit code, keep its output in a variable
  http_request   call a web service (GET/POST/PUT/DELETE), check the status, keep a JSON field in a variable
  sql_query      query a SQLite database (test-data set-up / verification), keep the first value in a variable
  screenshot     save a picture of the screen (or the active window) into the run's evidence

External effects are never performed in a dry run. Every action reports what it did in ``res['detail']``.
"""
from __future__ import annotations

import json
import os
import re
import shlex
import sqlite3
import subprocess
import time
import urllib.error
import urllib.request
from pathlib import Path

from core import paths
from core.playback import expr
from core.playback.compare import check as compare_check

MAX_OUTPUT = 64 * 1024
KIT_TYPES = ("set_variable", "run_command", "http_request", "sql_query", "screenshot")


def json_path(data, path: str):
    """``a.b.0.c`` -> data['a']['b'][0]['c'] ('' when absent)."""
    cur = data
    for part in [p for p in str(path or "").split(".") if p != ""]:
        if isinstance(cur, dict) and part in cur:
            cur = cur[part]
        elif isinstance(cur, list) and part.lstrip("-").isdigit() and -len(cur) <= int(part) < len(cur):
            cur = cur[int(part)]
        else:
            return ""
    return cur if isinstance(cur, str) else json.dumps(cur) if isinstance(cur, (dict, list)) else str(cur)


class KitActions:
    def _kit_save(self, p: dict, res: dict, value) -> None:
        var = str(p.get("save_as") or "").strip()
        if var:
            if not re.match(r"^[a-zA-Z0-9_\-]+$", var):
                raise ValueError(f"'{var}' is not a valid variable name")
            self.app_context.set_variable(var, value)
            res.setdefault("saved_as", {})[var] = value

    # ---- set_variable ------------------------------------------------------------------------------------------------
    def _act_set_variable(self, step: dict, res: dict) -> None:
        p = step.get("params") or {}
        name = str(p.get("name") or "").strip()
        if not re.match(r"^[a-zA-Z0-9_\-]+$", name):
            raise ValueError(f"'{name}' is not a valid variable name (letters, digits, - and _)")
        try:
            value = expr.evaluate(p.get("value", ""))
        except expr.ExpressionError as e:
            raise ValueError(f"variable '{name}': {e}") from e
        self.app_context.set_variable(name, value)
        res["saved_as"] = {name: value}
        res["method"] = "variable"
        res["detail"] = f"{name} = {value!r}"

    # ---- run_command -------------------------------------------------------------------------------------------------
    def _act_run_command(self, step: dict, res: dict) -> None:
        p = step.get("params") or {}
        cmd = str(p.get("command") or "").strip()
        if not cmd:
            raise ValueError("'Command' is required")
        res["method"] = "command"
        if self.dry_run:
            res["detail"] = f"dry run: would run: {cmd}"
            return
        if not self.opts.get("allow_commands", True):
            raise ValueError("running commands is switched off in Settings (allow_commands)")
        timeout = max(1.0, min(float(p.get("timeout_s") or 60), 3600.0))
        try:
            argv = shlex.split(cmd, posix=(os.name != "nt"))
        except ValueError as e:
            raise ValueError(f"cannot read the command: {e}") from e
        cwd = str(p.get("folder") or "") or None
        try:
            done = subprocess.run(argv, capture_output=True, text=True, timeout=timeout, cwd=cwd, shell=False)
        except FileNotFoundError as e:
            raise ValueError(f"program not found: {argv[0]}") from e
        except subprocess.TimeoutExpired as e:
            raise ValueError(f"the command did not finish within {timeout:g}s") from e
        out = (done.stdout or "")[:MAX_OUTPUT].strip()
        want = int(float(p.get("expect_exit", 0)))
        res["detail"] = f"exit code {done.returncode}" + (f"; output: {out[:200]}" if out else "")
        self._kit_save(p, res, out)
        if done.returncode != want:
            err = (done.stderr or "").strip()[:300]
            raise ValueError(f"the command ended with exit code {done.returncode} (expected {want})" + (f": {err}" if err else ""))
        if p.get("expect_output"):
            ok, why = compare_check(out, "contains", p["expect_output"])
            if not ok:
                raise ValueError(f"the command's output does not contain '{p['expect_output']}' ({why})")

    # ---- http_request ------------------------------------------------------------------------------------------------
    def _act_http_request(self, step: dict, res: dict) -> None:
        p = step.get("params") or {}
        url, method = str(p.get("url") or "").strip(), str(p.get("method") or "GET").upper()
        if not re.match(r"^https?://", url, re.I):
            raise ValueError("the address must start with http:// or https://")
        if method not in ("GET", "POST", "PUT", "PATCH", "DELETE", "HEAD"):
            raise ValueError(f"unsupported method {method}")
        res["method"] = "http"
        if self.dry_run:
            res["detail"] = f"dry run: would {method} {url}"
            return
        headers = {}
        if p.get("headers"):
            try:
                headers = json.loads(p["headers"]) if isinstance(p["headers"], str) else dict(p["headers"])
            except ValueError as e:
                raise ValueError("'Headers' must be JSON like {\"Authorization\": \"Bearer ...\"}") from e
        body = p.get("body")
        data = None if body in (None, "") else (body if isinstance(body, bytes) else str(body).encode("utf-8"))
        if data is not None and not any(k.lower() == "content-type" for k in headers):
            headers["Content-Type"] = "application/json" if str(body).lstrip()[:1] in "{[" else "text/plain"
        req = urllib.request.Request(url, data=data, headers=headers, method=method)
        timeout = max(1.0, min(float(p.get("timeout_s") or 30), 300.0))
        t0 = time.monotonic()
        try:
            with urllib.request.urlopen(req, timeout=timeout) as r:                  # noqa: S310 (scheme checked above)
                status, text = r.status, r.read(MAX_OUTPUT).decode("utf-8", "replace")
        except urllib.error.HTTPError as e:
            status, text = e.code, e.read(MAX_OUTPUT).decode("utf-8", "replace")
        except (urllib.error.URLError, OSError) as e:
            raise ValueError(f"could not reach {url}: {getattr(e, 'reason', e)}") from e
        ms = int((time.monotonic() - t0) * 1000)
        res["detail"] = f"{method} {url} -> {status} in {ms} ms"
        value = text
        if p.get("json_path"):
            try:
                value = json_path(json.loads(text), p["json_path"])
            except ValueError:
                raise ValueError("the answer is not JSON, so the JSON field cannot be read") from None
        self._kit_save(p, res, value)
        want = str(p.get("expect_status") or "").strip()
        ok = (str(status) in re.split(r"[,; ]+", want)) if want else 200 <= status < 300
        if not ok:
            raise ValueError(f"the service answered {status} (expected {want or '2xx'}): {text[:200]}")
        if p.get("expect_text") and str(p["expect_text"]) not in text:
            raise ValueError(f"the answer does not contain '{p['expect_text']}'")

    # ---- sql_query ---------------------------------------------------------------------------------------------------
    def _act_sql_query(self, step: dict, res: dict) -> None:
        p = step.get("params") or {}
        db, sql = str(p.get("database") or "").strip(), str(p.get("sql") or "").strip()
        if not db or not sql:
            raise ValueError("'Database file' and 'SQL' are required")
        write = bool(p.get("allow_changes"))
        if not write and not re.match(r"^\s*(select|with|pragma)\b", sql, re.I):
            raise ValueError("only SELECT is allowed unless 'Allow changes' is ticked")
        res["method"] = "sql"
        if self.dry_run:
            res["detail"] = f"dry run: would run on {db}: {sql[:120]}"
            return
        path = Path(db) if Path(db).is_absolute() else Path(self.dir) / db
        if not path.exists():
            raise ValueError(f"database file not found: {path}")
        uri = f"file:{path.as_posix()}?mode={'rw' if write else 'ro'}"
        try:
            con = sqlite3.connect(uri, uri=True, timeout=10)
            try:
                cur = con.execute(sql)
                rows = cur.fetchmany(1000) if cur.description else []
                if write:
                    con.commit()
            finally:
                con.close()
        except sqlite3.Error as e:
            raise ValueError(f"database error: {e}") from e
        first = "" if not rows else ("" if rows[0][0] is None else str(rows[0][0]))
        res["detail"] = f"{len(rows)} row(s); first value: {first[:80]!r}"
        self._kit_save(p, res, first)
        if p.get("expect_rows") not in (None, ""):
            if len(rows) != int(float(p["expect_rows"])):
                raise ValueError(f"the query returned {len(rows)} row(s), expected {int(float(p['expect_rows']))}")
        if p.get("expect_value") not in (None, ""):
            ok, why = compare_check(first, "equals", p["expect_value"])
            if not ok:
                raise ValueError(f"first value differs: {why}")

    # ---- screenshot --------------------------------------------------------------------------------------------------
    def _act_screenshot(self, step: dict, res: dict) -> None:
        p = step.get("params") or {}
        res["method"] = "screenshot"
        if self.dry_run:
            res["detail"] = "dry run: would save a screenshot"
            return
        import cv2
        from core.system.imageio import imwrite
        frame, _origin = self.grab()
        name = re.sub(r"[^\w\-]+", "_", str(p.get("name") or f"step{step.get('id', 0)}"))[:60] or "screenshot"
        run_dir = Path(getattr(self, "run_dir", None) or paths.workspace())
        out = run_dir / f"shot_{name}.jpg"
        imwrite(out, frame, 85)
        res["screenshot"] = out.name
        res["detail"] = f"saved {out.name}"
