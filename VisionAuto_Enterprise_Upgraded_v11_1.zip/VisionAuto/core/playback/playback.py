"""CLI entry kept for compatibility:  python -m core.playback.playback --name my_test [--dry-run]"""
from __future__ import annotations

import argparse

from core import paths
from core.playback.player import Player


def main() -> None:
    p = argparse.ArgumentParser(description="VisionAuto playback")
    p.add_argument("--name", required=True)
    p.add_argument("--dry-run", action="store_true", help="resolve nothing, press nothing, just walk the steps")
    p.add_argument("--no-ocr", action="store_true")
    p.add_argument("--no-ai", action="store_true")
    p.add_argument("--continue-on-failure", action="store_true")
    a = p.parse_args()
    paths.setup_logging()

    opts = {"use_ocr": not a.no_ocr, "use_ai": not a.no_ai}
    if a.continue_on_failure:
        opts["continue_on_failure"] = True

    def show(r):
        if r.get("status") != "running":
            print(f"  [{r['id']:>3}] {r['status'].upper():7} {r.get('description', '')}"
                  + (f"   via {r['method']}" if r.get("method") else "")
                  + (f"\n          {r['error']}" if r.get("error") else ""))

    run = Player(a.name, opts, dry_run=a.dry_run, on_step=show).run()
    s = run["summary"]
    print(f"\n{run['status'].upper()}: {s['passed']}/{s['total']} steps passed, {s['healed']} healed -> {run['_dir']}")
    raise SystemExit(0 if run["status"] == "passed" else 1)


if __name__ == "__main__":
    main()
