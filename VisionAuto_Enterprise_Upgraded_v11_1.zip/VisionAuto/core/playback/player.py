"""
Player v2: replays a recorded test exactly as the user did it.

Per step: make the right window active -> resolve the target through the
locator chain (waiting until it is visible) -> perform the action -> wait for
the screen to settle -> evaluate the step's validation points.
No fixed sleeps: every wait is condition based.

Self-healing: when a step is only found by a fallback tier (ORB / OCR / AI /
ring search) the new appearance is stored back into the test (test.json.bak is
kept), so the next run starts from the healed locator.
"""
from __future__ import annotations

import logging
import math
import platform
import shutil
import sys
import threading
import time
from copy import deepcopy
from datetime import datetime
from importlib import metadata
from pathlib import Path

import cv2

from core import paths, retry, settings, testfile
from core import datasource, redaction, validation
from core.system import geometry
from core.playback.app_context import AppContextManager, UndefinedVariable
from core.playback.backend import DryRunBackend, InputBackend, create_backend
from core.automation import effect as fx
from core.automation import window_target as wt
from core.automation.errors import (AmbiguousTarget, LowConfidenceTarget, PostconditionFailed, TargetError, WindowNotFound,
                                    WrongTarget)
from core.playback.actions_ext import ExtendedActions
from core.playback.stepkit import KIT_TYPES, KitActions
from core.system import excel_launch
from core.playback.resolver import Aborted, ElementNotFound, Resolution, Resolver
from core.playback.validators import Validator
from core.playback import textmatch
from core.system import excel_com
from core.system import launcher, winenv
from core.system.imageio import imwrite

log = logging.getLogger("visionauto.player")

BUTTON_CLICKS = {"click": ("left", 1), "double_click": ("left", 2),
                 "right_click": ("right", 1), "middle_click": ("middle", 1)}
MAX_EXPLICIT_WAIT_S = 3600.0


def _runtime_environment() -> dict:
    packages = {}
    for package in ("PySide6", "numpy", "opencv-python", "pynput", "pywinauto", "easyocr", "onnxruntime"):
        try:
            packages[package] = metadata.version(package)
        except metadata.PackageNotFoundError:
            continue
    return {"os": platform.platform(), "python": sys.version.split()[0], "packages": packages}


def _same_rect(a, b, tol: int = 24) -> bool:
    return all(abs(int(x) - int(y)) <= tol for x, y in zip(a, b))


class Player(ExtendedActions, KitActions):
    def __init__(self, test_ref, options: dict | None = None, backend: InputBackend | None = None,
                 on_step=None, should_stop=None, dry_run: bool = False, grab=None, base_dir=None,
                 data=None, data_select=None, controller=None, ask_user=None):
        saved_options = settings.load()
        if isinstance(test_ref, dict):          # in-memory test (Ranorex script mode builds steps on the fly)
            self.test, self.dir = test_ref, Path(base_dir or paths.workspace())
        else:
            self.test, self.dir = testfile.load_test(test_ref)
        try:                       # reusable modules: call_test steps become the called test's steps
            from core import modules as _modules
            if any(st.get("type") == "call_test" for st in self.test.get("steps") or []):
                self.test = _modules.expand(self.test, lambda n: testfile.load_test(n)[0])
        except _modules.ModuleError as e:
            raise ValueError(str(e)) from e
        try:                       # recordings made before open_app existed (or by an older build) still launch apps
            from core.recorder.launch_detect import compact_launches
            steps, changes = compact_launches(self.test.get("steps") or [])
            if changes:
                self.test = {**self.test, "steps": steps, "recording_notes": changes}
                log.info("playback: %d Start-menu launch(es) replaced by open_app", len(changes))
        except Exception:
            log.debug("launch compaction at load failed", exc_info=True)
        try:                       # values the tester chose (inputs.json next to the test) replace the recorded typed text
            from core import inputs as _inputs
            over = dict(self.test.get("input_overrides") or {}) or _inputs.load(self.dir)
            if over:
                self.test = {**self.test, "steps": deepcopy(self.test.get("steps") or [])}
                n = _inputs.apply(self.test, {int(k): v for k, v in over.items()})
                if n:
                    log.info("playback: %d typed value(s) taken from the tester's inputs", n)
        except Exception:
            log.debug("tester inputs not applied", exc_info=True)
        try:                       # a wrongly recorded element (e.g. "Close" where a cell was clicked) must not replay
            from core.recorder import sanity
            steps = deepcopy(self.test.get("steps") or [])
            notes = sanity.repair_steps(steps)
            if notes:
                self.test = {**self.test, "steps": steps,
                             "recording_notes": list(self.test.get("recording_notes") or []) + notes}
                log.warning("playback: %d step(s) named the wrong element and were repaired: %s", len(notes), notes)
        except Exception:
            log.debug("recording sanity check failed", exc_info=True)
        try:                       # older recordings get the same "what was the user doing" labels
            from core.recorder import intent
            if any(isinstance(x, dict) and "intent" not in x for x in self.test.get("steps") or []):
                self.test = {**self.test, "steps": deepcopy(self.test.get("steps") or [])}
                intent.annotate(self.test["steps"])
        except Exception:
            log.debug("intent annotation at load failed", exc_info=True)
        test_options = self.test.get("options") if isinstance(self.test.get("options"), dict) else {}
        self.opts = settings.validate({**saved_options, **test_options, **(options or {})})
        self.dry_run = dry_run
        self.backend = backend or (DryRunBackend() if dry_run else create_backend(self.opts.get("input_backend", "auto")))
        self.on_step = on_step
        self.controller = controller                   # execution.RunController (pause/resume/stop/cancel) or None
        base_stop = should_stop or (lambda: False)
        self.should_stop = (lambda: base_stop() or controller.should_stop()) if controller else base_stop
        self.ask_user = ask_user                       # callable(payload, timeout_s) -> "retry" | "skip" | "stop" | None
        self.policy = retry.RetryPolicy.from_options(self.opts)
        self._engine = None
        self._policy_stop = False
        self._restart_requested = False
        self._hard_failures = 0
        self._next_type = None
        self._next_step = None
        self._prev_step = None
        self._prev_res = None
        self._last_click = None
        self.grab = grab or winenv.grab_screen
        self.resolver = Resolver(self.dir, self.opts, abort_check=self.should_stop, grab=self.grab)
        if not dry_run:
            from core.playback.scrollfind import ScrollFinder
            self.resolver.scrollfinder = ScrollFinder(self.resolver, self.backend.scroll, self.backend.type_text, self.opts)
        # Scroll-to-find only where the recording itself shows scrolling (or the target lives in a list / drop-down):
        # a recording with no scroll must never scroll a sheet or a page on its own.
        self.resolver.recording_scrolls = any(isinstance(x, dict) and x.get("type") == "scroll"
                                              for x in self.test.get("steps") or [])
        self._note_recorded_scrolls()
        self.validator = Validator(self.resolver, self.opts, dry_run=dry_run)
        self.validator.park_pointer = self._park_pointer
        self._pending_cells: list[dict] = []      # typed values in Excel cells, verified after the commit key (COM)
        self._diag_cache: dict = {}               # one (slow) failure diagnosis per distinct failure, not per retry
        try:
            from core.ocr import ocr_engine
            ocr_engine.configure(self.opts.get("ocr_engine", "auto"))
        except Exception:
            pass
        self.app_context = AppContextManager.from_test(self.test, dry_run=self.dry_run, opts=self.opts)
        self._heals: list[dict] = []
        self.data_override, self.data_select = data, data_select      # data-driven run: path / inline rows, "1-3,5"
        self._row_secret_vars: dict = {}
        self._run_extra: dict = {}
        self._geometry_log: list[dict] = []
        self._recoveries: list[dict] = []
        self.run_dir: Path | None = None
        self.run_id = ""

    # ------------------------------------------------------------------ run
    MAX_EXECUTED_STEPS = 50_000     # hard ceiling on executed steps (loops + data rows) per run
    MAX_LOOP_ROWS = 20              # loop_start rows written to the report per loop

    def run(self) -> dict:
        started = self.begin()
        try:
            data = datasource.resolve(self.test, self.dir, self.data_override, self.data_select)
        except datasource.DataError as e:
            return self.finish([], "invalid", started, error=f"Data source: {e}")
        check = self.test
        if data:
            cfg = self.test.get("data") if isinstance(self.test.get("data"), dict) else {}
            check = {**self.test, "data": {**cfg, "columns": data["columns"]}}
        issues = validation.validate_test(check)
        self.validation_issues = issues
        blocking = validation.errors_only(issues)
        if blocking:
            # Nothing is launched and no input is sent when the test itself is invalid.
            return self.finish([], "invalid", started, error=validation.format_issues(blocking))
        results: list[dict] = []
        status = "passed"
        try:
            try:
                self.app_context.start_all()
            except Exception as e:
                log.exception("application startup failed")
                status = "failed"
                results.append({"id": 0, "type": "startup", "description": "Start applications", "status": "failed",
                                "error": f"{type(e).__name__}: {e}", "validations": [], "app": "", "duration_ms": 0})
            policy = self.test.get("failure_policy") or ("continue" if self.opts.get("continue_on_failure") else "stop")
            cleanup_steps = [st for st in self.test["steps"] if st.get("cleanup")]
            main_steps = [] if status == "failed" else [st for st in self.test["steps"] if not st.get("cleanup")]
            self._executed = 0
            if data:
                status = self._run_data_rows(data, main_steps, policy, results, status)
            elif main_steps:
                status = self._run_with_restarts(main_steps, policy, results, None)
            # Cleanup steps run after success, failure and cancellation alike.
            for step in cleanup_steps:
                res = self._run_with_retries(step)
                res["cleanup"] = True
                results.append(res)
                self._emit(res)
                if res["status"] == "failed" and status == "passed":
                    status = "failed"
        except BaseException:
            # Crash inside the engine: still close what we launched and write a result before propagating.
            try:
                self.finish(results, "failed", started, error="engine crashed; see log")
            finally:
                raise
        if status == "aborted" and self.controller is not None and self.controller.is_cancelled():
            status = "cancelled"
        return self.finish(results, status, started)

    # ------------------------------------------------------------------ restart-the-test recovery
    def _run_with_restarts(self, steps: list, policy: str, results: list, iteration) -> str:
        """Run the program; when the retry policy asks to restart the whole test case, close and relaunch the
        applications and run it again (at most ``retry_max_attempts`` times). Earlier attempts are kept in the
        report under ``restarts`` and are not counted in the summary."""
        first = len(results)
        restarts = 0
        while True:
            self._restart_requested = False
            status = self._run_program(steps, policy, results, iteration)
            if not (self._restart_requested and status == "failed" and not self.should_stop()
                    and restarts < max(1, self.policy.max_attempts)):
                return status
            restarts += 1
            self._run_extra.setdefault("restarts", []).append(
                {"attempt": restarts, "iteration": iteration, "steps": results[first:]})
            del results[first:]
            self._hard_failures = 0
            try:
                self.app_context.cleanup(policy=self.opts.get("app_cleanup_policy", "close_test_launched"))
                self._sleep(self.policy.delay_s)
                self.app_context.start_all()
            except Exception as e:                      # noqa: BLE001 - reported, then the run ends as failed
                log.exception("restart of the test case failed")
                results.append({"id": 0, "type": "startup", "description": f"Restart attempt {restarts}",
                                "status": "failed", "error": f"{type(e).__name__}: {e}", "validations": [],
                                "app": "", "duration_ms": 0})
                return "failed"

    # ------------------------------------------------------------------ data-driven iterations
    def _run_data_rows(self, data: dict, steps: list, policy: str, results: list, status: str) -> str:
        secret_cols = set(data["secret_columns"])
        iterations = []
        overall = status
        for n, (row_no, row) in enumerate(data["rows"], 1):
            if self.should_stop():
                overall = "aborted"
                break
            if n > 1 and data["restart_apps"] and not self.dry_run:
                try:
                    self.app_context.cleanup(policy=self.opts.get("app_cleanup_policy", "close_test_launched"))
                    self.app_context.start_all()
                except Exception as e:
                    log.exception("application restart between rows failed")
                    results.append({"id": 0, "type": "startup", "description": f"[#{n}] Restart applications",
                                    "status": "failed", "error": f"{type(e).__name__}: {e}", "validations": [],
                                    "app": "", "duration_ms": 0, "iteration": n})
                    iterations.append({"iteration": n, "row": row_no, "status": "failed"})
                    overall = "failed"
                    break
            for col, val in row.items():
                self.app_context.set_variable(col, val)
                if col in secret_cols:
                    self._row_secret_vars[f"_s{n}_{col}"] = val
            self.app_context.set_variable("_row", str(row_no))
            self.app_context.set_variable("_iteration", str(n))
            first = len(results)
            row_status = self._run_with_restarts(steps, policy, results, n)
            iterations.append({"iteration": n, "row": row_no, "status": row_status,
                               "data": {k: ("***" if k in secret_cols else v) for k, v in row.items()},
                               "failed_steps": sum(1 for r in results[first:] if r["status"] == "failed")})
            if row_status == "aborted":
                overall = "aborted"
                break
            if row_status == "failed":
                overall = "failed"
                if data["on_row_failure"] == "stop":
                    break
        self._run_extra["iterations"] = iterations
        self._run_extra["data"] = {"columns": [c for c in data["columns"] if c not in secret_cols],
                                   "rows_run": len(iterations), "rows_selected": len(data["rows"]),
                                   "rows_passed": sum(1 for i in iterations if i["status"] == "passed"),
                                   "rows_failed": sum(1 for i in iterations if i["status"] == "failed")}
        return overall

    # ------------------------------------------------------------------ control-flow executor
    @staticmethod
    def _block_map(steps: list) -> dict:
        """loop_start/if_start index -> {end, else}; else index -> {end}. validate_test guarantees balance."""
        info: dict = {}
        stack: list = []
        for i, st in enumerate(steps):
            t = st["type"]
            if t in ("loop_start", "if_start"):
                stack.append(i)
                info[i] = {"end": None, "else": None}
            elif t == "else" and stack:
                info[stack[-1]]["else"] = i
            elif t in ("loop_end", "if_end") and stack:
                top = stack.pop()
                info[top]["end"] = i
                if info[top]["else"] is not None:
                    info[info[top]["else"]] = {"end": i}
        return info

    def _control_row(self, step: dict, detail: str, iteration, status: str = "passed") -> dict:
        row = {"id": step["id"], "type": step["type"], "description": step.get("description", ""), "status": status,
               "detail": detail, "validations": [], "app": step.get("app", ""), "duration_ms": 0, "control": True}
        if iteration:
            row["iteration"] = iteration
            row["description"] = f"[#{iteration}] {row['description']}"
        return row

    def _run_program(self, steps: list, policy: str, results: list, iteration) -> str:
        n, blocks = len(steps), self._block_map(steps)
        failed_apps: set[str] = set()
        loops: list[dict] = []
        status, pc = "passed", 0
        while pc < n:
            if self.controller is not None and not self.controller.wait_if_paused():
                return "aborted"
            if self.should_stop():
                return "aborted"
            self._executed += 1
            if self._executed > self.MAX_EXECUTED_STEPS:
                results.append(self._control_row(steps[pc], f"stopped: more than {self.MAX_EXECUTED_STEPS} steps executed "
                                                 "(endless loop?)", iteration, "failed"))
                self._emit(results[-1])
                return "failed"
            step = steps[pc]
            t = step["type"]
            if t == "loop_start":
                end = blocks[pc]["end"]
                frame = loops[-1] if loops and loops[-1]["start"] == pc else None
                if frame is None:
                    try:
                        frame = self._new_loop(step, pc, end)
                    except (ValueError, UndefinedVariable) as e:
                        res = self._control_row(step, str(e), iteration, "failed")
                        results.append(res)
                        self._emit(res)
                        status = "failed"
                        if policy == "stop":
                            return status
                        pc = end + 1
                        continue
                    loops.append(frame)
                go = self._loop_continues(frame, step)
                if go:
                    frame["i"] += 1
                    self.app_context.set_variable("_loop", str(frame["i"]))
                    if frame["i"] <= self.MAX_LOOP_ROWS:
                        res = self._control_row(step, f"loop iteration {frame['i']}", iteration)
                        results.append(res)
                        self._emit(res)
                    pc += 1
                else:
                    loops.pop()
                    pc = end + 1
                continue
            if t == "loop_end":
                pc = loops[-1]["start"] if loops else pc + 1
                continue
            if t == "break_loop":
                if loops:
                    frame = loops.pop()
                    results.append(self._control_row(step, "break", iteration))
                    self._emit(results[-1])
                    pc = frame["end"] + 1
                else:
                    pc += 1
                continue
            if t == "if_start":
                info = blocks[pc]
                try:
                    ok = self._eval_condition(step.get("condition") or {}, step)
                except (ValueError, UndefinedVariable) as e:
                    res = self._control_row(step, str(e), iteration, "failed")
                    results.append(res)
                    self._emit(res)
                    status = "failed"
                    if policy == "stop":
                        return status
                    pc = info["end"] + 1
                    continue
                res = self._control_row(step, f"condition is {'true' if ok else 'false'}", iteration)
                results.append(res)
                self._emit(res)
                if ok:
                    pc += 1
                elif info["else"] is not None:
                    pc = info["else"] + 1
                else:
                    pc = info["end"] + 1
                continue
            if t == "else":
                pc = blocks[pc]["end"] + 1            # finished the true branch: skip the else branch
                continue
            if t == "if_end":
                pc += 1
                continue
            app = step.get("app") or ""
            if policy == "skip_app" and app and app in failed_apps:
                res = self._skipped(step, f"skipped: application '{app}' already failed in this test")
                if iteration:
                    res["iteration"] = iteration
                results.append(res)
                self._emit(res)
                pc += 1
                continue
            self._emit({"id": step["id"], "status": "running", "description": step.get("description", "")})
            self._next_type = steps[pc + 1]["type"] if pc + 1 < n else None
            self._next_step = steps[pc + 1] if pc + 1 < n else None
            res = self._run_with_retries(step)
            if iteration:
                res["iteration"] = iteration
                res["description"] = f"[#{iteration}] {res.get('description', '')}"
            results.append(res)
            self._emit(res)
            if res["status"] == "aborted":
                return "aborted"
            if res["status"] == "failed":
                status = "failed"
                if self._policy_stop or self._restart_requested:
                    return status
                if step.get("on_fail") == "continue":
                    res["soft_failure"] = True            # soft check: reported as failed, the rest of the test still runs
                    pc += 1
                    continue
                if policy == "stop":
                    return status
                if app:
                    failed_apps.add(app)
            pc += 1
        return status

    def _new_loop(self, step: dict, start: int, end: int) -> dict:
        p = step.get("params") or {}
        if "times" in p:
            raw = self.app_context.substitute_variables(p["times"], strict=True)
            try:
                times = int(str(raw).strip())
            except ValueError:
                raise ValueError(f"loop 'times' resolved to '{raw}', which is not a whole number") from None
            if not 1 <= times <= validation.MAX_LOOP_TIMES:
                raise ValueError(f"loop 'times' must be 1-{validation.MAX_LOOP_TIMES}, got {times}")
            return {"start": start, "end": end, "i": 0, "times": times, "cond": None, "max": times}
        return {"start": start, "end": end, "i": 0, "times": None, "cond": p.get("while"),
                "max": min(int(p.get("max", 100)), validation.MAX_LOOP_TIMES)}

    def _loop_continues(self, frame: dict, step: dict) -> bool:
        if frame["i"] >= frame["max"]:
            return False
        if frame["times"] is not None:
            return True
        if self.dry_run and frame["cond"] and frame["cond"].get("type") in ("exists", "not_exists", "text_contains", "text_equals"):
            return frame["i"] < 1        # a simulated UI cannot change: run a dry-run while-loop once
        return self._eval_condition(frame["cond"] or {}, step)

    # ------------------------------------------------------------------ conditions
    def _eval_condition(self, cond: dict, step: dict) -> bool:
        cond = self.app_context.substitute_variables(deepcopy(cond), strict=True)
        t = cond.get("type")
        if t == "variable":
            have = str(self.app_context.variables.get(cond.get("name"), ""))
            want, op = str(cond.get("value", "")), cond.get("op")
            if op == "equals":
                return have == want
            if op == "not_equals":
                return have != want
            if op == "contains":
                return want in have
            if op == "not_contains":
                return want not in have
            if op == "empty":
                return have.strip() == ""
            if op == "not_empty":
                return have.strip() != ""
            try:
                a, b = float(have), float(want)
            except ValueError:
                return False
            return {"gt": a > b, "lt": a < b, "ge": a >= b, "le": a <= b}[op]
        if self.dry_run:
            return t in ("exists", "text_contains", "text_equals")
        target, window = cond.get("target") or {}, cond.get("window") or step.get("window") or {}
        try:
            self._ensure_window({"window": window, "type": "wait"})
        except (ElementNotFound, Aborted):
            if self.should_stop():
                raise
            return t == "not_exists"
        if t in ("exists", "not_exists"):
            try:
                self.resolver.resolve(target, window, float(cond.get("timeout_s", 2.0)))
                found = True
            except ElementNotFound:
                found = False
            return found if t == "exists" else not found
        from core.playback import textmatch

        for actual, how in self.validator._text_candidates(target, window):
            if actual is None:
                return False
            if textmatch.match(actual, cond.get("expected", ""), t, how, cond.get("match") == "strict")[0]:
                return True
        return False

    def _skipped(self, step: dict, why: str) -> dict:
        return {"id": step["id"], "type": step["type"], "description": step.get("description", ""), "status": "skipped",
                "detail": why, "validations": [], "app": step.get("app", ""), "duration_ms": 0}

    def _run_with_retries(self, step: dict) -> dict:
        """Retry only failures that provably sent no input (target not found, or a read-only validate step)."""
        attempts = 1 + min(int(step.get("retries") or 0), validation.MAX_RETRIES)
        res = self._run_step(step)
        if res["status"] == "failed" and res.get("retryable") and self._try_recovery(step):
            res = self._run_step(step)
            res["recovered"] = True
        if res["status"] == "failed" and res.get("retryable") and not res.get("failure_kind") and step["type"] != "validate":
            done = self._repeat_previous(step)
            if done:
                res = self._run_step(step)
                res["repeated_previous"] = done
        n = 1
        while res["status"] == "failed" and res.get("retryable") and n < attempts and not self.should_stop():
            self._sleep(min(0.5 * n, 2.0))
            res = self._run_step(step)
            n += 1
        if n > 1:
            res["attempts"] = n
        if res["status"] == "passed" and step["type"] not in ("loop_start", "loop_end", "if_start", "else", "if_end", "break_loop"):
            self._prev_step, self._prev_res = step, res
        history: list[dict] = []
        res = self._policy_retries(step, res, history)
        if history:
            res["retry_history"] = history
        res.pop("retryable", None)
        if res["status"] == "failed":
            self._hard_failures += 1
            limit = self.policy.stop_after_failures
            if limit and self._hard_failures >= limit and not self._policy_stop:
                self._policy_stop = True
                res["stop_reason"] = f"stopped after {self._hard_failures} failed steps in a row (retry policy)"
        elif res["status"] == "passed":
            self._hard_failures = 0
        return res

    # ------------------------------------------------------------------ before / after evidence
    # A click that changed nothing is repeated ONLY on controls where a second click cannot do harm. Buttons (Save, Send,
    # Submit, Add ...) may have acted invisibly: they are reported, never repeated.
    RETRY_OK_ROLES = ("tabitem", "listitem", "treeitem", "dataitem", "edit", "document", "text", "pane", "hyperlink", "image")

    def _observe_change(self, region, before, origin):
        """Poll the same screen region until it differs from ``before`` (or the wait runs out)."""
        deadline = time.monotonic() + float(self.opts.get("effect_wait_s", 0.7))
        best = 0.0
        while True:
            time.sleep(0.12)
            frame, _ = self.grab()
            after = fx.crop(frame, region)
            best = max(best, fx.difference(before, after))
            if best >= fx.CHANGE_THRESHOLD or time.monotonic() >= deadline or self.should_stop():
                return fx.Effect(best >= fx.CHANGE_THRESHOLD, best)

    def _click_checked(self, r, button, count, mods, step, res) -> None:
        """Send the click with EXACTLY the recorded button / count / modifiers, then look at the same spot again.
        Nothing changed -> one repeat (never for toggles); still nothing -> reported (and a failure in strict mode)."""
        option = step.get("intent") == "pick_option"
        if option and not self.dry_run:                                 # list items highlight on hover; a click that arrives
            self.backend.move(r.x, r.y)                                 # with the pointer is sometimes ignored
            time.sleep(0.12)

        def send():
            if mods:
                self.backend.click(r.x, r.y, button, count, modifiers=mods)
            else:
                self.backend.click(r.x, r.y, button, count)
        opener = step.get("intent") == "open_dropdown"                 # a list that did not open is not a click that worked
        check = (not self.dry_run and (self.opts.get("verify_effect", True) or opener) and not step.get("no_effect_check"))
        before = region = None
        if check:
            try:
                self.backend.move(r.x, r.y)
                time.sleep(0.12)
                frame, origin = self.grab()
                region = fx.region_around((r.x, r.y), frame.shape, origin=origin)
                before = fx.crop(frame, region)
            except Exception:
                log.debug("effect check unavailable", exc_info=True)
        send()
        if before is None:
            return
        try:
            ef = self._observe_change(region, before, None)
            role = str((step.get("target") or {}).get("role") or "").casefold()
            if (not ef.changed and (self.opts.get("retry_no_effect", True) or opener) and count == 1 and button in ("left", "right")
                    and (role in self.RETRY_OK_ROLES or opener) and not mods):
                time.sleep(0.25)
                send()
                ef = self._observe_change(region, before, None)
                ef.retried = True
        except Aborted:
            raise
        except Exception:
            log.debug("effect check failed", exc_info=True)
            return
        res["effect"] = ef.as_dict()
        if ef.changed:
            self._verified(res, type="screen_changed_at_click", difference=round(ef.difference, 4))
        else:
            res.setdefault("warnings", []).append("nothing visibly changed at the clicked place")
            if self.opts.get("strict_effect", False):
                raise PostconditionFailed("The click was sent but nothing changed on screen at that place.",
                                          {"effect": ef.as_dict()})

    def _ocr_verify_typed(self, text: str, fe: dict, res: dict) -> None:
        """UI Automation cannot read the field back: look at the screen. Typed text must be visible next to the focus."""
        if not self.opts.get("ocr_verify_typing", True) or len(text.strip()) < 3 or len(text) > 200 or "\n" in text:
            return
        if fe.get("is_password"):
            return
        try:
            from core.ocr import ocr_engine
            frame, origin = self.grab()
            rect = fe.get("rect")
            if geometry.valid(rect):
                pt = ((rect[0] + rect[2]) / 2, (rect[1] + rect[3]) / 2)
                size = (max(320, int(rect[2] - rect[0]) + 40), max(100, int(rect[3] - rect[1]) + 40))
            elif getattr(self, "_last_click", None):
                pt, size = self._last_click, (420, 120)
            else:
                return
            img = fx.crop(frame, fx.region_around(pt, frame.shape, size, origin))
            seen = ocr_engine.read_all_text(img) if img is not None else ""
        except Exception:
            log.debug("OCR typing check unavailable", exc_info=True)
            return
        if fx.text_in(seen, text):
            self._verified(res, type="typed_text_seen_by_ocr")
        else:
            res.setdefault("warnings", []).append("typed text was not found on screen by OCR next to the focused field")
            if self.opts.get("strict_effect", False):
                raise PostconditionFailed("The text was typed but cannot be seen on screen at the focused field.",
                                          {"ocr_seen": seen[:80]})

    # ------------------------------------------------------------------ repeat the previous step (last rung)
    REPEAT_SAFE_TYPES = ("hover", "wait", "wait_for_window")
    REPEAT_SAFE_ROLES = ("tabitem", "menuitem", "treeitem", "hyperlink", "listitem", "dataitem")

    def _may_repeat(self, prev: dict | None, prev_res: dict | None) -> str:
        """'' = do not repeat, else the reason it is safe. 'safe' policy never repeats something that could duplicate
        data (Add / Submit buttons, typing); it repeats navigation and clicks that provably changed nothing."""
        policy = self.opts.get("repeat_previous_policy", "safe")
        if not prev or policy == "never" or prev["type"] in ("type", "set_value", "append_value", "fill_table", "drag_drop"):
            return ""
        if policy == "always":
            return "policy: always"
        if prev.get("idempotent"):
            return "step marked idempotent"
        if prev["type"] in self.REPEAT_SAFE_TYPES:
            return f"'{prev['type']}' can be repeated safely"
        if prev["type"] in BUTTON_CLICKS:
            if (prev_res or {}).get("effect", {}).get("changed") is False:
                return "the previous click had changed nothing on screen"
            if str((prev.get("target") or {}).get("role") or "").casefold() in self.REPEAT_SAFE_ROLES:
                return "previous click is a navigation click"
        return ""

    def _repeat_previous(self, step: dict) -> str:
        prev, prev_res = self._prev_step, self._prev_res
        why = self._may_repeat(prev, prev_res)
        if not why or self.dry_run or self.should_stop() or step.get("id") == (prev or {}).get("id"):
            return ""
        again = self._run_step(prev)
        if again["status"] != "passed":
            return ""
        self._sleep(0.4)
        return f"repeated step {prev['id']} ({why})"

    # ------------------------------------------------------------------ AI-assisted retry policy
    def _policy_retries(self, step: dict, res: dict, history: list) -> dict:
        """Diagnose -> classify -> (ask the user) -> corrective action -> retry, bounded and fully recorded."""
        pol = self.policy
        if self.dry_run or not pol.enabled or pol.max_attempts <= 0 or res["status"] != "failed":
            return res
        for attempt in range(1, pol.max_attempts + 1):
            if self.should_stop():
                break
            cls = retry.classify(res)
            diag = res.get("ai_diagnosis")
            entry = {"attempt": attempt, "at": datetime.now().isoformat(timespec="seconds"),
                     "error": res.get("error", ""), "category": cls["category"], "recoverable": cls["recoverable"],
                     "input_sent": cls["input_sent"], "diagnosis": diag, "screenshot": res.get("screenshot"),
                     "corrective_action": retry.corrective_action(diag, cls)}
            history.append(entry)
            if not cls["recoverable"]:
                entry.update(decision="give_up", via="permanent-failure", note=cls["reason"])
                break
            if pol.mode == "stop":
                entry.update(decision="stop", via="policy")
                self._policy_stop = True
                break
            answer, asked = None, False
            if pol.ask_before:
                asked = True
                answer = self._ask_retry(step, res, cls, entry, attempt)
                entry.update(asked=True, answer=answer or "no answer")
            elif not pol.auto:
                entry.update(decision="give_up", via="auto-retry-off")
                break
            action, via = retry.decide(pol, cls, answer, asked)
            entry.update(decision=action, via=via)
            if action == "stop":
                self._policy_stop = True
                break
            if action == "skip":
                break
            if pol.mode == "restart_test":
                self._restart_requested = True
                entry["note"] = "the whole test case will be restarted"
                break
            self._apply_corrective(step, entry["corrective_action"], attempt)
            if not self._retry_wait(pol.delay_s):
                break
            again = self._run_step(step)
            entry["result"] = again["status"]
            res = {**again, "attempts": res.get("attempts", 1) + attempt}
            if again["status"] == "passed":
                res["recovered_by_retry"] = True
                break
            if again["status"] == "aborted":
                break
        return res

    def _ask_retry(self, step: dict, res: dict, cls: dict, entry: dict, attempt: int):
        """Ask the user (via the GUI / CLI callback). No callback or no answer in time -> None."""
        if self.ask_user is None:
            return None
        payload = {"step_id": step.get("id"), "description": step.get("description", ""), "error": res.get("error", ""),
                   "diagnosis": res.get("ai_diagnosis"), "classification": cls,
                   "suggested_action": entry["corrective_action"], "attempt": attempt,
                   "max_attempts": self.policy.max_attempts, "timeout_s": self.policy.ask_timeout_s,
                   "screenshot": str(self.run_dir / res["screenshot"]) if res.get("screenshot") and self.run_dir else ""}
        try:
            answer = self.ask_user(payload, self.policy.ask_timeout_s)
        except Exception:                               # noqa: BLE001 - a broken prompt must not break the run
            log.exception("retry prompt failed")
            return None
        return answer if answer in ("retry", "skip", "stop") and not self.should_stop() else None

    def _apply_corrective(self, step: dict, action: str, attempt: int) -> None:
        if action == "refocus_window":
            title = (step.get("window") or {}).get("title")
            if title:
                winenv.activate_window(title)
        elif action == "wait_longer":
            self._retry_wait(min(self.policy.delay_s * attempt, 10.0))

    def _retry_wait(self, seconds: float) -> bool:
        """Delay before a retry that honours Pause and Stop. False = the run must end."""
        end = time.monotonic() + max(0.0, seconds)
        while time.monotonic() < end:
            if self.controller is not None and not self.controller.wait_if_paused():
                return False
            if self.should_stop():
                return False
            time.sleep(min(0.05, max(0.0, end - time.monotonic())))
        return not self.should_stop()

    def begin(self) -> datetime:
        """Prepare the run folder. Called by run(); script-mode callers call it themselves."""
        winenv.enable_dpi_awareness()
        winenv.init_com()
        self._t_start = time.monotonic()
        self.run_id = datetime.now().strftime("%Y%m%d-%H%M%S")
        self.run_dir = paths.runs_dir() / self.test["name"] / self.run_id
        self.run_dir.mkdir(parents=True, exist_ok=True)
        self._start_helpers()
        return datetime.now()

    def _start_helpers(self) -> None:
        """Things that must happen BEFORE the first step: load the local model once (its console flash, if any, is hidden
        and the focus restored) and start the optional screen video."""
        self._video = None
        if self.dry_run:
            return
        if self.opts.get("use_llm") and self.opts.get("llm_warmup", True):
            def warm():
                try:
                    from core.ai import ollama_manager
                    ollama_manager.warm_up(self.opts["llm_base_url"], self.opts["llm_model"])
                except Exception:
                    log.debug("model warm-up failed", exc_info=True)
            threading.Thread(target=warm, name="llm-warmup", daemon=True).start()
        if self.opts.get("record_video"):
            try:
                from core.reports.video import VideoRecorder
                self._video = VideoRecorder(self.run_dir / "run.avi", fps=int(self.opts.get("video_fps", 4)), grab=self.grab)
                self._video.start()
            except Exception:
                log.debug("video capture not started", exc_info=True)
                self._video = None

    def finish(self, results: list, status: str, started: datetime, kind: str = "native", error: str = "",
               extra: dict | None = None) -> dict:
        """Build + write run.json (shared by recorded tests and Ranorex script mode)."""
        if self.dry_run and status == "passed":
            # Simulated input cannot prove the application changed or any
            # assertion passed. Keep it distinct from a real successful run.
            status = "inconclusive"
        self._flush_cell_checks(None, final=True)                 # typed Excel values whose commit was the last step
        if status == "passed" and any(r.get("status") == "failed" for r in results):
            status = "failed"
        run_id = self.run_id
        heals = []
        # Commit recovered locators only after the complete test passed. A
        # failed assertion means the action's intended outcome is unverified.
        if self._heals and self.opts.get("auto_heal_update") and not self.dry_run and status == "passed":
            heals = self._apply_heals()

        video_file = None
        if getattr(self, "_video", None):
            try:
                video_file = self._video.stop()
            except Exception:
                log.debug("video stop failed", exc_info=True)
        count = lambda s: sum(1 for r in results if r["status"] == s)  # noqa: E731
        total = max(len(self.test["steps"]), len(results))
        cleanup_results: list[dict] = []
        try:
            cleanup_results = self.app_context.cleanup(policy=self.opts.get("app_cleanup_policy", "close_test_launched"))
        except Exception as e:
            log.exception("app_context cleanup failed")
            cleanup_results = [{"alias": "*", "action": "error", "error": f"{type(e).__name__}: {e}"}]
        run = {
            "schema": "visionauto.run/2", "test": self.test["name"], "title": self.test.get("title", ""),
            "run_id": run_id, "kind": kind, "dry_run": self.dry_run,
            "started_at": started.isoformat(timespec="seconds"),
            "finished_at": datetime.now().isoformat(timespec="seconds"),
            "status": status,
            "environment": _runtime_environment(),
            "summary": {
                "total": total, "passed": count("passed"), "failed": count("failed"),
                "skipped": count("skipped"),
                "not_run": total - len(results),
                "validations": sum(len(r.get("validations", [])) for r in results),
                "validations_failed": sum(1 for r in results for v in r.get("validations", []) if v["status"] == "failed"),
                "healed": len(heals),
                "duration_ms": int((time.monotonic() - getattr(self, '_t_start', time.monotonic())) * 1000),
            },
            "steps": results, "heals": heals,
            "applications": self.app_context.get_telemetry(),
            "variables": self.app_context.variables,
            "cleanup": cleanup_results,
            "validation": getattr(self, "validation_issues", []),
            "failure_policy": self.test.get("failure_policy") or ("continue" if self.opts.get("continue_on_failure") else "stop"),
        }
        if error:
            run["error"] = error
        if video_file:
            run["video"] = video_file
        run.update(self._run_extra)
        if self._geometry_log:
            run["window_geometry"] = self._geometry_log
        if self._recoveries:
            run["recoveries"] = self._recoveries
        run.update(extra or {})
        # Credentials never reach disk: secret variable values (of EVERY data row) are scrubbed from the result.
        all_vars = {**self.app_context.variables, **self._row_secret_vars}
        declared = list(self.test.get("secret_variables") or ()) + list(self._row_secret_vars)
        run = redaction.redact_run(run, all_vars, declared)
        testfile.write_json_atomic(self.run_dir / "run.json", run)
        try:
            from core.reports.junit import write_junit
            from core.reports.report import write_report

            write_report(self.run_dir)
            write_junit(run, self.run_dir)
        except Exception:
            log.exception("report generation failed")
        try:
            from core import dataset
            dataset.record_run(run, self.test, self.dir)          # local training data; never raises
        except Exception:
            log.debug("dataset hook failed", exc_info=True)
        run["_dir"] = str(self.run_dir)
        return run

    def emit_step(self, payload: dict) -> None:
        if self.on_step:
            try:
                self.on_step(payload)
            except Exception:
                log.exception("on_step callback failed")

    _emit = emit_step

    # ------------------------------------------------------------------ one step
    def run_step(self, step: dict) -> dict:
        t0 = time.monotonic()
        effective_step = deepcopy(step)
        res = {"id": step["id"], "type": step["type"], "description": step.get("description", ""),
               "status": "passed", "method": "", "validations": [], "app": step.get("app") or self.app_context.active_alias or ""}
        try:
            # Resolve the target application FIRST, so nothing is substituted or sent to the wrong one.
            if step.get("app"):
                self.app_context.switch_to(step["app"])
                res["app"] = step["app"]
            if effective_step.get("params") and step["type"] == "set_variable" and str((step["params"] or {}).get("value", "")).startswith("="):
                from core.playback import expr as _expr         # =expression: variables go in as typed literals
                try:
                    bound = _expr.bind(step["params"]["value"], self.app_context.variables)
                except _expr.ExpressionError as e:
                    raise ValueError(str(e)) from e
                effective_step["params"] = {**self.app_context.substitute_variables(
                    {k: v for k, v in effective_step["params"].items() if k != "value"}, strict=True), "value": bound}
            elif effective_step.get("params"):
                effective_step["params"] = self.app_context.substitute_variables(effective_step["params"], strict=True)
            if effective_step.get("check"):
                effective_step["check"] = self.app_context.substitute_variables(effective_step["check"], strict=True)
            self._ensure_window(effective_step)
            effective_step = self._defer_cell_checks(effective_step, res)
            self._execute(effective_step, res)
            self._flush_cell_checks(res, upto=step["id"])
            if step.get("save_as"):
                var_name = str(step["save_as"]).strip()
                if var_name:
                    if self.dry_run:
                        captured = step.get("mock_value", "mock_val_123")
                    else:
                        el = winenv.focused_element()
                        captured = el.get("value") or el.get("text") or ""
                    self.app_context.set_variable(var_name, captured)
                    res["saved_as"] = {var_name: captured}
            if self.opts.get("settle_wait", True) and not self.dry_run and self._needs_settle(effective_step):
                self._settle_rect = self._current_rect(effective_step.get("window") or {})
                self._settle(max_s=self._settle_budget(effective_step))
            limit = step.get("max_duration_ms")
            if limit and res["status"] == "passed":
                elapsed = int((time.monotonic() - t0) * 1000)
                res["measured_ms"] = elapsed
                if elapsed > int(limit):
                    res.update(status="failed", error=f"Too slow: the step took {elapsed} ms (limit {int(limit)} ms)")
            for v in effective_step.get("validations", []):
                vr = self.validator.evaluate(self.app_context.substitute_variables(v, strict=True), effective_step.get("window") or {})
                res["validations"].append(vr)
            failed = [v for v in res["validations"] if v["status"] == "failed"]
            if failed and res["status"] == "passed":
                res["status"] = "failed"
                res["error"] = f"Validation failed: {failed[0]['description']} ({failed[0]['detail']})"
                res["retryable"] = step.get("type") == "validate"
        except Aborted:
            res["status"] = "aborted"
            self._release_input()
        except TargetError as e:           # ambiguous / low confidence / wrong target / postcondition: explain, never guess
            res.update(status="failed", error=str(e), retryable=isinstance(e, WindowNotFound),
                       failure_kind=type(e).__name__, failure_detail=e.detail)
        except ElementNotFound as e:
            res.update(status="failed", error=str(e), retryable=True)   # no input was sent yet
        except ValueError as e:
            log.warning("step %s has invalid input: %s", step.get("id"), e)
            res.update(status="failed", error=str(e))
        except Exception as e:
            log.exception("step %s crashed", step.get("id"))
            res.update(status="failed", error=f"{type(e).__name__}: {e}")
            self._release_input()
        self._finalize_outcome(step, effective_step, res)
        if res["status"] == "failed":
            if not (step.get("params") or {}).get("redacted"):
                self._failure_screenshot(res)
            try:
                if self._engine is None:
                    self._engine = retry.make_engine(self.opts)
                active_win = winenv.foreground_window().get("title", "") if not self.dry_run else ""
                dkey = (step.get("type"), res.get("error", ""))
                diag = self._diag_cache.get(dkey)
                if diag is None:                      # the local LLM takes seconds: ask once per distinct failure
                    diag = self._engine.diagnose_failure(effective_step, res.get("error", ""), active_window=active_win)
                    self._diag_cache[dkey] = diag
                diag = dict(diag)
                cls = retry.classify(res)
                diag["recoverable"] = cls["recoverable"]
                diag["category"] = cls["category"]
                diag["corrective_action"] = retry.corrective_action(diag, cls)
                res["ai_diagnosis"] = diag
            except Exception:
                pass
        elif self.dry_run and res["status"] == "passed":
            res["status"] = "skipped"
            res["detail"] = "dry run: input was simulated; application behavior was not verified"
        res["duration_ms"] = int((time.monotonic() - t0) * 1000)
        return res

    NO_SETTLE = ("set_variable", "run_command", "http_request", "sql_query", "screenshot", "validate", "scroll", "wait", "launch_app", "open_app", "set_clipboard", "wait_until",
                 "scroll_until", "window_action")
    TYPING = ("type", "key", "hotkey", "fill_table")

    def _park_pointer(self, rect, window) -> None:
        """Rest the real pointer on the title bar when it is over pixels about to be read (never when dry-running)."""
        if self.dry_run:
            return
        from core.vision import pointer

        if pointer.park_if_over(self.backend.move, rect, window):
            time.sleep(0.12)                 # let hover effects (cell highlight, tooltips) clear before the capture

    def _settle_budget(self, step: dict) -> float | None:
        """A click that is directly followed by typing (select a cell, focus a field, then type) only needs the screen
        to be calm for a moment - the keystrokes queue in the OS anyway. Everything else keeps the full budget."""
        if self.opts.get("fast_entry", True) and step["type"] in BUTTON_CLICKS and self._next_type in self.TYPING:
            return min(0.3, float(self.opts.get("settle_max_s", 1.5)))
        return None

    # ------------------------------------------------------------------ Excel: verify typed values by COM, after commit
    TYPED_CHECKS = ("text_contains", "text_equals")

    def _defer_cell_checks(self, step: dict, res: dict) -> dict:
        """Typing into a spreadsheet cell is checked AFTER the commit key (Enter/Tab/click), against the cell that was
        active when the typing happened, read exactly through Excel (milliseconds, no pixels).

        Why: the recorded target of a typed step is the cell that was *clicked* ("G8") - but Enter moves the selection,
        so "type 2" lands in G9 while the recorded check still said "G8 contains 2"; and while the cell is being
        edited nothing (COM, UIA, OCR) can read the new value reliably. Only when COM is unavailable the old
        immediate check stays."""
        if self.dry_run or step.get("type") != "type" or not step.get("validations"):
            return step
        w = step.get("window") or {}
        if "excel" not in (str(w.get("process") or "") + " " + str(w.get("title") or "")).casefold():
            return step
        keep, moved = [], []
        for v in step["validations"]:
            tgt = v.get("target") or {}
            if v.get("type") in self.TYPED_CHECKS and excel_com.looks_like_address(tgt.get("automation_id") or tgt.get("name")):
                moved.append(v)
            else:
                keep.append(v)
        if not moved:
            return step
        addr = excel_com.active_cell()
        if not addr:
            return step                                        # COM not available: fall back to the immediate check
        for v in moved:
            self._pending_cells.append({"res": res, "v": v, "addr": addr, "window": w, "step_id": step["id"]})
        return {**step, "validations": keep}

    def _flush_cell_checks(self, current: dict | None, upto=None, final: bool = False) -> None:
        """Evaluate the cell checks whose commit has happened (their cell is readable through COM now)."""
        if not self._pending_cells:
            return
        still = []
        for item in self._pending_cells:
            if item["step_id"] == upto and not final:
                still.append(item)                              # typed by THIS step: not committed yet
                continue
            v, actual = item["v"], excel_com.read_cell(item["addr"], str(item["window"].get("title") or ""))
            if actual is None and not final:
                still.append(item)                              # still editing: wait for the next step
                continue
            kind = v.get("type", "text_contains")
            if actual is None:
                vr = {"type": kind, "status": "skipped", "description": f"cell {item['addr']} contains '{v.get('expected', '')}'",
                      "detail": "the cell could not be read from Excel at the end of the run", "expected": v.get("expected", "")}
            else:
                ok, note = textmatch.match(actual, v.get("expected", ""), kind, "Excel", v.get("match") == "strict")
                vr = {"type": kind, "status": "passed" if ok else "failed",
                      "description": f"cell {item['addr']} contains '{v.get('expected', '')}'",
                      "detail": "read via Excel" + (f"; matched {note}" if note else "") if ok
                      else f"cell {item['addr']} holds '{actual}' (read via Excel)",
                      "expected": v.get("expected", ""), "actual": actual}
            origin = item["res"]
            origin.setdefault("validations", []).append(vr)
            if vr["status"] == "failed":
                msg = f"Validation failed: {vr['description']} ({vr['detail']})"
                if origin.get("status") == "passed":
                    origin.update(status="failed", error=msg)
                if current is not None and current is not origin and current.get("status") == "passed":
                    current.update(status="failed", error=f"Delayed check of step {item['step_id']}: {msg}")
        self._pending_cells = still

    def _needs_settle(self, step: dict) -> bool:
        """Settling (screen-diff polling) after every keystroke step is what makes spreadsheet entry crawl:
        with ``fast_entry`` a typing step followed directly by another typing step skips it; the last step of
        the sequence (or any click) still waits for the screen to settle."""
        if step["type"] in self.NO_SETTLE:
            return False
        if self.opts.get("fast_entry", True) and step["type"] in self.TYPING and self._next_type in self.TYPING:
            return False
        return True

    def _execute(self, step: dict, res: dict) -> None:
        t, p = step["type"], step.get("params") or {}
        if t in BUTTON_CLICKS:
            try:
                r = self._resolve(step["target"], step, "src")
            except ElementNotFound:
                if step.get("intent") == "pick_option" and t == "click" and self._keyboard_pick_option(step, res):
                    return
                raise
            if r.evidence.get("disabled") and self.opts.get("strict_targeting", True):
                raise WrongTarget(f"Target '{step['target'].get('name') or step['target'].get('automation_id')}' is "
                                  "disabled; it was not clicked.", {"evidence": r.evidence})
            if self.opts.get("strict_targeting", True):
                self._refuse_stray_chrome_click(step, r)
            button, count = BUTTON_CLICKS[t]
            mods = self._modifiers(p)
            self._last_click = (r.x, r.y)
            if step.get("ensure_state") and self._state_already(step["ensure_state"], r, res):
                pass                                          # check box already as recorded: clicking would flip it back
            elif step.get("ensure_state"):
                self.backend.click(r.x, r.y, button, count)
                self._confirm_state(step["ensure_state"], r, button, res)
            else:                                             # exact button + modifiers as recorded, effect checked
                self._click_checked(r, button, count, mods, step, res)
            res.update(method=r.method, x=r.x, y=r.y, locator_confidence=r.confidence,
                       locator_evidence=r.evidence)
        elif t == "drag_drop":
            to_win = step.get("to_window") or None
            if to_win and not self.dry_run:
                res["window_layout"] = self._arrange_windows_for_drag(step, to_win)
            src = self._resolve(step["target"], step, "src")
            to = step.get("to") or {}
            has_destination_locator = bool(to.get("templates") or to.get("name") or to.get("text")
                                           or to.get("automation_id") or to.get("xpath") or to.get("neighbors"))
            dst_step = {**step, "window": to_win} if to_win else step
            if has_destination_locator:
                # A semantic destination that disappeared must fail safely.
                # Replaying its old coordinates could drag an unrelated item.
                quick = {k: v for k, v in to.items() if k != "container"}         # first: no scrolling, it may be visible
                try:
                    dst = self._resolve(quick, dst_step, "dst", timeout=min(3.0, self.opts.get("timeout_s", 10.0)))
                except ElementNotFound:
                    if self.dry_run or not (to.get("container") and self.opts.get("scroll_find", True)):
                        raise
                    self._reach_src = None
                    dst = self._reach_destination(step, src, to, to_win, p, res)
                    if dst is None:                                               # the drag itself was done with auto-scroll
                        return
                    src = self._reach_src or src                                  # source as it is after the scrolling
            else:
                dst = self._drop_point(step, src, to, to_win, p.get("drop_mode") or ("position" if to_win else "relative"))
            src, dst = self._reconcile_drag(step, src, dst, res)
            self.backend.drag(src.x, src.y, dst.x, dst.y, p.get("button", "left"), **self._drag_kwargs(p))
            res.update(method=f"{src.method}→{dst.method}", x=src.x, y=src.y,
                       locator_confidence=min(src.confidence, dst.confidence),
                       locator_evidence={"source": src.evidence, "destination": dst.evidence})
            if to_win:
                res["cross_window"] = {"from": (step.get("window") or {}).get("title", ""), "to": to_win.get("title", "")}
        elif t == "scroll":
            tg = {k: v for k, v in (step.get("target") or {}).items() if k != "container"}   # no scroll-search for a scroll
            if self._skip_scroll(step, p):
                res.update(method="skipped: the next target is already visible", x=tg.get("x", 0), y=tg.get("y", 0),
                           skipped_by_policy="scroll_mode=adaptive: the next target was already visible")
                return
            how = self._scroll_to_recorded_position(step, p) if self.opts.get("scroll_jump", True) else ""
            if how:                                           # exact jump, no wheel steps to over- or under-shoot
                res.update(method=how, x=tg.get("x", 0), y=tg.get("y", 0))
                return
            has_locator = bool(tg.get("templates") or tg.get("name") or tg.get("text")
                               or tg.get("automation_id"))
            r = self._resolve(tg, step, "src", timeout=2.0) if has_locator else None
            x, y = (r.x, r.y) if r else (tg.get("x", 0), tg.get("y", 0))
            self._scroll_notches(x, y, p.get("dx", 0), p.get("dy", 0))
            res.update(method=r.method if r else "recorded", x=x, y=y,
                       locator_confidence=r.confidence if r else None,
                       locator_evidence=r.evidence if r else {})
        elif t == "type":
            self._ensure_typing_focus(step, res)
            if p.get("redacted"):
                raise ValueError(
                    "Sensitive input was redacted while recording; the step cannot run until "
                    "a secure secret input provider is configured."
                )
            if p.get("paste") and not self.dry_run:
                self._paste_text(str(p.get("text", "")))
            else:
                self.backend.type_text(p.get("text", ""), self.opts.get("type_interval_ms", 15))
            self._verify_typed(step, p, res)
        elif t == "fill_table":
            self._fill_table(step, p, res)
        elif t == "key":
            self.backend.press(p["key"])
        elif t == "hotkey":
            self.backend.hotkey(p["keys"])
        elif t == "hover":
            r = self._resolve(step["target"], step, "src")
            self.backend.move(r.x, r.y)
            res.update(method=r.method, x=r.x, y=r.y, locator_confidence=r.confidence,
                       locator_evidence=r.evidence)
        elif t == "wait":
            wait_ms = p.get("ms", 0)
            if isinstance(wait_ms, bool):
                raise ValueError("Wait duration must be a number of milliseconds.")
            try:
                wait_s = float(wait_ms) / 1000.0
            except (TypeError, ValueError, OverflowError) as exc:
                raise ValueError("Wait duration must be a number of milliseconds.") from exc
            if not math.isfinite(wait_s) or not 0 <= wait_s <= MAX_EXPLICIT_WAIT_S:
                raise ValueError("Wait duration must be between 0 and 3,600,000 milliseconds.")
            self._sleep(wait_s)
        elif t == "wait_until":
            self._wait_until(step, p)
        elif t == "scroll_until":
            self._scroll_until(step, p, res)
        elif t == "window_action":
            self._window_action(step, p)
        elif t == "set_clipboard":
            if not self.dry_run:
                from core.system import clipboard
                clipboard.set_text(str(p.get("text", "")))
        elif t == "open_app":
            self._open_app(p, res)
        elif t == "launch_app":
            exe = str(p.get("exe") or "").strip()
            if not exe:
                raise ValueError("launch_app requires a non-empty 'exe' parameter.")
            dangerous = {"cmd", "cmd.exe", "powershell", "powershell.exe", "pwsh", "pwsh.exe", "bash", "sh", "wscript", "cscript", "mshta"}
            tokens = exe.split()
            base_exe = Path(tokens[0]).name.lower() if tokens else ""
            if base_exe in dangerous or any(char in exe for char in [";", "&", "|", "`", "$"]):
                raise ValueError(f"Direct invocation of shell or command chain '{exe}' in launch_app is restricted.")
            if not self.dry_run:
                import subprocess
                args = [exe]
                if p.get("args"):
                    if isinstance(p["args"], list):
                        args.extend(str(a) for a in p["args"])
                    else:
                        args.append(str(p["args"]))
                subprocess.Popen(args)
                self._sleep(0.5)
        elif t == "validate":
            v = dict(step.get("check") or {"type": "element_exists"}, target=step.get("target"))
            if v.get("type") == "element_exists" and "timeout_s" not in v:
                v["timeout_s"] = self.opts.get("timeout_s", 10.0)
            vr = self.validator.evaluate(v, step.get("window") or {})
            res["validations"].append(vr)
            res["status"] = "failed" if vr["status"] == "failed" else (
                "skipped" if vr["status"] == "skipped" else "passed")
            res["retryable"] = vr["status"] == "failed"
            if vr["status"] == "failed":
                res["error"] = f"Validation failed: {vr['description']} ({vr['detail']})"
        elif t in ("set_value", "append_value", "clear_value"):
            self._act_value(step, res)
        elif t == "read_value":
            self._act_read_value(step, res)
        elif t == "select_option":
            self._act_select_option(step, res)
        elif t == "set_state":
            self._act_set_state(step, res)
        elif t == "upload_file":
            self._act_upload_file(step, res)
        elif t == "wait_for_window":
            self._act_wait_for_window(step, res)
        elif t in ("excel_save", "excel_close"):
            self._act_excel_file(step, res)
        elif t == "custom":
            self._act_custom(step, res)
        elif t in KIT_TYPES:
            getattr(self, "_act_" + t)(step, res)
        else:
            raise ValueError(f"Unknown step type '{t}'")

    def _open_app(self, p: dict, res: dict) -> None:
        """Open an application by name and wait until its window exists (see core/system/launcher.py)."""
        name = str(p.get("name") or "").strip()
        exe, aumid = str(p.get("exe") or "").strip(), str(p.get("aumid") or "").strip()
        if not (name or exe or aumid):
            raise ValueError("open_app requires 'name' (or 'exe' / 'aumid').")
        timeout = p.get("timeout_s", 15)
        if isinstance(timeout, bool) or not isinstance(timeout, (int, float)) or not 1 <= timeout <= 300:
            raise ValueError("open_app timeout_s must be a number from 1 to 300.")
        mode = p.get("mode", "attach_or_launch")
        if mode not in ("attach_or_launch", "launch"):
            raise ValueError("open_app mode must be 'attach_or_launch' or 'launch'.")
        launcher.plan(name, exe, aumid, None, allow_keyboard=False)       # validates exe policy before anything starts
        path = str(p.get("path") or "").strip()
        if self.dry_run:
            res["method"] = "dry-run"
            return
        if path and excel_launch.is_excel_request(name, exe, path):
            # Excel gets its own launcher: COM attach, readiness, workbook by full path, the workbook's own HWND.
            out = excel_launch.open_excel(path, timeout_s=float(timeout), mode=mode,
                                          enable_editing=bool(p.get("enable_editing")), should_stop=self.should_stop)
            if self.should_stop():
                raise Aborted()
            res.update(method=f"excel:{out['method']}", opened=out["workbook"] or "Excel", tried=out["tried"], hwnd=out["hwnd"])
            self._verified(res, type="excel_ready", workbook=out["workbook"], hwnd=out["hwnd"])
            return
        out = launcher.open_application(name, exe=exe, aumid=aumid, window_title=str(p.get("window_title") or ""),
                                        process=str(p.get("process") or ""), timeout_s=float(timeout), mode=mode,
                                        backend=self.backend, should_stop=self.should_stop,
                                        chooser=self._llm_choose_app if self.opts.get("use_llm", False) else None)
        if self.should_stop():
            raise Aborted()
        res.update(method=out["method"], opened=name or exe, tried=out["tried"])
        self._wait_front(str(p.get("window_title") or name), min(float(timeout), 12.0))
        self._sleep(0.3)

    def _wait_front(self, title: str, wait_s: float) -> None:
        """The launched application's window is in front before the next step starts (Excel's Start screen draws its
        'Blank workbook' tile a moment after the window exists: the first click used to arrive too early)."""
        title = (title or "").strip().casefold()
        if not title or self.dry_run or not winenv.IS_WINDOWS:
            return
        deadline = time.monotonic() + wait_s
        while time.monotonic() < deadline and not self.should_stop():
            fg = str(winenv.foreground_window().get("title") or "").casefold()
            if title in fg:
                self._sleep(0.5)                                  # let it finish drawing
                return
            winenv.activate_window(title)
            time.sleep(0.15)

    @staticmethod
    def _llm_choose_app(name: str, candidates: list[str]) -> str:
        """Optional local model (Ollama) breaks a tie between look-alike Start-menu entries. Never required."""
        try:
            from core.ai.llm import OllamaClient
            c = OllamaClient()
            if not c.available():
                from core.ai import ollama_manager
                if ollama_manager.ensure_running(c.base_url):      # only starts an already-installed Ollama
                    c._ok = None
            if not c.available():
                return candidates[0]
            ans = c.generate(f"A user wants to open the application '{name}'. Which one of these Start menu entries is it? "
                             f"Answer with the exact entry text only.\n" + "\n".join(f"- {x}" for x in candidates))
            for x in candidates:
                if ans and x.casefold() in ans.casefold():
                    return x
        except Exception:
            pass
        return candidates[0]

    # ------------------------------------------------------------------ helpers
    MODIFIER_KEYS = ("ctrl", "shift", "alt", "cmd", "win")

    def _modifiers(self, p: dict) -> tuple:
        mods = p.get("modifiers") or ()
        if isinstance(mods, str):
            mods = [m for m in mods.replace(" ", "").split("+") if m]
        if not isinstance(mods, (list, tuple)) or any(m not in self.MODIFIER_KEYS for m in mods):
            raise ValueError(f"'modifiers' must be a list of: {', '.join(self.MODIFIER_KEYS)}.")
        return tuple(mods)

    # ------------------------------------------------------------------ scrolling
    SCROLLY = ("excel", "point", "uia", "anchor", "image")

    def _refuse_stray_chrome_click(self, step: dict, r) -> None:
        """Last line of defence: never press a window's Close / Minimize / Maximize button unless the recording's own click
        was in the title-bar corner. (Closing the application under test by accident ends every later step.)"""
        if self.dry_run:
            return
        from core.recorder import sanity
        tg = step.get("target") or {}
        if not sanity.is_chrome(tg) or tg.get("x") is None:
            return
        win = step.get("window") or {}
        if not sanity.in_caption_corner(tg["x"], tg["y"], win.get("rect")):
            raise ElementNotFound(
                f"Refused: step would press '{tg.get('name') or tg.get('automation_id')}' but the recorded click was not on "
                "the title bar. Re-record this step or delete it.")

    FIELD_ROLES = {"edit", "combobox", "document", "spinner", "textbox", "text box", "dataitem", "cell", "text"}
    FOCUS_MOVERS = ("key", "hotkey", "drag_drop")

    def _since_last_click(self, step: dict) -> list[dict]:
        out = []
        for st in reversed([x for x in self.test.get("steps") or [] if isinstance(x, dict) and x.get("id", 0) < step.get("id", 0)]):
            if st.get("type") in ("click", "double_click", "right_click", "middle_click"):
                break
            out.append(st)
        return out

    def _ensure_typing_focus(self, step: dict, res: dict) -> None:
        """Typing goes to whatever has the keyboard focus. If the field the user clicked before typing does not have it
        any more (a dialog took it, a refresh, a scroll that re-created the list), click that field first - but only
        when nothing since the click was meant to MOVE the focus (Tab, Enter, arrows, a drag), so tab-through forms are
        never disturbed."""
        if self.dry_run or not self.opts.get("ensure_focus", True):
            return
        tg = step.get("target") or {}
        role = str(tg.get("role") or "").replace(" ", "").casefold()
        if role not in self.FIELD_ROLES or tg.get("x") is None:
            return
        if any(x.get("type") in self.FOCUS_MOVERS for x in self._since_last_click(step)):
            return
        win = step.get("window") or {}
        addr = tg.get("automation_id") or tg.get("name")
        if "excel" in (str(win.get("process") or "") + " " + str(win.get("title") or "")).casefold() \
                and excel_com.looks_like_address(addr):
            active = excel_com.active_cell()
            if active is None or active.upper() == str(addr).replace("$", "").upper():
                return                                            # right cell, or Excel cannot tell: leave it
        else:
            fe = winenv.focused_element() or {}
            if not fe or Validator._same_control(fe, tg):
                return
        r = self._resolve(tg, step, "src")
        self.backend.click(r.x, r.y, "left", 1)
        time.sleep(0.08)
        if self.opts.get("strict_targeting", True):
            self._assert_focus_on(tg)                  # clicked the field - but did it take the focus?
        res["refocused"] = f"focus was elsewhere; clicked '{tg.get('name') or role}' before typing"

    def _verify_typed(self, step: dict, p: dict, res: dict) -> None:
        """Read the focused field back: did the text land where it was meant to? (only for plain edit controls whose
        value UI Automation can read; never for passwords; anything unreadable stays 'unverified')"""
        text = str(p.get("text", ""))
        if self.dry_run or not text or not self.opts.get("verify_typing", True) or self._pending_cells:
            return
        time.sleep(0.05)
        fe = winenv.focused_element() or {}
        if fe.get("is_password"):
            return
        actual = fe.get("value", fe.get("text"))
        if str(fe.get("role") or "").casefold() not in ("edit", "document") or actual is None:
            self._ocr_verify_typed(text, fe, res)           # not readable by UI Automation: read the screen instead
            return
        norm = lambda v: str(v).replace("\r\n", "\n").replace("\r", "\n")
        if norm(text) in norm(actual):
            self._verified(res, type="typed_text_in_field", field=fe.get("name") or fe.get("role"))
        else:
            raise PostconditionFailed(f"The text was typed but the focused field '{fe.get('name') or fe.get('role')}' does not "
                                      "contain it (focus moved, or the field rejected it).",
                                      {"field": fe.get("name"), "actual": str(actual)[:80]})

    def _note_recorded_scrolls(self) -> None:
        """How far did the user scroll a list before choosing its item? Stored on the option's target (``scroll_recorded``)
        so a search for an item that is not visible starts with exactly that scroll."""
        steps = self.test.get("steps") or []
        for i, st in enumerate(steps):
            if not isinstance(st, dict) or st.get("intent") != "pick_option" or not isinstance(st.get("target"), dict):
                continue
            total, j = 0, i - 1
            while j >= 0 and isinstance(steps[j], dict) and steps[j].get("type") == "scroll":
                total += int((steps[j].get("params") or {}).get("dy") or 0)
                j -= 1
            if total:
                st["target"].setdefault("scroll_recorded", {"dy": total})

    # --- keyboard fallback for a list option that cannot be found by looking ------------------------------------------
    def _keyboard_pick_option(self, step: dict, res: dict) -> bool:
        """Last resort for ``pick_option``: the item was not found on screen after scrolling the whole list. A person would
        type the item's text (type-ahead jumps to it) and press Enter. Reported as a warning, never silently."""
        tg = step.get("target") or {}
        name = str(tg.get("name") or tg.get("text") or "").strip()
        if self.dry_run or not name or not self.opts.get("keyboard_option_fallback", True):
            return False
        self.backend.type_text(name[:40], 20)
        time.sleep(0.25)
        self.backend.press("enter")
        time.sleep(0.15)
        res.update(method="keyboard-select", locator_confidence=0.5, locator_evidence={"typed": name[:40]})
        res.setdefault("warnings", []).append(
            f"option '{name}' was not visible after scrolling the whole list: typed its text and pressed Enter")
        return True

    def _scroll_notches(self, x, y, dx, dy) -> None:
        """Replay a scroll the way it was made: one wheel notch at a time with a short pause. One big wheel delta is
        clipped or animated half-way by many applications (browsers, Excel, list views), so the list stopped short."""
        dx, dy = int(dx or 0), int(dy or 0)
        if self.dry_run or (abs(dx) <= 1 and abs(dy) <= 1):
            self.backend.scroll(x, y, dx, dy)
            return
        pause = max(0, int(self.opts.get("scroll_notch_ms", 12))) / 1000.0
        sx, sy = (dx > 0) - (dx < 0), (dy > 0) - (dy < 0)
        for i in range(min(300, max(abs(dx), abs(dy)))):
            if self.should_stop():
                raise Aborted()
            self.backend.scroll(x, y, sx if i < abs(dx) else 0, sy if i < abs(dy) else 0)
            time.sleep(pause)

    # --- check boxes / toggles: reach the recorded STATE instead of blindly clicking ------------------------------------
    def _read_state(self, x: int, y: int) -> str:
        """'on' / 'off' / 'selected' / 'not selected' / '' (unknown) of the control at a point, time-boxed."""
        box: list = []
        t = threading.Thread(target=lambda: box.append(winenv.element_at(int(x), int(y))), daemon=True)
        t.start()
        t.join(0.8)
        st = ((box[0] if box else {}) or {}).get("state") or {}
        if st.get("toggle") in ("on", "off"):
            return st["toggle"]
        if "selected" in st:
            return "selected" if st["selected"] else "not selected"
        return ""

    def _state_already(self, want: str, r, res: dict) -> bool:
        if self.dry_run or not self.opts.get("ensure_state", True):
            return False
        now = self._read_state(r.x, r.y)
        if now == want:
            res["state_check"] = f"already {want}: click skipped"
            return True
        return False

    def _confirm_state(self, want: str, r, button: str, res: dict) -> None:
        """After the click: is it in the state the user left it in? A click that did not register is repeated ONCE;
        an unreadable state is left alone (never guess)."""
        if self.dry_run or not self.opts.get("ensure_state", True):
            return
        for attempt in range(2):
            time.sleep(0.15)
            now = self._read_state(r.x, r.y)
            if not now or now == want:
                if now == want and attempt == 0:
                    res["state_check"] = f"now {want}"
                return
            if attempt == 0:
                self.backend.click(r.x, r.y, button, 1)
                res["state_check"] = f"first click did not change it to {want}; clicked again"
        res["state_check"] = f"still not {want} after two clicks"

    def _scroll_to_recorded_position(self, step: dict, p: dict) -> str:
        """The click that follows this scroll recorded where its list was scrolled TO (percent). If the list is already
        there: nothing to do; otherwise jump straight there - one exact call instead of replaying wheel ticks."""
        if self.dry_run or p.get("exact"):
            return ""
        nxt = self._next_step or {}
        c = (nxt.get("target") or {}).get("container") or {}
        want = ((c.get("scroll_pct") or {}).get("v"))
        rect = c.get("rect")
        if nxt.get("type") not in BUTTON_CLICKS or not isinstance(want, (int, float)) or want < 0 or not geometry.valid(rect):
            return ""
        try:
            win = nxt.get("window") or step.get("window") or {}
            rect = (self.resolver._prepare({"container": {"rect": rect}, **{k: v for k, v in (nxt.get("target") or {}).items()
                                                                              if k in ("x", "y", "rect", "window_rect")}}, win)
                    .get("container") or {}).get("rect") or rect
            cx, cy = (rect[0] + rect[2]) // 2, (rect[1] + rect[3]) // 2
            now = winenv.scroll_percent_at(cx, cy) or {}
            if not isinstance(now.get("v"), (int, float)) or now["v"] < 0:
                return ""                                     # position unknown: replay the wheel
            if abs(now["v"] - want) <= 1.0:
                return "skipped: list already at the recorded scroll position"
            if winenv.set_scroll_percent_at(cx, cy, v=want):
                time.sleep(0.15)
                return f"scrolled to recorded position ({want:.0f}%)"
        except Exception:
            log.debug("scroll position replay failed", exc_info=True)
        return ""

    def _skip_scroll(self, step: dict, p: dict) -> bool:
        """'adaptive' scroll: a recorded wheel scroll before a click / drag in a list or drop-down is only a means to
        get the next target into view. If a bigger window already shows it, scrolling would only push it away or past
        it - so look first, scroll only when it is not (comfortably) visible. Anything that is not 'scroll, then act on
        a list item' (zoom, a slider, a map, a document with no list) is always replayed exactly."""
        if self.dry_run or self.opts.get("scroll_mode", "exact") != "adaptive" or p.get("exact"):
            return False
        nxt = self._next_step or {}
        if nxt.get("type") not in BUTTON_CLICKS and nxt.get("type") != "drag_drop":
            return False
        ntg = nxt.get("target") or {}
        if not (ntg.get("name") or ntg.get("automation_id") or ntg.get("neighbors")) or not ntg.get("container"):
            return False
        win = nxt.get("window") or step.get("window") or {}
        try:
            ntg = self.resolver._prepare(ntg, win)
            r = self.resolver.resolve_once(ntg, win, attempt=1, only=self.SCROLLY)
        except Exception:
            return False
        rect = (ntg.get("container") or {}).get("rect")
        if not r or not geometry.valid(rect):
            return False
        mx, my = min(24, (rect[2] - rect[0]) * 0.15), min(24, (rect[3] - rect[1]) * 0.15)
        return rect[0] + mx <= r.x <= rect[2] - mx and rect[1] + my <= r.y <= rect[3] - my

    def _reach_destination(self, step: dict, src, to: dict, to_win, p: dict, res: dict):
        """The drop target is not on screen (small window, long list).

        * different container than the source -> scroll the destination into view, then re-check the source;
        * same container -> keep the button held and scroll while dragging (wheel + hover at the edge) until it appears.
        Returns the destination Resolution, or None when the drag has already been performed (auto-scroll)."""
        win = to_win or step.get("window") or {}
        src_c = (step.get("target") or {}).get("container") or {}
        same = geometry.valid(src_c.get("rect")) and geometry.valid((to.get("container") or {}).get("rect")) and \
            _same_rect(src_c["rect"], to["container"]["rect"])
        if not same:
            dst = self._resolve(to, {**step, "window": win}, "dst")            # full resolve incl. scroll-to-find
            quick_src = {k: v for k, v in (step.get("target") or {}).items() if k != "container"}
            again = self.resolver.resolve_once(self.resolver._prepare(quick_src, step.get("window") or {}),
                                               step.get("window") or {}, attempt=1, only=self.SCROLLY)
            if not again:
                raise ElementNotFound("The source scrolled out of view while the destination was scrolled into view - "
                                      "both must fit in the window (or sit in the same list) for this drag.")
            res["scrolled_for_destination"] = True
            self._reach_src = again
            return dst
        return self._drag_with_autoscroll(step, src, to, win, p, res)

    def _drag_with_autoscroll(self, step: dict, src, to: dict, win: dict, p: dict, res: dict):
        tg = step.get("target") or {}
        to_p = self.resolver._prepare({k: v for k, v in to.items() if k != "container"}, win)
        rect = self.resolver._prepare(to, win)["container"]["rect"]
        down = to.get("y", 0) >= tg.get("y", 0)
        cx = int((rect[0] + rect[2]) / 2)
        edge_y = int(rect[3] - 8 if down else rect[1] + 8)
        button = p.get("button", "left")
        notches = max(1, int(self.opts.get("scroll_find_notches", 3)))
        deadline = time.monotonic() + float(self.opts.get("scroll_find_budget_s", 15.0))
        self.backend.mouse_down(src.x, src.y, button)
        try:
            time.sleep(self._drag_kwargs(p)["hold_ms"] / 1000.0)
            self.backend.mouse_move(src.x, src.y + (8 if down else -8))
            moves = 0
            while time.monotonic() < deadline and moves < int(self.opts.get("scroll_find_steps", 30)):
                if self.should_stop():
                    raise Aborted()
                r = self.resolver.resolve_once(to_p, win, attempt=1, only=self.SCROLLY)
                if r:
                    for i in range(1, 9):                                       # glide onto it, hover, release
                        self.backend.mouse_move(cx + (r.x - cx) * i / 8, edge_y + (r.y - edge_y) * i / 8)
                        time.sleep(0.012)
                    time.sleep(self._drag_kwargs(p)["hover_ms"] / 1000.0)
                    res.update(method=f"{src.method}→scroll+{r.method}", x=src.x, y=src.y, locator_confidence=min(src.confidence, r.confidence),
                               locator_evidence={"source": src.evidence, "destination": r.evidence, "autoscroll_steps": moves})
                    return None
                self.backend.mouse_move(cx, edge_y)
                self.backend.scroll(cx, edge_y, 0, -notches if down else notches)
                moves += 1
                time.sleep(0.15)
            raise ElementNotFound("The drop target never came into view while auto-scrolling the list.")
        finally:
            self.backend.mouse_up(button)

    def _drag_kwargs(self, p: dict) -> dict:
        def num(key, default, lo, hi):
            v = p.get(key, self.opts.get(f"drag_{key}", default))
            if isinstance(v, bool) or not isinstance(v, (int, float)) or not lo <= v <= hi:
                raise ValueError(f"drag '{key}' must be a number from {lo} to {hi}.")
            return int(v)
        kw = {"steps": num("steps", 18, 1, 200), "hold_ms": num("hold_ms", 150, 0, 5000),
              "hover_ms": num("hover_ms", 250, 0, 5000), "step_delay_ms": num("step_delay_ms", 12, 0, 500)}
        mods = self._modifiers(p)
        if mods:
            kw["modifiers"] = mods
        return kw

    def _hwnd_of(self, window: dict) -> int:
        """Window handle for a recorded / configured window. New-style specs (match mode, Main Window, application) use
        full window resolution; a legacy title-only window is matched by title, narrowed by process, and when several
        windows remain the one in front wins - otherwise the drag/step stops as ambiguous (never "the first")."""
        spec = wt.WindowSpec.from_dict(window)
        if spec.main_window or spec.explicit:
            try:
                return self._resolve_window(window, 0.0)
            except WindowNotFound:
                return 0
        found = winenv.find_windows(spec.title) if spec.title else []
        if spec.process and len(found) > 1:
            narrowed = [h for h in found if str(winenv.window_info(h).get("process") or "").casefold() == spec.process.casefold()]
            found = narrowed or found
        if len(found) > 1:
            fg = int(winenv.foreground_window().get("hwnd") or 0)
            if fg in [int(h) for h in found]:
                return fg
            raise AmbiguousTarget(f"{len(found)} windows match title {spec.title!r}; choose one (exact title, application or "
                                  "Main Window).", [{"hwnd": int(h)} for h in found[:10]], {"kind": "window"})
        return int(found[0]) if found else 0

    def _arrange_windows_for_drag(self, step: dict, to_win: dict) -> dict:
        """A drag that crosses windows (same app or another app) only works when BOTH windows are where they were.

        1. each window is put back to its recorded size / position / state (a small window is dragged to the same place),
        2. each window must be the one on top at its own drag point - a window that is covered is raised (no focus
           change), then the source gets the focus,
        3. what was done (and anything that could not be fixed) is returned for the report."""
        src_w = step.get("window") or {}
        info = {"source": src_w.get("title", ""), "destination": to_win.get("title", "")}
        h_src, h_dst = self._hwnd_of(src_w), self._hwnd_of(to_win)
        info["source_found"], info["destination_found"] = bool(h_src), bool(h_dst)
        if not h_dst:
            raise ElementNotFound(f"Destination window '{to_win.get('title', '')}' is not open; the drag was not started.")
        info["source_restored"] = self._restore_geometry(src_w, h_src) if h_src else False
        info["destination_restored"] = self._restore_geometry(to_win, h_dst)

        def point(rec_pt, win, hwnd):
            cur = winenv.window_rect(hwnd)
            rec = win.get("rect")
            if geometry.valid(rec) and geometry.valid(cur):
                return geometry.map_point(rec_pt, rec, cur)
            return rec_pt

        tg, to = step.get("target") or {}, step.get("to") or {}
        checks = []
        if h_src and "x" in tg and "y" in tg:
            checks.append(("source", h_src, point((tg["x"], tg["y"]), src_w, h_src)))
        if "x" in (to or {}) and "y" in (to or {}):
            checks.append(("destination", h_dst, point((to["x"], to["y"]), to_win, h_dst)))
        raised = []
        for _ in range(2):
            for name, hwnd, pt in checks:
                top = winenv.window_at(int(pt[0]), int(pt[1])).get("hwnd")
                if top and int(top) != int(hwnd):
                    winenv.raise_window(hwnd)
                    raised.append(name)
        if h_src:
            winenv.activate_window(str(src_w.get("title") or ""))
        covered = [name for name, hwnd, pt in checks
                   if int(winenv.window_at(int(pt[0]), int(pt[1])).get("hwnd") or 0) != int(hwnd)]
        info["raised"] = raised
        if covered:
            info["warning"] = "still covered by another window at the drag point: " + ", ".join(covered)
            log.warning("drag_drop step %s: %s", step.get("id"), info["warning"])
            if self.opts.get("strict_targeting", True):
                raise WrongTarget("Drag not started: " + info["warning"], dict(info))
        return info

    STRONG_METHODS = ("native", "point", "excel", "xpath", "anchor", "uia")

    def _reconcile_drag(self, step: dict, src, dst, res: dict):
        """The drag must go from where it started to where it ended, over the RECORDED distance. Two independent
        look-alike matches can each be 'fine' and still make the drag too short / too long (a copy lands one row early).
        If the replayed vector differs from the recorded one, the weaker end is moved so the vector is the recorded one."""
        tg, to = step.get("target") or {}, step.get("to") or {}
        if self.dry_run or step.get("to_window") or any(v.get(k) is None for v in (tg, to) for k in ("x", "y")):
            return src, dst
        rv = (to["x"] - tg["x"], to["y"] - tg["y"])
        av = (dst.x - src.x, dst.y - src.y)
        tol = max(10.0, 0.04 * math.hypot(*rv))
        if math.hypot(av[0] - rv[0], av[1] - rv[1]) <= tol:
            return src, dst
        strong = lambda r: str(r.method).startswith(self.STRONG_METHODS)          # noqa: E731
        if strong(src) and not strong(dst):
            new = Resolution(int(src.x + rv[0]), int(src.y + rv[1]), "coordinates(vector)", 0.9,
                             evidence={"verified_by": "recorded drag distance from the source"})
            note, dst = "destination moved to keep the recorded drag distance", new
        elif strong(dst) and not strong(src):
            new = Resolution(int(dst.x - rv[0]), int(dst.y - rv[1]), "coordinates(vector)", 0.9,
                             evidence={"verified_by": "recorded drag distance to the destination"})
            note, src = "source moved to keep the recorded drag distance", new
        elif getattr(self.resolver, "_layout_same", False):
            src = Resolution(int(tg["x"]), int(tg["y"]), "coordinates(layout)", 0.9, evidence={"verified_by": "window at its recorded geometry"})
            dst = Resolution(int(to["x"]), int(to["y"]), "coordinates(layout)", 0.9, evidence={"verified_by": "window at its recorded geometry"})
            note = "both ends use the recorded coordinates (window unchanged)"
        else:
            new = Resolution(int(src.x + rv[0]), int(src.y + rv[1]), "coordinates(vector)", 0.9,
                             evidence={"verified_by": "recorded drag distance from the source"})
            note, dst = "destination moved to keep the recorded drag distance", new
        res["drag_vector_corrected"] = {"recorded": list(rv), "replayed": list(av), "action": note}
        log.info("drag step %s: replayed distance %s differs from recorded %s - %s", step.get("id"), av, rv, note)
        return src, dst

    def _drop_point(self, step: dict, src, to: dict, to_win, mode: str) -> Resolution:
        """Where to release when the destination has no locator of its own.
        ``relative``: same displacement as recorded (slider thumb, reorder by N px).
        ``position``: the same place *inside the destination window* (drop zone, other window)."""
        tg = step["target"]
        if mode == "position":
            w = to_win or step.get("window") or {}
            rec = w.get("rect")
            cur = None if self.dry_run else self._current_rect(w)
            if geometry.valid(rec) and geometry.valid(cur):
                x, y = geometry.map_point((to.get("x", tg["x"]), to.get("y", tg["y"])), rec, cur)
                return Resolution(x, y, "position")
            return Resolution(int(to.get("x", tg["x"])), int(to.get("y", tg["y"])), "recorded")
        return Resolution(src.x + to.get("x", tg["x"]) - tg["x"], src.y + to.get("y", tg["y"]) - tg["y"], "relative")

    def _poll_condition(self, step: dict, cond: dict) -> bool:
        probe = {**cond, "timeout_s": 0.3} if cond.get("type") in ("exists", "not_exists") else cond
        return self._eval_condition(probe, step)

    def _wait_until(self, step: dict, p: dict) -> None:
        if self.dry_run:
            return
        timeout = float(p.get("timeout_s", 10))
        poll = max(50, int(p.get("poll_ms", 250))) / 1000.0
        cond = step.get("condition") or {}
        deadline = time.monotonic() + timeout
        while True:
            if self.should_stop():
                raise Aborted()
            if self._poll_condition(step, cond):
                return
            if time.monotonic() >= deadline:
                raise ValueError(f"Condition not met within {timeout:g}s: {step.get('description', '')}")
            self._sleep(min(poll, max(0.0, deadline - time.monotonic())))

    def _scroll_until(self, step: dict, p: dict, res: dict) -> None:
        tg = step.get("target") or {}
        dx, dy = int(p.get("dx", 0)), int(p.get("dy", -3))
        maximum = int(p.get("max_scrolls", 20))
        if self.dry_run:
            self.backend.scroll(tg.get("x", 0), tg.get("y", 0), dx, dy)
            return
        has_locator = bool(tg.get("templates") or tg.get("name") or tg.get("text") or tg.get("automation_id") or tg.get("zone"))
        r = self._resolve(tg, step, "src", timeout=2.0) if has_locator else None
        x, y = (r.x, r.y) if r else (tg.get("x", 0), tg.get("y", 0))
        cond = step.get("until") or {}
        for i in range(maximum + 1):
            if self.should_stop():
                raise Aborted()
            if self._poll_condition(step, cond):
                res["scrolls"] = i
                return
            if i == maximum:
                break
            self.backend.scroll(x, y, dx, dy)
            self._sleep(max(0, int(p.get("pause_ms", 200))) / 1000.0)
        raise ValueError(f"Condition not met after {maximum} scrolls: {step.get('description', '')}")

    def _window_action(self, step: dict, p: dict) -> None:
        action = p.get("action")
        window = step.get("window") or {}
        if self.dry_run:
            return
        title = str(window.get("title") or "")
        found = winenv.find_windows(title)
        if not found:
            raise ElementNotFound(f"Window '{title}' was not found; no input was sent.")
        hwnd = found[0]
        if action in ("maximize", "minimize", "restore"):
            winenv.set_window_state(hwnd, {"maximize": "maximized", "minimize": "minimized", "restore": "normal"}[action])
        elif action == "close":
            winenv.close_window(hwnd)
        elif action == "focus":
            winenv.activate_window(title)
        elif action == "restore_recorded":
            if not self._restore_geometry(window, hwnd):
                raise ValueError(f"Window '{title}' could not be restored to its recorded size (fixed-size window?).")
        elif action == "set_rect":
            rect = p.get("rect")
            if not geometry.valid(rect):
                raise ValueError("window_action set_rect needs params.rect = [left, top, right, bottom].")
            winenv.set_window_rect(hwnd, geometry.clamp_to_screen(rect, winenv.virtual_screen()))
        else:
            raise ValueError(f"Unknown window action '{action}'.")

    # ------------------------------------------------------------------ unexpected pop-ups
    MAX_RECOVERIES = 25

    def _try_recovery(self, step: dict) -> bool:
        """Dismiss a known interrupting window (update prompt, 'Save changes?', licence nag ...) so the failed step
        can be retried. Rules live in ``test['recovery']``: ``{"window": "Update", "action": "click_text", "value": "Later"}``.
        Actions: click_text, press_key, hotkey, close."""
        rules = self.test.get("recovery") or []
        if self.dry_run or not rules or len(self._recoveries) >= self.MAX_RECOVERIES:
            return False
        for i, rule in enumerate(rules):
            title = str(rule.get("window") or "")
            found = winenv.find_windows(title)
            if not found:
                continue
            action, value = rule.get("action"), str(rule.get("value") or "")
            try:
                if action == "close":
                    winenv.close_window(found[0])
                else:
                    winenv.activate_window(title)
                    time.sleep(0.15)
                    if action == "click_text":
                        r = self.resolver.resolve({"x": 0, "y": 0, "text": value, "name": value, "role": "Button"},
                                                  {"title": title}, 2.0)
                        self.backend.click(r.x, r.y, "left", 1)
                    elif action == "press_key":
                        self.backend.press(value)
                    elif action == "hotkey":
                        self.backend.hotkey(value)
                    else:
                        continue
            except (ElementNotFound, ValueError) as e:
                log.info("recovery rule %s could not run: %s", i, e)
                continue
            self._recoveries.append({"rule": i, "window": title, "action": action, "value": value, "step": step.get("id")})
            time.sleep(0.3)
            return True
        return False

    def _resolve(self, target: dict, step: dict, tag: str, timeout: float | None = None) -> Resolution:
        if self.dry_run:
            return Resolution(target.get("x", 0), target.get("y", 0), "recorded")
        r = self.resolver.resolve(target, step.get("window") or {}, timeout)
        if r.healed:
            self._heals.append({"step": step["id"], "tag": tag, "app": self.app_context.active_alias or "", "x": r.x, "y": r.y,
                                "method": r.method, "confidence": r.confidence,
                                "evidence": r.evidence, "crops": r.crops})
        return r

    # --- outcome / trace -------------------------------------------------------------------------------------------
    ACTION_TYPES = frozenset(BUTTON_CLICKS) | {"drag_drop", "type", "key", "hotkey", "set_value", "append_value",
                                               "clear_value", "select_option", "set_state", "upload_file", "fill_table", "excel_save", "excel_close",
                                               "scroll"}

    def _release_input(self) -> None:
        """No key or mouse button may stay pressed after a failure / stop (stuck Ctrl or button = chaos on the desktop)."""
        try:
            self.backend.release_all()
        except Exception:
            log.debug("release_all failed", exc_info=True)

    def _finalize_outcome(self, step: dict, effective: dict, res: dict) -> None:
        """What REALLY happened, separately from 'the input was sent'.
        verified    - at least one validation / read-back passed and none failed
        unverified  - an action was sent but nothing checked its effect (reported, and optionally a failure)
        """
        win = effective.get("window") or {}
        tg, ev = effective.get("target") or {}, res.get("locator_evidence") or {}
        ev = ev.get("destination") or ev if isinstance(ev, dict) and "source" in ev else ev
        ev = ev.get("source", ev) if isinstance(ev, dict) else {}
        res["intended"] = {k: tg.get(k) for k in ("name", "role", "automation_id", "text") if tg.get(k)}
        res["actual"] = {k: ev.get(k) for k in ("name", "role", "automation_id") if ev.get(k)}
        if (tg.get("container") or {}):
            res["container"] = {k: v for k, v in tg["container"].items() if k != "rect"}
        res["trace"] = {"window": {k: win.get(k) for k in ("title", "process", "main_window", "_hwnd") if win.get(k)},
                        "locator": res.get("method", ""), "confidence": res.get("locator_confidence"),
                        "point": [res.get("x"), res.get("y")] if res.get("x") is not None else None,
                        "evidence": res.get("locator_evidence"), "verified_by": res.get("verified_by", [])}
        if res.get("skipped_by_policy"):
            res["outcome"] = "skipped_by_policy"                 # visible in the report - never a silent skip
            return
        if res["status"] != "passed" or step.get("type") not in self.ACTION_TYPES:
            return
        checks = [v for v in res.get("validations", []) if v.get("status") == "passed"] + res.get("verified_by", [])
        if checks:
            res["outcome"] = "verified"
        else:
            res["outcome"] = "unverified"
            if self.opts.get("require_postcondition", False) and not self.dry_run:
                res.update(status="failed", error="Action was sent but no expected result is configured to prove it worked "
                                                  "(add a validation, or turn off 'require postcondition').",
                           failure_kind="PostconditionMissing")

    LAUNCH_TYPES = frozenset({"open_app", "launch_app", "excel_save", "excel_close"})

    def _enumerate_windows(self) -> list[dict]:
        return winenv.enumerate_windows()

    def _resolve_window(self, window: dict, wait_s: float = 0.0) -> int:
        """THE window for ``window`` (title / process / exe / Main Window ...): its HWND, or a TargetError.
        Several candidates -> AmbiguousTarget (listed), never the first one."""
        spec = wt.WindowSpec.from_dict(window)
        deadline = time.monotonic() + wait_s
        while True:
            if self.should_stop():
                raise Aborted()
            wins = self._enumerate_windows()
            m = wt.resolve_window(spec, wins, int(winenv.foreground_window().get("hwnd") or 0))
            if m.status == "unique":
                return int(m.window["hwnd"])
            if m.status == "ambiguous":
                raise AmbiguousTarget(m.reason, [wt.summarize(w) for w in m.windows[:10]],
                                      {"window_spec": spec.describe(), "kind": "window"})
            if time.monotonic() >= deadline:
                raise WindowNotFound(m.reason + "; no input was sent.",
                                     {"window_spec": spec.describe(), "open_windows": [wt.summarize(w) for w in wins[:15]]})
            time.sleep(0.1)

    def _ensure_window(self, step: dict) -> None:
        """Pipeline steps 1-2: resolve the intended window to ONE handle, bring it to the front, verify it is there.
        The handle is stored as ``window['_hwnd']`` so every later stage (UIA tree, rect, vet) uses exactly this window
        rather than 'whatever is in front'."""
        window = step.get("window")
        if self.dry_run or not isinstance(window, dict):
            return
        if self.opts.get("engine_profile") == "classic":
            return self._ensure_window_classic(step)          # the proven v10 behaviour (see core/settings.py)
        if step.get("type") in self.LAUNCH_TYPES:
            return          # these steps CREATE their window (and the recorded one is often the launcher: Start menu, explorer)
        spec = wt.WindowSpec.from_dict(window)
        if not (spec.title or spec.main_window or spec.explicit):
            return          # legacy recording with only a process name (e.g. explorer.exe): nothing to pin down, as before
        if not (window.get("title") or window.get("main_window") or window.get("process") or window.get("exe")):
            return
        if window.get("popup"):
            return self._ensure_popup_owner(window)
        timeout = float(self.opts.get("timeout_s", 10.0))
        deadline = time.monotonic() + timeout
        while True:
            hwnd = self._resolve_window(window, max(0.0, deadline - time.monotonic()))
            window["_hwnd"] = hwnd
            fg = winenv.foreground_window()
            if int(fg.get("hwnd") or 0) == hwnd:
                self._restore_geometry(window, hwnd)
                return
            if winenv.is_transient_of(fg, window.get("title") or ""):
                return          # mini toolbar / context menu of this app is in front; focusing the owner would close it
            if time.monotonic() >= deadline:
                raise ElementNotFound(f"Could not bring window '{window.get('title') or window.get('process')}' to the "
                                      f"front within {timeout:g}s; no input was sent.")
            winenv.focus_hwnd(hwnd)
            time.sleep(0.05)

    def _ensure_window_classic(self, step: dict) -> None:
        """Activate the recorded window by title (substring of the foreground title) - exactly as the best-working build did.
        No handle pinning, no ambiguity errors: when several windows could match, the foreground one is used."""
        window = step.get("window") or {}
        title = str(window.get("title") or "").strip()
        if not title or step.get("type") in self.LAUNCH_TYPES or window.get("popup"):
            return
        timeout = float(self.opts.get("timeout_s", 10.0))
        deadline = time.monotonic() + timeout
        while True:
            if self.should_stop():
                raise Aborted()
            foreground = winenv.foreground_window()
            actual = str(foreground.get("title") or "").strip().casefold()
            if actual and title.casefold() in actual:
                self._restore_geometry(window, foreground.get("hwnd"))
                return
            if winenv.is_transient_of(foreground, title):
                return              # the mini toolbar / context menu opened by the previous click is in front: leave it alone
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise ElementNotFound(f"Could not activate recorded window '{title}' within {timeout:g}s; no input was sent.")
            winenv.activate_window(title)
            time.sleep(min(0.05, remaining))

    def _ensure_popup_owner(self, window: dict) -> None:
        """The recorded window was a pop-up (drop-down list, menu, flyout). It is not a window to activate: it exists only
        while its owner is open and is created by an earlier click. So: if a pop-up (or the window it dropped from) is in
        front, carry on; otherwise bring the OWNER forward and let the locators look for the item on screen. Never fails
        here - an item that is really missing is reported by the locator, with a picture."""
        fg = winenv.foreground_window()
        owner = str(window.get("owner_title") or "").strip()
        fg_title = str(fg.get("title") or "").casefold()
        if fg.get("popup") or (owner and owner.casefold() in fg_title):
            return
        if owner:
            winenv.activate_window(owner)
            time.sleep(0.05)

    def _paste_text(self, text: str, hold_s: float = 0.15) -> None:
        """Put ``text`` on the clipboard, press Ctrl+V once, then restore what the clipboard held before.
        One paste replaces hundreds of keystrokes (and handles any special character exactly)."""
        from core.system import clipboard

        try:
            before = clipboard.get_text()
        except Exception:                                  # noqa: BLE001 - restoring is best effort
            before = None
        clipboard.set_text(text)
        try:
            self.backend.hotkey("ctrl+v")
            time.sleep(hold_s)                             # let the target application read the clipboard
        finally:
            if before is not None:
                try:
                    clipboard.set_text(before)
                except Exception:                          # noqa: BLE001
                    log.debug("could not restore the clipboard", exc_info=True)

    def _fill_table(self, step: dict, p: dict, res: dict) -> None:
        """Enter a whole block of cells into the focused grid (Excel, a data grid...) with ONE paste.

        The active cell is the top-left corner. Rows come from ``params.rows`` or ``params.file`` (CSV/XLSX/JSON, which must
        be inside the test's folder). ``header``: false (default) skips the file's header row."""
        from core import excel_io

        rows = p.get("rows")
        if not rows:
            base = Path(self.dir).resolve()
            target = (base / str(p["file"])).resolve()
            try:
                target.relative_to(base)
            except ValueError:
                raise ValueError("fill_table: a test's own data file must be inside the test's folder.") from None
            try:
                rows = excel_io.read_table(target, p.get("sheet"), cancel=self.should_stop,
                                           max_rows=p.get("max_rows"))
            except excel_io.TableError as e:
                raise ValueError(f"fill_table: {e}") from None
            if not p.get("header"):
                rows = rows[1:]
        res["cells"] = sum(len(r) for r in rows)
        res["rows"] = len(rows)
        if self.dry_run:
            return
        if not rows:
            raise ValueError("fill_table: there are no rows to enter.")
        self._paste_text(excel_io.to_clipboard_text(rows, bool(p.get("text_prefix"))), hold_s=0.25)

    def _sleep(self, seconds: float) -> None:
        """Abortable sleep (only used by explicit `wait` steps, e.g. imported from Ranorex)."""
        if self.dry_run:
            return
        end = time.monotonic() + seconds
        while time.monotonic() < end and not self.should_stop():
            time.sleep(min(0.1, max(0.0, end - time.monotonic())))

    # ------------------------------------------------------------------ window geometry
    def _restore_geometry(self, window: dict, hwnd=None) -> bool:
        """Put the window back to the size / position / state it had when recorded (a popped-up window or a
        window the user resized would otherwise move every control). Returns True if the window now matches.

        Fixed-size dialogs that refuse to resize are left alone: the resolver then translates the recorded
        positions to where the window really is (see ``Resolver._prepare``)."""
        if self.dry_run or not self.opts.get("restore_window_geometry", True):
            return True
        rec, state = window.get("rect"), window.get("state")
        if not geometry.valid(rec) and state != "maximized":
            return True
        if not hwnd:
            found = winenv.find_windows(str(window.get("title") or ""))
            hwnd = found[0] if found else 0
        if not hwnd:
            return False
        tol = int(self.opts.get("geometry_tolerance_px", 8))
        screen = winenv.virtual_screen()
        before = (winenv.window_rect(hwnd), winenv.window_state(hwnd))
        action = geometry.plan(rec, state, before[0], before[1], screen, tol)
        if action["action"] == "none":
            return True
        if action["action"] == "state":
            winenv.set_window_state(hwnd, action["state"])
        else:
            winenv.set_window_rect(hwnd, action["rect"])
        deadline = time.monotonic() + 1.0
        ok = False
        while time.monotonic() < deadline:
            now = (winenv.window_rect(hwnd), winenv.window_state(hwnd))
            if geometry.plan(rec, state, now[0], now[1], screen, tol)["action"] == "none":
                ok = True
                break
            time.sleep(0.05)
        if len(self._geometry_log) < 200:
            self._geometry_log.append({"window": window.get("title", ""), "from": before[0], "to": action.get("rect") or action.get("state"),
                                       "restored": ok})
        return ok

    def _current_rect(self, window: dict):
        return self.resolver.rect_provider(window or {})

    def _settle(self, max_s: float | None = None) -> None:
        """Wait until the window stops changing (animations, dialogs opening).

        Looks only at the recorded window (a clock or an animation elsewhere on screen cannot delay it) at 60 ms
        intervals, and returns after two identical samples - typically ~0.2 s instead of ~0.5 s per action."""
        max_s = float(self.opts.get("settle_max_s", 1.5)) if max_s is None else max_s
        time.sleep(0.05)
        prev, stable, t0 = None, 0, time.monotonic()
        while time.monotonic() - t0 < max_s and not self.should_stop():
            rect = self._settle_rect
            if geometry.valid(rect) and self.grab is winenv.grab_screen:
                frame, origin = winenv.grab_region(rect)        # only the window, not the whole desktop
            else:
                frame, origin = self.grab()
            if geometry.valid(rect):
                x0, y0 = max(0, int(rect[0] - origin[0])), max(0, int(rect[1] - origin[1]))
                x1, y1 = min(frame.shape[1], int(rect[2] - origin[0])), min(frame.shape[0], int(rect[3] - origin[1]))
                if x1 - x0 > 40 and y1 - y0 > 40:
                    frame = frame[y0:y1, x0:x1]
            small = cv2.cvtColor(cv2.resize(frame, (160, 90)), cv2.COLOR_BGR2GRAY)
            if prev is not None and float(cv2.absdiff(small, prev).mean()) < 1.0:
                stable += 1
                if stable >= 2:
                    return
            else:
                stable = 0
            prev = small
            time.sleep(0.06)

    _settle_rect = None

    def _failure_screenshot(self, res: dict) -> None:
        if self.dry_run or not self.run_dir:
            return
        try:
            frame, _ = self.grab()
            name, n = f"fail_step{res['id']:03d}.jpg", 1
            while (self.run_dir / name).exists():          # a retry must not overwrite the first failure's evidence
                n += 1
                name = f"fail_step{res['id']:03d}_try{n}.jpg"
            imwrite(self.run_dir / name, frame, 75)
            res["screenshot"] = name
        except Exception:
            log.debug("failure screenshot failed", exc_info=True)

    def _apply_heals(self) -> list[dict]:
        by_id = {s["id"]: s for s in self.test["steps"]}
        applied = []
        for h in self._heals:
            step = by_id.get(h["step"])
            tgt = (step or {}).get("target" if h["tag"] == "src" else "to")
            if tgt is None:
                continue
            old_locator = deepcopy(tgt)
            tpl = {}
            for size, (img, click) in h["crops"].items():
                rel = f"assets/s{step['id']:03d}_{h['tag']}_c{size}_healed.png"
                imwrite(self.dir / rel, img)
                tpl[f"crop{size}"] = {"path": rel, "click": [int(click[0]), int(click[1])],
                                      "size": [int(img.shape[1]), int(img.shape[0])]}
            tgt.setdefault("templates", {}).update(tpl)
            tgt["x"], tgt["y"] = h["x"], h["y"]
            tgt.setdefault("heal_history", []).append(
                {"at": datetime.now().isoformat(timespec="seconds"), "method": h["method"]})
            applied.append({"step": step["id"], "tag": h["tag"], "method": h["method"],
                            "description": step.get("description", ""),
                            "confidence": h.get("confidence", 0.0),
                            "old_locator": old_locator, "new_locator": deepcopy(tgt)})
        if applied:
            tj = self.dir / "test.json"
            bak = self.dir / "test.json.bak"
            if tj.exists():
                tmp = bak.with_suffix(bak.suffix + ".tmp")
                tmp.write_bytes(tj.read_bytes())
                tmp.replace(bak)
            testfile.save_test(self.test, self.dir)
        return applied

Player._run_step = Player.run_step
