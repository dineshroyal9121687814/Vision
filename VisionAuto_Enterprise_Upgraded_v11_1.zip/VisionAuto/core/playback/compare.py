"""Value comparison used by the ``value_check`` validation and by ``if`` conditions: numbers with tolerance, text,
regular expressions, dates. Pure functions, no UI."""
from __future__ import annotations

import re
from datetime import datetime

OPS = ("equals", "not_equals", "contains", "not_contains", "starts_with", "ends_with", "regex", "not_empty", "empty",
       "is_number", "gt", "ge", "lt", "le", "between", "date_before", "date_after", "length_equals", "in_list")


def _n(x):
    return float(re.sub(r"[^\d.\-eE+]", "", str(x).replace(",", "")) or "nan")


def check(actual, op: str, expected="", expected2="", tolerance: float = 0.0, fmt: str = "%Y-%m-%d",
          ignore_case: bool = False) -> tuple[bool, str]:
    """-> (passed, explanation). Never raises for bad data: an unreadable number simply fails with a reason."""
    a, e = str(actual if actual is not None else ""), str(expected if expected is not None else "")
    if ignore_case:
        a, e = a.casefold(), e.casefold()
    na = " ".join(a.split())
    ne = " ".join(e.split())
    try:
        if op == "equals":
            if tolerance:
                return abs(_n(a) - _n(e)) <= tolerance, f"{a!r} vs {e!r} (tolerance {tolerance})"
            return na == ne, f"{a!r} vs {e!r}"
        if op == "not_equals":
            return na != ne, f"{a!r} vs {e!r}"
        if op == "contains":
            return ne in na, f"{e!r} in {a!r}"
        if op == "not_contains":
            return ne not in na, f"{e!r} not in {a!r}"
        if op == "starts_with":
            return na.startswith(ne), f"{a!r} starts with {e!r}"
        if op == "ends_with":
            return na.endswith(ne), f"{a!r} ends with {e!r}"
        if op == "regex":
            return re.search(str(expected), str(actual), re.I if ignore_case else 0) is not None, f"{a!r} ~ /{expected}/"
        if op == "not_empty":
            return bool(na), f"{a!r} is {'not ' if na else ''}empty"
        if op == "empty":
            return not na, f"{a!r} is {'not ' if na else ''}empty"
        if op == "is_number":
            return _n(a) == _n(a), f"{a!r} is a number"
        if op in ("gt", "ge", "lt", "le"):
            x, y = _n(a), _n(e)
            if x != x or y != y:
                return False, f"cannot read numbers from {a!r} / {e!r}"
            return {"gt": x > y, "ge": x >= y, "lt": x < y, "le": x <= y}[op], f"{x} {op} {y}"
        if op == "between":
            x, lo, hi = _n(a), _n(e), _n(expected2)
            if x != x or lo != lo or hi != hi:
                return False, f"cannot read numbers from {a!r}, {e!r}, {expected2!r}"
            return lo <= x <= hi, f"{x} between {lo} and {hi}"
        if op in ("date_before", "date_after"):
            d1, d2 = datetime.strptime(a.strip(), fmt), datetime.strptime(e.strip(), fmt)
            return (d1 < d2) if op == "date_before" else (d1 > d2), f"{a} {op} {e}"
        if op == "length_equals":
            return len(str(actual)) == int(float(e)), f"len({a!r}) == {e}"
        if op == "in_list":
            items = [i.strip() for i in re.split(r"[;,|]", str(expected)) if i.strip()]
            return (a.strip() in ([i.casefold() for i in items] if ignore_case else items)), f"{a!r} in {items}"
    except (ValueError, re.error) as ex:
        return False, f"cannot compare {a!r} with {e!r}: {ex}"
    return False, f"unknown comparison '{op}'"
