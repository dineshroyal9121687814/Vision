"""
Scroll-to-find: bring an element that is not on screen into view, the way a person would.

Used when every locator tier failed and the recorded element lived in a scrollable container (list, drop-down, tree,
grid, document).  Strategies, cheapest and safest first:

  1. native   UI Automation ``ScrollItemPattern.ScrollIntoView`` - exact, no mouse, no side effects
  2. type     keyboard type-ahead in a list / combo box ("Ger" jumps to "Germany") - only for list-like containers, never menus
  3. position jump to the recorded scroll position (UIA ScrollPattern percent) - one call instead of many wheel steps,
              works for virtualised lists whose items do not exist until scrolled to
  4. wheel    scroll the container in small steps, looking after every step; the recorded direction first, then the
              opposite one; the end of the content is detected by the picture no longer changing

Bounded by a step count and a time budget; every step re-runs the cheap locator tiers only. The result is reported in the
resolution evidence (``scrolled`` = wheel steps, ``strategy``) so a report shows how the element was reached.
"""
from __future__ import annotations

import logging
import time

import numpy as np

from core.system import geometry, winenv
from core.vision.neighbors import LIST_ROLES

log = logging.getLogger("visionauto.scrollfind")

FAST_TIERS = ("excel", "point", "uia", "anchor", "image", "orb", "nbimg")


def _changed(a: np.ndarray | None, b: np.ndarray | None, thresh: float = 1.5) -> bool:
    if a is None or b is None or a.shape != b.shape:
        return True
    return float(np.mean(np.abs(a.astype(np.int16) - b.astype(np.int16)))) > thresh


class ScrollFinder:
    def __init__(self, resolver, scroller, typer=None, options: dict | None = None, sleep=time.sleep,
                 clock=time.monotonic, getpct=None, setpct=None):
        self.r, self.scroll, self.type = resolver, scroller, typer
        self.getpct = getpct or winenv.scroll_percent_at
        self.setpct = setpct or winenv.set_scroll_percent_at
        self.o = options or {}
        self.sleep, self.clock = sleep, clock

    # ------------------------------------------------------------------ geometry
    def container_rect(self, target: dict, window: dict):
        c = target.get("container") or {}
        rect = c.get("rect")
        if geometry.valid(rect):
            return list(rect)
        return None

    def _region(self, rect):
        try:
            frame, origin = winenv.grab_region(rect)
            return frame
        except Exception:
            return None

    # ------------------------------------------------------------------ main
    def find(self, target: dict, window: dict, budget_s: float | None = None):
        rect = self.container_rect(target, window)
        if rect is None:
            return None
        option = str(target.get("intent", "")) == "pick_option"
        max_steps = int(self.o.get("scroll_find_steps", 30))
        if option:
            max_steps = max(max_steps, 120)               # a long drop-down (fonts, countries) needs more than 30 notches
        budget = float(budget_s if budget_s is not None else self.o.get("scroll_find_budget_s", 15.0))
        if option:
            budget = max(budget, 25.0)
        deadline = self.clock() + budget
        cx, cy = int((rect[0] + rect[2]) / 2), int((rect[1] + rect[3]) / 2)

        def look(strategy: str, steps: int):
            res = self.r.resolve_once(target, window, attempt=1, only=FAST_TIERS)
            if res:
                res.evidence = {**(res.evidence or {}), "scrolled": steps, "strategy": strategy}
                res.method = f"scroll+{res.method}"
            return res

        container = target.get("container") or {}
        # 1. native
        if self.o.get("use_native", True) and (target.get("name") or target.get("automation_id")):
            try:
                if self.r.governor.allowed(window, target) and self.r.governor.call(
                        window, lambda: winenv.scroll_into_view(window.get("title", ""), target.get("name", ""),
                                                                target.get("role", ""), target.get("automation_id", ""))):
                    self.sleep(0.12)
                    res = look("scroll-into-view", 0)
                    if res:
                        return res
            except Exception:
                log.debug("native scroll-into-view failed", exc_info=True)
        # 2. type-ahead
        name = str(target.get("name") or target.get("text") or "").strip()
        if (self.o.get("typeahead", True) and self.type and name
                and (str(container.get("role", "")).casefold() in LIST_ROLES
                     or str(target.get("intent", "")) == "pick_option"
                     and str(container.get("role", "")).casefold() not in ("menu", "menubar"))):
            try:
                self.scroll(cx, cy, 0, 0)               # hover / focus the list (no wheel movement)
                self.type(name[:24], 15)
                self.sleep(0.2)
                res = look("type-ahead", 0)
                if res:
                    return res
            except Exception:
                log.debug("type-ahead failed", exc_info=True)
        # 3. jump to the recorded scroll position, then (below) fine-tune with the wheel
        rec = container.get("scroll_pct") or {}
        hint = int(target.get("scroll_hint", 1))
        if self.o.get("use_native", True) and isinstance(rec.get("v"), (int, float)) and rec["v"] >= 0:
            try:
                now = self.getpct(cx, cy) or {}
                if isinstance(now.get("v"), (int, float)) and now["v"] >= 0:
                    hint = 1 if rec["v"] >= now["v"] else -1            # the item is further down / up than we are now
                    if abs(rec["v"] - now["v"]) > 1.0 and self.setpct(cx, cy, v=rec["v"]):
                        self.sleep(0.2)
                        res = look("scroll-position", 0)
                        if res:
                            return res
            except Exception:
                log.debug("scroll position jump failed", exc_info=True)
        # 3b. do what the user did: the same number of wheel notches in the same direction, looking after every notch
        steps = 0
        rec_dy = int((target.get("scroll_recorded") or {}).get("dy") or 0)
        if rec_dy:
            sign = 1 if rec_dy > 0 else -1
            for _ in range(min(abs(rec_dy), max_steps)):
                if self.clock() >= deadline:
                    break
                self.scroll(cx, cy, 0, sign)
                steps += 1
                self.sleep(0.08)
                res = look("recorded-scroll", steps)
                if res:
                    return res
            hint = -sign                                                                # keep going the same way next
        # 4. wheel scan: same direction to the end of the list, then the opposite way through the WHOLE list.
        # Drop-downs scroll a notch at a time so no row is stepped over.
        first = -1 if hint >= 0 else 1                                                  # wheel dy<0 = content moves up
        notches = 1 if option else max(1, int(self.o.get("scroll_find_notches", 3)))
        for direction in (first, -first):
            stuck = 0
            before = self._region(rect)
            while steps < max_steps and self.clock() < deadline:
                self.scroll(cx, cy, 0, direction * notches)
                steps += 1
                self.sleep(0.1)
                after = self._region(rect)
                moved = _changed(before, after)
                before = after
                res = look("wheel", steps)
                if res:
                    return res
                stuck = 0 if moved else stuck + 1
                if stuck >= 2:                                                       # end of the content
                    break
        return None
