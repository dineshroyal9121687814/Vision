"""Requirement -> organised test cases (positive / negative / boundary / validation / ui / error / regression).

Two sources, both honest about what they are:
* **rules** - deterministic, offline: parses the requirement for fields, limits and verbs and applies standard
  test design techniques (equivalence classes, boundary value analysis, input validation, error guessing).
* **ai** - when ``use_llm`` is on and the local model answers, its extra cases are merged in (``source: "ai"``).
  Without a model the rules still produce a full set; nothing is faked.

Generated cases always have ``status: "not_run"``. They are *proposals* for a human to review and edit
before saving (``save_generated``); nothing here executes or marks anything as passed.
"""
from __future__ import annotations

import json
import re
from difflib import SequenceMatcher

from core import testcases

CATEGORY_TITLES = {"positive": "Positive", "negative": "Negative", "boundary": "Boundary", "validation": "Validation",
                   "ui": "UI interaction", "error_handling": "Error handling", "regression": "Regression"}

_STOP = set("the a an and or of to for in on at is are be can must should shall will with by from as it this that "
            "user users system application app when then if not no any all each".split())
_FIELD_HINTS = {
    "username": r"user ?name|login id|user id", "password": r"password|passcode|pin\b", "email": r"e-?mail",
    "phone": r"phone|mobile|contact number", "amount": r"amount|price|total|payment", "quantity": r"quantity|qty|count",
    "age": r"\bage\b", "date": r"\bdate\b|dob|birth", "name": r"\bname\b", "address": r"address",
    "zip": r"zip|postal|pin ?code", "card": r"card number|credit card|cvv", "search": r"search",
}
_RANGE = re.compile(r"(?P<field>[A-Za-z][\w ]{1,24}?)\s*(?:must be|should be|is|between|from|range)?\s*(?:between|from)\s+"
                    r"(?P<lo>-?\d+(?:\.\d+)?)\s*(?:and|to|-)\s*(?P<hi>-?\d+(?:\.\d+)?)", re.I)
_LEN = re.compile(r"(?P<field>[A-Za-z][\w ]{1,24}?)\s*(?:must be|should be|is)?\s*(?P<kind>min(?:imum)?|max(?:imum)?|at least|at most|up to)"
                  r"\s*(?:length\s*(?:of)?\s*)?(?P<n>\d+)\s*(?:characters|chars|digits|letters)", re.I)
_REQ_FIELD = re.compile(r"([A-Za-z][\w ]{1,24}?)\s+(?:is|are)\s+(?:a\s+)?(?:required|mandatory)", re.I)


# ============================================================================ parsing
def split_topics(text: str, default: str = "General") -> list[tuple[str, str]]:
    """'Login: ...\\nPayment: ...' or '# Login' headings -> [(topic, requirement text)]. One block if no headings."""
    parts: list[tuple[str, list[str]]] = []
    for line in text.splitlines():
        m = re.match(r"^\s*(?:#{1,3}\s*|\*\*)?([A-Za-z][\w &/-]{1,40}?)(?:\*\*)?\s*:\s*$", line) or \
            re.match(r"^\s*#{1,3}\s*(.+?)\s*$", line)
        if m and (line.strip().endswith(":") or line.lstrip().startswith("#")):
            parts.append((m.group(1).strip(), []))
        elif parts:
            parts[-1][1].append(line)
        else:
            parts.append((default, [line]))
    out = [(t, "\n".join(b).strip()) for t, b in parts if "\n".join(b).strip()]
    return out or [(default, text.strip())]


def analyse(requirement: str) -> dict:
    """Pull fields, numeric ranges, length limits and required fields out of free text."""
    low = requirement.casefold()
    fields = [name for name, pat in _FIELD_HINTS.items() if re.search(pat, low)]
    ranges = [{"field": m.group("field").strip().split()[-1].casefold(), "lo": float(m.group("lo")), "hi": float(m.group("hi"))}
              for m in _RANGE.finditer(requirement)]
    lengths = []
    for m in _LEN.finditer(requirement):
        kind = m.group("kind").casefold()
        lengths.append({"field": m.group("field").strip().split()[-1].casefold(),
                        "kind": "min" if kind.startswith(("min", "at least")) else "max", "n": int(m.group("n"))})
    required = [m.group(1).strip().split()[-1].casefold() for m in _REQ_FIELD.finditer(requirement)]
    for f in ranges + lengths:
        if f["field"] not in fields and f["field"] not in _STOP:
            fields.append(f["field"])
    return {"fields": fields, "ranges": ranges, "lengths": lengths, "required": required,
            "is_auth": bool(re.search(r"log ?in|sign ?in|authenticat|password", low)),
            "is_payment": bool(re.search(r"pay|checkout|card|transaction|invoice", low)),
            "is_form": bool(re.search(r"regist|sign ?up|form|submit|create account|profile", low))}


# ============================================================================ rule based generation
def _case(topic, category, title, desc, pre, data, steps, expected, priority) -> dict:
    return {"title": title, "description": desc, "preconditions": pre, "test_data": data, "steps": steps,
            "expected_results": expected, "priority": priority, "category": category, "topic": topic,
            "status": "not_run", "source": "rules"}


def _fmt(n: float):
    return int(n) if float(n).is_integer() else n


def generate_rules(topic: str, requirement: str, categories=testcases.CATEGORIES) -> list[dict]:
    a = analyse(requirement)
    fields = a["fields"] or ["input"]
    T = topic
    out: list[dict] = []
    pre = [f"The application is installed and {T} is reachable", "Test environment and test data are available"]
    primary = fields[0]

    if "positive" in categories:
        data = {f: f"<valid {f}>" for f in fields}
        out.append(_case(T, "positive", f"{T}: complete the main flow with valid data",
                         f"Verify the primary {T} scenario succeeds when every input is valid.", pre, data,
                         [f"Open the {T} feature", *[f"Enter a valid {f}" for f in fields], "Submit / confirm the action"],
                         [f"The {T} action completes successfully", "A success confirmation is shown",
                          "The data is saved / state is updated correctly"], "High"))
        out.append(_case(T, "positive", f"{T}: main flow using keyboard only",
                         "The same flow can be finished without the mouse.", pre, {f: f"<valid {f}>" for f in fields},
                         ["Navigate with Tab / Shift+Tab", *[f"Type a valid {f}" for f in fields], "Press Enter to submit"],
                         ["Focus order is logical", "The action completes exactly as with the mouse"], "Medium"))
        if a["is_auth"]:
            out.append(_case(T, "positive", f"{T}: valid credentials sign the user in", "Correct username and password.",
                             pre + ["A registered active account exists"], {"username": "<valid user>", "password": "<valid password>"},
                             ["Enter the registered username", "Enter the correct password", "Click Login"],
                             ["The user lands on the home / dashboard page", "The user name is displayed"], "High"))

    if "negative" in categories:
        for f in fields:
            out.append(_case(T, "negative", f"{T}: {f} left empty",
                             f"Submitting without a {f} must be rejected.", pre, {f: ""},
                             [f"Open the {T} feature", *[f"Enter a valid {g}" for g in fields if g != f], f"Leave {f} empty", "Submit"],
                             [f"The action is NOT performed", f"A clear message tells the user that {f} is required"], "High"))
            out.append(_case(T, "negative", f"{T}: invalid {f} format",
                             f"A malformed {f} is rejected with a helpful message.", pre, {f: "!!@@##"},
                             [f"Open the {T} feature", f"Enter an invalid {f} (e.g. '!!@@##')", "Submit"],
                             ["The input is rejected", "The error message names the problem; no data is saved"], "Medium"))
        if a["is_auth"]:
            out.append(_case(T, "negative", f"{T}: wrong password", "Valid user, incorrect password.", pre,
                             {"username": "<valid user>", "password": "<wrong password>"},
                             ["Enter a valid username", "Enter a wrong password", "Click Login"],
                             ["Login is refused", "A generic 'invalid credentials' message is shown (no hint which part is wrong)"], "High"))
            out.append(_case(T, "negative", f"{T}: unknown user", "Username that does not exist.", pre,
                             {"username": "no_such_user", "password": "<any>"},
                             ["Enter an unregistered username", "Enter any password", "Click Login"],
                             ["Login is refused", "No account information is leaked"], "Medium"))
            out.append(_case(T, "negative", f"{T}: repeated failed attempts", "Lock-out / throttling after several failures.",
                             pre, {"attempts": "5+"}, ["Fail the login several times in a row"],
                             ["The account is locked or throttled according to the requirement", "The user is told what happens next"], "Medium"))

    if "boundary" in categories:
        for r in a["ranges"]:
            f, lo, hi = r["field"], r["lo"], r["hi"]
            for label, val, ok in (("minimum", lo, True), ("minimum - 1", lo - 1, False), ("maximum", hi, True), ("maximum + 1", hi + 1, False),
                                   ("just above minimum", lo + 1, True), ("just below maximum", hi - 1, True)):
                out.append(_case(T, "boundary", f"{T}: {f} at {label} ({_fmt(val)})",
                                 f"Boundary value analysis for {f} in [{_fmt(lo)}, {_fmt(hi)}].", pre, {f: _fmt(val)},
                                 [f"Open the {T} feature", f"Enter {f} = {_fmt(val)}", "Submit"],
                                 ["The value is accepted and processed"] if ok else ["The value is rejected with a range message"],
                                 "High" if label in ("minimum", "maximum", "minimum - 1", "maximum + 1") else "Medium"))
        for ln in a["lengths"]:
            f, n = ln["field"], ln["n"]
            probes = [(n, True), (n - 1, ln["kind"] == "max"), (n + 1, ln["kind"] == "min")]
            for length, ok in probes:
                if length < 0:
                    continue
                out.append(_case(T, "boundary", f"{T}: {f} with {length} characters ({ln['kind']} {n})",
                                 f"Length limit of {f}: {ln['kind']} {n}.", pre, {f: f"<{length} characters>"},
                                 [f"Enter a {f} of exactly {length} characters", "Submit"],
                                 ["The value is accepted"] if ok else ["The value is rejected with a length message"], "High"))
        if not a["ranges"] and not a["lengths"]:
            out.append(_case(T, "boundary", f"{T}: very long input in {primary}", "Maximum practical length.", pre,
                             {primary: "<1000+ characters>"}, [f"Paste 1000+ characters into {primary}", "Submit"],
                             ["The application does not crash or truncate silently", "Either the value is accepted fully or rejected with a message"], "Medium"))
            out.append(_case(T, "boundary", f"{T}: single character in {primary}", "Minimum practical length.", pre,
                             {primary: "a"}, [f"Enter one character into {primary}", "Submit"],
                             ["The result matches the documented minimum length rule"], "Low"))

    if "validation" in categories:
        out.append(_case(T, "validation", f"{T}: leading / trailing spaces are handled", "Whitespace around values.", pre,
                         {primary: "  value  "}, [f"Enter '  value  ' in {primary}", "Submit"],
                         ["Spaces are trimmed or rejected consistently; behaviour matches the requirement"], "Low"))
        out.append(_case(T, "validation", f"{T}: special characters and Unicode", "Quotes, symbols and non-Latin text.", pre,
                         {primary: "O'Brien <b>\" ; -- ñ 你好"}, [f"Enter special characters in {primary}", "Submit"],
                         ["Input is stored / rejected safely; nothing is executed or rendered as markup"], "Medium"))
        out.append(_case(T, "validation", f"{T}: SQL / script injection text", "Typical injection strings are inert.", pre,
                         {primary: "' OR '1'='1"}, [f"Enter \"' OR '1'='1\" in {primary}", "Submit"],
                         ["The text is treated as plain data", "No error leaks internal details"], "High"))
        for f in a["required"]:
            out.append(_case(T, "validation", f"{T}: required field '{f}'", f"'{f}' is mandatory.", pre, {f: ""},
                             [f"Leave {f} blank", "Submit"], [f"A required-field message is shown for {f}"], "High"))
        if "email" in fields:
            out.append(_case(T, "validation", f"{T}: e-mail format rules", "Missing @, domain or dots.", pre,
                             {"email": ["plain", "a@", "@b.com", "a@b", "a b@c.com"]}, ["Try each invalid e-mail"],
                             ["Each invalid address is rejected with a format message"], "Medium"))
        if a["is_form"]:
            out.append(_case(T, "validation", f"{T}: duplicate submission is detected", "Same unique value twice.", pre,
                             {"value": "<already used>"}, ["Submit a value that already exists"],
                             ["A duplicate message is shown; no second record is created"], "High"))

    if "ui" in categories:
        out.append(_case(T, "ui", f"{T}: default state and labels", "Screen opens in a sensible state.", pre, {},
                         [f"Open the {T} feature"],
                         ["All labels are readable and spelled correctly", "Required fields are marked", "The primary button state matches the requirement"], "Medium"))
        out.append(_case(T, "ui", f"{T}: Tab order and focus", "Keyboard navigation.", pre, {},
                         ["Press Tab repeatedly through the screen"], ["Focus moves in visual order; focus is always visible"], "Low"))
        out.append(_case(T, "ui", f"{T}: window resize / maximise", "Layout remains usable.", pre, {},
                         ["Resize, maximise and restore the window"], ["No control is cut off or overlapping; scrolling works"], "Low"))
        out.append(_case(T, "ui", f"{T}: error message presentation", "Where and how errors appear.", pre, {},
                         ["Trigger a validation error"], ["The message is next to the field, readable and disappears once fixed"], "Medium"))

    if "error_handling" in categories:
        out.append(_case(T, "error_handling", f"{T}: backend / network unavailable", "Dependency down while submitting.", pre,
                         {"condition": "network disabled"}, ["Disable the network / stop the service", "Submit the form"],
                         ["A clear, non-technical error is shown", "No data is lost or half-saved", "The user can retry"], "High"))
        out.append(_case(T, "error_handling", f"{T}: double click on submit", "Duplicate submission guard.", pre, {},
                         ["Double-click the submit button quickly"], ["The action is performed once only"], "Medium"))
        out.append(_case(T, "error_handling", f"{T}: cancel / close in the middle", "Abandon the flow.", pre, {},
                         ["Start the flow", "Close the window or press Cancel before finishing"],
                         ["No partial data is saved", "The application stays stable"], "Medium"))
        out.append(_case(T, "error_handling", f"{T}: slow response", "Timeouts and progress feedback.", pre,
                         {"condition": "response delayed 30s"}, ["Submit while the backend is slow"],
                         ["A progress indicator is shown", "A timeout message appears if the limit is exceeded"], "Low"))

    if "regression" in categories:
        out.append(_case(T, "regression", f"{T}: main flow after a new build", "Smoke check after every change.", pre,
                         {f: f"<valid {f}>" for f in fields}, ["Run the main positive scenario on the new build"],
                         ["Behaviour is identical to the previous release"], "High"))
        out.append(_case(T, "regression", f"{T}: persisted data survives restart", "Data remains after restart.", pre, {},
                         ["Complete the flow", "Close and reopen the application", "Open the saved data"],
                         ["The saved data is still present and unchanged"], "Medium"))
        if a["is_payment"]:
            out.append(_case(T, "regression", f"{T}: totals and rounding unchanged", "Money calculations.", pre,
                             {"amount": "<known amounts>"}, ["Repeat calculations with known inputs"],
                             ["Totals, taxes and rounding equal the baseline"], "High"))
    return out


# ============================================================================ optional LLM
def generate_llm(topic: str, requirement: str, llm, categories=testcases.CATEGORIES, limit: int = 8) -> list[dict]:
    """Ask the local model for *additional* cases. Returns [] when it is unavailable or answers badly."""
    if llm is None or not llm.available():
        return []
    prompt = ("You are a senior QA engineer. Return ONLY JSON: {\"cases\":[{\"title\":str,\"description\":str,"
              "\"preconditions\":[str],\"test_data\":{},\"steps\":[str],\"expected_results\":[str],\"priority\":"
              "\"High|Medium|Low\",\"category\":\"" + "|".join(categories) + "\"}]}. "
              f"Write up to {limit} NON-OBVIOUS test cases for the topic '{topic}'.\nRequirement:\n{requirement[:3000]}")
    text = llm.generate(prompt) or ""
    m = re.search(r"\{.*\}", text, re.S)
    if not m:
        return []
    try:
        raw = json.loads(m.group(0)).get("cases", [])
    except ValueError:
        return []
    out = []
    for c in raw[:limit] if isinstance(raw, list) else []:
        try:
            n = testcases.normalize_case({**c, "topic": topic, "source": "ai"}, topic, str(c.get("category") or "positive"))
        except testcases.CaseError:
            continue
        if n["category"] in categories:
            out.append(n)
    return out


# ============================================================================ duplicates and coverage
def _norm(c: dict) -> str:
    text = c.get("title", "") + " " + " ".join(map(str, c.get("steps", []))) + " " + json.dumps(c.get("test_data", {}), sort_keys=True)
    return re.sub(r"[^a-z0-9 ]+", " ", text.casefold())


def similarity(a: dict, b: dict) -> float:
    """0..1. Cases with different test data are never similar: boundary cases differ only by their numbers."""
    if a.get("test_data") != b.get("test_data"):
        return 0.0
    return SequenceMatcher(None, _norm(a), _norm(b)).ratio()


def find_duplicates(cases: list[dict], existing: list[dict] | None = None, threshold: float = 0.9) -> list[dict]:
    """-> [{"case": i, "duplicate_of": "<id|index>", "similarity": 0.93, "where": "batch|saved"}]"""
    found = []
    for i, c in enumerate(cases):
        for j in range(i):
            s = similarity(c, cases[j])
            if s >= threshold:
                found.append({"case": i, "duplicate_of": cases[j].get("id") or f"#{j + 1}", "similarity": round(s, 3), "where": "batch"})
                break
        else:
            for e in existing or []:
                s = similarity(c, e)
                if s >= threshold:
                    found.append({"case": i, "duplicate_of": e.get("id", ""), "similarity": round(s, 3), "where": "saved"})
                    break
    return found


def _tokens(text: str) -> set[str]:
    return {w for w in re.findall(r"[a-z0-9]+", text.casefold()) if w not in _STOP and len(w) > 2}


def coverage(requirement: str, cases: list[dict]) -> dict:
    """Which requirement statements are touched by at least one case (token overlap, reported with the evidence)."""
    atoms = [s.strip(" -*\t") for s in re.split(r"[\n.;]+", requirement) if len(s.strip()) > 8]
    rows, covered = [], 0
    for atom in atoms:
        t = _tokens(atom)
        hits = []
        for c in cases:
            ct = _tokens(" ".join([c.get("title", ""), c.get("description", ""), " ".join(map(str, c.get("steps", []))),
                                   " ".join(map(str, c.get("expected_results", [])))]))
            if t and len(t & ct) / len(t) >= 0.34:
                hits.append(c.get("id") or c.get("title"))
        rows.append({"requirement": atom, "covered": bool(hits), "cases": hits[:6]})
        covered += bool(hits)
    return {"total": len(atoms), "covered": covered, "percent": round(100 * covered / len(atoms), 1) if atoms else 0.0,
            "items": rows, "uncovered": [r["requirement"] for r in rows if not r["covered"]]}


# ============================================================================ public API
def generate(text: str, topic: str | None = None, categories=testcases.CATEGORIES, llm=None,
             existing: list[dict] | None = None) -> dict:
    """-> {"topics": {topic: [cases]}, "duplicates": [...], "coverage": {topic: {...}}}. Nothing is saved."""
    if not text or not text.strip():
        raise testcases.CaseError("Enter a feature, requirement, user story or scenario first.")
    blocks = [(topic, text.strip())] if topic else split_topics(text)
    result = {"topics": {}, "duplicates": {}, "coverage": {}}
    for name, req in blocks:
        name = (name or "General").strip()
        cases = generate_rules(name, req, categories) + generate_llm(name, req, llm, categories)
        for n, c in enumerate(cases, 1):
            c["id"] = ""
        dups = find_duplicates(cases, existing)
        drop = {d["case"] for d in dups}
        kept = [c for i, c in enumerate(cases) if i not in drop]
        counters: dict[str, int] = {}
        prefix = re.sub(r"[^A-Za-z]", "", name).upper()[:3] or "TC"
        for c in kept:
            counters[c["category"]] = counters.get(c["category"], 0) + 1
            c["id"] = f"{prefix}-{c['category'][:3].upper()}-{counters[c['category']]:03d}"
        result["topics"][name] = kept
        result["duplicates"][name] = dups
        result["coverage"][name] = coverage(req, kept)
    return result


def save_generated(topics: dict[str, list[dict]], out_dir=None, merge: bool = True) -> dict:
    """Write cases as ``<out>/<Topic>/<topic>_<category>.json``. With ``merge`` existing files are extended, never
    overwritten; ids that already exist are renumbered so nothing is lost."""
    base = testcases.validate_dir(out_dir) if out_dir else testcases.validate_dir(testcases.root())
    files, total = [], 0
    for topic, cases in topics.items():
        by_cat: dict[str, list[dict]] = {}
        for c in cases:
            n = testcases.normalize_case(c, topic)
            by_cat.setdefault(n["category"], []).append(n)
        for cat, items in by_cat.items():
            path = testcases.file_for(topic, cat, base)
            have = testcases.load_file(path)["cases"] if (merge and path.is_file()) else []
            used = {c.get("id") for c in have}
            for it in items:
                k = 1
                while not it["id"] or it["id"] in used:
                    it["id"] = f"{re.sub(r'[^A-Za-z]', '', topic).upper()[:3] or 'TC'}-{cat[:3].upper()}-{len(used) + k:03d}"
                    k += 1
                used.add(it["id"])
            testcases.save_file(path, topic, cat, have + items)
            files.append(str(path))
            total += len(items)
    return {"files": files, "cases": total, "root": str(base)}
