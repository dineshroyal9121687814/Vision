"""Plugins & integrations overview: what VisionAuto can drive, what is ready on this computer and what is missing."""
from __future__ import annotations

import importlib.util
import shutil

from core import settings
from core.plugins.plugin_manager import PluginManager

DESCRIPTIONS = {
    "generic": ("Windows desktop (UI Automation)", "Win32, WinForms, WPF, UWP; pictures + OCR fallbacks"),
    "web": ("Web browsers", "Chrome / Edge DOM through the debugging port"),
    "electron": ("Electron apps", "VS Code, Teams, Slack ... through the debugging port"),
    "java": ("Java Swing / SWT", "Java Access Bridge"),
    "sap": ("SAP GUI", "SAP GUI scripting API"),
    "citrix_rdp": ("Citrix / Remote Desktop", "pictures and OCR only (no accessibility tree is available)"),
}


def _has(mod: str) -> bool:
    try:
        return importlib.util.find_spec(mod) is not None
    except (ImportError, ValueError):
        return False


def plugins() -> list[dict]:
    out = []
    for p in PluginManager().plugins:
        title, how = DESCRIPTIONS.get(p.name, (p.name, ""))
        out.append({"id": p.name, "title": title, "how": how, "uses_accessibility": bool(p.uses_uia)})
    return out


def components() -> list[dict]:
    """Optional components and whether they are installed here. Never installs anything."""
    opts = settings.load()
    rows = [
        ("Windows UI Automation", _has("pywinauto"), "pywinauto"),
        ("Excel automation (COM)", _has("win32com"), "pywin32"),
        ("Excel files (openpyxl)", _has("openpyxl"), "openpyxl"),
        ("OCR: RapidOCR", _has("rapidocr_onnxruntime"), "rapidocr-onnxruntime"),
        ("OCR: EasyOCR", _has("easyocr"), "easyocr"),
        ("OCR: Tesseract", bool(shutil.which("tesseract")), "Tesseract OCR program"),
        ("Image matching (OpenCV)", _has("cv2"), "opencv-python"),
        ("Input: pynput", _has("pynput"), "pynput"),
        ("Input: pyautogui", _has("pyautogui"), "pyautogui"),
        ("Local AI (Ollama)", bool(shutil.which("ollama")), "Ollama"),
        ("Screen capture (mss)", _has("mss"), "mss"),
    ]
    return [{"name": n, "installed": ok, "package": pkg} for n, ok, pkg in rows] + [
        {"name": "AI provider in use", "installed": bool(opts.get("use_llm")),
         "package": f"{opts.get('llm_model', '')} @ {opts.get('llm_base_url', '')}" if opts.get("use_llm") else "off (rules only)"}]
