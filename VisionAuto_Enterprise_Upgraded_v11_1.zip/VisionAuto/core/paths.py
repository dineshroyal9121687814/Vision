"""
Workspace layout. Everything VisionAuto creates lives under one folder so a
user can back it up / move it / put it in git:

    workspace/
      tests/<name>/test.json, steps.jsonl, assets/     recorded tests
      imported/<project>/*.py, repository.json         imported Ranorex tests
      testcases/<Topic>/<topic>_<category>.json        generated / managed test cases (path configurable)
      runs/<name>/<run_id>/run.json, report.html       execution results
      logs/visionauto.log
      settings.json

Override the location with the VISIONAUTO_HOME environment variable.
All helpers are functions (not constants) so tests can redirect the workspace.
"""
from __future__ import annotations

import logging
import os
from logging.handlers import RotatingFileHandler
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def workspace() -> Path:
    return Path(os.environ.get("VISIONAUTO_HOME") or (ROOT / "workspace"))


def tests_dir() -> Path:
    return workspace() / "tests"


def runs_dir() -> Path:
    return workspace() / "runs"


def testcases_dir() -> Path:
    """Default folder of topic-wise test case files (Settings can point somewhere else)."""
    return workspace() / "testcases"


def imported_dir() -> Path:
    return workspace() / "imported"


def logs_dir() -> Path:
    return workspace() / "logs"


def applications_file() -> Path:
    return workspace() / "applications.json"


def ensure_dirs() -> None:
    for d in (tests_dir(), runs_dir(), imported_dir(), logs_dir()):
        d.mkdir(parents=True, exist_ok=True)


_logging_ready = False


def setup_logging(level: int = logging.INFO) -> None:
    global _logging_ready
    if _logging_ready:
        return
    ensure_dirs()
    root = logging.getLogger("visionauto")
    root.setLevel(level)
    handler = RotatingFileHandler(
        logs_dir() / "visionauto.log", maxBytes=2_000_000, backupCount=3, encoding="utf-8"
    )
    handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s"))
    from core.security import MaskingFilter

    handler.addFilter(MaskingFilter())            # secrets that reach a log call never reach the log file
    root.addHandler(handler)
    _logging_ready = True
