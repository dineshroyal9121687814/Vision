"""
Turn "I used the Start menu to open an app" into one reliable ``open_app`` step.

What a recording of that looks like (taken from a real run - see workspace/tests/cal):

    1 click   'Start' button                      (explorer.exe)
    2 type    'cal'                               (SearchHost.exe)
    3 click   'CoreInput' pane at (661, 459)      (SearchHost.exe)   <- a pixel in a 968x832 pane, not "Calculator"
    4 double_click 'Nine' button                  (ApplicationFrameHost.exe, window 'Calculator')

Replaying step 3 blindly is what made "cal gets typed but Calculator never opens": the click fires before Windows
Search has drawn its results, and even afterwards the pixel only means "Calculator" on the machine that was recorded.

``compact_launches`` finds every such run (an optional Start click / Win+key, a ``type`` inside a Search/Start host
process, any clicks / Enter inside that host) and replaces it with:

    {"type": "open_app", "params": {"name": "Calculator", "window_title": "Calculator", "query": "cal"}}

The application's name comes from the window that opened next (what the user actually got), not from the typed text.
Pure function over the step list - no OS access.
"""
from __future__ import annotations

import re
from copy import deepcopy

from core.system.launcher import SEARCH_PROCESSES

_NOISE_TITLES = {"search", "start", "", "program manager", "windows shell experience host"}


def _proc(step: dict) -> str:
    return str((step.get("window") or {}).get("process") or "").casefold()


def _in_search_host(step: dict) -> bool:
    """A step made inside the Start menu / Search flyout (by process, or by the shell's own 'Start'/'Search' window)."""
    if _proc(step) in SEARCH_PROCESSES:
        return True
    w = step.get("window") or {}
    return _proc(step) in ("explorer.exe", "") and str(w.get("title") or "").strip().casefold() in ("start", "search")


def _clicked_name(step: dict) -> str:
    """The app tile / list item that was clicked in the Start menu ('Calculator', 'Notepad, Pinned' -> 'Notepad')."""
    t = step.get("target") or {}
    name = str(t.get("name") or t.get("text") or "").strip()
    name = re.split(r"\s*[,\u2013-]\s*(?:Pinned|Recommended|App|Application)\b", name, maxsplit=1)[0].strip()
    skip = {"", "start", "search", "pinned", "all apps", "all", "recommended", "more", "back", "coreinput", "type here to search"}
    if name.casefold() in skip or t.get("role") in ("Pane", "Window", "Document", "Edit"):
        return ""
    return name


def _is_start_click(step: dict) -> bool:
    if step.get("type") not in ("click", "double_click"):
        return False
    t = step.get("target") or {}
    return t.get("automation_id") == "StartButton" or (t.get("name") == "Start" and t.get("role") == "Button")


def _is_win_key(step: dict) -> bool:
    p = step.get("params") or {}
    if step.get("type") == "key":
        return str(p.get("key", "")).casefold() in ("win", "cmd")
    if step.get("type") == "hotkey":
        keys = str(p.get("keys", "")).casefold().split("+")
        return keys[0] == "win" and len(keys) == 2 and keys[1] in ("s", "q")
    return False


def _selects_result(step: dict) -> bool:
    """A click / Enter / arrow key made inside the Start-search host (choosing a result)."""
    t = step.get("type")
    if not _in_search_host(step):
        return False
    if t in ("click", "double_click"):
        return True
    return t == "key" and (step.get("params") or {}).get("key") in ("enter", "down", "up", "tab")


def _pretty(text: str) -> str:
    return " ".join(w.capitalize() for w in re.split(r"\s+", text.strip()) if w)


def compact_launches(steps: list[dict]) -> tuple[list[dict], list[dict]]:
    """Return ``(new_steps, changes)``. ``changes`` lists what was merged (for the report / GUI).

    A launch is: an optional Start click / Win key, then anything done *inside* the Start menu - typing a query, and/or
    clicking a tile or list item, and/or Enter - then the window that opened. Typing is NOT required: clicking Start and
    choosing a pinned / All-apps tile is a launch too (it used to be replayed as a blind click on Start + a blind click
    on a pixel, so the app never opened)."""
    out: list[dict] = []
    changes: list[dict] = []
    i, n = 0, len(steps)
    while i < n:
        s = steps[i]
        start = i
        has_start = _is_start_click(s) or _is_win_key(s)
        j = i + 1 if has_start else i
        k, query, names, typed = j, "", [], False
        while k < n and _in_search_host(steps[k]) and not _is_start_click(steps[k]):
            st = steps[k]
            if st.get("type") == "type":
                if (st.get("params") or {}).get("redacted"):
                    break
                query += str((st.get("params") or {}).get("text") or "")
                typed = True
            elif st.get("type") in ("click", "double_click"):
                nm = _clicked_name(st)
                if nm:
                    names.append(nm)
            elif not _selects_result(st):
                break
            k += 1
        did_something = k > j
        if (has_start and did_something) or (not has_start and typed):
            nxt = steps[k] if k < n else None
            opened = ""
            if nxt is not None and not _in_search_host(nxt):
                title = str((nxt.get("window") or {}).get("title") or "").strip()
                if title.casefold() not in _NOISE_TITLES:
                    opened = title
            name = opened or (names[-1] if names else "") or _pretty(query)
            if name:
                first = steps[start]
                step = {
                    "id": first.get("id", 0), "type": "open_app", "t_ms": first.get("t_ms", 0),
                    "window": {"title": "", "process": "explorer.exe"},
                    "params": {"name": name, "window_title": opened or name, "query": query, "timeout_s": 15},
                    "description": f"Open '{name}'",
                    "validations": ([{"type": "window_title_contains", "expected": opened,
                                      "description": f"window title contains '{opened}'"}] if opened else []),
                }
                out.append(step)
                changes.append({"replaced_steps": [x.get("id") for x in steps[start:k]], "name": name, "query": query,
                                "reason": "Start-menu launch replaced by open_app (no blind click on a result pixel)"})
                i = k
                continue
        out.append(deepcopy(steps[start]))
        i = start + 1
    for idx, st in enumerate(out, 1):
        st["id"] = idx
    return out, changes


def compact_test(test: dict) -> list[dict]:
    """In-place version for a loaded test dict. Returns the list of changes (empty = nothing to fix)."""
    steps, changes = compact_launches(test.get("steps") or [])
    if changes:
        test["steps"] = steps
        test["summary"] = f"{len(steps)} steps (Start-menu launch merged into open_app)"
    return changes
