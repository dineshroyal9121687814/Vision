"""
Understand what the user was doing, not just where they clicked.

A recording is a list of mouse / keyboard events. What matters for a reliable replay is the *intent* behind them:

  open_dropdown    clicked a combo box / split button that opens a list
  pick_option      chose an item of a drop-down / list / menu (often in its own pop-up window)
  scroll_to_find   scrolled only to bring the next target into view
  enter_value      clicked a field / cell and typed into it
  drag_reorder     dragged an item to another place of the same list
  drag_cross       dragged between two windows / applications
  drag_move        any other drag

Each step gets ``intent`` (and ``intent_for`` / ``opener`` links). Playback uses it to choose the strategy:
a ``pick_option`` may jump to its item by typing the item's text first (``typeahead``), a ``scroll_to_find`` scroll is
skipped when the target is already visible, a cross-window drag arranges both windows first.

Rules decide everything they can (instant, offline, deterministic). Only what the rules cannot place is offered to the
optional local model (Ollama), which must answer with one word from a fixed list - anything else is ignored, so the
model can refine a recording but never break one.
"""
from __future__ import annotations

import json
import logging

from core.vision.neighbors import LIST_ROLES

log = logging.getLogger("visionauto.intent")

INTENTS = ("open_dropdown", "pick_option", "scroll_to_find", "enter_value", "drag_reorder", "drag_cross", "drag_move",
           "click")
OPENERS = {"combobox", "splitbutton"}
OPTIONS = {"listitem", "menuitem", "treeitem", "dataitem"}
CLICKS = ("click", "double_click", "right_click", "middle_click")


def _role(step: dict) -> str:
    return str((step.get("target") or {}).get("role") or "").replace(" ", "").casefold()


def _container_role(step: dict) -> str:
    return str(((step.get("target") or {}).get("container") or {}).get("role") or "").casefold()


def classify(step: dict, prev: dict | None, nxt: dict | None) -> tuple[str, dict]:
    """(intent, links) for one step from its neighbours in the recording. ``"click"`` = nothing special."""
    t = step.get("type")
    win = step.get("window") or {}
    if t == "drag_drop":
        to_win = step.get("to_window")
        if to_win and (to_win.get("title") != win.get("title") or to_win.get("process") != win.get("process")):
            return "drag_cross", {}
        c1 = (step.get("target") or {}).get("container") or {}
        c2 = (step.get("to") or {}).get("container") or step.get("to_container") or {}
        if c1.get("rect") and c1.get("rect") == c2.get("rect"):
            return "drag_reorder", {}
        return "drag_move", {}
    if t == "scroll":
        if nxt and nxt.get("type") in CLICKS + ("drag_drop",) and (nxt.get("target") or {}).get("container"):
            return "scroll_to_find", {"intent_for": nxt.get("id")}
        return "click", {}
    if t in CLICKS:
        role = _role(step)
        in_list = _container_role(step) in LIST_ROLES or _container_role(step) == "list"
        opener_before = prev is not None and (prev.get("intent") == "open_dropdown" or (
            prev.get("type") == "scroll" and prev.get("intent") == "scroll_to_find"))
        if win.get("popup") or role in OPTIONS and (in_list or opener_before):
            return "pick_option", ({"opener": prev.get("id")} if prev and prev.get("intent") == "open_dropdown" else {})
        if role in OPENERS or (nxt and (nxt.get("window") or {}).get("popup") and nxt.get("type") in CLICKS):
            return "open_dropdown", {}
        if nxt and nxt.get("type") == "type" and role in ("edit", "document", "dataitem", "text", "custom", ""):
            return "enter_value", {"value_step": nxt.get("id")}
    return "click", {}


def compact_scrolls(steps: list[dict]) -> list[str]:
    """Remove scrolling that changes nothing. Wheel bursts that follow each other with no other action in between
    (same window, same place) become one step with the summed distance; if they cancel out (down 5, up 5) the step is
    dropped. Returns a note per change so the user can see it in the recording notes. Edits ``steps`` in place."""
    notes: list[str] = []
    i = 0
    while i < len(steps) - 1:
        a, b = steps[i], steps[i + 1]
        if (a.get("type") == "scroll" and b.get("type") == "scroll"
                and (a.get("window") or {}).get("title") == (b.get("window") or {}).get("title")
                and abs(int((a.get("target") or {}).get("x", 0)) - int((b.get("target") or {}).get("x", 0))) <= 40
                and abs(int((a.get("target") or {}).get("y", 0)) - int((b.get("target") or {}).get("y", 0))) <= 40):
            pa, pb = a.setdefault("params", {}), b.get("params") or {}
            pa["dx"], pa["dy"] = int(pa.get("dx", 0)) + int(pb.get("dx", 0)), int(pa.get("dy", 0)) + int(pb.get("dy", 0))
            del steps[i + 1]
            notes.append(f"Merged two consecutive scrolls into one (total {pa['dx']},{pa['dy']}).")
            continue
        i += 1
    for st in [s for s in steps if s.get("type") == "scroll" and not (s.get("params") or {}).get("dx")
               and not (s.get("params") or {}).get("dy")]:
        steps.remove(st)
        notes.append("Removed a scroll that was undone by scrolling back (net distance 0).")
    return notes


def ensure_state_of(step: dict) -> str:
    """What the user wanted a check box / radio button / toggle to BE after this click ('on' / 'off' / 'selected').
    Recorded as a state to reach, not as a click to repeat, so a replay on a box that is already in that state does not
    flip it back."""
    if step.get("type") != "click":
        return ""
    tg = step.get("target") or {}
    st = tg.get("state") or {}
    role = str(tg.get("role") or "").replace(" ", "").casefold()
    tog = st.get("toggle")
    if role in ("checkbox", "togglebutton", "switch", "menuitem", "listitem", "treeitem", "dataitem") and tog in ("on", "off"):
        return "off" if tog == "on" else "on"
    if role == "radiobutton" and st.get("selected") is False:
        return "selected"
    return ""


def annotate(steps: list[dict]) -> list[dict]:
    """Add ``intent`` to every step (in place) and mirror what playback needs onto the target. Returns the ambiguous
    steps (a click on an unnamed thing right after a scroll or an opener) that the optional model may refine."""
    ambiguous = []
    for i, st in enumerate(steps):
        if not isinstance(st, dict):
            continue
        prev = steps[i - 1] if i else None
        nxt = steps[i + 1] if i + 1 < len(steps) else None
        intent, links = classify(st, prev, nxt)
        st["intent"] = intent
        want = ensure_state_of(st)
        if want:
            st["ensure_state"] = want
        for k, v in links.items():
            st[k] = v
        tg = st.get("target")
        if isinstance(tg, dict) and intent in ("pick_option", "open_dropdown"):
            tg["intent"] = intent                               # ScrollFinder reads this to prefer type-ahead
        if intent == "click" and st.get("type") in CLICKS and prev and prev.get("intent") in ("open_dropdown", "scroll_to_find") \
                and not (st.get("target") or {}).get("name"):
            ambiguous.append(st)
    return ambiguous


def refine(steps: list[dict], llm, max_steps: int = 6) -> int:
    """Let the optional local model label what the rules could not. One short question per step, answer must be one of
    ``INTENTS``. Returns how many steps were relabelled. No model / no answer = no change."""
    if llm is None or not getattr(llm, "available", lambda: False)():
        return 0
    changed = 0
    for st in annotate(steps)[:max_steps]:
        i = steps.index(st)
        before = steps[i - 1] if i else {}
        prompt = ("A user recorded a test. Previous action: %s. This action: %s. Which one word best describes what the "
                  "user does in THIS action? Choose from: %s. Answer with the word only." % (
                      before.get("description") or before.get("type"), st.get("description") or st.get("type"),
                      ", ".join(INTENTS)))
        try:
            ans = (llm.generate(prompt) or "").strip().casefold().split()[0].strip(".,\"'")
        except Exception:
            continue
        if ans in INTENTS and ans != st.get("intent"):
            st["intent"], st["intent_source"] = ans, "ai"
            tg = st.get("target")
            if isinstance(tg, dict) and ans in ("pick_option", "open_dropdown"):
                tg["intent"] = ans
            changed += 1
    return changed
