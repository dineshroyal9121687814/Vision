"""
Recorder v2.

Design rules (each one is a bug found on a real Windows run):

 1. OS hooks only enqueue a tiny event and return immediately. The first
    version took a full-screen screenshot *inside* the hook; Windows silently
    removes low-level hooks that are too slow, which is why ESC stopped working
    and the recording was lost. All heavy work (screenshots, UI Automation,
    saving) happens in one worker thread.
 2. Steps are journaled to steps.jsonl as they are produced; stop() (or crash
    recovery) always yields a test.json.
 3. DPI awareness is switched on before any coordinate is read.
 4. Clicks inside VisionAuto's own windows (the recorder toolbar) are ignored.

Hotkeys while recording:   F9 = stop      F8 = add a validation point
    F8 with the mouse over an element validates that element; the GUI button
    validates the item you clicked last (e.g. the list item you just selected).

CLI:  python -m core.recorder.recorder --name my_test
"""
from __future__ import annotations

import argparse
import json
import logging
import queue
import shutil
import threading
import time
from pathlib import Path

from core import testfile
from core.ai.describe import describe_step
from core.recorder.builder import RawEvent, StepBuilder
from core.recorder import sanity
from core.recorder.launch_detect import compact_launches
from core.xpath.pathgen import element_path
from core.system import quiet, winenv
from core.system.imageio import imwrite
from core.vision import neighbors, pointer, visual_neighbors, zones

log = logging.getLogger("visionauto.recorder")

CROP_SIZES = (100, 300)

def _window_record(win: dict) -> dict:
    """What we remember about a window: identity + geometry, so playback can restore its size and position."""
    out = {"title": win.get("title", ""), "process": win.get("process", "")}
    r = win.get("rect")
    if isinstance(r, (list, tuple)) and len(r) == 4:
        out["rect"] = [int(v) for v in r]
    if win.get("state"):
        out["state"] = win["state"]
    if win.get("kind") and win["kind"] != "main":
        out["kind"] = win["kind"]            # dialog | menu | popup | tooltip
    if win.get("popup") or win.get("kind") in ("menu", "popup"):                      # a drop-down list / menu: playback must not demand it to be the active window
        out["popup"] = True
        if win.get("owner_title"):
            out["owner_title"] = win["owner_title"]
    return out


POINTER_TYPES = ("click", "double_click", "right_click", "middle_click", "drag_drop", "scroll", "validate")
CLICK_TYPES = ("click", "double_click", "right_click", "middle_click")


def key_name(key) -> tuple[str, bool]:
    """pynput key -> (normalised name, is_printable_character)."""
    from pynput import keyboard

    if isinstance(key, keyboard.KeyCode):
        ch = getattr(key, "char", None)
        vk = getattr(key, "vk", None)
        if ch and ch.isprintable():
            return ch, True
        if vk is not None:
            if 0x30 <= vk <= 0x39 or 0x41 <= vk <= 0x5A:   # ctrl+<letter> arrives without a char
                return chr(vk).lower(), False
            if 0x60 <= vk <= 0x69:                           # numpad digits
                return str(vk - 0x60), True
        return f"vk{vk}", False
    name = (getattr(key, "name", "") or "").lower()
    if name == "space":
        return " ", True
    if name in ("cmd", "cmd_l", "cmd_r"):
        return "win", False
    if name == "alt_gr":
        return "altgr", False
    for base in ("ctrl", "alt", "shift"):
        if name == base or name in (base + "_l", base + "_r"):
            return base, False
    return name, False


def default_check(target: dict) -> dict:
    text = target.get("value") or target.get("text") or target.get("name")
    if text:
        return {"type": "text_equals", "expected": str(text)}
    return {"type": "element_exists"}


class Recorder:
    STOP_KEY = "f9"
    VALIDATE_KEY = "f8"

    def __init__(self, name: str, on_step=None, on_stop_requested=None, ignore_pids=None, probe=None):
        self.title = name
        self.name = testfile.safe_name(name)
        self.dir = testfile.test_dir(name)
        self.on_step = on_step
        self.on_stop_requested = on_stop_requested
        self.ignore_pids = set(ignore_pids or ())
        self.probe = probe or winenv.SystemProbe()
        try:
            from core import settings
            self._record_neighbors = bool(settings.load().get("record_neighbors", True))
        except Exception:
            self._record_neighbors = True

        self.steps: list[dict] = []
        self.test: dict = {}
        self.path: Path | None = None

        self._q: queue.Queue = queue.Queue()
        self._builder = StepBuilder(self._finalize)
        self._t0 = time.monotonic()
        self._journal = None
        self._journal_lock = threading.Lock()
        self._worker: threading.Thread | None = None
        self._listeners: list = []
        self._mctl = None
        self._paused = False
        self._stopping = False
        self._stopped = False
        self._stop_event = threading.Event()
        self._skip_press = False
        self._down_pos = None
        self._hover = None                 # last context sampled while a drag was in progress (BEFORE the drop changes the UI)
        self._sampler_stop = threading.Event()
        self._last_scroll_t = -1e9
        self._last_target: dict | None = None
        self._last_xy: tuple[int, int] | None = None

    # ------------------------------------------------------------------ lifecycle
    def start(self, listeners: bool = True, overwrite: bool = False) -> None:
        winenv.enable_dpi_awareness()
        if self.dir.exists() and (self.dir / "test.json").exists():
            if not overwrite:
                raise FileExistsError(f"Test '{self.name}' already exists")
            shutil.rmtree(self.dir, ignore_errors=True)
        (self.dir / "assets").mkdir(parents=True, exist_ok=True)
        self.test = testfile.new_test(self.title, self._screen_info())
        self.test["name"] = self.name
        testfile.save_test(self.test, self.dir)
        self._journal = open(self.dir / "steps.jsonl", "w", encoding="utf-8")
        try:
            self._t0 = time.monotonic()
            self._worker = threading.Thread(target=self._run_worker, name="va-recorder-worker", daemon=True)
            self._worker.start()
            if listeners:
                self._start_listeners()
            log.info("recording '%s' started", self.name)
        except Exception:
            with self._journal_lock:
                if self._journal and not self._journal.closed:
                    self._journal.close()
            raise

    def stop(self, timeout: float = 30.0) -> Path:
        if self._stopped:
            return self.path
        if not self._stopping:
            self._stopping = True
            self._stop_event.set()
            self._sampler_stop.set()
            for lst in self._listeners:
                try:
                    lst.stop()
                except Exception:
                    log.exception("failed to stop recorder listener")
            self._q.put(None)
        if self._worker:
            self._worker.join(timeout)
            if self._worker.is_alive():
                raise TimeoutError(
                    f"Recorder worker did not stop within {timeout:g}s; "
                    "the journal remains open and can be saved by calling stop again."
                )
        compacted, changes = compact_launches(self.steps)
        if changes:                                   # "Start -> type -> click result" becomes one reliable open_app step
            self.steps[:] = compacted
            self.test["recording_notes"] = changes
            self._rewrite_journal()
        try:
            from core.recorder import intent
            fixed = sanity.repair_steps(self.steps)
            if fixed:
                self.test.setdefault("recording_notes", []).extend(fixed)
            merged = intent.compact_scrolls(self.steps)      # 3 wheel bursts in a row = 1 step; scroll down then back up = none
            if merged:
                from core import testfile as _tf
                self.test["steps"] = self.steps
                _tf.renumber(self.test)
                self.test.setdefault("recording_notes", []).extend(merged)
            intent.annotate(self.steps)               # what the user was doing: pick an option, scroll to find, drag across windows...
            from core import settings as _settings
            _o = _settings.load()
            if _o.get("use_llm"):                      # optional: the local model labels what the rules could not place
                from core.ai.llm import OllamaClient
                intent.refine(self.steps, OllamaClient(_o["llm_model"], base_url=_o["llm_base_url"], timeout=6.0))
        except Exception:
            log.debug("intent annotation failed", exc_info=True)
        self.test["steps"] = self.steps
        try:
            from core import dataset
            dataset.record_recording(self.test, changes, self.dir)
        except Exception:
            log.debug("dataset hook failed", exc_info=True)
        first = next((s for s in self.steps if s.get("window", {}).get("process")), None)
        if first:
            self.test["app"] = dict(first["window"])
        self.path = testfile.save_test(testfile.renumber(self.test), self.dir)
        try:
            if self._journal and not self._journal.closed:
                self._journal.close()
        except Exception:
            log.exception("failed to close recorder journal")
        self._stopped = True
        log.info("recording '%s' saved: %d steps", self.name, len(self.steps))
        return self.path

    def wait(self) -> None:
        while not self._stop_event.wait(0.25):  # polling keeps Ctrl+C responsive on Windows
            pass

    def request_stop(self) -> None:
        self._stop_event.set()
        if self.on_stop_requested:
            threading.Thread(target=self.on_stop_requested, daemon=True).start()

    def pause(self) -> None:
        self._paused = True
        self._q.put(RawEvent("flush", time.monotonic()))

    def resume(self) -> None:
        self._paused = False

    @property
    def paused(self) -> bool:
        return self._paused

    def inject(self, ev: RawEvent) -> None:
        """Feed a synthetic event (used by tests)."""
        self._q.put(ev)

    def add_validation(self, x: int | None = None, y: int | None = None) -> None:
        """Mark a validation point. Without coordinates: the last item the user clicked."""
        if x is None:  # resolved by the worker, after the last click has been processed (no race)
            self._q.put(RawEvent("marker", time.monotonic(), extra={"use_last": True}))
            return
        self._q.put(RawEvent("marker", time.monotonic(), int(x), int(y)))

    # ------------------------------------------------------------------ OS hooks (must stay tiny)
    def _start_listeners(self) -> None:
        from pynput import keyboard, mouse

        self._mctl = mouse.Controller()

        def guarded(fn):
            def wrapper(*a):
                try:
                    return fn(*a)
                except Exception:  # an exception would kill the pynput listener thread
                    log.exception("hook error")
            return wrapper

        @guarded
        def on_click(x, y, button, pressed, injected=False):
            name = getattr(button, "name", "left")
            if self._paused or self._stopping or name not in ("left", "right", "middle"):
                return
            self._q.put(RawEvent("mouse_down" if pressed else "mouse_up", time.monotonic(), int(x), int(y), button=name))

        @guarded
        def on_scroll(x, y, dx, dy, injected=False):
            if self._paused or self._stopping:
                return
            self._q.put(RawEvent("scroll", time.monotonic(), int(x), int(y), dx=int(dx), dy=int(dy)))

        @guarded
        def on_press(key, injected=False):
            name, is_char = key_name(key)
            if name == self.STOP_KEY:
                self.request_stop()
                return
            if name == self.VALIDATE_KEY:
                x, y = self._mctl.position
                self._q.put(RawEvent("marker", time.monotonic(), int(x), int(y)))
                return
            if self._paused or self._stopping:
                return
            self._q.put(RawEvent("key_down", time.monotonic(), key=name, is_char=is_char))

        @guarded
        def on_release(key, injected=False):
            name, _ = key_name(key)
            if name in (self.STOP_KEY, self.VALIDATE_KEY):
                return
            self._q.put(RawEvent("key_up", time.monotonic(), key=name))

        ml = mouse.Listener(on_click=on_click, on_scroll=on_scroll)
        kl = keyboard.Listener(on_press=on_press, on_release=on_release)
        ml.start()
        kl.start()
        self._listeners = [ml, kl]

    # ------------------------------------------------------------------ worker
    def _run_worker(self) -> None:
        winenv.init_com()
        while True:
            try:
                ev = self._q.get(timeout=0.1)
            except queue.Empty:
                self._builder.flush_due(time.monotonic())
                continue
            if ev is None:
                break
            try:
                self._process(ev)
            except Exception:
                log.exception("failed to process %s event", ev.kind)
        try:
            self._builder.flush_all()
        except Exception:
            log.exception("final flush failed")

    def _enrich(self, ev: RawEvent, win=None) -> None:
        frame, origin = self.probe.grab()          # screenshot first: the UI is still in its "before" state
        ev.extra.update(
            frame=frame, origin=origin,
            window=win or self.probe.window_at(ev.x, ev.y),
            element=self.probe.element_at(ev.x, ev.y),
        )
        try:
            tip = winenv.tooltip_text()
            if tip:
                ev.extra["tooltip"] = tip
        except Exception:
            log.debug("tooltip capture failed", exc_info=True)
        self._context(ev)

    def _context(self, ev: RawEvent) -> None:
        """What is around the pointer (neighbour anchors) and which scrollable container it is in - captured while
        the UI is still as the user saw it (a drop-down closes after the click)."""
        try:
            el = ev.extra.get("element") or {}
            win = ev.extra.get("window") or {}
            ev.extra["container"] = neighbors.container_of((ev.x, ev.y), el.get("ancestors"), win.get("rect"))
            pct = getattr(self.probe, "scroll_percent", None)
            if ev.extra["container"] and pct:
                try:
                    pos = pct(ev.x, ev.y)
                    if pos:
                        ev.extra["container"] = {**ev.extra["container"], "scroll_pct": pos}     # where the list was scrolled to
                except Exception:
                    log.debug("scroll position capture failed", exc_info=True)
            if self._record_neighbors:
                ev.extra["neighbors"] = neighbors.sample(self.probe.element_at, ev.x, ev.y, el)
        except Exception:
            log.debug("neighbour capture failed", exc_info=True)

    def _start_drag_sampler(self) -> None:
        """While the button is held and the pointer has left the press point, keep sampling what is under it (element,
        scroll container, neighbours). The drop changes the destination, so the last sample before it is the truth."""
        self._sampler_stop.set()
        self._sampler_stop = stop = threading.Event()
        origin = self._down_pos
        self._hover = None

        def loop():
            last = None
            while not stop.wait(0.12):
                try:
                    pos = pointer.position()
                    if not pos or not origin or abs(pos[0] - origin[0]) + abs(pos[1] - origin[1]) <= StepBuilder.DRAG_PX:
                        continue
                    if last == pos and self._hover and self._hover.get("x") == pos[0]:
                        continue                                   # same place, already sampled
                    last = pos
                    el = self.probe.element_at(pos[0], pos[1])
                    win = self.probe.window_at(pos[0], pos[1])
                    holder = RawEvent(kind="sample", x=pos[0], y=pos[1], t=time.monotonic())
                    holder.extra.update(element=el, window=win)
                    self._context(holder)
                    if not stop.is_set():
                        self._hover = {"x": pos[0], "y": pos[1], "t": holder.t, "element": el,
                                       "container": holder.extra.get("container"),
                                       "neighbors": holder.extra.get("neighbors")}
                except Exception:
                    log.debug("drag sampling failed", exc_info=True)

        threading.Thread(target=loop, name="drag-sampler", daemon=True).start()

    def _process(self, ev: RawEvent) -> None:
        k = ev.kind
        if k == "flush":
            self._builder.flush_all()
            return
        if k == "mouse_down":
            win = self.probe.window_at(ev.x, ev.y)
            if win.get("pid") in self.ignore_pids or quiet.is_noise(win) or win.get("kind") == "tooltip":
                self._skip_press = True
                return
            self._skip_press = False
            self._enrich(ev, win)
            self._down_pos = (ev.x, ev.y)
            self._start_drag_sampler()
        elif k == "mouse_up":
            if self._skip_press:
                self._skip_press = False
                return
            self._sampler_stop.set()
            if self._down_pos and abs(ev.x - self._down_pos[0]) + abs(ev.y - self._down_pos[1]) > StepBuilder.DRAG_PX:
                h = self._hover
                if h and abs(h["x"] - ev.x) + abs(h["y"] - ev.y) <= 12 and ev.t - h["t"] < 3.0:
                    ev.extra.update(element=h["element"], container=h["container"], neighbors=h["neighbors"],
                                    context_phase="before-drop")      # what the destination looked like BEFORE the drop
                else:
                    ev.extra["element"] = self.probe.element_at(ev.x, ev.y)
                    self._context(ev)
                    ev.extra["context_phase"] = "after-drop"
            self._down_pos = None
            self._hover = None
            self._last_xy = (ev.x, ev.y)
        elif k == "scroll":
            win = self.probe.window_at(ev.x, ev.y)
            if win.get("pid") in self.ignore_pids or quiet.is_noise(win):
                return
            if ev.t - self._last_scroll_t > StepBuilder.SCROLL_GAP_S:
                self._enrich(ev, win)
                try:                                  # WHAT is being scrolled and where it stands before the scroll
                    ev.extra.setdefault("element", self.probe.element_at(ev.x, ev.y))
                    ev.extra.setdefault("window", win)
                    saved = self._record_neighbors
                    self._record_neighbors = False
                    try:
                        self._context(ev)
                    finally:
                        self._record_neighbors = saved
                except Exception:
                    log.debug("scroll context capture failed", exc_info=True)
            self._last_scroll_t = ev.t
        elif k == "key_down":
            fg = self.probe.foreground()
            if fg.get("pid") in self.ignore_pids or quiet.is_noise(fg):
                return
            ev.extra["window"] = fg
            focused = getattr(self.probe, "focused_element", lambda: {})()
            ev.extra["sensitive"] = bool(focused.get("is_password"))
        elif k == "marker":
            if ev.extra.pop("use_last", False):
                if not self._last_xy:
                    return
                ev.x, ev.y = self._last_xy
            self._enrich(ev)
        self._builder.feed(ev)

    # ------------------------------------------------------------------ step construction
    def _finalize(self, raw: dict) -> None:
        try:
            step = self._build_step(raw)
        except Exception:
            log.exception("could not build step %s", raw.get("type"))
            return
        self.steps.append(step)
        with self._journal_lock:
            if self._journal and not self._journal.closed:
                try:
                    self._journal.write(json.dumps(step, ensure_ascii=False) + "\n")
                    self._journal.flush()
                except Exception:
                    log.exception("journal write failed")
        if self.on_step:
            try:
                self.on_step(step)
            except Exception:
                log.exception("on_step callback failed")

    def _build_step(self, raw: dict) -> dict:
        idx = len(self.steps) + 1
        t = raw["type"]
        win = raw.get("window") or (self.probe.foreground() if t in POINTER_TYPES else {})
        step = {
            "id": idx, "type": t, "t_ms": int((raw["t"] - self._t0) * 1000),
            "window": _window_record(win),
        }
        if t in CLICK_TYPES:
            step["params"] = {"button": raw.get("button", "left")}
            if raw.get("modifiers"):
                step["params"]["modifiers"] = list(raw["modifiers"])          # Ctrl+click, Shift+click ...
            step["target"] = self._target(raw, raw["x"], raw["y"], raw.get("element"), idx, "src", True)
            self._last_target = self._light(step["target"])
        elif t == "drag_drop":
            step["params"] = {"button": raw.get("button", "left")}
            if raw.get("modifiers"):
                step["params"]["modifiers"] = list(raw["modifiers"])          # Ctrl+drag = copy, Shift+drag ...
            step["target"] = self._target(raw, raw["x"], raw["y"], raw.get("element"), idx, "src", True)
            step["to"] = self._target(raw, raw["to_x"], raw["to_y"], raw.get("to_element"), idx, "dst", False)
            to_win = raw.get("to_window") or {}
            different = (to_win.get("title") != win.get("title") or to_win.get("process") != win.get("process")
                         or (to_win.get("hwnd") and win.get("hwnd") and to_win.get("hwnd") != win.get("hwnd")))
            if to_win.get("title") and different:
                step["to_window"] = _window_record(to_win)          # drag crosses windows: remember the destination window
            self._last_target = self._light(step["to"])
        elif t == "scroll":
            step["params"] = {"dx": raw["dx"], "dy": raw["dy"]}
            step["target"] = self._target(raw, raw["x"], raw["y"], raw.get("element"), idx, "src", False)
        elif t == "validate":
            step["target"] = self._target(raw, raw["x"], raw["y"], raw.get("element"), idx, "src", True)
            step["check"] = default_check(step["target"])
        elif t == "type":
            step["params"] = ({"text": "", "redacted": True} if raw.get("sensitive")
                               else {"text": raw["text"]})
            if self._last_target:
                step["target"] = dict(self._last_target)
        elif t == "key":
            step["params"] = {"key": raw["key"]}
        elif t == "hotkey":
            step["params"] = {"keys": raw["keys"]}
        step["description"] = describe_step(step)
        step["validations"] = []
        return step

    def _rewrite_journal(self) -> None:
        with self._journal_lock:
            try:
                if self._journal and not self._journal.closed:
                    self._journal.seek(0)
                    self._journal.truncate()
                    for st in self.steps:
                        self._journal.write(json.dumps(st, ensure_ascii=False) + "\n")
                    self._journal.flush()
            except Exception:
                log.exception("journal rewrite failed")

    def opts_get(self, key, default=None):
        try:
            from core import settings
            return settings.load().get(key, default)
        except Exception:
            return default

    @staticmethod
    def _ocr_label(frame, origin, x, y) -> str:
        """Text printed right at the click (<= 40 chars), for controls UI Automation gives no name. Best effort."""
        try:
            from core.automation import effect
            from core.ocr import ocr_engine
            img = effect.crop(frame, effect.region_around((x, y), frame.shape, (180, 44), origin))
            text = " ".join(ocr_engine.read_all_text(img).split()) if img is not None else ""
            return text[:40]
        except Exception:
            log.debug("record-time OCR label failed", exc_info=True)
            return ""

    @staticmethod
    def _light(target: dict) -> dict:
        return {k: v for k, v in target.items() if k not in ("templates", "full")}

    def _target(self, raw: dict, x: int, y: int, element, idx: int, tag: str, full: bool) -> dict:
        wrect = ((raw.get("to_window") if tag == "dst" and raw.get("to_window") else raw.get("window")) or {}).get("rect")
        el, why = sanity.clean_element(element, x, y, wrect)
        if why:
            log.warning("recording: dropped an untrusted element at (%s, %s): %s", x, y, why)
            raw = {**raw, "container": None, "neighbors": raw.get("neighbors")}
        t: dict = {"x": int(x), "y": int(y)}
        for k in ("name", "role", "automation_id", "class_name", "rect", "text", "value", "state", "help"):
            if el.get(k):
                t[k] = el[k]
        if raw.get("tooltip") and tag == "src":
            t["tooltip"] = raw["tooltip"]            # what the tooltip said while the pointer rested here
        nb = raw.get("to_neighbors") if tag == "dst" else raw.get("neighbors")
        ct = raw.get("to_container") if tag == "dst" else raw.get("container")
        if nb:
            t["neighbors"] = nb                      # what surrounds it: findable again even without a name or a picture
        if ct:
            t["container"] = ct                      # scrollable parent: where to scroll when it is off-screen
        try:                                         # Inspect-style location: Window > Pane > Tab > Button, plus a window-scoped XPath
            path = element_path(el)
            if path:
                t["path"], t["inspect_xpath"] = path["breadcrumb"], path["xpath"]
        except Exception:
            log.debug("element path failed", exc_info=True)
        r = el.get("rect")
        if r and r[2] > r[0] and r[3] > r[1] and r[0] <= x <= r[2] and r[1] <= y <= r[3]:
            t["rel"] = [round((x - r[0]) / (r[2] - r[0]), 4), round((y - r[1]) / (r[3] - r[1]), 4)]
        frame, origin = raw.get("frame"), raw.get("origin")
        zwin = (raw.get("to_window") if tag == "dst" and raw.get("to_window") else raw.get("window")) or {}
        try:
            zone = zones.detect_zone(frame, origin or (0, 0), zwin.get("rect"), (x, y), el.get("ancestors"))
        except Exception:
            log.debug("zone detection failed", exc_info=True)
            zone = None
        if zone:
            t["zone"] = zone
        if frame is not None and not (t.get("name") or t.get("text")) and self.opts_get("record_ocr_label", True):
            label = self._ocr_label(frame, origin or (0, 0), x, y)      # custom-drawn control: remember what it SAYS
            if label:
                t["ocr_label"] = label
        if frame is not None:
            tpl = {}
            for size in CROP_SIZES:
                crop, click = winenv.crop_around(frame, origin, x, y, size)
                rel = f"assets/s{idx:03d}_{tag}_c{size}.png"
                imwrite(self.dir / rel, crop)
                tpl[f"crop{size}"] = {"path": rel, "click": [int(click[0]), int(click[1])],
                                      "size": [int(crop.shape[1]), int(crop.shape[0])]}
            t["templates"] = tpl
            try:
                items = visual_neighbors.capture(frame, origin or (0, 0), int(x), int(y), zwin.get("rect"))
                if items:
                    t["visual_neighbors"] = []
                    for k, it in enumerate(items, 1):
                        rel = f"assets/s{idx:03d}_{tag}_n{k}.png"
                        imwrite(self.dir / rel, it["img"])
                        t["visual_neighbors"].append({"path": rel, "dx": it["dx"], "dy": it["dy"], "size": it["size"]})
                    rel = f"assets/s{idx:03d}_{tag}_context.jpg"
                    imwrite(self.dir / rel, visual_neighbors.overview(frame, origin or (0, 0), int(x), int(y), items), 80)
                    t["context_shot"] = rel                  # annotated picture: click + neighbours, for people to review
            except Exception:
                log.debug("visual neighbour capture failed", exc_info=True)
            if full:
                rel = f"assets/s{idx:03d}_full.jpg"
                imwrite(self.dir / rel, frame, 70)
                t["full"] = rel
        return t

    def _screen_info(self) -> dict:
        try:
            frame, origin = self.probe.grab()
            return {"width": int(frame.shape[1]), "height": int(frame.shape[0]),
                    "origin": [int(origin[0]), int(origin[1])], "dpi_scale": winenv.dpi_scale_percent()}
        except Exception:
            return {}


# ---------------------------------------------------------------------- CLI
def main() -> None:
    from core import paths

    parser = argparse.ArgumentParser(description="VisionAuto recorder")
    parser.add_argument("--name", required=True)
    parser.add_argument("--overwrite", action="store_true")
    args = parser.parse_args()
    paths.setup_logging()

    rec = Recorder(args.name, on_step=lambda s: print(f"  [{s['id']:>3}] {s['description']}"))
    rec.start(overwrite=args.overwrite)
    print(f"Recording '{rec.name}'.   F9 = stop    F8 = add validation point (hover over an element)\n")
    try:
        rec.wait()
    except KeyboardInterrupt:
        print("\nInterrupted, saving what was recorded...")
    finally:
        path = rec.stop()
    print(f"\nSaved {len(rec.steps)} steps -> {path}")


if __name__ == "__main__":
    main()
