"""Read a recording the way a person would describe it: what is the user actually DOING?

``analyze(steps)`` returns findings; ``apply_data_loop(test, finding)`` turns a repeated block into a data-driven loop.

Patterns recognised (all deterministic, nothing is guessed from pixels):
  form_fill      several fields typed one after another, then a button            -> "Fill form (3 fields) and press Save"
  grid_entry     values typed into cells separated by Tab / Enter                  -> can become ONE 'fill_table'-style row set
  repeated_block the same sequence of actions again and again with different typed
                 values                                                            -> "do this for each row of data" (loop + data)
  login          a password-like field typed near the start                        -> labelled "Login"
  dropdown_pick  open_dropdown + pick_option                                       -> "Choose 'X' from 'Y'"
  copy_paste     ctrl+c ... ctrl+v                                                 -> "Copy and paste"
  search_select  type into a field then click a result                             -> "Search for 'X' and open the result"
"""
from __future__ import annotations

import copy
import re

CLICKS = ("click", "double_click", "right_click")


def _name(step: dict) -> str:
    t = step.get("target") or {}
    return str(t.get("name") or t.get("automation_id") or t.get("text") or t.get("role") or "element")


def _signature(step: dict) -> tuple:
    """What a step IS, without the typed values: type + element + key."""
    p = step.get("params") or {}
    key = p.get("key") or p.get("keys") or ""
    return (step.get("type"), _name(step) if step.get("type") in CLICKS + ("type",) else "", str(key))


def _typed(step: dict) -> str:
    return str((step.get("params") or {}).get("text", ""))


def analyze(steps: list[dict]) -> list[dict]:
    findings: list[dict] = []
    n = len(steps)
    # ---- repeated blocks: smallest period p (2..20) whose signature sequence repeats >= 2 times back to back
    i = 0
    while i < n:
        best = None
        for p in range(2, min(20, (n - i) // 2) + 1):
            sig = [_signature(s) for s in steps[i:i + p]]
            if not any(s[0] == "type" for s in sig):
                continue
            reps = 1
            while i + (reps + 1) * p <= n and [_signature(s) for s in steps[i + reps * p:i + (reps + 1) * p]] == sig:
                reps += 1
            if reps >= 2 and (best is None or reps * p > best[0] * best[1]):
                best = (reps, p)
        if best:
            reps, p = best
            fields = [k for k, s in enumerate(steps[i:i + p]) if s.get("type") == "type"]
            findings.append({
                "kind": "repeated_block", "start": i, "length": p, "repeats": reps, "fields": fields,
                "title": f"The same {p} actions repeat {reps} times with different values",
                "advice": "Make it data-driven: one block + a data table with one row per repetition.",
                "values": [[_typed(steps[i + r * p + f]) for f in fields] for r in range(reps)],
            })
            i += reps * p
        else:
            i += 1
    covered = {k for f in findings for k in range(f["start"], f["start"] + f["length"] * f["repeats"])}
    # ---- form fill / login / search
    j = 0
    while j < n:
        if steps[j].get("type") == "type" and j not in covered:
            k = j
            while k + 1 < n and steps[k + 1].get("type") in ("type", "key") and (k + 1) not in covered:
                k += 1
            fields = [s for s in steps[j:k + 1] if s.get("type") == "type"]
            after = steps[k + 1] if k + 1 < n and (k + 1) not in covered else None
            names = [_name(s) for s in fields]
            if any(re.search(r"pass(word)?|pwd", x, re.I) for x in names) or any((s.get("params") or {}).get("redacted") for s in fields):
                findings.append({"kind": "login", "start": j, "length": k - j + 1 + (1 if after and after.get("type") in CLICKS else 0),
                                 "title": "Login", "advice": "Make this a reusable module ('login') and call it from every test."})
            elif len(fields) >= 2:
                findings.append({"kind": "form_fill", "start": j, "length": k - j + 1,
                                 "title": f"Fill form ({len(fields)} fields: {', '.join(names[:4])})"
                                          + (f" and press '{_name(after)}'" if after and after.get("type") in CLICKS else ""),
                                 "advice": "Put the values in a data table so the same form can be filled with many rows."})
            elif len(fields) == 1 and after and after.get("type") in CLICKS and (after.get("window") or {}).get("popup") is None \
                    and after.get("intent") == "pick_option":
                findings.append({"kind": "search_select", "start": j, "length": 2,
                                 "title": f"Search for '{_typed(fields[0])}' and open '{_name(after)}'", "advice": ""})
            j = k + 1
        else:
            j += 1
    for idx in range(n - 1):
        a, b = steps[idx], steps[idx + 1]
        if a.get("intent") == "open_dropdown" and b.get("intent") == "pick_option":
            findings.append({"kind": "dropdown_pick", "start": idx, "length": 2, "title": f"Choose '{_name(b)}' from '{_name(a)}'", "advice": ""})
    keys = [(i2, str((s.get("params") or {}).get("keys") or (s.get("params") or {}).get("key") or "").lower()) for i2, s in enumerate(steps)
            if s.get("type") in ("hotkey", "key")]
    for (i1, k1), (i2, k2) in zip(keys, keys[1:]):
        if k1 in ("ctrl+c", "ctrl+x") and k2 == "ctrl+v":
            findings.append({"kind": "copy_paste", "start": i1, "length": i2 - i1 + 1, "title": "Copy and paste", "advice": ""})
    findings.sort(key=lambda f: f["start"])
    return findings


def describe(steps: list[dict]) -> list[str]:
    """One plain-language line per finding: what the user did."""
    return [f"steps {f['start'] + 1}-{f['start'] + f['length'] * f.get('repeats', 1)}: {f['title']}" for f in analyze(steps)]


def apply_data_loop(test: dict, finding: dict) -> dict:
    """Replace a ``repeated_block`` by ONE block inside a loop. The recorded values become visible ``set_variable`` steps
    (``field_1_list`` = ["Ann","Bob",...]) in front of the loop; inside, ``field_1 = item(field_1_list, ${_loop})`` feeds
    the typing. The test still does exactly what was recorded, and the tester can add values by editing the lists."""
    import json
    if finding.get("kind") != "repeated_block":
        raise ValueError("only a repeated block can become a data loop")
    steps = copy.deepcopy(test.get("steps") or [])
    s0, p, reps = finding["start"], finding["length"], finding["repeats"]
    block = copy.deepcopy(steps[s0:s0 + p])
    cols = [f"field_{k + 1}" for k in range(len(finding["fields"]))]
    lists, pulls = [], []
    for k, (col, f) in enumerate(zip(cols, finding["fields"])):
        block[f].setdefault("params", {})["text"] = "${" + col + "}"
        lists.append({"type": "set_variable", "params": {"name": f"{col}_list",
                      "value": json.dumps([row[k] for row in finding["values"]], ensure_ascii=False)},
                      "description": f"Data for {_name(block[f])} ({reps} values)"})
        pulls.append({"type": "set_variable", "params": {"name": col, "value": "=item(${" + col + "_list}, ${_loop})"},
                      "description": f"Take {_name(block[f])} for this round"})
    loop = lists + [{"type": "loop_start", "params": {"times": reps}, "description": f"Repeat {reps} times (once per value)"}] \
        + pulls + block + [{"type": "loop_end", "description": "next round"}]
    steps[s0:s0 + p * reps] = loop
    for i, st in enumerate(steps, 1):
        st["id"] = i
    return {**test, "steps": steps}
