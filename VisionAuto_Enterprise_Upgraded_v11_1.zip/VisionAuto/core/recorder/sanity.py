"""
Guard against a recording that names the WRONG element (and so replays as a different, sometimes destructive, click).

Typical case: the user clicks a spreadsheet cell right after a font drop-down closed. Accessibility returns whatever was
under the pointer a moment earlier - the title bar's "Close" button - and the step is recorded as "click Close". Replay
then closes Excel.

Two rules, applied while recording AND when an older recording is loaded:
  1. The element's own rectangle must contain the click point. If not, the identity (name, id, role, rect) is dropped
     and the step keeps its coordinates / picture / neighbours.
  2. A window-chrome button (Close, Minimize, Maximize, Restore) is only believed when the click really was in the title
     bar strip, in the right-hand corner of its window.
"""
from __future__ import annotations

CHROME_NAMES = {"close", "minimize", "maximize", "restore", "close window", "minimise", "restore down"}
CHROME_IDS = {"close", "minimize", "maximize", "restore"}
IDENTITY_KEYS = ("name", "role", "automation_id", "class_name", "rect", "text", "value", "state", "path",
                 "inspect_xpath", "rel")
BAND_H, BAND_W = 52, 220                      # title-bar strip height and right-hand corner width, in pixels


def _valid(r) -> bool:
    return isinstance(r, (list, tuple)) and len(r) == 4 and r[2] > r[0] and r[3] > r[1]


def contains(rect, x, y, tol: int = 4) -> bool:
    return _valid(rect) and rect[0] - tol <= x <= rect[2] + tol and rect[1] - tol <= y <= rect[3] + tol


def is_chrome(el: dict) -> bool:
    name = str(el.get("name") or "").strip().casefold()
    aid = str(el.get("automation_id") or "").strip().casefold()
    return name in CHROME_NAMES or aid in CHROME_IDS


def in_caption_corner(x, y, window_rect) -> bool:
    if not _valid(window_rect):
        return True                                   # nothing to check against: do not guess
    return y - window_rect[1] <= BAND_H and window_rect[2] - x <= BAND_W


def problem(el: dict, x, y, window_rect=None) -> str:
    """'' = fine, otherwise why this element identity cannot be trusted."""
    if not el:
        return ""
    if _valid(el.get("rect")) and not contains(el["rect"], x, y):
        return "the element's area does not contain the click"
    if is_chrome(el) and not in_caption_corner(x, y, window_rect):
        return "a window button (Close/Minimize/Maximize) was named but the click was not on the title bar"
    return ""


def clean_element(el: dict | None, x, y, window_rect=None) -> tuple[dict, str]:
    """(element, reason). Untrusted element -> ({}, reason)."""
    why = problem(el or {}, x, y, window_rect)
    return ({}, why) if why else (el or {}, "")


def repair_steps(steps: list[dict]) -> list[str]:
    """Fix an existing recording in place: strip untrusted identities from click / drag targets. One note per repair."""
    notes = []
    for st in steps:
        if not isinstance(st, dict):
            continue
        for key, wkey in (("target", "window"), ("to", "to_window")):
            tg = st.get(key)
            if not isinstance(tg, dict) or tg.get("x") is None:
                continue
            win = st.get(wkey) or st.get("window") or {}
            why = problem(tg, tg["x"], tg["y"], win.get("rect"))
            if not why:
                continue
            was = tg.get("name") or tg.get("automation_id") or tg.get("role")
            for k in IDENTITY_KEYS:
                tg.pop(k, None)
            tg.pop("container", None)
            tg["identity_dropped"] = why
            st["description"] = f"Click at ({tg['x']}, {tg['y']})"
            notes.append(f"Step {st.get('id')}: '{was}' was wrongly recorded ({why}); it now clicks by position/picture.")
    return notes
