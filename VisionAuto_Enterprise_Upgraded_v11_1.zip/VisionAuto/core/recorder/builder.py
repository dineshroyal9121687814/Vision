"""
StepBuilder: turns the raw mouse/keyboard event stream into meaningful steps.

Pure logic (no OS access) so it is unit-testable. What it understands:

  press+release near each other            -> click / right_click / middle_click
  two clicks within 0.45s on the same spot -> double_click (one step, not two)
  press, move > 10px, release              -> drag_drop (from, to)
  wheel notches close in time              -> one scroll step (summed)
  printable keys                           -> one `type` step per burst
                                              (backspace edits the pending text)
  ctrl/alt/win + key                       -> hotkey ("ctrl+c")
  enter, tab, esc, arrows, F-keys ...      -> key
  marker event (validation hotkey)         -> validate

Steps are emitted strictly in the order the user did them.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Callable

MODIFIERS = ("ctrl", "alt", "shift", "win")
CHORD_MODIFIERS = ("ctrl", "alt", "win")  # shift alone just makes capital letters
IGNORED_KEYS = ("altgr",)


@dataclass
class RawEvent:
    kind: str                 # mouse_down | mouse_up | scroll | key_down | key_up | marker
    t: float                  # time.monotonic()
    x: int = 0
    y: int = 0
    button: str = "left"
    dx: int = 0
    dy: int = 0
    key: str = ""
    is_char: bool = False
    extra: dict = field(default_factory=dict)  # frame / origin / window / element (added by the recorder worker)


def _xy(o) -> tuple[int, int]:
    return (o["x"], o["y"]) if isinstance(o, dict) else (o.x, o.y)


def _dist(a, b) -> float:
    (ax, ay), (bx, by) = _xy(a), _xy(b)
    return math.hypot(ax - bx, ay - by)


def _ctx(ev: RawEvent) -> dict:
    e = ev.extra
    return {k: e.get(k) for k in ("frame", "origin", "window", "element", "neighbors", "container", "tooltip")}


class StepBuilder:
    DRAG_PX = 10
    DOUBLE_PX = 6
    DOUBLE_S = 0.45
    TYPE_GAP_S = 2.5
    SCROLL_GAP_S = 0.6

    def __init__(self, emit: Callable[[dict], None]):
        self.emit = emit
        self._down: RawEvent | None = None
        self._pending: dict | None = None   # click waiting to see if it becomes a double click
        self._dbl = False
        self._type: dict | None = None
        self._scroll: dict | None = None
        self._mods: list[str] = []

    # ------------------------------------------------------------ public
    def feed(self, ev: RawEvent) -> None:
        self.flush_due(ev.t)
        handler = getattr(self, "_on_" + ev.kind, None)
        if handler:
            handler(ev)

    def flush_due(self, now: float) -> None:
        p = self._pending
        if p and self._down is None and now - p["t_up"] > self.DOUBLE_S:
            self._flush_pending()
        if self._type and now - self._type["t_last"] > self.TYPE_GAP_S:
            self._flush_typing()
        if self._scroll and now - self._scroll["t_last"] > self.SCROLL_GAP_S:
            self._flush_scroll()

    def flush_all(self) -> None:
        self._flush_pending()
        self._flush_typing()
        self._flush_scroll()

    # ------------------------------------------------------------ flushing
    def _flush_pending(self) -> None:
        if self._pending:
            step, self._pending, self._dbl = self._pending, None, False
            self.emit(step)

    def _flush_typing(self) -> None:
        if self._type:
            step, self._type = self._type, None
            if step["text"] or step.get("sensitive"):
                self.emit(step)

    def _flush_scroll(self) -> None:
        if self._scroll:
            step, self._scroll = self._scroll, None
            self.emit(step)

    # ------------------------------------------------------------ mouse
    def _on_mouse_down(self, ev: RawEvent) -> None:
        self._flush_typing()
        self._flush_scroll()
        p = self._pending
        if p and p["button"] == ev.button and _dist(p, ev) <= self.DOUBLE_PX and ev.t - p["t_up"] <= self.DOUBLE_S:
            self._dbl = True
        else:
            self._flush_pending()
        self._down = ev
        self._down_mods = [m for m in MODIFIERS if m in self._mods]          # keys held while pressing: Ctrl+click, Ctrl+drag

    def _on_mouse_up(self, ev: RawEvent) -> None:
        d, self._down = self._down, None
        if d is None:
            return
        if _dist(d, ev) > self.DRAG_PX:
            self._flush_pending()
            self.emit({
                "type": "drag_drop", "t": d.t, "button": d.button, "x": d.x, "y": d.y,
                "to_x": ev.x, "to_y": ev.y, "to_element": ev.extra.get("element"),
                "to_window": ev.extra.get("window"),
                "to_neighbors": ev.extra.get("neighbors"), "to_container": ev.extra.get("container"),
                "modifiers": list(getattr(self, "_down_mods", [])), **_ctx(d),
            })
            return
        kind = {"left": "click", "right": "right_click", "middle": "middle_click"}.get(d.button, "click")
        if self._dbl and self._pending and kind == "click":
            step, self._pending, self._dbl = self._pending, None, False
            step["type"] = "double_click"
            self.emit(step)
            return
        self._flush_pending()
        self._pending = {"type": kind, "t": d.t, "t_up": ev.t, "button": d.button, "x": d.x, "y": d.y,
                         "modifiers": list(getattr(self, "_down_mods", [])), **_ctx(d)}

    def _on_scroll(self, ev: RawEvent) -> None:
        self._flush_typing()
        self._flush_pending()
        s = self._scroll
        if s and ev.t - s["t_last"] <= self.SCROLL_GAP_S:
            s["dx"] += ev.dx
            s["dy"] += ev.dy
            s["t_last"] = ev.t
            return
        self._flush_scroll()
        self._scroll = {"type": "scroll", "t": ev.t, "t_last": ev.t, "x": ev.x, "y": ev.y,
                        "dx": ev.dx, "dy": ev.dy, **_ctx(ev)}

    # ------------------------------------------------------------ keyboard
    def _on_key_down(self, ev: RawEvent) -> None:
        k = ev.key
        if k in IGNORED_KEYS:
            return
        if k in MODIFIERS:
            if k not in self._mods:
                self._mods.append(k)
            return
        self._flush_pending()
        self._flush_scroll()
        window = ev.extra.get("window")
        held = [m for m in MODIFIERS if m in self._mods]
        if any(m in CHORD_MODIFIERS for m in held):
            self._flush_typing()
            keys = "+".join(held + ["space" if k == " " else k])
            self.emit({"type": "hotkey", "t": ev.t, "keys": keys, "window": window})
            return
        if ev.is_char:
            sensitive = bool(ev.extra.get("sensitive"))
            if self._type and (ev.t - self._type["t_last"] > self.TYPE_GAP_S
                               or bool(self._type.get("sensitive")) != sensitive):
                self._flush_typing()
            if not self._type:
                self._type = {"type": "type", "t": ev.t, "t_last": ev.t, "text": "", "window": window}
                if sensitive:
                    self._type["sensitive"] = True
            if not sensitive:
                self._type["text"] += k
            self._type["t_last"] = ev.t
        elif k == "backspace" and self._type and self._type.get("sensitive"):
            self._type["t_last"] = ev.t
        elif k == "backspace" and self._type and self._type["text"]:
            self._type["text"] = self._type["text"][:-1]
            self._type["t_last"] = ev.t
        else:
            self._flush_typing()
            self.emit({"type": "key", "t": ev.t, "key": k, "window": window})

    def _on_key_up(self, ev: RawEvent) -> None:
        if ev.key in self._mods:
            self._mods.remove(ev.key)

    # ------------------------------------------------------------ validation marker
    def _on_marker(self, ev: RawEvent) -> None:
        self.flush_all()
        self.emit({"type": "validate", "t": ev.t, "x": ev.x, "y": ev.y, **_ctx(ev)})
