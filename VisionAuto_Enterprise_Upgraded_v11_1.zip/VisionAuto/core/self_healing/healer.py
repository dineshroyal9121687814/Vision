"""
Self-healing search: the element is not where it was recorded and the normal
tiers failed, so search expanding rings around its last known position.
The caller (Player) writes the new location back into the test.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from core.vision.locator import Locator


@dataclass
class HealResult:
    healed: bool
    x: int = 0          # centre of the template match, in `screen` coordinates
    y: int = 0
    confidence: float = 0.0
    radius_used: int = 0
    scale: float = 1.0


class SelfHealer:
    def __init__(self, locator: Locator | None = None):
        self.locator = locator or Locator()

    def heal(self, screen: np.ndarray, template: np.ndarray, last_x: int, last_y: int,
             rings=(150, 300, 500, 800), threshold: float = 0.72) -> HealResult:
        h, w = screen.shape[:2]
        for radius in rings:
            x0, x1 = max(0, last_x - radius), min(w, last_x + radius)
            y0, y1 = max(0, last_y - radius), min(h, last_y + radius)
            region = screen[y0:y1, x0:x1]
            if region.shape[0] < template.shape[0] or region.shape[1] < template.shape[1]:
                continue
            r = self.locator.find_by_template(region, template, scales=(1.0, 0.9, 1.1), threshold=threshold)
            if r.found:
                return HealResult(True, x0 + r.x, y0 + r.y, r.confidence, radius, r.scale)
        return HealResult(False)
