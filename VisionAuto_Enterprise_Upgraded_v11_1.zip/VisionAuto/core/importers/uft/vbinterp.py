"""Tree-walking interpreter for the ``visionauto.script/1`` AST.

Why an interpreter and not ``exec`` of generated code: imported scripts come from other people.
Interpreting the AST means no ``eval``/``exec``/``import`` is ever reachable, every loop and every
statement is counted against a budget, recursion is bounded, and UI actions can only happen through
the ``Host`` object.  VBScript semantics that matter for UFT tests are kept: case-insensitive names,
Variant coercion, ``&`` concatenation, ``On Error Resume Next`` + ``Err``, hoisted Sub/Function,
ByRef parameters, ``Exit For/Do/Sub/Function``, ``Select Case`` with ``Is``/``To`` tests.
"""
from __future__ import annotations

import copy
import time

from core.importers.uft import vbruntime as rt
from core.importers.uft.vbruntime import (EMPTY, NOTHING, NULL, VbError, to_bool, to_int, to_num, to_str)


class StopRun(Exception):
    """User abort or ExitTest/ExitRun."""

    def __init__(self, reason: str = "stopped", status: str = "aborted"):
        super().__init__(reason)
        self.reason, self.status = reason, status


class _Exit(Exception):
    def __init__(self, what: str):
        self.what = what


class BudgetExceeded(VbError):
    def __init__(self, what: str):
        super().__init__(28, f"{what} budget exceeded - the script may be in an endless loop")


class TestObjectRef:
    """A UFT test object path such as Window("Calc").WinButton("1")."""

    __test__ = False
    __slots__ = ("chain",)

    def __init__(self, chain: tuple):
        self.chain = chain

    @property
    def leaf_class(self) -> str:
        return self.chain[-1][0] if self.chain else ""

    def child(self, cls: str, spec) -> "TestObjectRef":
        return TestObjectRef(self.chain + ((cls, spec),))

    def __repr__(self):
        return ".".join(f'{c}("{s}")' for c, s in self.chain)


def _spec(args: list):
    """A test-object argument list -> one spec string: ("text:=OK", "class:=Button") -> "text:=OK|class:=Button"."""
    parts = [a for a in args if a is not None]
    if not parts:
        return None
    if len(parts) == 1:
        return parts[0]
    return "|".join(to_str(a) for a in parts)


class Host:
    """What the interpreter needs from the outside world. Subclassed by ``UftContext``; tests use fakes."""

    def invoke(self, ref: TestObjectRef, method: str, args: list):          # test-object method / property
        raise VbError(rt.NO_MEMBER, f"Object doesn't support this property or method: '{method}'")

    def procedure(self, name: str, args: list):                              # Wait, Print, MsgBox, SystemUtil.Run ...
        raise VbError(rt.NO_MEMBER, f"Unknown procedure: '{name}'")

    def builtin_object(self, name: str):                                    # Reporter, DataTable, Environment ...
        return None

    def is_test_class(self, name: str) -> bool:
        return False

    def should_stop(self) -> bool:
        return False

    def load_library(self, path: str) -> str | None:                         # ExecuteFile - returns source text
        return None

    def load_action(self, name: str) -> dict | None:                         # RunAction - returns parsed AST
        return None

    def unhandled(self, err: VbError) -> None:
        pass


class Frame:
    __slots__ = ("vars", "consts", "resume_next", "func_name", "with_stack", "is_global", "ret")

    def __init__(self, is_global=False, func_name=""):
        self.vars: dict = {}
        self.consts: set = set()
        self.resume_next = False
        self.func_name = func_name.casefold()
        self.with_stack: list = []
        self.is_global = is_global
        self.ret = EMPTY


class Interpreter:
    def __init__(self, host: Host | None = None, max_statements: int = 2_000_000, max_seconds: float | None = 3600,
                 max_depth: int = 120, max_array: int = 1_000_000):
        self.host = host or Host()
        self.max_statements, self.max_depth, self.max_array = max_statements, max_depth, max_array
        self.deadline = time.monotonic() + max_seconds if max_seconds else None
        self.statements = 0
        self.depth = 0
        self.procs: dict = {}
        self.globals = Frame(is_global=True)
        self.err = rt.ErrObject()
        self.output: list[str] = []
        self._loaded_libs: set = set()

    # =============================================================== public
    def run_program(self, program: dict) -> None:
        self.define_procedures(program)
        try:
            self.exec_block(program["body"], self.globals)
        except _Exit:
            pass

    def define_procedures(self, program: dict) -> None:
        for proc in program.get("procedures", []):
            self.procs[proc["name"].casefold()] = proc

    # =============================================================== budget
    def tick(self, frame: Frame | None = None) -> None:
        self.statements += 1
        if self.statements > self.max_statements:
            raise BudgetExceeded("statement")
        if self.deadline and (self.statements & 0xFF) == 0 and time.monotonic() > self.deadline:
            raise BudgetExceeded("time")
        if (self.statements & 0x3F) == 0 and self.host.should_stop():
            raise StopRun("aborted by user")

    # =============================================================== statements
    def exec_block(self, body: list, frame: Frame) -> None:
        for stmt in body:
            self.exec_stmt(stmt, frame)

    def exec_stmt(self, stmt: dict, frame: Frame) -> None:
        self.tick(frame)
        try:
            getattr(self, "x_" + stmt["k"])(stmt, frame)
        except (_Exit, StopRun):
            raise
        except VbError as e:
            if isinstance(e, BudgetExceeded):
                raise
            self.err.set(e)
            if frame.resume_next:
                return
            raise
        except RecursionError:
            raise VbError(28, "Out of stack space") from None

    def x_unsupported(self, s, f):
        raise VbError(rt.NO_MEMBER, f"Unsupported statement at line {s.get('line')}: {s.get('text')} - {s.get('reason')}")

    def x_dim(self, s, f):
        for item in s["names"]:
            name = item["name"].casefold()
            if item["dims"] is None:
                f.vars.setdefault(name, EMPTY) if name not in f.vars else None
            else:
                f.vars[name] = self.make_array([to_int(self.ev(d, f)) for d in item["dims"]])

    def make_array(self, bounds: list) -> list:
        total = 1
        for b in bounds:
            if b < -1:
                raise VbError(rt.SUBSCRIPT, "Subscript out of range")
            total *= max(b + 1, 0)
        if total > self.max_array:
            raise VbError(7, "Out of memory")
        if not bounds:
            return []
        if len(bounds) == 1:
            return [EMPTY] * (bounds[0] + 1)
        return [self.make_array(bounds[1:]) for _ in range(bounds[0] + 1)]

    def x_redim(self, s, f):
        name = s["name"].casefold()
        new = self.make_array([to_int(self.ev(d, f)) for d in s["dims"]])
        old = self.lookup_var(name, f)
        if s["preserve"] and isinstance(old, list) and len(s["dims"]) == 1:
            for i, v in enumerate(old[:len(new)]):
                new[i] = v
        self.store_var(name, new, f)

    def x_const(self, s, f):
        name = s["name"].casefold()
        f.vars[name] = self.ev(s["value"], f)
        f.consts.add(name)

    def x_assign(self, s, f):
        value = self.ev(s["value"], f)
        if isinstance(value, list) and not s.get("set"):
            value = copy.deepcopy(value)
        self.assign(s["target"], value, f)

    def x_call(self, s, f):
        expr, args = s["expr"], s["args"]
        if args is None:
            self.ev_call_statement(expr, [], f)
        else:
            self.ev_call_statement(expr, [None if a is None else self.ev(a, f) for a in args], f, args)

    def x_if(self, s, f):
        for br in s["branches"]:
            if to_bool(self.ev(br["cond"], f)):
                self.exec_block(br["body"], f)
                return
        if s.get("else"):
            self.exec_block(s["else"], f)

    def x_for(self, s, f):
        start, end = to_num(self.ev(s["start"], f)), to_num(self.ev(s["end"], f))
        step = to_num(self.ev(s["step"], f)) if s["step"] else 1
        if step == 0:
            raise VbError(rt.INVALID_CALL, "For loop step cannot be zero")
        i = start
        while (i <= end) if step > 0 else (i >= end):
            self.assign(s["var"], i, f)
            try:
                self.exec_block(s["body"], f)
            except _Exit as e:
                if e.what == "for":
                    return
                raise
            self.tick(f)
            cur = to_num(self.ev(s["var"], f))
            i = cur + step

    def x_foreach(self, s, f):
        coll = self.ev(s["coll"], f)
        if isinstance(coll, list):
            items = list(self._flatten(coll))
        elif hasattr(coll, "vb_iter"):
            items = list(coll.vb_iter())
        else:
            raise VbError(rt.TYPE_MISMATCH, "Object not a collection")
        for item in items:
            self.store_var(s["var"].casefold(), item, f)
            try:
                self.exec_block(s["body"], f)
            except _Exit as e:
                if e.what == "for":
                    return
                raise
            self.tick(f)

    def _flatten(self, seq):
        for x in seq:
            if isinstance(x, list):
                yield from self._flatten(x)
            else:
                yield x

    def x_do(self, s, f):
        kind, cond, pos = s["kind"], s["cond"], s["pos"]

        def keep_going() -> bool:
            if cond is None:
                return True
            v = to_bool(self.ev(cond, f))
            return v if kind == "while" else not v

        while True:
            if pos == "pre" and not keep_going():
                return
            try:
                self.exec_block(s["body"], f)
            except _Exit as e:
                if e.what == "do":
                    return
                raise
            self.tick(f)
            if pos == "post" and not keep_going():
                return

    def x_select(self, s, f):
        subject = self.ev(s["subject"], f)
        for case in s["cases"]:
            for test in case["tests"]:
                if "range" in test:
                    lo, hi = (self.ev(x, f) for x in test["range"])
                    ok = to_bool(rt.vb_compare(">=", subject, lo)) and to_bool(rt.vb_compare("<=", subject, hi))
                else:
                    ok = rt.vb_compare(test["op"], subject, self.ev(test["value"], f))
                    ok = ok is True
                if ok:
                    self.exec_block(case["body"], f)
                    return
        if s.get("else"):
            self.exec_block(s["else"], f)

    def x_with(self, s, f):
        obj = self.ev(s["obj"], f)
        f.with_stack.append(obj)
        try:
            self.exec_block(s["body"], f)
        finally:
            f.with_stack.pop()

    def x_exit(self, s, f):
        what = s["what"]
        if what in ("sub", "function", "property"):
            raise _Exit("proc")
        raise _Exit(what)

    def x_onerror(self, s, f):
        f.resume_next = s["mode"] == "resume_next"
        if s["mode"] == "goto0":
            self.err.clear()

    def x_sub(self, s, f):          # nested definitions are hoisted by run_program; ignore at runtime
        self.procs.setdefault(s["name"].casefold(), s)

    x_function = x_sub

    # =============================================================== variables
    def lookup_var(self, name: str, f: Frame):
        if name in f.vars:
            return f.vars[name]
        if name in self.globals.vars:
            return self.globals.vars[name]
        raise KeyError(name)

    def store_var(self, name: str, value, f: Frame) -> None:
        if name in f.consts or name in self.globals.consts and name not in f.vars:
            raise VbError(rt.INVALID_CALL, f"Illegal assignment: '{name}' is a constant")
        if name in f.vars or f.is_global:
            f.vars[name] = value
        elif name in self.globals.vars:
            self.globals.vars[name] = value
        else:
            f.vars[name] = value

    def assign(self, target: dict, value, f: Frame) -> None:
        k = target["k"]
        if k == "id":
            name = target["name"].casefold()
            if name == f.func_name and not f.is_global:
                f.ret = value
                return
            self.store_var(name, value, f)
            return
        if k == "index":
            base = target["target"]
            container = self.ev(base, f) if base["k"] != "id" else self._var_or_error(base, f)
            idx = [self.ev(a, f) for a in target["args"]]
            if hasattr(container, "vb_set"):
                container.vb_set("Item", value, idx)
                return
            if isinstance(container, list):
                cur = container
                for i in idx[:-1]:
                    cur = cur[self._index(cur, i)]
                cur[self._index(cur, idx[-1])] = value
                return
            if base["k"] == "id" and self.host.builtin_object(base["name"].casefold()) is not None:
                self.host.builtin_object(base["name"].casefold()).vb_set("Value", value, idx)
                return
            raise VbError(rt.TYPE_MISMATCH, "Type mismatch")
        if k == "member":
            obj = self.ev(target["obj"], f) if target["obj"]["k"] != "withobj" else self._with(f)
            args = [self.ev(a, f) for a in (target["args"] or [])]
            if hasattr(obj, "vb_set"):
                obj.vb_set(target["name"], value, args)
                return
            if isinstance(obj, TestObjectRef):
                self.host.invoke(obj, "set_" + target["name"], [value] + args)
                return
            raise VbError(rt.NO_MEMBER, f"Object doesn't support this property or method: '{target['name']}'")
        raise VbError(rt.INVALID_CALL, "Invalid assignment target")

    def _var_or_error(self, node, f):
        name = node["name"].casefold()
        try:
            return self.lookup_var(name, f)
        except KeyError:
            obj = self.host.builtin_object(name)
            if obj is not None:
                return obj
            raise VbError(500, f"Variable is undefined: '{node['name']}'") from None

    @staticmethod
    def _index(arr: list, i) -> int:
        n = to_int(i)
        if n < 0 or n >= len(arr):
            raise VbError(rt.SUBSCRIPT, "Subscript out of range")
        return n

    def _with(self, f: Frame):
        if not f.with_stack:
            raise VbError(rt.INVALID_CALL, "Invalid use of '.' outside a With block")
        return f.with_stack[-1]

    # =============================================================== expressions
    def ev(self, n: dict, f: Frame):
        return getattr(self, "e_" + n["k"])(n, f)

    def e_num(self, n, f):
        return n["v"]

    def e_str(self, n, f):
        return n["v"]

    def e_paren(self, n, f):
        return self.ev(n["e"], f)

    def e_neg(self, n, f):
        v = self.ev(n["e"], f)
        return NULL if v is NULL else -to_num(v)

    def e_not(self, n, f):
        v = self.ev(n["e"], f)
        if v is NULL:
            return NULL
        return (not v) if isinstance(v, bool) else ~to_int(v)

    def e_withobj(self, n, f):
        return self._with(f)

    def e_bin(self, n, f):
        op = n["op"]
        if op in ("and", "or"):                                    # VBScript does NOT short-circuit; keep side effects
            a, b = self.ev(n["l"], f), self.ev(n["r"], f)
            return rt.vb_logic(op, a, b)
        a, b = self.ev(n["l"], f), self.ev(n["r"], f)
        if op == "&":
            return (to_str(a) if a is not NULL else "") + (to_str(b) if b is not NULL else "")
        if op == "+":
            return rt.vb_add(a, b)
        if op in ("-", "*", "/", "\\", "mod", "^"):
            return rt.vb_arith(op, a, b)
        if op in ("=", "<>", "<", ">", "<=", ">="):
            return rt.vb_compare(op, a, b)
        if op == "is":
            return a is b or (a is NOTHING and b is NOTHING)
        if op in ("xor", "eqv", "imp"):
            return rt.vb_logic(op, a, b)
        raise VbError(rt.INVALID_CALL, f"Unknown operator {op}")

    def e_id(self, n, f):
        name = n["name"].casefold()
        return self.resolve_name(name, n["name"], [], f, has_args=False)

    def resolve_name(self, name: str, display: str, args: list, f: Frame, has_args: bool, arg_nodes: list | None = None):
        if name in f.vars or name in self.globals.vars:
            val = self.lookup_var(name, f)
            if has_args:
                return self.index_value(val, args, display)
            return val
        if name == f.func_name and not f.is_global and not has_args:
            return f.ret
        if name in self.procs:
            return self.call_proc(self.procs[name], args, f, arg_nodes)
        if name in rt.FUNCTIONS:
            return self.call_builtin(name, args)
        if name in rt.CONSTANTS and not has_args:
            return rt.CONSTANTS[name]
        if name == "err":
            return self.err
        obj = self.host.builtin_object(name)
        if obj is not None:
            if has_args:
                return obj.vb_call("Value", args) if hasattr(obj, "vb_call") else obj
            return obj
        if self.host.is_test_class(name):
            spec = _spec(args)
            if has_args and spec is not None:
                return TestObjectRef(((display, spec),))
            raise VbError(rt.INVALID_CALL, f"{display} needs a name or description argument")
        if has_args:                      # unknown function-style call: let the host decide (Wait, Print ...)
            return self.host.procedure(display, args)
        return EMPTY                      # undeclared variable = Empty (no Option Explicit enforcement)

    def index_value(self, val, args: list, display: str):
        if isinstance(val, list):
            cur = val
            for i in args:
                if not isinstance(cur, list):
                    raise VbError(rt.SUBSCRIPT, "Subscript out of range")
                cur = cur[self._index(cur, i)]
            return cur
        if hasattr(val, "vb_call"):
            return val.vb_call("Item", args)
        raise VbError(rt.TYPE_MISMATCH, f"Type mismatch: '{display}' is not an array")

    def call_builtin(self, name: str, args: list):
        fn = rt.FUNCTIONS[name]
        args = [EMPTY if a is None else a for a in args] if name not in ("replace", "split", "instr", "string") else args
        try:
            return fn(*args)
        except TypeError:
            raise VbError(rt.INVALID_CALL, f"Wrong number of arguments: '{name}'") from None
        except (ValueError, OverflowError) as exc:
            raise VbError(rt.INVALID_CALL, f"Invalid procedure call or argument: {exc}") from None

    def e_index(self, n, f):
        target = n["target"]
        args = [None if a is None else self.ev(a, f) for a in n["args"]]
        if target["k"] == "id":
            return self.resolve_name(target["name"].casefold(), target["name"], args, f, has_args=True,
                                    arg_nodes=n["args"])
        base = self.ev(target, f)
        return self.index_value(base, args, "expression")

    def e_member(self, n, f):
        return self.member_value(n, f)

    def member_value(self, n, f):
        obj = self._with(f) if n["obj"]["k"] == "withobj" else self.ev(n["obj"], f)
        name = n["name"]
        args = [None if a is None else self.ev(a, f) for a in (n["args"] or [])]
        return self.invoke_member(obj, name, args, f, has_args=n["args"] is not None)

    def invoke_member(self, obj, name: str, args: list, f: Frame, has_args: bool = False):
        low = name.casefold()
        if isinstance(obj, TestObjectRef):
            if self.host.is_test_class(low) and _spec(args) is not None:
                return obj.child(name, _spec(args))
            return self.host.invoke(obj, name, args)
        if hasattr(obj, "vb_call"):
            return obj.vb_call(name, args)
        if obj is NOTHING or obj is EMPTY or obj is NULL:
            raise VbError(91, "Object variable not set")
        raise VbError(rt.NO_MEMBER, f"Object doesn't support this property or method: '{name}'")

    def ev_call_statement(self, expr: dict, args: list, f: Frame, arg_nodes: list | None = None):
        """A statement-level call. ``expr`` is the callee; ``args`` are the command-style arguments."""
        k = expr["k"]
        if k == "id":
            name = expr["name"].casefold()
            if name in self.procs:
                return self.call_proc(self.procs[name], args, f, arg_nodes)
            if name in rt.FUNCTIONS:
                return self.call_builtin(name, args)
            if name in f.vars or name in self.globals.vars:
                return self.resolve_name(name, expr["name"], args, f, has_args=bool(args))
            if name == "err":
                return self.err
            return self.host_procedure(expr["name"], args, f)
        if k == "index" and expr["target"]["k"] == "id":
            base = expr["target"]
            name = base["name"].casefold()
            inner = [None if a is None else self.ev(a, f) for a in expr["args"]] + args
            if name in self.procs:
                return self.call_proc(self.procs[name], inner, f, list(expr["args"]) + list(arg_nodes or []))
            if name in rt.FUNCTIONS:
                return self.call_builtin(name, inner)
            if name in f.vars or name in self.globals.vars:
                return self.resolve_name(name, base["name"], inner, f, has_args=True)
            if self.host.is_test_class(name) or self.host.builtin_object(name) is not None:
                return self.resolve_name(name, base["name"], inner, f, has_args=True)
            return self.host_procedure(base["name"], inner, f)
        if k == "member":
            obj = self._with(f) if expr["obj"]["k"] == "withobj" else self.ev(expr["obj"], f)
            margs = [None if a is None else self.ev(a, f) for a in (expr["args"] or [])] + args
            return self.invoke_member(obj, expr["name"], margs, f, has_args=True)
        return self.ev(expr, f)

    def host_procedure(self, name: str, args: list, f: Frame):
        low = name.casefold()
        if low == "exitaction":
            raise _Exit("action")
        if low in ("exittest", "exitrun"):
            raise StopRun(name, "passed")
        if low == "executefile":
            return self.execute_file(to_str(args[0]))
        if low == "runaction":
            return self.run_action(to_str(args[0]), args[1:])
        return self.host.procedure(name, args)

    # =============================================================== procedures
    def call_proc(self, proc: dict, args: list, caller: Frame, arg_nodes: list | None = None):
        if self.depth >= self.max_depth:
            raise VbError(28, "Out of stack space")
        params = proc["params"]
        if len(args) > len(params):
            raise VbError(450, f"Wrong number of arguments: '{proc['name']}'")
        frame = Frame(func_name=proc["name"] if proc["k"] == "function" else "")
        for i, p in enumerate(params):
            v = args[i] if i < len(args) and args[i] is not None else EMPTY
            frame.vars[p["name"].casefold()] = copy.deepcopy(v) if isinstance(v, list) else v
        self.depth += 1
        try:
            try:
                self.exec_block(proc["body"], frame)
            except _Exit as e:
                if e.what not in ("proc", "action"):
                    raise
        finally:
            self.depth -= 1
        # ByRef write-back: only plain variables can be written back (VBScript passes ByRef by default)
        for i, p in enumerate(params):
            if p["byref"] and arg_nodes and i < len(arg_nodes) and arg_nodes[i] and arg_nodes[i]["k"] == "id":
                nm = arg_nodes[i]["name"].casefold()
                if nm in caller.vars or nm in self.globals.vars:
                    self.store_var(nm, frame.vars.get(p["name"].casefold(), EMPTY), caller)
        return frame.ret

    def execute_file(self, path: str):
        if path.casefold() in self._loaded_libs:
            return EMPTY
        src = self.host.load_library(path)
        if src is None:
            raise VbError(53, f"File not found or not allowed: '{path}'")
        from core.importers.uft.vbparse import VbSyntaxError, parse

        self._loaded_libs.add(path.casefold())
        try:
            prog = parse(src)
        except VbSyntaxError as exc:
            raise VbError(1002, f"Syntax error in library '{path}': {exc}") from None
        self.define_procedures(prog)
        self.exec_block(prog["body"], self.globals)
        return EMPTY

    def run_action(self, name: str, extra: list):
        prog = self.host.load_action(name)
        if prog is None:
            raise VbError(53, f"Action '{name}' was not found in the imported test")
        if self.depth >= self.max_depth:
            raise VbError(28, "Out of stack space")
        saved_procs, saved_globals = self.procs, self.globals
        self.procs, self.globals = dict(self.procs), Frame(is_global=True)
        self.depth += 1
        try:
            self.define_procedures(prog)
            self.exec_block(prog["body"], self.globals)
        except _Exit as e:
            if e.what not in ("action", "proc"):
                raise
        finally:
            self.depth -= 1
            self.procs, self.globals = saved_procs, saved_globals
        return EMPTY
