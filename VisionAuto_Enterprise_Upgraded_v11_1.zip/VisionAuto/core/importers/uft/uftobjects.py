"""UFT object model on top of the VisionAuto engine.

``Window("Calc").WinButton("1").Click`` in a VBScript test becomes the same Player steps a recorded test
uses (UI Automation -> XPath -> template -> OCR -> AI -> self-heal), so imported UFT tests inherit
every locator tier, the wait-until-visible logic, failure screenshots and the HTML report.

Safety: no COM, no shell, no file system access beyond the project folder.  SetSecure, CreateObject
for anything but Dictionary/RegExp, process killing and file I/O are refused with an explicit error.
"""
from __future__ import annotations

import csv
import re
import time
from pathlib import Path

from core.importers.ranorex.keys import parse_key_sequence
from core.importers.ranorex.runtime import RxContext, ValidationError
from core.importers.uft import vbruntime as rt
from core.importers.uft.object_repository import find_object
from core.importers.uft.vbinterp import Host, StopRun, TestObjectRef
from core.importers.uft.vbruntime import EMPTY, VbError, to_bool, to_int, to_num, to_str

UFT_STEP_FAILED = 1000

WINDOW_CLASSES = {"browser", "window", "dialog", "swfwindow", "javawindow", "javadialog", "vbwindow",
                  "sapguiwindow", "uiawindow", "wpfwindow"}
_PREFIXES = ("swf", "win", "web", "java", "vb", "sap", "uia", "wpf", "ax", "ie", "mobile", "ora")
_EXTRA_CLASSES = {"browser", "page", "frame", "window", "dialog", "link", "image", "static", "webarea", "webelement"}

ROLES = {
    "button": "Button", "webbutton": "Button", "winbutton": "Button", "swfbutton": "Button", "javabutton": "Button",
    "vbbutton": "Button", "edit": "Edit", "webedit": "Edit", "winedit": "Edit", "swfedit": "Edit", "javaedit": "Edit",
    "vbedit": "Edit", "winobject": "", "swfobject": "", "static": "Text", "swflabel": "Text", "vblabel": "Text",
    "link": "Hyperlink", "weblink": "Hyperlink", "checkbox": "CheckBox", "webcheckbox": "CheckBox",
    "wincheckbox": "CheckBox", "swfcheckbox": "CheckBox", "javacheckbox": "CheckBox", "vbcheckbox": "CheckBox",
    "radiobutton": "RadioButton", "webradiogroup": "RadioButton", "winradiobutton": "RadioButton",
    "swfradiobutton": "RadioButton", "javaradiobutton": "RadioButton", "vbradiobutton": "RadioButton",
    "list": "List", "weblist": "ComboBox", "winlist": "List", "swflist": "List", "javalist": "List", "vblist": "List",
    "combobox": "ComboBox", "wincombobox": "ComboBox", "swfcombobox": "ComboBox",
    "webtable": "Table", "wintable": "Table", "swftable": "Table", "javatable": "Table", "vbtable": "Table",
    "webelement": "", "image": "Image", "webimage": "Image", "wintab": "Tab", "swftab": "Tab", "javatab": "Tab",
    "winmenu": "MenuItem", "swfmenu": "MenuItem", "javamenu": "MenuItem", "wintreeview": "Tree", "swftree": "Tree",
    "javatree": "Tree", "winlistview": "List", "winstatusbar": "StatusBar", "swfstatusbar": "StatusBar",
    "wintoolbar": "ToolBar", "swftoolbar": "ToolBar", "winscrollbar": "ScrollBar", "winspin": "Spinner",
    "swfspin": "Spinner", "winslider": "Slider",
}
CHECKBOX_CLASSES = {c for c, r in ROLES.items() if r == "CheckBox"}
SELECTOR_CLASSES = {c for c, r in ROLES.items() if r in ("ComboBox", "List", "Tab", "MenuItem", "Tree")}
TAB_CLASSES = {c for c, r in ROLES.items() if r == "Tab"}
MENU_CLASSES = {c for c, r in ROLES.items() if r == "MenuItem"}

_LABEL_KEYS = ("text", "label", "acc_name", "name", "caption", "attachedtext", "value", "title", "innertext")
_ID_KEYS = ("automationid", "automation id", "swfname", "htmlid", "html id", "id", "windowsformsname", "name_for_id")
_TITLE_KEYS = ("regexpwndtitle", "text", "title", "windowtitle", "name", "caption")
_UFT_KEYS = {"enter": "Return", "tab": "Tab", "esc": "Escape", "escape": "Escape", "backspace": "Back", "bs": "Back",
             "delete": "Delete", "del": "Delete", "up": "Up", "down": "Down", "left": "Left", "right": "Right",
             "home": "Home", "end": "End", "pgup": "PageUp", "pgdn": "PageDown", "insert": "Insert",
             **{f"f{i}": f"F{i}" for i in range(1, 13)}}


def is_test_class_name(name: str) -> bool:
    low = name.casefold()
    return low in _EXTRA_CLASSES or low in ROLES or low.startswith(_PREFIXES)


def parse_description(spec) -> dict | None:
    """``"text:=OK|micclass:=Button"`` -> {"text": "OK", "micclass": "Button"}; plain logical names -> None."""
    if not isinstance(spec, str) or ":=" not in spec:
        return None
    props = {}
    for part in re.split(r"\|{1}", spec):
        key, sep, val = part.partition(":=")
        if sep and key.strip():
            props[key.strip().casefold()] = val.strip()
    return props


def _strip_regex(value: str) -> str:
    v = value.strip()
    v = v[1:] if v.startswith("^") else v
    v = v[:-1] if v.endswith("$") and not v.endswith("\\$") else v
    v = re.sub(r"^(\.\*)+|(\.\*)+$", "", v)
    return v.replace("\\.", ".").replace("\\ ", " ")


def build_target(chain: tuple, repo: dict) -> tuple[dict, dict, list[str]]:
    """TestObjectRef chain -> (target, window, notes). Looks repository objects up by logical path."""
    notes: list[str] = []
    logical = [str(spec) for _, spec in chain]
    desc_chain = []
    for cls, spec in chain:
        desc = parse_description(spec)
        obj = None if desc else find_object(repo, [str(spec)]) if repo else None
        props = dict(desc or (obj or {}).get("properties", {}))
        if obj and obj.get("class"):
            props.setdefault("micclass", obj["class"])
        if not desc and not obj and repo:
            notes.append(f"{cls}({spec!r}) was not found in the object repository; the logical name is used as the locator.")
        desc_chain.append((cls, spec, props))

    # window = first window-like element, else nothing
    window_title = ""
    for cls, spec, props in desc_chain:
        if cls.casefold() in WINDOW_CLASSES:
            raw = next((props[k] for k in _TITLE_KEYS if props.get(k)), "")
            window_title = _strip_regex(raw) if raw else (str(spec) if ":=" not in str(spec) else "")
            break
    leaf_cls, leaf_spec, props = desc_chain[-1]
    target: dict = {"x": 0, "y": 0, "source_locator": {"kind": "uft", "path": ".".join(logical)}}
    label = next((props[k] for k in _LABEL_KEYS if props.get(k)), "")
    if not label and ":=" not in str(leaf_spec):
        label = str(leaf_spec)
    if label:
        target["name"] = _strip_regex(label)
    mic = (props.get("micclass") or leaf_cls).casefold()
    role = ROLES.get(leaf_cls.casefold()) or ROLES.get(mic.replace(" ", ""))
    if role:
        target["role"] = role
    aid = next((props[k] for k in _ID_KEYS if props.get(k)), "")
    if aid:
        target["automation_id"] = aid
    cls_name = props.get("nativeclass") or props.get("regexpwndclass") or props.get("class")
    if cls_name and cls_name.casefold() != "window":
        target["class_name"] = cls_name
    if props.get("index") or props.get("ordinal"):
        target["index"] = props.get("index") or props.get("ordinal")
        notes.append("The 'index' / ordinal property is recorded but VisionAuto resolves duplicates by position and context.")
    if leaf_cls.casefold() in WINDOW_CLASSES and len(chain) == 1:
        target.setdefault("name", window_title)
    return target, {"title": window_title, "process": ""}, notes


def read_datatable(path: str | Path) -> list[dict]:
    """CSV export of a UFT data table (first row = column names)."""
    with open(path, newline="", encoding="utf-8-sig") as fh:
        return [dict(r) for r in csv.DictReader(fh)]


# ---------------------------------------------------------------------------------- UFT globals
class _Sheet:
    def __init__(self, host: "UftHost"):
        self.h = host

    def vb_call(self, name, args):
        n, h = name.casefold(), self.h
        if n in ("value", "item"):
            return h.dt_get(to_str(args[0]))
        if n == "getrowcount":
            return len(h.rows)
        if n == "getcurrentrow":
            return h.row_index + 1
        if n == "setcurrentrow":
            h.row_index = max(0, min(to_int(args[0]) - 1, max(len(h.rows) - 1, 0)))
            return EMPTY
        if n == "setnextrow":
            h.row_index = min(h.row_index + 1, max(len(h.rows) - 1, 0))
            return EMPTY
        if n == "setprevrow":
            h.row_index = max(h.row_index - 1, 0)
            return EMPTY
        if n == "getparametercount":
            return len(h.rows[0]) if h.rows else 0
        if n == "addparameter":
            h.dt_set(to_str(args[0]), args[1] if len(args) > 1 else EMPTY)
            return EMPTY
        raise VbError(rt.NO_MEMBER, f"DataTable does not support '{name}' in VisionAuto")

    def vb_set(self, name, value, args=()):
        if name.casefold() in ("value", "item"):
            self.h.dt_set(to_str(args[0]), value)
            return
        raise VbError(rt.NO_MEMBER, f"DataTable does not support '{name}' in VisionAuto")


class _DataTable(_Sheet):
    def vb_call(self, name, args):
        if name.casefold() in ("globalsheet", "localsheet", "getsheet"):
            return _Sheet(self.h)
        return super().vb_call(name, args)


class _Dict:
    """Environment / Parameter: Value("key") and default member."""

    def __init__(self, store: dict, writable=True, secret_check=None):
        self.store, self.writable = store, writable

    def vb_call(self, name, args):
        if name.casefold() in ("value", "item"):
            v = self.store.get(to_str(args[0]), EMPTY)
            return v
        raise VbError(rt.NO_MEMBER, f"Object doesn't support this property or method: '{name}'")

    def vb_set(self, name, value, args=()):
        if name.casefold() in ("value", "item") and self.writable:
            self.store[to_str(args[0])] = value
            return
        raise VbError(rt.NO_MEMBER, f"Object doesn't support this property or method: '{name}'")


class _Reporter:
    def __init__(self, host):
        self.h = host

    def vb_call(self, name, args):
        n = name.casefold()
        if n == "reportevent":
            status = to_int(args[0])
            self.h.report_event(status, to_str(args[1]) if len(args) > 1 else "", to_str(args[2]) if len(args) > 2 else "")
            return EMPTY
        if n in ("filter", "reportpath", "runstatus"):
            return 0 if n != "reportpath" else ""
        raise VbError(rt.NO_MEMBER, f"Reporter.{name} is not supported")

    def vb_set(self, name, value, args=()):
        if name.casefold() == "filter":
            return
        raise VbError(rt.NO_MEMBER, f"Reporter.{name} is not supported")


class _SystemUtil:
    def __init__(self, host):
        self.h = host

    def vb_call(self, name, args):
        n = name.casefold()
        if n == "run":
            exe = to_str(args[0])
            extra = to_str(args[1]) if len(args) > 1 and args[1] is not None else ""
            self.h.ctx.run_app(exe, extra)
            return EMPTY
        raise VbError(rt.BLOCKED, f"SystemUtil.{name} is blocked for safety (only SystemUtil.Run is available)")


class _Noop:
    def __init__(self, label):
        self.label = label

    def vb_call(self, name, args):
        return EMPTY

    def vb_set(self, name, value, args=()):
        return


# ---------------------------------------------------------------------------------- the host
class UftHost(Host):
    def __init__(self, ctx: RxContext, repo: dict | None = None, rows: list | None = None,
                 parameters: dict | None = None, environment: dict | None = None,
                 actions: dict | None = None, base_dir: str | Path | None = None):
        self.ctx = ctx
        self.repo = repo or {}
        self.rows = rows or []
        self.row_index = 0
        self.parameters = dict(parameters or {})
        self.environment = dict(environment or {})
        self.actions = {k.casefold(): v for k, v in (actions or {}).items()}
        self.base_dir = Path(base_dir).resolve() if base_dir else None
        self.output: list[str] = []
        self.failures = 0
        self.notes: list[str] = []
        self._report_n = 0
        self._objects = {
            "reporter": _Reporter(self), "datatable": _DataTable(self), "environment": _Dict(self.environment),
            "parameter": _Dict(self.parameters, writable=False), "systemutil": _SystemUtil(self),
            "services": _Noop("Services"), "setting": _Noop("Setting"),
        }

    # ------------------------------------------------------------ Host protocol
    def is_test_class(self, name: str) -> bool:
        return is_test_class_name(name)

    def should_stop(self) -> bool:
        return bool(self.ctx.player.should_stop())

    def builtin_object(self, name: str):
        return self._objects.get(name)

    def load_action(self, name: str):
        return self.actions.get(name.casefold())

    def load_library(self, path: str):
        if self.base_dir is None:
            return None
        p = Path(path.replace("\\", "/"))
        candidate = (p if p.is_absolute() else self.base_dir / p).resolve()
        try:
            candidate.relative_to(self.base_dir)
        except ValueError:
            return None
        if candidate.suffix.casefold() not in (".vbs", ".qfl", ".txt", ".mts") or not candidate.is_file():
            return None
        return candidate.read_text(encoding="utf-8-sig", errors="replace")

    def procedure(self, name: str, args: list):
        n = name.casefold()
        if n == "wait":
            secs = to_num(args[0]) if args and args[0] is not None else 0
            extra_ms = to_num(args[1]) if len(args) > 1 and args[1] is not None else 0
            self._act("wait", {"ms": int(secs * 1000 + extra_ms)})
            return EMPTY
        if n == "print":
            text = " ".join(to_str(a) for a in args if a is not None)
            self.output.append(text)
            self.ctx.log("Info", "Print", text)
            return EMPTY
        if n == "msgbox":
            text = to_str(args[0]) if args and args[0] is not None else ""
            self.output.append(f"[MsgBox] {text}")
            self.ctx.log("Info", "MsgBox", text)
            return 1
        if n == "inputbox":
            return ""
        raise VbError(rt.NO_MEMBER, f"'{name}' is not supported by the VisionAuto UFT runtime")

    # ------------------------------------------------------------ DataTable
    def dt_get(self, col: str):
        if self.rows and 0 <= self.row_index < len(self.rows):
            row = self.rows[self.row_index]
            for k, v in row.items():
                if k.casefold() == col.casefold():
                    return v if v is not None else ""
        if col in self.parameters:
            return self.parameters[col]
        raise VbError(rt.INVALID_CALL, f"DataTable column '{col}' was not found - supply it with --data / data_rows")

    def dt_set(self, col: str, value):
        if not self.rows:
            self.rows.append({})
        self.rows[min(self.row_index, len(self.rows) - 1)][col] = value

    # ------------------------------------------------------------ results
    def report_event(self, status: int, step: str, details: str) -> None:
        self._report_n += 1
        label = {0: "Passed", 1: "Failed", 2: "Done", 3: "Warning"}.get(status, "Done")
        ok = status != 1
        row = {"id": 10_000 + self._report_n, "type": "report", "description": f"{step}: {details}".strip(": "),
               "status": "passed" if ok else "failed", "method": f"Reporter ({label})", "validations": []}
        if not ok:
            row["error"] = details or step
            self.failures += 1
        self.ctx.results.append(row)
        self.ctx.player._emit(row)

    # ------------------------------------------------------------ steps
    def _act(self, step_type, params=None, target=None, window=None, check=None):
        try:
            return self.ctx._do(step_type, params, target, window, check)
        except ValidationError as exc:
            if self.should_stop():
                raise StopRun("aborted by user") from None
            raise VbError(UFT_STEP_FAILED, str(exc), "VisionAuto") from None

    def _soft(self, step_type, params=None, target=None, window=None, check=None) -> bool:
        """Run a check that reports pass/fail but lets the script continue (UFT CheckProperty semantics)."""
        ctx = self.ctx
        step = {"id": len(ctx.test["steps"]) + 1, "type": step_type, "t_ms": 0,
                "window": dict(window or ctx._window), "validations": []}
        for key, val in (("params", params), ("target", target), ("check", check)):
            if val:
                step[key] = val
        from core.ai.describe import describe_step
        step["description"] = describe_step(step)
        ctx.test["steps"].append(step)
        res = ctx.player._run_step(step)
        ctx.results.append(res)
        ctx.player._emit(res)
        if res["status"] == "aborted":
            raise StopRun("aborted by user")
        if res["status"] == "failed":
            self.failures += 1
            return False
        return True

    def _tw(self, ref: TestObjectRef):
        target, window, notes = build_target(ref.chain, self.repo)
        for n in notes:
            if n not in self.notes:
                self.notes.append(n)
        if window.get("title"):
            self.ctx._window = window
        return target, (window if window.get("title") else self.ctx._window)

    # ------------------------------------------------------------ existence / properties
    def _exists(self, ref: TestObjectRef, timeout_s: float) -> bool:
        if self.ctx.player.dry_run:
            return True
        target, window = self._tw(ref)
        from core.playback.resolver import Aborted, ElementNotFound
        from core.system import winenv

        deadline = time.monotonic() + max(0.0, timeout_s)
        if len(ref.chain) == 1 and ref.leaf_class.casefold() in WINDOW_CLASSES:
            while True:
                if self.should_stop():
                    raise StopRun("aborted by user")
                if window.get("title") and winenv.window_exists(window["title"]):
                    return True
                if time.monotonic() >= deadline:
                    return False
                time.sleep(0.25)
        try:
            if window.get("title") and not winenv.window_exists(window["title"]):
                return False
            self.ctx.player.resolver.resolve(target, window, max(0.0, timeout_s))
            return True
        except ElementNotFound:
            return False
        except Aborted:
            raise StopRun("aborted by user") from None

    def _read_property(self, ref: TestObjectRef, prop: str):
        target, window = self._tw(ref)
        p = prop.casefold().replace(" ", "")
        if self.ctx.player.dry_run:
            return target.get("name", "") if p in ("text", "value", "name", "label", "innertext") else EMPTY
        if p in ("exist",):
            return self._exists(ref, 0.5)
        if p in ("text", "value", "innertext", "name", "label", "acc_name", "attachedtext", "caption", "title", "selection"):
            actual, _how = self.ctx.player.validator._read_text(target, window)
            return actual if actual is not None else ""
        info = None
        try:
            from core.plugins.plugin_manager import PluginManager
            info = PluginManager().get_plugin_for(window).find_element_native(target, window)
        except Exception:
            info = None
        if info is None:
            if p in ("visible", "enabled"):
                return self._exists(ref, 0.5)
            return ""
        rect = info.get("rect", [0, 0, 0, 0])
        state = info.get("state", {}) or {}
        table = {"width": rect[2] - rect[0], "height": rect[3] - rect[1], "x": rect[0], "y": rect[1],
                 "class": info.get("class_name", ""), "nativeclass": info.get("class_name", ""),
                 "automationid": info.get("automation_id", ""), "visible": True, "enabled": True,
                 "checked": 1 if state.get("toggle") == "on" else 0, "selected": bool(state.get("selected", False))}
        if p == "focused":
            from core.system import winenv
            return winenv.focused_element().get("automation_id") == info.get("automation_id") and bool(info.get("automation_id"))
        return table.get(p, "")

    # ------------------------------------------------------------ UFT keys
    @staticmethod
    def _uft_keys(text: str) -> str:
        def sub(m):
            name = m.group(1).casefold()
            return "{" + _UFT_KEYS[name] + "}" if name in _UFT_KEYS else m.group(0)
        return re.sub(r"\{([A-Za-z0-9]+)\}", sub, text)

    def _send(self, text: str) -> None:
        for k in parse_key_sequence(self._uft_keys(text)):
            self._act(k["type"], k["params"])

    # ------------------------------------------------------------ invoke
    def invoke(self, ref: TestObjectRef, method: str, args: list):
        m = method.casefold()
        cls = ref.leaf_class.casefold()
        arg = lambda i, d=None: args[i] if len(args) > i and args[i] is not None else d   # noqa: E731
        ctx = self.ctx

        if m in ("exist", "exists"):
            timeout = to_num(arg(0, ctx.player.opts.get("timeout_s", 10.0)))
            return self._exists(ref, float(timeout))
        if m in ("click", "dblclick", "rightclick", "doubleclick", "middleclick"):
            t, w = self._tw(ref)
            if len(args) >= 2 and args[0] is not None and args[1] is not None:
                note = "Click(x, y) offsets are ignored: the control centre is clicked."
                if note not in self.notes:
                    self.notes.append(note)
            button = to_int(arg(2, 0))
            kind = "double_click" if m in ("dblclick", "doubleclick") else \
                   "right_click" if (m == "rightclick" or button == 2) else \
                   "middle_click" if (m == "middleclick" or button == 1) else "click"
            self._act(kind, {"button": "right" if kind == "right_click" else "middle" if kind == "middle_click" else "left"}, t, w)
            return EMPTY
        if m == "setsecure":
            raise VbError(rt.BLOCKED, "SetSecure needs UFT's encrypted secret store, which VisionAuto cannot decrypt. "
                                      "Pass the credential through Environment/Parameter and use .Set instead.")
        if m == "set":
            t, w = self._tw(ref)
            val = arg(0, "")
            if cls in CHECKBOX_CLASSES:
                want = to_str(val).strip().casefold() in ("on", "true", "1", "checked") or val is True
                state = self._read_property(ref, "checked") if not ctx.player.dry_run else ""
                if state in (0, 1) and bool(state) == want:
                    return EMPTY
                self._act("click", {"button": "left"}, t, w)
                return EMPTY
            if ROLES.get(cls) == "RadioButton":
                self._act("click", {"button": "left"}, t, w)
                return EMPTY
            self._act("click", {"button": "left"}, t, w)
            self._act("hotkey", {"keys": "ctrl+a"})
            text = to_str(val)
            if text == "":
                self._act("key", {"key": "delete"})
            else:
                self._act("type", {"text": text})
            return EMPTY
        if m == "type":
            t, w = self._tw(ref)
            self._act("click", {"button": "left"}, t, w)
            self._send(to_str(arg(0, "")))
            return EMPTY
        if m == "select":
            return self._select(ref, to_str(arg(0, "")), cls)
        if m in ("setfocus", "highlight", "setcursorpos"):
            if m == "setfocus":
                t, w = self._tw(ref)
                self._act("click", {"button": "left"}, t, w)
            return EMPTY
        if m in ("activate", "maximize", "minimize", "restore", "close"):
            t, w = self._tw(ref)
            self._act("wait", {"ms": 100}, window=w)       # window activation happens before every step
            if m == "maximize":
                self._act("hotkey", {"keys": "win+up"})
            elif m == "minimize":
                self._act("hotkey", {"keys": "win+down"})
            elif m == "close":
                self._act("hotkey", {"keys": "alt+f4"})
            return EMPTY
        if m in ("sync", "waitforpageload"):
            return EMPTY
        if m in ("getroproperty", "getvisibletext", "getcelldata_unsupported"):
            return self._read_property(ref, to_str(arg(0, "text")) if m == "getroproperty" else "text")
        if m == "gettoproperty":
            t, w = self._tw(ref)
            props = parse_description(ref.chain[-1][1]) or (find_object(self.repo, [str(ref.chain[-1][1])]) or {}).get("properties", {})
            return props.get(to_str(arg(0, "")).casefold().replace(" ", ""), "")
        if m == "waitproperty":
            return self._poll_property(ref, to_str(arg(0, "")), arg(1, ""), to_num(arg(2, 10000)), report=False)
        if m == "checkproperty":
            return self._poll_property(ref, to_str(arg(0, "")), arg(1, ""), to_num(arg(2, 10000)), report=True)
        if m == "navigate":
            self._act("hotkey", {"keys": "ctrl+l"})
            self._act("type", {"text": to_str(arg(0, ""))})
            self._act("key", {"key": "enter"})
            return EMPTY
        if m in ("back", "forward", "refresh"):
            self._act("hotkey", {"keys": {"back": "alt+left", "forward": "alt+right", "refresh": "f5"}[m]})
            return EMPTY
        if m == "capturebitmap":
            return self._capture(to_str(arg(0, "capture.png")))
        if m == "drag" or m == "drop":
            raise VbError(rt.NO_MEMBER, f"{ref.leaf_class}.{method} is not supported - use a recorded drag_drop step")
        raise VbError(rt.NO_MEMBER, f"Object doesn't support this property or method: '{ref.leaf_class}.{method}' "
                                    "in the VisionAuto UFT runtime")

    def _select(self, ref: TestObjectRef, item: str, cls: str):
        t, w = self._tw(ref)
        if cls in MENU_CLASSES:
            for part in [p.strip() for p in item.split(";") if p.strip()]:
                self._act("click", {"button": "left"}, {"x": 0, "y": 0, "name": part, "text": part, "role": "MenuItem"}, w)
            return EMPTY
        self._act("click", {"button": "left"}, t, w)
        if cls in TAB_CLASSES:
            self._act("click", {"button": "left"}, {"x": 0, "y": 0, "name": item, "text": item, "role": "TabItem"}, w)
            return EMPTY
        if item.startswith("#") and item[1:].isdigit():        # UFT: "#0" = first item
            idx = int(item[1:])
            self._act("hotkey", {"keys": "home"})
            for _ in range(idx):
                self._act("key", {"key": "down"})
            self._act("key", {"key": "enter"})
            return EMPTY
        self._act("click", {"button": "left"}, {"x": 0, "y": 0, "name": item, "text": item}, w)
        return EMPTY

    def _poll_property(self, ref, prop, expected, timeout_ms, report: bool) -> bool:
        if self.ctx.player.dry_run:
            if report:
                self.report_event(0, f"CheckProperty {prop}", "simulated (dry run)")
            return True
        deadline = time.monotonic() + max(0.0, float(timeout_ms)) / 1000.0
        want = to_str(expected).strip().casefold()
        actual = ""
        while True:
            if self.should_stop():
                raise StopRun("aborted by user")
            actual = self._read_property(ref, prop)
            got = to_str(actual).strip().casefold() if not isinstance(actual, bool) else str(actual).casefold()
            if got == want or (want in ("true", "false") and got == want):
                if report:
                    self.report_event(0, f"CheckProperty {prop}", f"{ref} {prop} = {actual!r}")
                return True
            if time.monotonic() >= deadline:
                break
            time.sleep(0.25)
        if report:
            self.report_event(1, f"CheckProperty {prop}", f"{ref}: expected {to_str(expected)!r} but found {actual!r}")
        return False

    def _capture(self, name: str):
        if self.ctx.player.dry_run:
            return EMPTY
        import cv2

        from core.system import winenv

        run_dir = self.ctx.player.run_dir
        if run_dir is None:
            return EMPTY
        safe = re.sub(r"[^\w.\-]", "_", Path(name.replace("\\", "/")).name) or "capture.png"
        frame, _ = winenv.grab_screen()
        cv2.imwrite(str(Path(run_dir) / safe), frame)
        return EMPTY
