"""VBScript lexer + parser -> JSON-serialisable AST (``visionauto.script/1``).

Covers the language UFT tests are written in: Dim/ReDim/Const, Set, If (block and single-line),
For/For Each, Do/Loop (While/Until, pre/post), While/Wend, Select Case, Sub/Function with
ByVal/ByRef, Exit, On Error, With, Call, command-style calls without parentheses and
empty arguments (``.Click , , micRightBtn``).  Anything it cannot parse becomes an ``unsupported``
node that is reported at import time and fails loudly at run time - never silently skipped.
Nodes are plain dicts: ``{"k": kind, "line": n, ...}``.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field

MAX_SOURCE_BYTES = 2_000_000
MAX_DEPTH = 120


class VbSyntaxError(Exception):
    def __init__(self, message: str, line: int = 0):
        super().__init__(f"line {line}: {message}" if line else message)
        self.line = line


@dataclass
class Tok:
    kind: str      # NUM STR ID OP NL COLON EOF
    value: object
    line: int


_OPS2 = ("<>", "<=", ">=")
_OPS1 = "+-*/\\^&=<>(),."
_ID = re.compile(r"[A-Za-z_][A-Za-z0-9_]*")
_NUM = re.compile(r"(?:\d+\.\d*|\.\d+|\d+)(?:[eE][+-]?\d+)?")


def tokenize(src: str) -> list[Tok]:
    if len(src.encode("utf-8", "replace")) > MAX_SOURCE_BYTES:
        raise VbSyntaxError("script is larger than the 2 MB import limit")
    toks: list[Tok] = []
    i, n, line = 0, len(src), 1
    at_stmt_start = True
    while i < n:
        ch = src[i]
        if ch in " \t\r\f\v\ufeff":
            i += 1
            continue
        if ch == "_" and re.match(r"_[ \t]*\r?\n", src[i:i + 20] or ""):      # line continuation
            m = re.match(r"_[ \t]*\r?\n", src[i:])
            i += m.end()
            line += 1
            continue
        if ch == "\n":
            toks.append(Tok("NL", "\n", line))
            line += 1
            i += 1
            at_stmt_start = True
            continue
        if ch == "'":
            while i < n and src[i] != "\n":
                i += 1
            continue
        if ch == ":" and not src.startswith(":=", i):
            toks.append(Tok("COLON", ":", line))
            i += 1
            at_stmt_start = True
            continue
        if ch == '"':
            j, buf = i + 1, []
            while True:
                if j >= n or src[j] == "\n":
                    raise VbSyntaxError("unterminated string", line)
                if src[j] == '"':
                    if j + 1 < n and src[j + 1] == '"':
                        buf.append('"')
                        j += 2
                        continue
                    break
                buf.append(src[j])
                j += 1
            toks.append(Tok("STR", "".join(buf), line))
            i = j + 1
            at_stmt_start = False
            continue
        if ch == "#":
            j = src.find("#", i + 1)
            if j > 0 and "\n" not in src[i:j]:
                toks.append(Tok("STR", src[i + 1:j], line))
                i = j + 1
                at_stmt_start = False
                continue
        if ch == "&" and i + 2 < n and src[i + 1] in "hHoO":
            m = re.match(r"&([hH][0-9A-Fa-f]+|[oO][0-7]+)&?", src[i:])
            if m:
                body = m.group(1)
                toks.append(Tok("NUM", int(body[1:], 16 if body[0] in "hH" else 8), line))
                i += m.end()
                at_stmt_start = False
                continue
        m = _NUM.match(src, i)
        if m and (ch.isdigit() or (ch == "." and i + 1 < n and src[i + 1].isdigit() and
                                  not (toks and toks[-1].kind in ("ID",) ) and not (toks and toks[-1].kind == "OP" and toks[-1].value == ")"))):
            text = m.group(0)
            toks.append(Tok("NUM", float(text) if any(c in text for c in ".eE") else int(text), line))
            i = m.end()
            at_stmt_start = False
            continue
        m = _ID.match(src, i)
        if m:
            word = m.group(0)
            if at_stmt_start and word.casefold() == "rem" and (i + 3 >= n or not (src[i + 3].isalnum() or src[i + 3] == "_")):
                while i < n and src[i] != "\n":
                    i += 1
                continue
            toks.append(Tok("ID", word, line))
            i = m.end()
            at_stmt_start = False
            continue
        two = src[i:i + 2]
        if two in _OPS2:
            toks.append(Tok("OP", two, line))
            i += 2
            at_stmt_start = False
            continue
        if ch in _OPS1:
            toks.append(Tok("OP", ch, line))
            i += 1
            at_stmt_start = False
            continue
        if src.startswith(":=", i):
            toks.append(Tok("OP", ":=", line))
            i += 2
            continue
        raise VbSyntaxError(f"unexpected character {ch!r}", line)
    toks.append(Tok("NL", "\n", line))
    toks.append(Tok("EOF", None, line))
    return toks


# ---------------------------------------------------------------------------------- parser
BLOCK_END = {
    "if": ("end", "if"), "for": ("next",), "do": ("loop",), "while": ("wend",),
    "select": ("end", "select"), "sub": ("end", "sub"), "function": ("end", "function"),
    "with": ("end", "with"), "class": ("end", "class"), "property": ("end", "property"),
}
_UNSUPPORTED_CALLS = {"execute", "executeglobal", "eval", "getref", "createobject"}


class Parser:
    def __init__(self, toks: list[Tok]):
        self.t = toks
        self.p = 0
        self.depth = 0
        self.unsupported: list[dict] = []

    # --------------------------------------------------------------- token helpers
    @property
    def cur(self) -> Tok:
        return self.t[self.p]

    def peek(self, k: int = 1) -> Tok:
        return self.t[min(self.p + k, len(self.t) - 1)]

    def adv(self) -> Tok:
        tok = self.t[self.p]
        if tok.kind != "EOF":
            self.p += 1
        return tok

    def is_kw(self, *words: str, k: int = 0) -> bool:
        tok = self.peek(k) if k else self.cur
        return tok.kind == "ID" and tok.value.casefold() in words

    def is_op(self, *ops: str) -> bool:
        return self.cur.kind == "OP" and self.cur.value in ops

    def expect_op(self, op: str) -> Tok:
        if not self.is_op(op):
            raise VbSyntaxError(f"expected '{op}' but found {self.cur.value!r}", self.cur.line)
        return self.adv()

    def expect_kw(self, word: str) -> Tok:
        if not self.is_kw(word):
            raise VbSyntaxError(f"expected '{word}' but found {self.cur.value!r}", self.cur.line)
        return self.adv()

    def skip_nl(self) -> None:
        while self.cur.kind in ("NL", "COLON"):
            self.adv()

    def at_end_of_stmt(self) -> bool:
        return self.cur.kind in ("NL", "COLON", "EOF")

    def end_stmt(self) -> None:
        if self.cur.kind in ("NL", "COLON"):
            self.adv()
        elif self.cur.kind != "EOF":
            raise VbSyntaxError(f"unexpected {self.cur.value!r} at end of statement", self.cur.line)

    def skip_to_eol(self) -> None:
        while self.cur.kind not in ("NL", "EOF"):
            self.adv()

    # --------------------------------------------------------------- program
    def parse_program(self) -> dict:
        body = self.parse_block(lambda: self.cur.kind == "EOF")
        procs = [s for s in body if s["k"] in ("sub", "function")]
        main = [s for s in body if s["k"] not in ("sub", "function")]
        return {"schema": "visionauto.script/1", "procedures": procs, "body": main,
                "unsupported": self.unsupported}

    def parse_block(self, stop) -> list[dict]:
        out: list[dict] = []
        self.depth += 1
        if self.depth > MAX_DEPTH:
            raise VbSyntaxError("blocks are nested too deeply", self.cur.line)
        while True:
            self.skip_nl()
            if self.cur.kind == "EOF" or stop():
                break
            start = self.p
            try:
                stmt = self.parse_statement()
            except VbSyntaxError as exc:
                self.unsupported.append({"source_line": exc.line or self.t[start].line,
                                         "construct": self._line_text(start), "reason": str(exc)})
                out.append({"k": "unsupported", "line": self.t[start].line, "text": self._line_text(start),
                            "reason": str(exc)})
                self.p = max(self.p, start + 1)
                self.skip_to_eol()
                continue
            if stmt is not None:
                out.append(stmt)
        self.depth -= 1
        return out

    def _line_text(self, start: int) -> str:
        parts, i = [], start
        while i < len(self.t) and self.t[i].kind not in ("NL", "EOF"):
            v = self.t[i].value
            parts.append(f'"{v}"' if self.t[i].kind == "STR" else str(v))
            i += 1
        return " ".join(parts)[:200]

    # --------------------------------------------------------------- statements
    def parse_statement(self):
        tok = self.cur
        line = tok.line
        if tok.kind != "ID":
            raise VbSyntaxError(f"unexpected {tok.value!r}", line)
        word = tok.value.casefold()
        handler = getattr(self, f"st_{word}", None)
        if handler and not (self.peek().kind == "OP" and self.peek().value in ("=", ".") and word not in ("set", "call")):
            r = handler(line)
            return r
        return self.st_expression(line)

    # --- declarations
    def st_dim(self, line):
        self.adv()
        names = []
        while True:
            name = self.adv()
            if name.kind != "ID":
                raise VbSyntaxError("variable name expected", line)
            size = None
            if self.is_op("("):
                self.adv()
                if self.is_op(")"):
                    size = []
                else:
                    size = [self.expr()]
                    while self.is_op(","):
                        self.adv()
                        size.append(self.expr())
                self.expect_op(")")
            names.append({"name": name.value, "dims": size})
            if self.is_op(","):
                self.adv()
                continue
            break
        self.end_stmt()
        return {"k": "dim", "line": line, "names": names}

    st_private = st_public = st_dim

    def st_redim(self, line):
        self.adv()
        preserve = False
        if self.is_kw("preserve"):
            self.adv()
            preserve = True
        name = self.adv().value
        self.expect_op("(")
        dims = [self.expr()]
        while self.is_op(","):
            self.adv()
            dims.append(self.expr())
        self.expect_op(")")
        self.end_stmt()
        return {"k": "redim", "line": line, "name": name, "dims": dims, "preserve": preserve}

    def st_const(self, line):
        self.adv()
        name = self.adv().value
        self.expect_op("=")
        val = self.expr()
        self.end_stmt()
        return {"k": "const", "line": line, "name": name, "value": val}

    def st_option(self, line):
        self.skip_to_eol()
        return None

    def st_randomize(self, line):
        self.skip_to_eol()
        return None

    # --- assignment / calls
    def st_set(self, line):
        self.adv()
        target = self.postfix()
        self.expect_op("=")
        if self.is_kw("new"):
            raise VbSyntaxError("'Set x = New Class' (VBScript classes) is not supported", line)
        value = self.expr()
        self.end_stmt()
        return {"k": "assign", "line": line, "target": target, "value": value, "set": True}

    def st_call(self, line):
        self.adv()
        expr = self.postfix()
        self.end_stmt()
        return {"k": "call", "line": line, "expr": expr, "args": None}

    def st_expression(self, line):
        target = self.postfix()
        if self.is_op("="):
            self.adv()
            value = self.expr()
            self.end_stmt()
            return {"k": "assign", "line": line, "target": target, "value": value, "set": False}
        if self.at_end_of_stmt() or self.is_kw("else"):
            if self.at_end_of_stmt():
                self.end_stmt()
            return {"k": "call", "line": line, "expr": target, "args": None}
        args = self.arg_list(bare=True)
        self.end_stmt()
        return {"k": "call", "line": line, "expr": target, "args": args}

    # --- control flow
    def st_if(self, line):
        self.adv()
        cond = self.expr()
        self.expect_kw("then")
        if not self.at_end_of_stmt():                       # single-line If
            then_body = self.inline_stmts()
            else_body = None
            if self.is_kw("else"):
                self.adv()
                else_body = self.inline_stmts()
            self.end_stmt()
            return {"k": "if", "line": line, "branches": [{"cond": cond, "body": then_body}], "else": else_body}
        branches = []
        else_body = None
        body = self.parse_block(lambda: self.is_kw("elseif", "else") or self.is_end("if"))
        branches.append({"cond": cond, "body": body})
        while True:
            if self.is_kw("elseif"):
                self.adv()
                c = self.expr()
                self.expect_kw("then")
                b = self.parse_block(lambda: self.is_kw("elseif", "else") or self.is_end("if"))
                branches.append({"cond": c, "body": b})
            elif self.is_kw("else"):
                self.adv()
                else_body = self.parse_block(lambda: self.is_end("if"))
            else:
                break
        self.close("if", line)
        return {"k": "if", "line": line, "branches": branches, "else": else_body}

    def inline_stmts(self) -> list[dict]:
        out = []
        while not (self.cur.kind in ("NL", "EOF") or self.is_kw("else")):
            if self.cur.kind == "COLON":
                self.adv()
                continue
            st = self.parse_statement_inline()
            if st:
                out.append(st)
        return out

    def parse_statement_inline(self):
        # statements inside a single-line If end at ':' (kept in the clause), 'Else', or newline
        tok = self.cur
        saved = self.p
        stmt = self.parse_statement_noeol()
        return stmt

    def parse_statement_noeol(self):
        """Like parse_statement but never consumes the NL that ends the whole line."""
        line = self.cur.line
        word = self.cur.value.casefold() if self.cur.kind == "ID" else ""
        if word == "exit":
            return self.st_exit(line, consume=False)
        if word == "set":
            self.adv()
            target = self.postfix()
            self.expect_op("=")
            value = self.expr()
            return {"k": "assign", "line": line, "target": target, "value": value, "set": True}
        if word == "call":
            self.adv()
            expr = self.postfix()
            return {"k": "call", "line": line, "expr": expr, "args": None}
        if word == "on":
            return self.st_on(line, consume=False)
        target = self.postfix()
        if self.is_op("="):
            self.adv()
            value = self.expr()
            return {"k": "assign", "line": line, "target": target, "value": value, "set": False}
        if self.at_end_of_stmt() or self.is_kw("else"):
            return {"k": "call", "line": line, "expr": target, "args": None}
        args = self.arg_list(bare=True)
        return {"k": "call", "line": line, "expr": target, "args": args}

    def is_end(self, what: str) -> bool:
        return self.is_kw("end") and self.is_kw(what, k=1)

    def close(self, what: str, line: int) -> None:
        if not self.is_end(what):
            raise VbSyntaxError(f"'If' started on line {line} has no matching 'End {what.title()}'" if what == "if"
                                else f"'{what}' started on line {line} was not closed", self.cur.line)
        self.adv()
        self.adv()
        self.end_stmt()

    def st_for(self, line):
        self.adv()
        if self.is_kw("each"):
            self.adv()
            var = self.adv().value
            self.expect_kw("in")
            coll = self.expr()
            self.end_stmt()
            body = self.parse_block(lambda: self.is_kw("next"))
            self.expect_kw("next")
            if self.cur.kind == "ID":
                self.adv()
            self.end_stmt()
            return {"k": "foreach", "line": line, "var": var, "coll": coll, "body": body}
        var = self.postfix()
        self.expect_op("=")
        start = self.expr()
        self.expect_kw("to")
        end = self.expr()
        step = None
        if self.is_kw("step"):
            self.adv()
            step = self.expr()
        self.end_stmt()
        body = self.parse_block(lambda: self.is_kw("next"))
        self.expect_kw("next")
        if self.cur.kind == "ID":
            self.adv()
        self.end_stmt()
        return {"k": "for", "line": line, "var": var, "start": start, "end": end, "step": step, "body": body}

    def st_do(self, line):
        self.adv()
        kind = cond = None
        if self.is_kw("while", "until"):
            kind = self.adv().value.casefold()
            cond = self.expr()
        self.end_stmt()
        body = self.parse_block(lambda: self.is_kw("loop"))
        self.expect_kw("loop")
        pos = "pre" if cond is not None else None
        if self.is_kw("while", "until"):
            kind = self.adv().value.casefold()
            cond = self.expr()
            pos = "post"
        self.end_stmt()
        return {"k": "do", "line": line, "kind": kind, "cond": cond, "pos": pos, "body": body}

    def st_while(self, line):
        self.adv()
        cond = self.expr()
        self.end_stmt()
        body = self.parse_block(lambda: self.is_kw("wend"))
        self.expect_kw("wend")
        self.end_stmt()
        return {"k": "do", "line": line, "kind": "while", "cond": cond, "pos": "pre", "body": body}

    def st_select(self, line):
        self.adv()
        self.expect_kw("case")
        subject = self.expr()
        self.end_stmt()
        cases, else_body = [], None
        self.skip_nl()
        while self.is_kw("case"):
            self.adv()
            if self.is_kw("else"):
                self.adv()
                self.end_stmt()
                else_body = self.parse_block(lambda: self.is_kw("case") or self.is_end("select"))
                continue
            tests = []
            while True:
                if self.is_kw("is"):
                    self.adv()
                    op = self.adv().value
                    if op == "<" and self.is_op(">", "="):
                        op += self.adv().value
                    elif op in (">", "<") and self.is_op("="):
                        op += self.adv().value
                    tests.append({"op": op, "value": self.expr()})
                else:
                    lo = self.expr()
                    if self.is_kw("to"):
                        self.adv()
                        tests.append({"range": [lo, self.expr()]})
                    else:
                        tests.append({"op": "=", "value": lo})
                if self.is_op(","):
                    self.adv()
                    continue
                break
            self.end_stmt()
            body = self.parse_block(lambda: self.is_kw("case") or self.is_end("select"))
            cases.append({"tests": tests, "body": body})
        self.close("select", line)
        return {"k": "select", "line": line, "subject": subject, "cases": cases, "else": else_body}

    def st_with(self, line):
        self.adv()
        obj = self.expr()
        self.end_stmt()
        body = self.parse_block(lambda: self.is_end("with"))
        self.close("with", line)
        return {"k": "with", "line": line, "obj": obj, "body": body}

    def st_exit(self, line, consume=True):
        self.adv()
        what = self.adv().value.casefold()
        if what not in ("for", "do", "sub", "function", "property"):
            raise VbSyntaxError(f"unknown Exit target {what!r}", line)
        if consume:
            self.end_stmt()
        return {"k": "exit", "line": line, "what": what}

    def st_on(self, line, consume=True):
        self.adv()
        self.expect_kw("error")
        if self.is_kw("resume"):
            self.adv()
            self.expect_kw("next")
            mode = "resume_next"
        else:
            self.expect_kw("goto")
            n = self.adv()
            if n.value != 0:
                raise VbSyntaxError("On Error GoTo <label> is not supported (only GoTo 0)", line)
            mode = "goto0"
        if consume:
            self.end_stmt()
        return {"k": "onerror", "line": line, "mode": mode}

    def st_sub(self, line):
        return self.procedure(line, "sub")

    def st_function(self, line):
        return self.procedure(line, "function")

    def procedure(self, line, kind):
        self.adv()
        name = self.adv().value
        params = []
        if self.is_op("("):
            self.adv()
            while not self.is_op(")"):
                byref = True
                if self.is_kw("byval"):
                    self.adv()
                    byref = False
                elif self.is_kw("byref"):
                    self.adv()
                pname = self.adv()
                if pname.kind != "ID":
                    raise VbSyntaxError("parameter name expected", line)
                if self.is_op("("):
                    self.adv()
                    self.expect_op(")")
                params.append({"name": pname.value, "byref": byref})
                if self.is_op(","):
                    self.adv()
            self.expect_op(")")
        self.end_stmt()
        body = self.parse_block(lambda: self.is_end(kind))
        self.close(kind, line)
        return {"k": kind, "line": line, "name": name, "params": params, "body": body}

    def st_class(self, line):
        raise VbSyntaxError("VBScript Class definitions are not supported", line)

    def st_property(self, line):
        raise VbSyntaxError("Property procedures are not supported", line)

    def st_goto(self, line):
        raise VbSyntaxError("GoTo / labels are not supported", line)

    def st_stop(self, line):
        self.skip_to_eol()
        return {"k": "unsupported", "line": line, "text": "Stop", "reason": "Stop is ignored"}

    # --------------------------------------------------------------- expressions
    def arg_list(self, bare: bool = False) -> list:
        """Comma separated args; an omitted argument is ``None`` (``.Click , , micRightBtn``)."""
        args = []
        if not bare and self.is_op(")"):
            return args
        while True:
            if self.is_op(","):
                args.append(None)
                self.adv()
                if (not bare and self.is_op(")")) or (bare and self.at_end_of_stmt()):
                    args.append(None)
                    break
                continue
            if bare and self.at_end_of_stmt():
                break
            args.append(self.expr())
            if self.is_op(","):
                self.adv()
                if (not bare and self.is_op(")")) or (bare and self.at_end_of_stmt()):
                    args.append(None)
                    break
                continue
            break
        return args

    def postfix(self):
        node = self.primary()
        while True:
            if self.is_op("."):
                self.adv()
                tok = self.adv()
                if tok.kind != "ID":
                    raise VbSyntaxError("member name expected after '.'", tok.line)
                if self.is_op("(") and not self._paren_is_bare_arg():
                    self.adv()
                    args = self.arg_list()
                    self.expect_op(")")
                    node = {"k": "member", "obj": node, "name": tok.value, "args": args, "line": tok.line}
                else:
                    node = {"k": "member", "obj": node, "name": tok.value, "args": None, "line": tok.line}
            elif self.is_op("(") and node["k"] in ("id", "call_expr", "member", "index"):
                self.adv()
                args = self.arg_list()
                self.expect_op(")")
                node = {"k": "index", "target": node, "args": args, "line": self.cur.line}
            else:
                break
        return node

    def _paren_is_bare_arg(self) -> bool:
        return False

    def primary(self):
        tok = self.cur
        if tok.kind == "NUM":
            self.adv()
            return {"k": "num", "v": tok.value}
        if tok.kind == "STR":
            self.adv()
            return {"k": "str", "v": tok.value}
        if tok.kind == "OP" and tok.value == "(":
            self.adv()
            inner = self.expr()
            self.expect_op(")")
            return {"k": "paren", "e": inner}
        if tok.kind == "OP" and tok.value == ".":                     # With-block member
            self.adv()
            name = self.adv()
            args = None
            if self.is_op("("):
                self.adv()
                args = self.arg_list()
                self.expect_op(")")
            return {"k": "member", "obj": {"k": "withobj"}, "name": name.value, "args": args, "line": name.line}
        if tok.kind == "ID":
            self.adv()
            low = tok.value.casefold()
            if low == "new":
                raise VbSyntaxError("'New' (VBScript classes / COM objects) is not supported", tok.line)
            if low in _UNSUPPORTED_CALLS and low != "createobject":
                raise VbSyntaxError(f"{tok.value} executes dynamic code and is not supported", tok.line)
            return {"k": "id", "name": tok.value, "line": tok.line}
        raise VbSyntaxError(f"unexpected {tok.value!r}", tok.line)

    # precedence climbing
    _BIN = [
        ("imp", {"imp"}), ("eqv", {"eqv"}), ("xor", {"xor"}), ("or", {"or"}), ("and", {"and"}),
    ]

    def expr(self):
        return self.e_imp()

    def _kw_binary(self, nxt, words):
        left = nxt()
        while self.cur.kind == "ID" and self.cur.value.casefold() in words:
            op = self.adv().value.casefold()
            left = {"k": "bin", "op": op, "l": left, "r": nxt()}
        return left

    def e_imp(self):
        return self._kw_binary(self.e_eqv, {"imp"})

    def e_eqv(self):
        return self._kw_binary(self.e_xor, {"eqv"})

    def e_xor(self):
        return self._kw_binary(self.e_or, {"xor"})

    def e_or(self):
        return self._kw_binary(self.e_and, {"or"})

    def e_and(self):
        return self._kw_binary(self.e_not, {"and"})

    def e_not(self):
        if self.is_kw("not"):
            self.adv()
            return {"k": "not", "e": self.e_not()}
        return self.e_cmp()

    def e_cmp(self):
        left = self.e_concat()
        while True:
            if self.cur.kind == "OP" and self.cur.value in ("=", "<>", "<", ">", "<=", ">="):
                op = self.adv().value
                left = {"k": "bin", "op": op, "l": left, "r": self.e_concat()}
            elif self.is_kw("is"):
                self.adv()
                left = {"k": "bin", "op": "is", "l": left, "r": self.e_concat()}
            else:
                return left

    def e_concat(self):
        left = self.e_add()
        while self.is_op("&"):
            self.adv()
            left = {"k": "bin", "op": "&", "l": left, "r": self.e_add()}
        return left

    def e_add(self):
        left = self.e_mod()
        while self.is_op("+", "-"):
            op = self.adv().value
            left = {"k": "bin", "op": op, "l": left, "r": self.e_mod()}
        return left

    def e_mod(self):
        left = self.e_idiv()
        while self.is_kw("mod"):
            self.adv()
            left = {"k": "bin", "op": "mod", "l": left, "r": self.e_idiv()}
        return left

    def e_idiv(self):
        left = self.e_mul()
        while self.is_op("\\"):
            self.adv()
            left = {"k": "bin", "op": "\\", "l": left, "r": self.e_mul()}
        return left

    def e_mul(self):
        left = self.e_unary()
        while self.is_op("*", "/"):
            op = self.adv().value
            left = {"k": "bin", "op": op, "l": left, "r": self.e_unary()}
        return left

    def e_unary(self):
        if self.is_op("-", "+"):
            op = self.adv().value
            inner = self.e_unary()
            return {"k": "neg", "e": inner} if op == "-" else inner
        return self.e_pow()

    def e_pow(self):
        left = self.postfix()
        while self.is_op("^"):
            self.adv()
            left = {"k": "bin", "op": "^", "l": left, "r": self.e_unary_pow()}
        return left

    def e_unary_pow(self):
        if self.is_op("-"):
            self.adv()
            return {"k": "neg", "e": self.e_unary_pow()}
        return self.postfix()


def parse(source: str) -> dict:
    """Parse VBScript source into the ``visionauto.script/1`` AST."""
    return Parser(tokenize(source)).parse_program()
