"""UFT/VBScript migration into VisionAuto's shared test schema."""

from core.importers.uft.importer import import_script
from core.importers.uft.vbscript import UFTConversion, convert_script

__all__ = ["UFTConversion", "convert_script", "import_script"]
