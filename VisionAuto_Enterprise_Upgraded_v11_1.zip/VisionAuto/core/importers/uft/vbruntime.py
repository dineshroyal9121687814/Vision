"""VBScript value model and standard library (no UI automation in here - fully testable on any OS).

Values: ``int``/``float``/``bool``/``str`` map directly; ``EMPTY``/``NULL``/``NOTHING`` are singletons;
arrays are ``list`` (nested for multi-dimensional); ``datetime`` is Date; ``VbDict`` is
Scripting.Dictionary; ``VbRegExp`` is VBScript.RegExp.  Unsafe COM objects (WScript.Shell,
FileSystemObject, ADODB, ...) are deliberately NOT available - ``CreateObject`` refuses them.
"""
from __future__ import annotations

import math
import random
import re
import time
from datetime import datetime, timedelta


class VbError(Exception):
    def __init__(self, number: int, description: str, source: str = "VisionAuto"):
        super().__init__(f"{description} (error {number})")
        self.number, self.description, self.source = number, description, source


class _Singleton:
    def __init__(self, name):
        self.name = name

    def __repr__(self):
        return self.name

    def __bool__(self):
        return False


EMPTY, NULL, NOTHING = _Singleton("Empty"), _Singleton("Null"), _Singleton("Nothing")

TYPE_MISMATCH = 13
SUBSCRIPT = 9
DIV_ZERO = 11
OVERFLOW = 6
INVALID_CALL = 5
NO_MEMBER = 438
KEY_EXISTS = 457
BLOCKED = 429


# ------------------------------------------------------------------ coercion
def _fmt_float(v: float) -> str:
    if math.isinf(v) or math.isnan(v):
        raise VbError(OVERFLOW, "Overflow")
    if v == int(v) and abs(v) < 1e15:
        return str(int(v))
    s = repr(v)
    return s.replace("e+", "E+").replace("e-", "E-") if "e" in s else s


def fmt_date(d: datetime) -> str:
    hour = d.hour % 12 or 12
    ampm = "AM" if d.hour < 12 else "PM"
    date = f"{d.month}/{d.day}/{d.year}"
    if d.hour == d.minute == d.second == 0:
        return date
    return f"{date} {hour}:{d.minute:02d}:{d.second:02d} {ampm}"


def to_str(v) -> str:
    if isinstance(v, str):
        return v
    if v is EMPTY:
        return ""
    if v is NULL:
        raise VbError(94, "Invalid use of Null")
    if isinstance(v, bool):
        return "True" if v else "False"
    if isinstance(v, int):
        return str(v)
    if isinstance(v, float):
        return _fmt_float(v)
    if isinstance(v, datetime):
        return fmt_date(v)
    if isinstance(v, list):
        raise VbError(TYPE_MISMATCH, "Type mismatch")
    if v is NOTHING:
        raise VbError(TYPE_MISMATCH, "Type mismatch")
    return str(v)


_NUMERIC = re.compile(r"^\s*[+-]?(\d+\.?\d*|\.\d+)([eE][+-]?\d+)?\s*$")


def is_numeric(v) -> bool:
    if isinstance(v, bool):
        return True
    if isinstance(v, (int, float)):
        return True
    if v is EMPTY:
        return True
    if isinstance(v, str):
        return bool(_NUMERIC.match(v)) or bool(re.match(r"^\s*&[hH][0-9A-Fa-f]+\s*$", v))
    return False


def to_num(v):
    if isinstance(v, bool):
        return -1 if v else 0
    if isinstance(v, (int, float)):
        return v
    if v is EMPTY:
        return 0
    if isinstance(v, str):
        s = v.strip()
        if re.match(r"^&[hH][0-9A-Fa-f]+$", s):
            return int(s[2:], 16)
        if _NUMERIC.match(s):
            f = float(s)
            return int(f) if f == int(f) and "." not in s and "e" not in s.casefold() else f
        raise VbError(TYPE_MISMATCH, "Type mismatch")
    if v is NULL:
        raise VbError(94, "Invalid use of Null")
    if isinstance(v, datetime):
        return (v - datetime(1899, 12, 30)).total_seconds() / 86400.0
    raise VbError(TYPE_MISMATCH, "Type mismatch")


def to_int(v) -> int:
    n = to_num(v)
    r = round(n)               # banker's rounding like VBScript CInt
    return int(r)


def to_bool(v) -> bool:
    if isinstance(v, bool):
        return v
    if v is NULL:
        return False
    if isinstance(v, str):
        low = v.strip().casefold()
        if low == "true":
            return True
        if low == "false":
            return False
    return to_num(v) != 0


# ------------------------------------------------------------------ operators
def vb_add(a, b):
    if a is NULL or b is NULL:
        return NULL
    if isinstance(a, str) and isinstance(b, str):
        return a + b
    if (isinstance(a, str) and not is_numeric(a)) or (isinstance(b, str) and not is_numeric(b)):
        raise VbError(TYPE_MISMATCH, "Type mismatch")
    return to_num(a) + to_num(b)


def vb_arith(op, a, b):
    if a is NULL or b is NULL:
        return NULL
    x, y = to_num(a), to_num(b)
    try:
        if op == "-":
            return x - y
        if op == "*":
            return x * y
        if op == "/":
            if y == 0:
                raise VbError(DIV_ZERO, "Division by zero")
            r = x / y
            return int(r) if r == int(r) and abs(r) < 1e15 else r
        if op == "\\":
            if int(round(y)) == 0:
                raise VbError(DIV_ZERO, "Division by zero")
            return int(math.trunc(round(x) / round(y)))
        if op == "mod":
            if int(round(y)) == 0:
                raise VbError(DIV_ZERO, "Division by zero")
            return int(math.fmod(round(x), round(y)))
        if op == "^":
            if abs(y) > 1000:
                raise VbError(OVERFLOW, "Overflow")
            r = x ** y
            if isinstance(r, complex):
                raise VbError(INVALID_CALL, "Invalid procedure call or argument")
            return r
    except OverflowError:
        raise VbError(OVERFLOW, "Overflow") from None
    raise VbError(INVALID_CALL, f"unknown operator {op}")


def vb_compare(op, a, b):
    if a is NULL or b is NULL:
        return NULL
    if isinstance(a, list) or isinstance(b, list):
        raise VbError(TYPE_MISMATCH, "Type mismatch")
    if isinstance(a, str) and isinstance(b, str):
        x, y = a, b
    elif isinstance(a, datetime) and isinstance(b, datetime):
        x, y = a, b
    elif is_numeric(a) and is_numeric(b):
        x, y = to_num(a), to_num(b)
    elif isinstance(a, str) or isinstance(b, str):
        x, y = to_str(a), to_str(b)
    else:
        x, y = to_num(a), to_num(b)
    return {"=": x == y, "<>": x != y, "<": x < y, ">": x > y, "<=": x <= y, ">=": x >= y}[op]


def vb_logic(op, a, b):
    if isinstance(a, bool) and isinstance(b, bool):
        return {"and": a and b, "or": a or b, "xor": a != b, "eqv": a == b, "imp": (not a) or b}[op]
    if a is NULL or b is NULL:
        if op == "and" and (a is False or b is False):
            return False
        if op == "or" and (a is True or b is True):
            return True
        return NULL
    x, y = to_int(a), to_int(b)
    return {"and": x & y, "or": x | y, "xor": x ^ y, "eqv": ~(x ^ y), "imp": (~x) | y}[op]


# ------------------------------------------------------------------ objects
class VbDict:
    """Scripting.Dictionary (binary compare = case-sensitive unless CompareMode = 1)."""

    def __init__(self):
        self.d: dict = {}
        self.compare_mode = 0

    def _k(self, k):
        k = to_str(k) if not isinstance(k, (int, float)) or isinstance(k, bool) else k
        return k.casefold() if self.compare_mode == 1 and isinstance(k, str) else k

    def vb_call(self, name, args):
        n = name.casefold()
        if n == "add":
            k = self._k(args[0])
            if k in self.d:
                raise VbError(KEY_EXISTS, "This key is already associated with an element of this collection")
            self.d[k] = (args[0], args[1])
            return EMPTY
        if n == "exists":
            return self._k(args[0]) in self.d
        if n == "item":
            k = self._k(args[0])
            return self.d[k][1] if k in self.d else EMPTY
        if n == "remove":
            k = self._k(args[0])
            if k not in self.d:
                raise VbError(32811, "Element not found")
            del self.d[k]
            return EMPTY
        if n == "removeall":
            self.d.clear()
            return EMPTY
        if n == "count":
            return len(self.d)
        if n == "keys":
            return [orig for orig, _ in self.d.values()]
        if n == "items":
            return [v for _, v in self.d.values()]
        if n == "comparemode":
            return self.compare_mode
        raise VbError(NO_MEMBER, f"Object doesn't support this property or method: '{name}'")

    def vb_set(self, name, value, args=()):
        n = name.casefold()
        if n == "item":
            k = self._k(args[0])
            self.d[k] = (self.d[k][0] if k in self.d else args[0], value)
        elif n == "key":
            old, new = self._k(args[0]), self._k(value)
            self.d[new] = (value, self.d.pop(old)[1])
        elif n == "comparemode":
            self.compare_mode = to_int(value)
        else:
            raise VbError(NO_MEMBER, f"Object doesn't support this property or method: '{name}'")

    def vb_iter(self):
        return [orig for orig, _ in self.d.values()]


class VbMatch:
    def __init__(self, m):
        self.m = m

    def vb_call(self, name, args):
        n = name.casefold()
        if n == "value":
            return self.m.group(0)
        if n == "firstindex":
            return self.m.start()
        if n == "length":
            return self.m.end() - self.m.start()
        if n == "submatches":
            return [g if g is not None else EMPTY for g in self.m.groups()] if not args else \
                (self.m.group(to_int(args[0]) + 1) or "")
        raise VbError(NO_MEMBER, f"Object doesn't support this property or method: '{name}'")


class VbRegExp:
    MAX_PATTERN, MAX_TEXT = 500, 200_000

    def __init__(self):
        self.pattern, self.ignore_case, self.is_global, self.multiline = "", False, False, False

    def _rx(self):
        if len(self.pattern) > self.MAX_PATTERN:
            raise VbError(INVALID_CALL, "Regular expression is too long")
        flags = (re.I if self.ignore_case else 0) | (re.M if self.multiline else 0)
        try:
            return re.compile(self.pattern, flags)
        except re.error as exc:
            raise VbError(5017, f"Syntax error in regular expression: {exc}") from None

    def vb_call(self, name, args):
        n = name.casefold()
        if n in ("pattern", "ignorecase", "global", "multiline"):
            return {"pattern": self.pattern, "ignorecase": self.ignore_case, "global": self.is_global,
                    "multiline": self.multiline}[n]
        text = to_str(args[0]) if args else ""
        if len(text) > self.MAX_TEXT:
            raise VbError(INVALID_CALL, "Input is too long for the regular-expression engine")
        if n == "test":
            return self._rx().search(text) is not None
        if n == "execute":
            rx = self._rx()
            found = list(rx.finditer(text)) if self.is_global else [m for m in [rx.search(text)] if m]
            return [VbMatch(m) for m in found]
        if n == "replace":
            rep = re.sub(r"\$(\d)", r"\\\1", to_str(args[1]))
            return self._rx().sub(rep, text, count=0 if self.is_global else 1)
        raise VbError(NO_MEMBER, f"Object doesn't support this property or method: '{name}'")

    def vb_set(self, name, value, args=()):
        n = name.casefold()
        if n == "pattern":
            self.pattern = to_str(value)
        elif n == "ignorecase":
            self.ignore_case = to_bool(value)
        elif n == "global":
            self.is_global = to_bool(value)
        elif n == "multiline":
            self.multiline = to_bool(value)
        else:
            raise VbError(NO_MEMBER, f"Object doesn't support this property or method: '{name}'")


class ErrObject:
    def __init__(self):
        self.clear()

    def clear(self):
        self.number, self.description, self.source = 0, "", ""

    def set(self, e: VbError):
        self.number, self.description, self.source = e.number, e.description, e.source

    def vb_call(self, name, args):
        n = name.casefold()
        if n == "number":
            return self.number
        if n == "description":
            return self.description
        if n == "source":
            return self.source
        if n == "clear":
            self.clear()
            return EMPTY
        if n == "raise":
            raise VbError(to_int(args[0]), to_str(args[2]) if len(args) > 2 and args[2] is not None else "Application-defined or object-defined error",
                          to_str(args[1]) if len(args) > 1 and args[1] is not None else "VisionAuto")
        raise VbError(NO_MEMBER, f"Object doesn't support this property or method: '{name}'")

    def vb_set(self, name, value, args=()):
        n = name.casefold()
        if n == "number":
            self.number = to_int(value)
        elif n == "description":
            self.description = to_str(value)
        elif n == "source":
            self.source = to_str(value)
        else:
            raise VbError(NO_MEMBER, f"Object doesn't support this property or method: '{name}'")


def create_object(prog_id: str):
    low = prog_id.casefold()
    if low == "scripting.dictionary":
        return VbDict()
    if low == "vbscript.regexp":
        return VbRegExp()
    raise VbError(BLOCKED, f"ActiveX component can't create object: '{prog_id}' (blocked: VisionAuto only provides "
                           "Scripting.Dictionary and VBScript.RegExp; use Environment/DataTable/Parameter for I/O)")


# ------------------------------------------------------------------ type names
def type_name(v) -> str:
    if v is EMPTY:
        return "Empty"
    if v is NULL:
        return "Null"
    if v is NOTHING:
        return "Nothing"
    if isinstance(v, bool):
        return "Boolean"
    if isinstance(v, int):
        return "Integer" if -32768 <= v <= 32767 else "Long"
    if isinstance(v, float):
        return "Double"
    if isinstance(v, str):
        return "String"
    if isinstance(v, datetime):
        return "Date"
    if isinstance(v, list):
        return "Variant()"
    if isinstance(v, VbDict):
        return "Dictionary"
    if isinstance(v, VbRegExp):
        return "IRegExp2"
    return "Object"


def var_type(v) -> int:
    return {"Empty": 0, "Null": 1, "Integer": 2, "Long": 3, "Double": 5, "Date": 7, "String": 8, "Boolean": 11,
            "Variant()": 8204}.get(type_name(v), 9)


# ------------------------------------------------------------------ standard library
_rng = random.Random()


def _mid(s, start, length=None):
    s, start = to_str(s), to_int(start)
    if start < 1:
        raise VbError(INVALID_CALL, "Invalid procedure call or argument")
    if length is None:
        return s[start - 1:]
    n = to_int(length)
    if n < 0:
        raise VbError(INVALID_CALL, "Invalid procedure call or argument")
    return s[start - 1:start - 1 + n]


def _instr(*args):
    if len(args) >= 3 and (isinstance(args[0], (int, float)) and not isinstance(args[0], bool)):
        start, s1, s2 = to_int(args[0]), to_str(args[1]), to_str(args[2])
        cmp_ = to_int(args[3]) if len(args) > 3 and args[3] is not None else 0
    else:
        start, s1, s2 = 1, to_str(args[0]), to_str(args[1])
        cmp_ = to_int(args[2]) if len(args) > 2 and args[2] is not None else 0
    if start < 1:
        raise VbError(INVALID_CALL, "Invalid procedure call or argument")
    if cmp_ == 1:
        s1, s2 = s1.casefold(), s2.casefold()
    if s2 == "":
        return start
    i = s1.find(s2, start - 1)
    return i + 1 if i >= 0 else 0


def _instrrev(s1, s2, start=-1, cmp_=0):
    s1, s2 = to_str(s1), to_str(s2)
    if to_int(cmp_ if cmp_ is not None else 0) == 1:
        s1, s2 = s1.casefold(), s2.casefold()
    end = len(s1) if start is None or to_int(start) == -1 else to_int(start)
    i = s1.rfind(s2, 0, end + len(s2) - 1 if s2 else end)
    return i + 1 if i >= 0 else 0


def _replace(s, find, rep, start=1, count=-1, cmp_=0):
    s, find, rep = to_str(s), to_str(find), to_str(rep)
    start = 1 if start is None else to_int(start)
    count = -1 if count is None else to_int(count)
    if find == "":
        return s
    flags = re.I if (cmp_ is not None and to_int(cmp_) == 1) else 0
    tail = s[max(0, start - 1):]
    # VBScript returns only the part of the string from ``start`` onwards
    return re.sub(re.escape(find), lambda m: rep, tail, count=0 if count < 0 else count, flags=flags)


def _split(s, delim=" ", count=-1, cmp_=0):
    s = to_str(s)
    delim = " " if delim is None else to_str(delim)
    count = -1 if count is None else to_int(count)
    if s == "":
        return []
    parts = s.split(delim) if delim else [s]
    if count > 0 and len(parts) > count:
        parts = parts[:count - 1] + [delim.join(parts[count - 1:])]
    return parts


def _join(arr, delim=" "):
    if not isinstance(arr, list):
        raise VbError(TYPE_MISMATCH, "Type mismatch")
    return ("" if delim is None else to_str(delim)).join(to_str(x) for x in arr)


def _ubound(arr, dim=1):
    if not isinstance(arr, list):
        raise VbError(TYPE_MISMATCH, "Type mismatch")
    cur = arr
    for _ in range(max(0, to_int(dim) - 1)):
        if not cur or not isinstance(cur[0], list):
            raise VbError(SUBSCRIPT, "Subscript out of range")
        cur = cur[0]
    return len(cur) - 1


def _round(n, digits=0):
    n, d = to_num(n), 0 if digits is None else to_int(digits)
    q = 10 ** d
    r = round(n * q) / q
    return int(r) if d <= 0 and r == int(r) else r


def _cint(v):
    n = to_int(v)
    if not -32768 <= n <= 32767:
        raise VbError(OVERFLOW, "Overflow")
    return n


def _clng(v):
    n = to_int(v)
    if not -2147483648 <= n <= 2147483647:
        raise VbError(OVERFLOW, "Overflow")
    return n


def _cdate(v):
    if isinstance(v, datetime):
        return v
    s = to_str(v).strip()
    for fmt in ("%m/%d/%Y %I:%M:%S %p", "%m/%d/%Y %H:%M:%S", "%m/%d/%Y", "%Y-%m-%d %H:%M:%S", "%Y-%m-%d", "%H:%M:%S", "%I:%M:%S %p"):
        try:
            return datetime.strptime(s, fmt)
        except ValueError:
            continue
    raise VbError(TYPE_MISMATCH, "Type mismatch")


def _dateadd(interval, number, d):
    d, n, i = _cdate(d), to_int(number), to_str(interval).casefold()
    if i == "yyyy":
        try:
            return d.replace(year=d.year + n)
        except ValueError:
            return d.replace(year=d.year + n, day=28)
    if i == "m":
        total = d.year * 12 + d.month - 1 + n
        y, m = divmod(total, 12)
        day = min(d.day, [31, 29 if y % 4 == 0 and (y % 100 or y % 400 == 0) else 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][m])
        return d.replace(year=y, month=m + 1, day=day)
    delta = {"d": timedelta(days=n), "y": timedelta(days=n), "w": timedelta(days=n), "ww": timedelta(weeks=n),
             "h": timedelta(hours=n), "n": timedelta(minutes=n), "s": timedelta(seconds=n)}.get(i)
    if delta is None:
        raise VbError(INVALID_CALL, "Invalid procedure call or argument")
    return d + delta


def _datediff(interval, d1, d2):
    a, b, i = _cdate(d1), _cdate(d2), to_str(interval).casefold()
    if i == "yyyy":
        return b.year - a.year
    if i == "m":
        return (b.year - a.year) * 12 + b.month - a.month
    secs = (b - a).total_seconds()
    div = {"d": 86400, "y": 86400, "w": 86400, "ww": 604800, "h": 3600, "n": 60, "s": 1}.get(i)
    if div is None:
        raise VbError(INVALID_CALL, "Invalid procedure call or argument")
    return int(secs // div) if secs >= 0 else -int((-secs) // div)


def _format_number(v, digits=-1, lead=-2, paren=-2, group=-2):
    n = to_num(v)
    d = 2 if digits is None or to_int(digits) < 0 else to_int(digits)
    grouped = group is None or to_int(group) != 0          # -2 / -1 = default (grouping on), 0 = off
    s = f"{abs(n):,.{d}f}" if grouped else f"{abs(n):.{d}f}"
    return ("-" if n < 0 else "") + s


def _filter(arr, value, include=True, cmp_=0):
    inc = True if include is None else to_bool(include)
    ci = cmp_ is not None and to_int(cmp_) == 1
    needle = to_str(value)
    return [x for x in arr if ((needle.casefold() in to_str(x).casefold()) if ci else (needle in to_str(x))) == inc]


def _chr(n):
    n = to_int(n)
    if not 0 <= n <= 0x10FFFF:
        raise VbError(INVALID_CALL, "Invalid procedure call or argument")
    return chr(n)


def _weekday(d, first=1):
    wd = (_cdate(d).weekday() + 1) % 7 + 1     # Sunday = 1
    return wd


FUNCTIONS = {
    "len": lambda s: len(to_str(s)),
    "left": lambda s, n: to_str(s)[:to_int(n)],
    "right": lambda s, n: to_str(s)[-to_int(n):] if to_int(n) > 0 else "",
    "mid": _mid,
    "ucase": lambda s: to_str(s).upper(),
    "lcase": lambda s: to_str(s).lower(),
    "trim": lambda s: to_str(s).strip(" "),
    "ltrim": lambda s: to_str(s).lstrip(" "),
    "rtrim": lambda s: to_str(s).rstrip(" "),
    "instr": _instr,
    "instrrev": _instrrev,
    "replace": _replace,
    "space": lambda n: " " * to_int(n),
    "string": lambda n, c: (to_str(c)[:1] if isinstance(c, str) else chr(to_int(c))) * to_int(n),
    "strcomp": lambda a, b, m=0: (lambda x, y: (x > y) - (x < y))(*( (to_str(a).casefold(), to_str(b).casefold()) if m is not None and to_int(m) == 1 else (to_str(a), to_str(b)))),
    "strreverse": lambda s: to_str(s)[::-1],
    "chr": _chr, "chrw": _chr,
    "asc": lambda s: ord(to_str(s)[0]) if to_str(s) else (_ for _ in ()).throw(VbError(INVALID_CALL, "Invalid procedure call or argument")),
    "cstr": lambda v: to_str(v),
    "cint": _cint, "clng": _clng,
    "cdbl": lambda v: float(to_num(v)), "csng": lambda v: float(to_num(v)),
    "cbool": to_bool, "cdate": _cdate, "cbyte": lambda v: to_int(v),
    "int": lambda v: math.floor(to_num(v)), "fix": lambda v: math.trunc(to_num(v)),
    "abs": lambda v: abs(to_num(v)),
    "sqr": lambda v: math.sqrt(to_num(v)) if to_num(v) >= 0 else (_ for _ in ()).throw(VbError(INVALID_CALL, "Invalid procedure call or argument")),
    "round": _round,
    "sgn": lambda v: (to_num(v) > 0) - (to_num(v) < 0),
    "hex": lambda v: format(to_int(v), "X"), "oct": lambda v: format(to_int(v), "o"),
    "exp": lambda v: math.exp(to_num(v)), "log": lambda v: math.log(to_num(v)),
    "sin": lambda v: math.sin(to_num(v)), "cos": lambda v: math.cos(to_num(v)),
    "tan": lambda v: math.tan(to_num(v)), "atn": lambda v: math.atan(to_num(v)),
    "rnd": lambda *a: _rng.random(),
    "randomize": lambda *a: EMPTY,
    "isnumeric": lambda v: is_numeric(v) and v is not EMPTY,
    "isempty": lambda v: v is EMPTY, "isnull": lambda v: v is NULL,
    "isobject": lambda v: v is NOTHING or not isinstance(v, (str, int, float, bool, list, datetime, _Singleton)),
    "isarray": lambda v: isinstance(v, list),
    "isdate": lambda v: (lambda: (_cdate(v), True)[1])() if isinstance(v, (str, datetime)) and _safe(lambda: _cdate(v)) else False,
    "typename": type_name, "vartype": var_type,
    "array": lambda *a: list(a),
    "ubound": _ubound, "lbound": lambda a, d=1: 0,
    "split": _split, "join": _join, "filter": _filter,
    "now": lambda: datetime.now().replace(microsecond=0),
    "date": lambda: datetime.now().replace(hour=0, minute=0, second=0, microsecond=0),
    "time": lambda: datetime(1899, 12, 30).replace(hour=datetime.now().hour, minute=datetime.now().minute, second=datetime.now().second),
    "timer": lambda: (lambda n: n.hour * 3600 + n.minute * 60 + n.second + n.microsecond / 1e6)(datetime.now()),
    "year": lambda d: _cdate(d).year, "month": lambda d: _cdate(d).month, "day": lambda d: _cdate(d).day,
    "hour": lambda d: _cdate(d).hour, "minute": lambda d: _cdate(d).minute, "second": lambda d: _cdate(d).second,
    "weekday": _weekday, "dateadd": _dateadd, "datediff": _datediff,
    "monthname": lambda m, abbr=False: datetime(2000, to_int(m), 1).strftime("%b" if abbr and to_bool(abbr) else "%B"),
    "weekdayname": lambda w, abbr=False, first=1: ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"][(to_int(w) - 1) % 7][:3 if abbr and to_bool(abbr) else None],
    "formatnumber": _format_number,
    "formatpercent": lambda v, d=2, *a: f"{to_num(v) * 100:.{2 if d is None else to_int(d)}f}%",
    "formatcurrency": lambda v, d=2, *a: ("-" if to_num(v) < 0 else "") + f"${abs(to_num(v)):,.{2 if d is None else to_int(d)}f}",
    "createobject": lambda p, *a: create_object(to_str(p)),
}


def _safe(fn) -> bool:
    try:
        fn()
        return True
    except VbError:
        return False


CONSTANTS = {
    "vbcrlf": "\r\n", "vbcr": "\r", "vblf": "\n", "vbnewline": "\r\n", "vbtab": "\t", "vbnullstring": "",
    "vbnullchar": "\x00", "vbformfeed": "\f", "vbverticaltab": "\v", "vbback": "\b",
    "true": True, "false": False, "empty": EMPTY, "null": NULL, "nothing": NOTHING,
    "vbbinarycompare": 0, "vbtextcompare": 1, "vbokonly": 0, "vbyes": 6, "vbno": 7, "vbok": 1, "vbcancel": 2,
    "vbinformation": 64, "vbexclamation": 48, "vbcritical": 16, "vbquestion": 32, "vbyesno": 4, "vbokcancel": 1,
    "vbsunday": 1, "vbmonday": 2, "vbusesystemdayofweek": 0,
    "vbempty": 0, "vbnull": 1, "vbinteger": 2, "vblong": 3, "vbdouble": 5, "vbdate": 7, "vbstring": 8,
    "vbboolean": 11, "vbarray": 8192,
    # UFT
    "micpass": 0, "micfail": 1, "micdone": 2, "micwarning": 3,
    "micleftbtn": 0, "micmiddlebtn": 1, "micrightbtn": 2,
    "micreturn": "{ENTER}", "mictab": "{TAB}", "micesc": "{ESC}", "micbackspace": "{BACKSPACE}",
    "micdel": "{DELETE}", "micup": "{UP}", "micdown": "{DOWN}", "micleft": "{LEFT}", "micright": "{RIGHT}",
    "michome": "{HOME}", "micend": "{END}", "micpgup": "{PGUP}", "micpgdwn": "{PGDN}",
    "micf1": "{F1}", "micf2": "{F2}", "micf3": "{F3}", "micf4": "{F4}", "micf5": "{F5}", "micf6": "{F6}",
    "micf7": "{F7}", "micf8": "{F8}", "micf9": "{F9}", "micf10": "{F10}", "micf11": "{F11}", "micf12": "{F12}",
    "dtglobalsheet": "Global", "dtlocalsheet": "Action",
    "onoff_dummy": 0, "oneiteration": 0, "alliterations": 1, "onerroriteration": 2,
    "stoprun": 0, "nextiteration": 1, "stoprunexit": 2,
}
