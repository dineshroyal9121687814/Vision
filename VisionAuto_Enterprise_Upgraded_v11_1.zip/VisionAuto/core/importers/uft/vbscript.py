"""Conservative translator for a documented UFT VBScript subset."""
from __future__ import annotations

import re
from dataclasses import dataclass, field

from core.ai.describe import describe_step
from core.importers.uft.object_repository import find_object

CLASS_ROLES = {
    "button": "Button", "webbutton": "Button", "winbutton": "Button",
    "edit": "Edit", "webedit": "Edit", "winedit": "Edit", "textbox": "Edit",
    "link": "Hyperlink", "weblink": "Hyperlink", "checkbox": "CheckBox",
    "webcheckbox": "CheckBox", "radiobutton": "RadioButton", "webradiogroup": "RadioButton",
    "list": "ComboBox", "weblist": "ComboBox", "combobox": "ComboBox",
    "webtable": "Table", "webelement": "Custom", "image": "Image", "webimage": "Image",
}
CONTROL_KINDS = {"button", "webbutton", "winbutton", "edit", "webedit", "winedit", "textbox",
                 "link", "weblink", "checkbox", "webcheckbox", "radiobutton", "webradiogroup",
                 "list", "weblist", "combobox", "webtable", "webelement", "image", "webimage"}
OBJECT_RE = re.compile(r'([A-Za-z_]\w*)\(\s*"((?:[^"]|"")*)"\s*\)', re.I)
PARAM_RE = re.compile(r'^(?:Parameter|DataTable\.Value)\(\s*"((?:[^"]|"")*)"(?:\s*,\s*(?:"((?:[^"]|"")*)"|([A-Za-z_]\w*)))?\s*\)$', re.I)


def _unquote(value: str) -> str | None:
    value = value.strip()
    if len(value) < 2 or value[0] != '"' or value[-1] != '"':
        return None
    return value[1:-1].replace('""', '"')


def _split_args(value: str) -> list[str]:
    out, current = [], []
    quoted = False
    depth = 0
    i = 0
    while i < len(value):
        ch = value[i]
        if ch == '"':
            current.append(ch)
            if quoted and i + 1 < len(value) and value[i + 1] == '"':
                current.append('"')
                i += 1
            else:
                quoted = not quoted
        elif not quoted and ch == "(":
            depth += 1
            current.append(ch)
        elif not quoted and ch == ")":
            depth = max(0, depth - 1)
            current.append(ch)
        elif ch == "," and not quoted and depth == 0:
            out.append("".join(current).strip())
            current = []
        else:
            current.append(ch)
        i += 1
    if current or value.strip():
        out.append("".join(current).strip())
    return out


def _resolve_value(expr: str, parameters: dict) -> tuple[str | None, str | None]:
    literal = _unquote(expr)
    if literal is not None:
        return literal, None
    m = PARAM_RE.match(expr.strip())
    if m:
        name = m.group(1).replace('""', '"')
        sheet = (m.group(2) or m.group(3) or "").replace('""', '"')
        keys = [f"{sheet}.{name}" if sheet else "", name]
        for key in keys:
            if key and key in parameters:
                return str(parameters[key]), None
        return None, f"Unresolved input parameter {name!r}; supply it in the import parameter mapping."
    return None, f"Unsupported VBScript value expression: {expr.strip()}"


@dataclass
class UFTConversion:
    steps: list[dict] = field(default_factory=list)
    converted: list[dict] = field(default_factory=list)
    unsupported: list[dict] = field(default_factory=list)
    assumptions: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    parameters_used: list[str] = field(default_factory=list)

    def report(self, source_name: str) -> dict:
        return {
            "schema": "visionauto.migration-report/1",
            "source_platform": "UFT/VBScript",
            "source_file": source_name,
            "converted_count": len(self.converted),
            "unsupported_count": len(self.unsupported),
            "converted_operations": self.converted,
            "unsupported_constructs": self.unsupported,
            "parameters_used": sorted(set(self.parameters_used)),
            "assumptions": list(dict.fromkeys(self.assumptions)),
            "warnings": list(dict.fromkeys(self.warnings)),
            "manual_review_required": bool(self.unsupported or self.warnings or self.assumptions),
            "runtime_requirement": "Converted native steps run on the VisionAuto engine. Unconverted UFT operations require UFT One and manual migration.",
        }


def _target(control_name: str, chain: list[tuple[str, str]], repo: dict[str, dict], conv: UFTConversion) -> tuple[dict, dict]:
    names = [value.replace('""', '"') for _, value in chain]
    obj = find_object(repo, names)
    leaf = names[-1] if names else control_name
    props = obj.get("properties", {}) if obj else {}
    uft_class = (obj.get("class") if obj else "") or control_name
    role = CLASS_ROLES.get(uft_class.casefold(), CLASS_ROLES.get(control_name.casefold()))
    automation_id = props.get("htmlid") or props.get("automationid") or props.get("id") or ""
    name = props.get("name") or props.get("htmlname") or props.get("text") or leaf
    text = props.get("text")
    target = {"x": 0, "y": 0, "name": name, "source_locator": {"kind": "uft", "path": ".".join(names)}}
    if role:
        target["role"] = role
    if automation_id:
        target["automation_id"] = automation_id
    if text:
        target["text"] = text
    if props.get("class"):
        target["class_name"] = props["class"]
    if not obj:
        conv.assumptions.append(f"Object {'.'.join(names)!r} was not found in the supplied XML repository; the logical control name is used as a locator hint.")
    roots = [(kind.casefold(), value.replace('""', '"')) for kind, value in chain if kind.casefold() in {"browser", "window", "dialog", "swfwindow"}]
    window = {"title": roots[0][1] if roots else "", "process": ""}
    return target, window


def _step(conv: UFTConversion, line_no: int, source_name: str, operation: str, kind: str,
          target: dict | None = None, window: dict | None = None, params: dict | None = None,
          check: dict | None = None) -> None:
    step = {"id": len(conv.steps) + 1, "type": kind, "t_ms": 0, "window": window or {},
            "validations": [], "source": {"file": source_name, "line": line_no}}
    if target:
        step["target"] = target
    if params:
        step["params"] = params
    if check:
        step["check"] = check
    step["description"] = describe_step(step)
    conv.steps.append(step)
    conv.converted.append({"source_line": line_no, "operation": operation, "step_id": step["id"], "action": kind})


def convert_script(script: str, source_name: str = "test.vbs", object_repository: dict | None = None,
                   parameters: dict | None = None) -> UFTConversion:
    """Convert supported one-line UFT object calls to ``visionauto.test/2`` steps.

    Supported: Click, Set, Type, Exist, Sync and selected CheckProperty calls
    for common Web/Windows controls. Control flow, functions, loops, data-table
    expressions without supplied values, and unrecognized calls are reported.
    """
    conv = UFTConversion()
    repo, values = object_repository or {}, parameters or {}
    lines = script.splitlines()
    unsupported_block: str | None = None
    for line_no, raw in enumerate(lines, 1):
        line = raw.strip()
        if not line or line.startswith("'") or line.startswith("Rem "):
            continue
        if unsupported_block:
            closer = {"if": r"^End\s+If\b", "for": r"^Next\b", "do": r"^Loop\b",
                      "while": r"^Wend\b", "select": r"^End\s+Select\b",
                      "procedure": r"^End\s+(?:Sub|Function)\b"}[unsupported_block]
            if re.match(closer, line, re.I):
                conv.unsupported.append({"source_line": line_no, "construct": line,
                                         "reason": "End of unsupported control-flow/procedure block."})
                unsupported_block = None
            else:
                conv.unsupported.append({"source_line": line_no, "construct": line,
                                         "reason": f"Statement is inside unsupported {unsupported_block} control flow."})
            continue
        if line.startswith("#") or line.startswith("Option Explicit") or line.casefold() in {"end if", "end sub", "end function", "else"}:
            if line.casefold() in {"end if", "end sub", "end function", "else"}:
                conv.unsupported.append({"source_line": line_no, "construct": line, "reason": "Control flow and procedure boundaries are not executable in the static step runner."})
            continue
        control = re.match(r"^(If|For|For Each|Do|While|Select Case|Function|Sub)\b", line, re.I)
        if control:
            head = control.group(1).casefold()
            if head == "if" and re.search(r"\bThen\s*\S", line, re.I):
                block = None  # single-line If: the whole statement stays unsupported
            else:
                block = ("if" if head == "if" else "for" if head.startswith("for") else
                         "do" if head == "do" else "while" if head == "while" else
                         "select" if head == "select case" else "procedure")
                unsupported_block = block
            conv.unsupported.append({"source_line": line_no, "construct": line, "reason": "Control flow or procedure declaration is outside the supported straight-line subset."})
            continue
        if re.match(r"^(ElseIf|Else|Loop|Next|Wend|Case|End\s+(If|Select|Sub|Function))\b", line, re.I):
            conv.unsupported.append({"source_line": line_no, "construct": line, "reason": "Control-flow boundary is not supported."})
            continue

        objects = [(m.group(1), m.group(2)) for m in OBJECT_RE.finditer(line)]
        control_idx = next((i for i, (kind, _) in enumerate(objects) if kind.casefold() in CONTROL_KINDS), None)
        if control_idx is None:
            # Recognize UFT input expressions and startup statements as explicit limitations.
            reason = "No supported UFT object action/checkpoint was recognized."
            conv.unsupported.append({"source_line": line_no, "construct": line, "reason": reason})
            continue
        control_name, _ = objects[control_idx]
        chain = objects[:control_idx + 1]
        # The action follows the final object call, so locate that exact occurrence.
        matches = list(OBJECT_RE.finditer(line))
        tail = line[matches[control_idx].end():].strip()
        call = re.match(r"^\.\s*([A-Za-z_]\w*)\s*(.*)$", tail)
        if not call:
            conv.unsupported.append({"source_line": line_no, "construct": line, "reason": "Object reference has no recognized method call."})
            continue
        method, args_text = call.group(1).casefold(), call.group(2).strip()
        args_text = args_text.removesuffix(";").strip()
        if args_text.startswith("(") and args_text.endswith(")"):
            args_text = args_text[1:-1].strip()
        args = _split_args(args_text) if args_text else []
        target, window = _target(control_name, chain, repo, conv)
        operation = f"{control_name}.{method}"

        if method == "click" and not args:
            _step(conv, line_no, source_name, operation, "click", target, window, {"button": "left"})
        elif method in {"set", "type"} and len(args) == 1:
            value, err = _resolve_value(args[0], values)
            parameter_match = PARAM_RE.match(args[0].strip())
            if parameter_match:
                conv.parameters_used.append(parameter_match.group(1).replace('""', '"'))
            if err:
                conv.unsupported.append({"source_line": line_no, "construct": line, "reason": err})
                continue
            # UFT Set operates on the named control. VisionAuto types through
            # the active input backend, so explicitly focus it; Set also
            # replaces the old field contents before typing.
            _step(conv, line_no, source_name, operation, "click", target, window, {"button": "left"})
            if method == "set":
                _step(conv, line_no, source_name, operation, "hotkey", window=window, params={"keys": "ctrl+a"})
            _step(conv, line_no, source_name, operation, "type", window=window, params={"text": value})
        elif method == "exist" and (not args or len(args) == 1):
            timeout = 10.0
            if args:
                try:
                    timeout = max(0.0, float(args[0]))
                except ValueError:
                    conv.unsupported.append({"source_line": line_no, "construct": line, "reason": "Exist timeout must be a numeric literal."})
                    continue
            _step(conv, line_no, source_name, operation, "validate", target, window,
                  check={"type": "element_exists", "timeout_s": timeout})
        elif method == "sync" and not args:
            _step(conv, line_no, source_name, operation, "validate", target, window,
                  check={"type": "element_exists", "timeout_s": 10.0})
            conv.assumptions.append("UFT Sync was translated to a 10-second element-exists wait.")
        elif method == "checkproperty" and len(args) >= 2:
            prop = _unquote(args[0])
            expected = _unquote(args[1])
            if expected is None and args[1].strip().casefold() in {"true", "false"}:
                expected = args[1].strip().casefold()
            if prop is None or expected is None:
                conv.unsupported.append({"source_line": line_no, "construct": line, "reason": "CheckProperty requires literal property and expected-value strings in this importer."})
                continue
            if prop.casefold() in {"text", "innertext", "value", "title"}:
                check = {"type": "text_equals", "expected": expected}
            elif prop.casefold() in {"visible", "exist"} and expected.casefold() in {"true", "false"}:
                check = {"type": "element_exists" if expected.casefold() == "true" else "element_not_exists"}
            else:
                conv.unsupported.append({"source_line": line_no, "construct": line, "reason": f"CheckProperty for {prop!r} is not supported."})
                continue
            _step(conv, line_no, source_name, operation, "validate", target, window, check=check)
        elif method == "waitproperty" and len(args) >= 2:
            prop, expected = _unquote(args[0]), _unquote(args[1])
            if expected is None and args[1].strip().casefold() in {"true", "false"}:
                expected = args[1].strip().casefold()
            if prop and prop.casefold() in {"visible", "exist"} and expected and expected.casefold() in {"true", "false"}:
                check = {"type": "element_exists" if expected.casefold() == "true" else "element_not_exists"}
                _step(conv, line_no, source_name, operation, "validate", target, window, check=check)
                conv.assumptions.append("WaitProperty timeout/interval options are not preserved; VisionAuto's validation timeout applies.")
            else:
                conv.unsupported.append({"source_line": line_no, "construct": line, "reason": "Only Visible/Exist boolean WaitProperty checks are supported."})
        else:
            conv.unsupported.append({"source_line": line_no, "construct": line, "reason": f"Method {method!r} is outside the supported UFT subset."})

    if not conv.steps and not conv.unsupported:
        conv.warnings.append("No executable operations were found in the source file.")
    return conv
