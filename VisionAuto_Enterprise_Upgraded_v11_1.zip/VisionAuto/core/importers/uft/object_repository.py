"""Reader for XML exports of UFT object repositories.

Native UFT ``.tsr`` repositories are binary and are deliberately not parsed
here. Export them to XML first; unsupported repository formats are reported.
"""
from __future__ import annotations

import xml.etree.ElementTree as ET
from pathlib import Path


def _local(tag: str) -> str:
    return tag.rsplit("}", 1)[-1].casefold()


def _value(node: ET.Element) -> str:
    if node.text and node.text.strip():
        return node.text.strip()
    for child in node:
        if _local(child.tag) in {"value", "val", "propertyvalue"} and child.text:
            return child.text.strip()
    return ""


def _properties(node: ET.Element) -> dict[str, str]:
    props: dict[str, str] = {}

    def visit(current: ET.Element, is_root: bool = False) -> None:
        tag = _local(current.tag)
        # A repository object must not inherit properties from child objects.
        if not is_root and tag in {"object", "testobject", "objectnode", "browser", "page", "dialog", "window"}:
            return
        name = (current.attrib.get("name") or current.attrib.get("Name") or
                current.attrib.get("property") or current.attrib.get("Property") or "")
        if tag in {"property", "item", "attribute"} and name:
            value = _value(current)
            if value:
                props[name.casefold().replace(" ", "")] = value
        for child in current:
            visit(child)

    visit(node, is_root=True)
    for key, value in node.attrib.items():
        if key.casefold() not in {"name", "id"} and value.strip():
            props.setdefault(key.casefold().replace(" ", ""), value.strip())
    return props


def parse_xml_repository(path: str | Path) -> tuple[dict[str, dict], list[str]]:
    """Return named XML objects and diagnostics.

    The parser intentionally accepts common XML exports rather than claiming
    compatibility with UFT's binary ``.tsr`` format.
    """
    source = Path(path)
    try:
        raw_content = source.read_text(encoding="utf-8", errors="replace")
        if "<!ENTITY" in raw_content.upper():
            raise ValueError(f"Suspicious XML entity declarations detected in '{source}'")
        parser = ET.XMLParser()
        root = ET.fromstring(raw_content, parser=parser)
    except (OSError, ET.ParseError, ValueError) as exc:
        raise ValueError(f"Could not read UFT XML object repository '{source}': {exc}") from exc

    objects: dict[str, dict] = {}
    leaf_keys: dict[str, dict] = {}
    ambiguous_leaves: set[str] = set()

    def visit(node: ET.Element, parents: tuple[str, ...]) -> None:
        name = node.attrib.get("name") or node.attrib.get("Name") or ""
        lname = _local(node.tag)
        segment = name.strip() if name.strip() else ""
        path_parts = parents + ((segment,) if segment else ())
        props = _properties(node)
        class_name = (props.get("micclass") or props.get("class") or
                      props.get("controltype") or node.attrib.get("micclass") or "")
        if segment and (props or class_name or lname in {"object", "testobject", "objectnode", "webelement"}):
            entry = {
                "name": segment,
                "path": ".".join(path_parts),
                "class": class_name,
                "properties": props,
            }
            objects[entry["path"].casefold()] = entry
            leaf_key = segment.casefold()
            previous = leaf_keys.get(leaf_key)
            if previous and previous["path"] != entry["path"]:
                ambiguous_leaves.add(leaf_key)
            else:
                leaf_keys[leaf_key] = entry
        for child in node:
            visit(child, path_parts)

    visit(root, ())
    for key, entry in leaf_keys.items():
        if key not in ambiguous_leaves:
            objects[key] = entry
    diagnostics = []
    if not objects:
        diagnostics.append("The XML contained no named objects with recognizable properties.")
    diagnostics.append("Native binary UFT .tsr repositories are not supported; only XML exports are read.")
    return objects, diagnostics


def find_object(repository: dict[str, dict], names: list[str]) -> dict | None:
    """Resolve a chain by full path first, then by an unambiguous leaf name."""
    if not names:
        return None
    keys = [".".join(names).casefold(), names[-1].casefold()]
    for key in keys:
        obj = repository.get(key)
        if obj:
            return obj
    leaf = names[-1].casefold()
    matches = {id(obj): obj for key, obj in repository.items()
               if key.endswith("." + leaf) or key == leaf}
    return next(iter(matches.values())) if len(matches) == 1 else None
