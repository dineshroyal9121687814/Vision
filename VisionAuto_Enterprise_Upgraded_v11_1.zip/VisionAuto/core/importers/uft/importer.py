"""Persist a UFT conversion as a normal VisionAuto test plus diagnostics."""
from __future__ import annotations

import json
import re
from pathlib import Path

from core import paths, testfile
from core.importers.uft.object_repository import parse_xml_repository
from core.importers.uft.vbscript import convert_script
from core.importers.uft.vbparse import VbSyntaxError, parse as parse_vbs
from core.importers.uft.runner import AST_SUFFIX, static_check


def import_script(script_path: str | Path, repository_path: str | Path | None = None,
                  name: str | None = None, parameters: dict | None = None,
                  overwrite: bool = False, force_script: bool = False, actions: dict | None = None) -> dict:
    """Import a UFT VBScript.

    * Straight-line scripts (Click/Set/Exist/Sync/CheckProperty only) -> a NATIVE test, exactly as before.
    * Anything with If/For/Do/Select/Sub/Function/variables/DataTable/RunAction -> SCRIPT mode:
      the parsed AST is stored beside the original source and executed by the VisionAuto VBScript
      interpreter on the same engine (``python -m core.importers.uft.cli run ...`` or the Tests page).
    """
    source = Path(script_path)
    script = source.read_text(encoding="utf-8-sig", errors="replace")
    if not force_script:
        probe = convert_script(script, source.name, {}, parameters or {})
        # anything the straight-line converter cannot express runs on the interpreter instead of being dropped
        needs_script = bool(probe.unsupported)
        force_script = needs_script
    if force_script:
        return import_script_mode(source, repository_path, name, parameters, overwrite, actions)
    return _import_native(source, script, repository_path, name, parameters, overwrite)


def import_script_mode(source: Path, repository_path, name, parameters, overwrite, actions: dict | None = None) -> dict:
    script = source.read_text(encoding="utf-8-sig", errors="replace")
    repo: dict = {}
    repo_diag: list[str] = []
    if repository_path:
        repo, repo_diag = parse_xml_repository(repository_path)
    main = parse_vbs(script)
    parsed_actions = {}
    for aname, apath in (actions or {}).items():
        parsed_actions[aname] = parse_vbs(Path(apath).read_text(encoding="utf-8-sig", errors="replace"))
    check = static_check(main, parsed_actions, repo)

    project = testfile.safe_name(name or source.stem)
    out_dir = paths.imported_dir() / project
    out_dir.mkdir(parents=True, exist_ok=True)
    target_script = out_dir / f"{testfile.safe_name(source.stem)}.vbs"
    ast_path = out_dir / f"{testfile.safe_name(source.stem)}{AST_SUFFIX}"
    if (target_script.exists() or ast_path.exists()) and not overwrite:
        raise FileExistsError(f"Imported UFT script already exists at {target_script}; choose another --name or pass overwrite=True.")
    target_script.write_text(script, encoding="utf-8")
    for aname, apath in (actions or {}).items():
        (out_dir / f"{target_script.stem}.action.{testfile.safe_name(aname)}.vbs").write_text(
            Path(apath).read_text(encoding="utf-8-sig", errors="replace"), encoding="utf-8")
    ast_path.write_text(json.dumps({"schema": "visionauto.script/1", "source": source.name, "main": main,
                                    "actions": parsed_actions}, indent=1), encoding="utf-8")
    if repository_path:
        (out_dir / "repository.xml").write_text(Path(repository_path).read_text(encoding="utf-8", errors="replace"), encoding="utf-8")
    report = {
        "schema": "visionauto.migration-report/1", "source_platform": "UFT/VBScript", "source_file": source.name,
        "mode": "script", "converted_count": _count_statements(main, parsed_actions),
        "unsupported_count": len(check["unsupported_constructs"]), "unsupported_constructs": check["unsupported_constructs"],
        "control_flow_blocks": check["control_flow_blocks"], "procedures": check["procedures"],
        "test_object_classes": check["test_object_classes"], "methods_used": check["methods_used"],
        "repository_file": Path(repository_path).name if repository_path else None, "repository_diagnostics": repo_diag,
        "parameters": sorted((parameters or {}).keys()),
        "assumptions": ["Executed by VisionAuto's VBScript interpreter (no UFT, no COM, no cscript). "
                        "Click(x, y) offsets are ignored; the control centre is clicked.",
                        "Binary .tsr / .bdb repositories are not read; export the repository to XML."],
        "manual_review_required": bool(check["unsupported_constructs"]),
        "runtime_requirement": "VisionAuto only. UFT One is not required.",
    }
    report_path = out_dir / f"{target_script.stem}.migration_report.json"
    testfile.write_json_atomic(report_path, report)
    return {"mode": "script", "script": str(target_script), "ast": str(ast_path), "directory": str(out_dir),
            "report": report, "report_path": str(report_path), "test": {"name": project, "steps": []}}


def _count_statements(main: dict, actions: dict) -> int:
    def count(stmts):
        n = 0
        for s in stmts:
            if not isinstance(s, dict):
                continue
            n += s["k"] != "unsupported"
            for key in ("body", "else"):
                if isinstance(s.get(key), list):
                    n += count(s[key])
            for br in s.get("branches", []):
                n += count(br["body"])
            for c in s.get("cases", []):
                n += count(c["body"])
        return n
    total = count(main["body"]) + sum(count(p["body"]) for p in main["procedures"])
    for a in actions.values():
        total += count(a["body"]) + sum(count(p["body"]) for p in a["procedures"])
    return total


def _import_native(source: Path, script: str, repository_path, name, parameters, overwrite) -> dict:
    objects: dict = {}
    repo_diagnostics: list[str] = []
    if repository_path:
        objects, repo_diagnostics = parse_xml_repository(repository_path)
    conv = convert_script(script, source.name, objects, parameters)
    report = conv.report(source.name)
    report["repository_file"] = Path(repository_path).name if repository_path else None
    report["repository_diagnostics"] = repo_diagnostics

    test_name = testfile.safe_name(name or source.stem)
    directory = testfile.test_dir(test_name)
    test_path = directory / "test.json"
    if test_path.exists() and not overwrite:
        raise FileExistsError(f"Test '{test_name}' already exists at {test_path}; choose another --name or pass overwrite=True.")
    test = testfile.new_test(test_name)
    test.update(
        title=source.stem,
        steps=conv.steps,
        source={"type": "uft", "file": source.name,
                "repository_file": Path(repository_path).name if repository_path else None},
        migration={"report": "migration_report.json", "manual_review_required": report["manual_review_required"]},
    )
    first_window = next((step.get("window") for step in conv.steps if step.get("window", {}).get("title")), {})
    test["app"] = dict(first_window)
    directory.mkdir(parents=True, exist_ok=True)
    testfile.save_test(test, directory)
    testfile.write_json_atomic(directory / "migration_report.json", report)
    return {"test": test, "report": report, "directory": str(directory), "test_path": str(test_path),
            "report_path": str(directory / "migration_report.json")}
