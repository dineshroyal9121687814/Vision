"""UFT/VBScript migration CLI.

    python -m core.importers.uft.cli --script Login.vbs --repository OR.xml --name Login [--force-script]
    python -m core.importers.uft.cli run --script workspace/imported/Login/Login.vbs [--data rows.csv] [--dry-run]
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[3]))


def _kv(items: list[str]) -> dict[str, str]:
    out = {}
    for item in items:
        key, sep, value = item.partition("=")
        if not sep or not key.strip():
            raise ValueError(f"Invalid KEY=VALUE argument {item!r}.")
        out[key.strip()] = value
    return out


def _import(argv) -> None:
    from core.importers.uft.importer import import_script

    parser = argparse.ArgumentParser(description="Import a UFT VBScript (control flow, functions, DataTable supported).")
    parser.add_argument("--script", required=True)
    parser.add_argument("--repository", help="XML export of the UFT object repository")
    parser.add_argument("--name")
    parser.add_argument("--parameter", action="append", default=[], metavar="KEY=VALUE")
    parser.add_argument("--force-script", action="store_true", help="always use the VBScript interpreter")
    parser.add_argument("--action", action="append", default=[], metavar="NAME=FILE", help="extra UFT action script")
    parser.add_argument("--overwrite", action="store_true")
    args = parser.parse_args(argv)
    try:
        result = import_script(args.script, args.repository, args.name, _kv(args.parameter), args.overwrite,
                               args.force_script, _kv(args.action) or None)
    except (OSError, ValueError, FileExistsError) as exc:
        parser.error(str(exc))
    report = result["report"]
    mode = result.get("mode", "native")
    print(f"Mode: {mode}; converted: {report.get('converted_count')}; unsupported: {report['unsupported_count']}")
    for issue in report["unsupported_constructs"]:
        print(f"  line {issue['source_line']}: {issue['reason']}")
    print(json.dumps({"report": result["report_path"], "script": result.get("script"), "test": result.get("test_path")}, indent=2))


def _run(argv) -> None:
    from core.importers.uft.runner import run_script

    parser = argparse.ArgumentParser(prog="run")
    parser.add_argument("--script", required=True)
    parser.add_argument("--repository")
    parser.add_argument("--data", help="CSV export of the UFT data table")
    parser.add_argument("--all-iterations", action="store_true")
    parser.add_argument("--parameter", action="append", default=[], metavar="KEY=VALUE")
    parser.add_argument("--env", action="append", default=[], metavar="KEY=VALUE")
    parser.add_argument("--timeout", type=float, default=10.0)
    parser.add_argument("--dry-run", action="store_true")
    a = parser.parse_args(argv)
    run = run_script(a.script, a.repository, {"timeout_s": a.timeout}, dry_run=a.dry_run, data=a.data,
                     parameters=_kv(a.parameter), environment=_kv(a.env),
                     iterations="all" if a.all_iterations else "one",
                     on_step=lambda r: print(f"[{r.get('status')}] {r.get('description', '')}") if r.get("status") != "running" else None)
    print(f"\nStatus: {run['status']}")
    sys.exit(0 if run["status"] in ("passed", "inconclusive") else 1)


def main() -> None:
    argv = sys.argv[1:]
    if argv and argv[0] == "run":
        _run(argv[1:])
    else:
        _import(argv[1:] if argv and argv[0] == "import" else argv)


if __name__ == "__main__":
    main()
