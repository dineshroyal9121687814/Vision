"""Run an imported UFT script on the shared VisionAuto engine (same Player, Resolver, report as every test)."""
from __future__ import annotations

import json
from pathlib import Path

from core.importers.ranorex.runtime import RxContext
from core.importers.uft.object_repository import parse_xml_repository
from core.importers.uft.uftobjects import UftHost, read_datatable
from core.importers.uft.vbinterp import BudgetExceeded, Interpreter, StopRun
from core.importers.uft.vbparse import VbSyntaxError, parse
from core.importers.uft.vbruntime import VbError

AST_SUFFIX = ".ast.json"


def load_program(script: str | Path) -> tuple[dict, dict]:
    """Return (main program AST, {action name: AST}). Accepts a ``.vbs`` / ``.mts`` source or a saved ``.ast.json``."""
    script = Path(script)
    if script.name.endswith(AST_SUFFIX):
        data = json.loads(script.read_text(encoding="utf-8"))
        return data["main"], data.get("actions", {})
    main = parse(script.read_text(encoding="utf-8-sig", errors="replace"))
    actions = {}
    for sibling in sorted(script.parent.glob(f"{script.stem}.action.*.vbs")):
        actions[sibling.stem.split(".action.", 1)[1]] = parse(sibling.read_text(encoding="utf-8-sig", errors="replace"))
    return main, actions


def run_script(script, repo_path=None, options=None, dry_run=False, on_step=None, should_stop=None, backend=None,
               grab=None, data: str | list | None = None, parameters: dict | None = None,
               environment: dict | None = None, iterations: str = "one") -> dict:
    script = Path(script)
    program, actions = load_program(script)
    project_dir = script.parent
    repo: dict = {}
    repo_path = Path(repo_path) if repo_path else None
    if repo_path is None:
        for cand in (project_dir / "repository.xml", project_dir / "ObjectRepository.xml"):
            if cand.exists():
                repo_path = cand
                break
    if repo_path and repo_path.exists() and repo_path.suffix.casefold() == ".xml":
        repo, _ = parse_xml_repository(repo_path)
    rows = read_datatable(data) if isinstance(data, (str, Path)) else list(data or [])
    if not rows:
        csv_guess = project_dir / f"{script.stem.split('.')[0]}.data.csv"
        if csv_guess.exists():
            rows = read_datatable(csv_guess)

    ctx = RxContext(f"{project_dir.name}__{script.stem.split('.')[0]}", {}, project_dir, options, dry_run,
                    on_step, should_stop, backend, grab)
    ctx.test["source"] = {"type": "uft_script"}
    host = UftHost(ctx, repo, rows, parameters, environment, actions, project_dir)
    ctx.begin()
    status = "passed"
    runs = range(len(rows)) if iterations == "all" and rows else range(1)
    try:
        for row_i in runs:
            host.row_index = row_i
            interp = Interpreter(host)
            interp.run_program(program)
            host.output.extend(interp.output)
    except StopRun as stop:
        status = stop.status if stop.status != "passed" else status
    except BudgetExceeded as exc:
        status = "failed"
        _error_row(ctx, f"Script stopped: {exc.description}")
    except VbError as exc:
        status = "failed"
        _error_row(ctx, f"Run error {exc.number}: {exc.description}")
    except RecursionError:
        status = "failed"
        _error_row(ctx, "Script stopped: recursion too deep")
    if host.failures and status == "passed":
        status = "failed"
    if should_stop and should_stop():
        status = "aborted"
    run = ctx.finish(status)
    if host.notes:
        run["migration_notes"] = host.notes
    if host.output:
        run["script_output"] = host.output[-200:]
    return run


def _error_row(ctx: RxContext, message: str) -> None:
    row = {"id": len(ctx.results) + 1, "type": "script", "description": "Script error", "status": "failed",
           "method": "", "validations": [], "error": message}
    ctx.results.append(row)
    ctx.player._emit(row)


def static_check(program: dict, actions: dict | None = None, repo: dict | None = None) -> dict:
    """Walk the AST *without running it* and list everything the runtime cannot do (reported at import time)."""
    from core.importers.uft import vbruntime as rt
    from core.importers.uft.uftobjects import is_test_class_name

    supported_methods = {"click", "dblclick", "doubleclick", "rightclick", "middleclick", "set", "setsecure", "type",
                         "select", "setfocus", "highlight", "activate", "maximize", "minimize", "restore", "close",
                         "sync", "exist", "exists", "getroproperty", "gettoproperty", "getvisibletext",
                         "waitproperty", "checkproperty", "navigate", "back", "forward", "refresh", "capturebitmap",
                         "waitforpageload", "setcursorpos"}
    blocked_calls = {"createobject": "only Scripting.Dictionary and VBScript.RegExp are available"}
    issues: list[dict] = []
    used_classes: set[str] = set()
    methods: dict[str, int] = {}
    control_flow = {"if", "for", "foreach", "do", "select", "while"}
    flow_count = 0
    procs = {p["name"].casefold() for p in program.get("procedures", [])}

    def note(line, construct, reason):
        issues.append({"source_line": line, "construct": construct, "reason": reason})

    def walk_expr(n, line):
        if not isinstance(n, dict):
            return
        k = n.get("k")
        if k == "member":
            name = n["name"]
            low = name.casefold()
            obj = n["obj"]
            # a member of a test-object chain that is not a child class and not a supported method
            if _is_chain(obj) and not is_test_class_name(low) and low not in supported_methods:
                if low not in ("value", "count", "object", "exist"):
                    note(n.get("line", line), name, f"'{name}' is not supported by the VisionAuto UFT runtime")
                elif low == "object":
                    note(n.get("line", line), name, ".Object (native COM/DOM access) cannot be emulated")
            methods[low] = methods.get(low, 0) + 1
        if k == "id":
            low = n["name"].casefold()
            if is_test_class_name(low):
                used_classes.add(n["name"])
            if low in blocked_calls:
                pass
        for v in n.values():
            if isinstance(v, dict):
                walk_expr(v, line)
            elif isinstance(v, list):
                for x in v:
                    if isinstance(x, dict):
                        walk_expr(x, line)

    def _is_chain(n) -> bool:
        while isinstance(n, dict):
            if n["k"] == "index" and n["target"]["k"] == "id":
                return is_test_class_name(n["target"]["name"])
            if n["k"] == "member":
                n = n["obj"]
            else:
                return False
        return False

    def walk_stmts(stmts):
        nonlocal flow_count
        for s in stmts:
            if not isinstance(s, dict):
                continue
            if s["k"] in control_flow:
                flow_count += 1
            if s["k"] == "unsupported":
                note(s.get("line", 0), s.get("text", ""), s.get("reason", "unsupported"))
            for key, v in s.items():
                if key in ("body", "else") and isinstance(v, list):
                    walk_stmts(v)
                elif key == "branches":
                    for br in v:
                        walk_expr(br["cond"], s.get("line", 0))
                        walk_stmts(br["body"])
                elif key == "cases":
                    for c in v:
                        walk_stmts(c["body"])
                        for t in c["tests"]:
                            for x in ([t["value"]] if "value" in t else t.get("range", [])):
                                walk_expr(x, s.get("line", 0))
                elif isinstance(v, dict) and key not in ("body",):
                    walk_expr(v, s.get("line", 0))
                elif isinstance(v, list) and key not in ("body", "else", "branches", "cases", "names", "params", "dims"):
                    for x in v:
                        if isinstance(x, dict):
                            walk_expr(x, s.get("line", 0))

    walk_stmts(program.get("body", []))
    for p in program.get("procedures", []):
        walk_stmts(p["body"])
    for a in (actions or {}).values():
        walk_stmts(a.get("body", []))
        for p in a.get("procedures", []):
            walk_stmts(p["body"])
    issues.extend(i for i in program.get("unsupported", []) if i not in issues)
    # de-duplicate
    seen, uniq = set(), []
    for i in issues:
        key = (i["source_line"], i["construct"], i["reason"])
        if key not in seen:
            seen.add(key)
            uniq.append(i)
    return {"unsupported_constructs": uniq, "control_flow_blocks": flow_count, "procedures": sorted(procs),
            "test_object_classes": sorted(used_classes), "methods_used": dict(sorted(methods.items()))}
