"""
Ranorex project importer.

    import_project(rxrep, [Recording1.cs, ...], project="MyProject")

For every .cs file:
  * straight-line recording  -> NATIVE test (workspace/tests/<project>__<file>/test.json).
    It then behaves exactly like a recorded test: library, playback, validation
    points, reports, self-healing.
  * control flow / variables -> SCRIPT (workspace/imported/<project>/<file>.py), executed
    by RxContext on the same engine.
Lines neither mode understands become '# TODO' (scripts) or are listed in the summary;
an optional local LLM (Ollama) can take a pass at them in script mode.
"""
from __future__ import annotations

import json
from pathlib import Path

from core import paths, testfile
from core.importers.ranorex.cs_to_steps import convert
from core.importers.ranorex.cs_translator import Translator
from core.importers.ranorex.repo_parser import parse_rxrep
from core.importers.ranorex.script_safety import validate_script_source


def import_project(rxrep, cs_files, project: str, llm=None, force_script: bool = False,
                  overwrite: bool = False) -> dict:
    project = testfile.safe_name(project)
    repo = parse_rxrep(rxrep) if rxrep else {}
    out_dir = paths.imported_dir() / project
    out_dir.mkdir(parents=True, exist_ok=True)
    repo_file = out_dir / "repository.json"
    repo_data = json.dumps(repo, indent=2)
    if repo_file.exists() and repo_file.read_text(encoding="utf-8") != repo_data and not overwrite:
        raise FileExistsError(f"Imported repository already exists at {repo_file}; pass overwrite=True to replace it.")
    repo_file.write_text(repo_data, encoding="utf-8")

    items = []
    for cs in cs_files:
        cs = Path(cs)
        src = cs.read_text(encoding="utf-8-sig", errors="replace")
        conv = None if force_script else convert(src, repo, source_name=cs.name)
        if conv and conv.ok and conv.steps:
            name = testfile.safe_name(f"{project}__{cs.stem}")
            test = testfile.new_test(name)
            test.update(title=cs.stem, steps=conv.steps,
                        source={"type": "ranorex", "file": cs.name, "project": project})
            first = next((s["window"] for s in conv.steps if s["window"].get("title")), {})
            test["app"] = dict(first)
            d = testfile.test_dir(name)
            if (d / "test.json").exists() and not overwrite:
                raise FileExistsError(f"Imported test already exists at {d / 'test.json'}; choose another project name or pass overwrite=True.")
            (d / "assets").mkdir(parents=True, exist_ok=True)
            testfile.save_test(test, d)
            migration = {
                "schema": "visionauto.migration-report/1", "source_platform": "Ranorex/C#",
                "source_file": cs.name, "mode": "native", "converted_count": len(conv.converted),
                "unsupported_count": len(conv.unsupported_details), "converted_operations": conv.converted,
                "unsupported_constructs": conv.unsupported_details,
                "ignored_count": conv.ignored,
                "assumptions": list(dict.fromkeys(["Only recognized straight-line operations were converted.", *conv.assumptions])),
                "dependencies": ["VisionAuto shared playback engine"],
                "runtime_note": "Original source execution may require the licensed Ranorex runtime; translated native steps use VisionAuto only.",
                "manual_review_required": bool(conv.unsupported_details or conv.assumptions),
                "asset_support": "Ranorex .rximg assets are not imported or bound to native steps yet.",
            }
            testfile.write_json_atomic(d / "migration_report.json", migration)
            items.append({"file": cs.name, "mode": "native", "test": name, "steps": len(conv.steps),
                          "ignored": conv.ignored, "unsupported": conv.unsupported,
                          "migration_report": str(d / "migration_report.json")})
        else:
            tr = Translator(llm=llm)
            py = tr.translate(src, module_name=cs.stem)
            compile(py, cs.stem, "exec")      # never write a script that is not valid Python
            safety_errors = validate_script_source(py)
            script = out_dir / f"{testfile.safe_name(cs.stem)}.py"
            if script.exists() and not overwrite:
                raise FileExistsError(f"Imported script already exists at {script}; pass overwrite=True to replace it.")
            script.write_text(py, encoding="utf-8")
            migration = {
                "schema": "visionauto.migration-report/1", "source_platform": "Ranorex/C#",
                "source_file": cs.name, "mode": "script", "converted_count": tr.stats["rule"] + tr.stats["llm"],
                "unsupported_count": len(tr.todo_details), "converted_operations": [],
                "unsupported_constructs": tr.todo_details,
                "assumptions": list(dict.fromkeys(["Generated code is translated to the VisionAuto RxContext, not executed by Ranorex.", *(conv.assumptions if conv else [])])),
                "dependencies": ["VisionAuto shared playback engine", "Ranorex runtime not required for translated operations"],
                "runtime_note": "Untranslated TODO statements require manual implementation; direct source execution may require the licensed Ranorex runtime.",
                "manual_review_required": bool(tr.todo_details or safety_errors or (conv and conv.needs_script)),
                "execution_validation": "passed" if not safety_errors else "rejected",
                "execution_safety_errors": safety_errors,
                "asset_support": "Ranorex .rximg assets are not imported or bound automatically.",
            }
            report_path = script.with_suffix(".migration_report.json")
            testfile.write_json_atomic(report_path, migration)
            items.append({"file": cs.name, "mode": "script", "script": str(script),
                          "reason": conv.reason if conv else "forced",
                          "rules": tr.stats["rule"], "llm": tr.stats["llm"],
                          "unsupported": [*tr.todos, *safety_errors],
                          "migration_report": str(report_path)})
    return {"project": project, "repository_items": len(repo), "items": items, "dir": str(out_dir)}
