"""
Ranorex C# -> Python translator (rule-based, line oriented).

Ranorex recordings generate C# (`Recording1.cs`) and users write C# code
modules, so translating the .cs files covers both. Handles the statements
that make up the vast majority of recorded/hand-written Ranorex tests;
anything else goes to the optional LLM fallback or becomes a TODO comment.

Output is a Python module with `def run(ctx):` that drives
core.importers.ranorex.runtime.RxContext.
"""
from __future__ import annotations

import re

IGNORED = (
    r"^using\s", r"^\[", r"^#", r"^Mouse\.Default", r"^Keyboard\.Default",
    r"^Delay\.SpeedFactor", r"^Init\(\)", r"^//",
)
CONTAINER_RE = re.compile(r"^(namespace|(public|internal|static|sealed|partial|abstract|\s)*\b(class|struct|interface|enum))\b")
METHOD_RE = re.compile(r"^(?:public|private|protected|internal|static|\s)*[\w<>\[\],\.]+\s+(?:ITestModule\.)?(\w+)\s*\(([^)]*)\)\s*$")
REPO_RE = r"repo\.([\w\.]+?)"


def _repo_path(expr: str) -> str:
    """repo.Calculator.Button1.Self / .SelfInfo -> 'Calculator.Button1'"""
    parts = expr.split(".")
    while parts and parts[-1] in ("Self", "SelfInfo", "Info"):
        parts.pop()
    if parts and parts[-1].endswith("Info") and len(parts[-1]) > 4:
        parts[-1] = parts[-1][:-4]
    return ".".join(parts)


def _split_top(expr: str, sep: str) -> list[str]:
    """Split on ``sep`` at bracket depth 0, outside string literals."""
    parts, buf, depth, quote, i = [], [], 0, "", 0
    while i < len(expr):
        c = expr[i]
        if quote:
            buf.append(c)
            if c == "\\" and i + 1 < len(expr):
                buf.append(expr[i + 1])
                i += 1
            elif c == quote:
                quote = ""
        elif c in "\"'":
            quote = c
            buf.append(c)
        elif c in "([{":
            depth += 1
            buf.append(c)
        elif c in ")]}":
            depth -= 1
            buf.append(c)
        elif c == sep and depth == 0:
            parts.append("".join(buf))
            buf = []
        else:
            buf.append(c)
        i += 1
    parts.append("".join(buf))
    return parts


def _interpolate(m) -> str:
    """$"Hello {name}" -> rx_format("Hello {0}", name)"""
    body, args = m.group(1), []

    def sub(mm):
        args.append(mm.group(1).split(":")[0])
        return "{" + str(len(args) - 1) + "}"
    body = re.sub(r"\{([^{}]+)\}", sub, body)
    return "rx_format(\"" + body + "\"" + "".join(", " + a for a in args) + ")"


def _py_expr(expr: str) -> str:
    expr = expr.strip().rstrip(";")
    expr = re.sub(r'\$"((?:[^"\\]|\\.)*)"', _interpolate, expr)
    expr = re.sub(r'@"((?:[^"]|"")*)"', lambda m: '"' + m.group(1).replace('""', '\\"').replace("\\", "\\\\") + '"', expr)
    expr = re.sub(r"\bstring\.Format\(", "rx_format(", expr)
    expr = re.sub(r"\bConvert\.ToInt(?:32|64)\(", "int(", expr)
    expr = re.sub(r"\bConvert\.ToDouble\(", "float(", expr)
    expr = re.sub(r"\bConvert\.ToString\(", "str(", expr)
    expr = re.sub(r"\b(?:int|double|long)\.Parse\(", "int(", expr)
    expr = re.sub(r"\bMath\.(Abs|Min|Max)\(", lambda m: m.group(1).lower() + "(", expr)
    expr = re.sub(r"\bstring\.(?:IsNullOrEmpty)\(([^()]*)\)", r"(not (\1))", expr)
    expr = re.sub(r"([\w.\[\]]+)\.Length\b", r"len(\1)", expr)
    expr = re.sub(r"([\w.\[\]]+)\.Count\b(?!\()", r"len(\1)", expr)
    expr = re.sub(r"([\w.\[\]]+)\.ToString\(\)", r"str(\1)", expr)
    expr = re.sub(r"\bnew\s+(?:string|int|double)\[\]\s*\{([^}]*)\}", r"[\1]", expr)
    expr = re.sub(r"\bnew\s+List<[^>]+>\s*\(\)", "[]", expr)
    parts = _split_top(expr, "+")
    if len(parts) > 1 and any(re.match(r"""^\s*["']""", p) for p in parts):
        expr = "rx_concat(" + ", ".join(p.strip() for p in parts) + ")"
    def ops(code: str) -> str:
        code = re.sub(r"\btrue\b", "True", code)
        code = re.sub(r"\bfalse\b", "False", code)
        code = re.sub(r"\bnull\b", "None", code)
        code = code.replace("&&", " and ").replace("||", " or ")
        return re.sub(r"!(?!=)", "not ", code)
    # only touch code, never the inside of string literals
    pieces = re.split(r'("(?:[^"\\]|\\.)*")', expr)
    return "".join(piece if piece.startswith('"') else ops(piece) for piece in pieces)


# (regex, handler) pairs; handler gets the match and returns python source
def _rules():
    R = []

    def add(pattern, fn):
        R.append((re.compile(pattern), fn))

    add(rf"^{REPO_RE}\.Click\((.*)\);$",
        lambda m: f"ctx.right_click({_repo_path(m[1])!r})" if "Right" in m[2] else f"ctx.click({_repo_path(m[1])!r})")
    add(rf"^{REPO_RE}\.DoubleClick\((.*)\);$", lambda m: f"ctx.double_click({_repo_path(m[1])!r})")
    add(rf"^{REPO_RE}\.(?:PressKeys|EnsureVisible|Focus)\((.*)\);$",
        lambda m: f"ctx.type_text({_repo_path(m[1])!r}, {m[2].strip() or repr('')})" if "PressKeys" in m[0]
        else f"ctx.click({_repo_path(m[1])!r})")
    add(rf"^{REPO_RE}\.MoveTo\((.*)\);$", lambda m: f"ctx.hover({_repo_path(m[1])!r})")
    add(r'^Keyboard\.Press\((.*)\);$', lambda m: f"ctx.press_keys({m[1].strip()})")
    add(r'^Keyboard\.PrepareFocus\((.*)\);$', lambda m: f"ctx.click({_repo_path(m[1].replace('repo.', '', 1))!r})")
    add(r"^Delay\.Milliseconds\((.*)\);$", lambda m: f"ctx.delay({_py_expr(m[1])})")
    add(r"^Delay\.Seconds\((.*)\);$", lambda m: f"ctx.delay(({_py_expr(m[1])}) * 1000)")
    add(rf"^Validate\.Exists\({REPO_RE}(?:\s*,.*)?\);$", lambda m: f"ctx.validate_exists({_repo_path(m[1])!r})")
    add(rf"^Validate\.NotExists\({REPO_RE}(?:\s*,.*)?\);$", lambda m: f"ctx.validate_not_exists({_repo_path(m[1])!r})")
    add(rf'^Validate\.AttributeEqual\({REPO_RE}\s*,\s*"(?:Text|InnerText|AccessibleName)"\s*,\s*(.+?)\s*(?:,.*)?\);$',
        lambda m: f"ctx.validate_text({_repo_path(m[1])!r}, {m[2]})")
    add(r"^Report\.Log\(\s*ReportLevel\.(\w+)\s*,\s*(.+?)\s*,\s*(.+?)(?:\s*,.*)?\);$",
        lambda m: f"ctx.log({m[1]!r}, {_py_expr(m[2])}, {_py_expr(m[3])})")
    add(r"^Report\.(Success|Failure|Info|Warn|Error)\((.+?)\s*,\s*(.+?)\);$",
        lambda m: f"ctx.log({m[1]!r}, {_py_expr(m[2])}, {_py_expr(m[3])})")
    add(r"^Report\.Screenshot\(.*\);$", lambda m: "ctx.screenshot()")
    add(r'^Host\.Local\.RunApplication\(\s*(".*?")\s*(?:,\s*(".*?")\s*)?(?:,.*)?\);$',
        lambda m: f"ctx.run_app({m[1]}, {m[2] or chr(34)*2})")
    add(rf"^(?:var|string|int|double|bool|long)\s+(\w+)\s*=\s*{REPO_RE}\.(?:Text|InnerText|Value)\s*;$",
        lambda m: f"{m[1]} = ctx.get_text({_repo_path(m[2])!r})")
    add(r"^(?:var|string|int|double|bool|long|float|decimal)\s+(\w+)\s*=\s*(.+);$",
        lambda m: f"{m[1]} = {_py_expr(m[2])}")
    add(r"^(?:Thread\.Sleep)\((.*)\);$", lambda m: f"ctx.delay({_py_expr(m[1])})")
    add(rf'^Validate\.AttributeContains\({REPO_RE}\s*,\s*"(?:Text|InnerText|AccessibleName)"\s*,\s*(.+?)\s*(?:,.*)?\);$',
        lambda m: f"ctx.validate_text_contains({_repo_path(m[1])!r}, {_py_expr(m[2])})")
    add(r"^Validate\.IsTrue\((.+?)(?:\s*,\s*(.+))?\);$", lambda m: f"ctx.assert_true({_py_expr(m[1])}, {_py_expr(m[2]) if m[2] else repr('')})")
    add(r"^Validate\.IsFalse\((.+?)(?:\s*,\s*(.+))?\);$", lambda m: f"ctx.assert_true(not ({_py_expr(m[1])}), {_py_expr(m[2]) if m[2] else repr('')})")
    add(r"^Validate\.AreEqual\((.+?)\s*,\s*(.+?)(?:\s*,\s*(\".*\"))?\);$",
        lambda m: f"ctx.assert_equal({_py_expr(m[1])}, {_py_expr(m[2])})")
    add(rf"^Mouse\.Click\(\s*{REPO_RE}\.Self\s*(?:,.*)?\);$", lambda m: f"ctx.click({_repo_path(m[1])!r})")
    add(rf"^{REPO_RE}\.(?:Check|Uncheck)\(\);$", lambda m: f"ctx.click({_repo_path(m[1])!r})")
    add(rf"^(?:var|string)\s+(\w+)\s*=\s*{REPO_RE}\.GetAttributeValue(?:<\w+>)?\(\"\w+\"\)\s*(?:\.ToString\(\))?;$",
        lambda m: f"{m[1]} = ctx.get_text({_repo_path(m[2])!r})")
    add(rf"^(?:var|bool)\s+(\w+)\s*=\s*{REPO_RE}\.Exists\(\);$", lambda m: f"{m[1]} = ctx.exists({_repo_path(m[2])!r})")
    # specific declarations must win over the generic "<type> x = <expr>;" rule
    generic = [r for r in R if r[0].pattern.startswith("^(?:var|string|int|double|bool|long|float|decimal)\\s+(\\w+)\\s*=\\s*(.+);$")]
    return [r for r in R if r not in generic] + generic


RULES = _rules()


class Translator:
    def __init__(self, llm=None):
        self.llm = llm
        self.stats = {"rule": 0, "llm": 0, "todo": 0}
        self.todos: list[str] = []
        self.todo_details: list[dict] = []
        self.current_source_line = 0

    def _translate_statement(self, line: str) -> list[str]:
        for rx, fn in RULES:
            m = rx.match(line)
            if m:
                self.stats["rule"] += 1
                return [fn(m)]
        if self.llm:
            out = self.llm.translate_line(line)
            if out:
                self.stats["llm"] += 1
                return [f"# (LLM-translated from: {line})"] + out.splitlines()
        self.stats["todo"] += 1
        self.todos.append(line)
        self.todo_details.append({"source_line": self.current_source_line, "construct": line,
                                  "reason": "No rule or validated local-model translation was available."})
        return [f"# TODO(untranslated): {line}"]

    def translate(self, cs_source: str, module_name: str = "ranorex_test") -> str:
        out = [
            f'"""Auto-translated from Ranorex C# ({module_name}). Review `# TODO` lines."""',
            "",
        ]
        indent = 0
        kinds: list[str] = []      # 'c' container, 'b' python block
        body_lines: list[int] = [] # statements emitted per open python block
        pending: str | None = None # 'c' or 'b' decided by the last header line
        in_comment = False

        def emit(text):
            out.append("    " * indent + text)
            if body_lines:
                body_lines[-1] += 1

        expanded: list[tuple[int, str]] = []
        for no, raw in enumerate(cs_source.splitlines(), 1):
            text = raw.strip()
            code = text.split("//", 1)[0].rstrip() if '"' not in text else text
            if code.endswith("{") and code != "{" and not code.startswith("//"):
                expanded.append((no, code[:-1].strip()))
                expanded.append((no, "{"))
            elif code.startswith("}") and len(code) > 1 and code not in ("};",):
                expanded.append((no, "}"))
                rest = code[1:].strip()
                if rest.endswith("{"):
                    expanded.append((no, rest[:-1].strip()))
                    expanded.append((no, "{"))
                elif rest:
                    expanded.append((no, rest))
            else:
                expanded.append((no, text))
        block_first: list[str | None] = []
        pending_first: str | None = None
        for self.current_source_line, raw in expanded:
            line = raw.strip()
            if in_comment:
                if "*/" in line:
                    in_comment = False
                continue
            if line.startswith("/*"):
                in_comment = "*/" not in line
                continue
            if not line or line.startswith("//") or any(re.match(p, line) for p in IGNORED):
                continue

            if line == "{":
                kinds.append(pending or "b")
                if (pending or "b") == "b":
                    indent += 1
                    body_lines.append(0)
                    if pending_first:
                        emit(pending_first)
                pending_first = None
                pending = None
                continue
            if line == "}" or line.startswith("}"):
                if kinds:
                    kind = kinds.pop()
                    if kind == "b":
                        if body_lines.pop() == 0:
                            emit("pass")
                        indent -= 1
                        if line != "}":  # e.g. '} else {' handled below
                            pass
                if line in ("}", "};"):
                    continue
                line = line.lstrip("}").strip()
                if not line:
                    continue

            if CONTAINER_RE.match(line):
                pending = "c"
                continue

            m = METHOD_RE.match(line)
            if m and not re.match(r"^(if|for|foreach|while|switch|return|else|using)\b", line):
                name, params = m.group(1), m.group(2)
                pnames = [p.strip().split()[-1] for p in params.split(",") if p.strip()]
                pyname = "run" if name == "Run" else re.sub(r"(?<!^)(?=[A-Z])", "_", name).lower()
                sig = ", ".join(["ctx"] + pnames)
                out.append("")
                emit(f"def {pyname}({sig}):")
                pending = "b"
                continue

            if re.match(r"^(else\s*if|if)\b", line):
                cond = re.sub(r"^(else\s*if|if)\s*\((.*)\)\s*$", lambda mm: mm.group(2), line)
                kw = "elif" if line.startswith("else") else "if"
                emit(f"{kw} {_py_expr(cond)}:")
                pending = "b"
                continue
            if re.match(r"^else\s*$", line):
                emit("else:")
                pending = "b"
                continue
            fm = re.match(r"^foreach\s*\(\s*(?:var|\w+)\s+(\w+)\s+in\s+(.+)\)\s*$", line)
            if fm:
                emit(f"for {fm.group(1)} in {_py_expr(fm.group(2))}:")
                pending = "b"
                continue
            wm = re.match(r"^while\s*\((.*)\)\s*$", line)
            if wm:     # bounded: at most 1000 iterations, so an imported test can never hang the machine
                emit("for _w in rx_range(0, 1000):")
                pending_first = f"if not ({_py_expr(wm.group(1))}): break"
                pending = "b"
                continue
            cf = re.match(r"^for\s*\(\s*(?:int|var|long)\s+(\w+)\s*=\s*([^;]+);\s*\1\s*(<=|<|>=|>)\s*([^;]+);\s*"
                          r"(?:\1(\+\+|--)|\+\+\1|--\1|\1\s*(\+=|-=)\s*(\d+))\s*\)\s*$", line)
            if cf:
                var, a, op, b = cf.group(1), _py_expr(cf.group(2)), cf.group(3), _py_expr(cf.group(4))
                down = cf.group(5) == "--" or cf.group(6) == "-=" or line.replace(" ", "").find("--" + var) >= 0
                step = int(cf.group(7)) if cf.group(7) else 1
                if down:
                    stop = f"({b}) - 1" if op == ">" else f"({b}) - 1" if op == ">=" else b
                    emit(f"for {var} in rx_range({a}, {b if op == '>' else '(' + b + ') - 1'}, -{step}):")
                else:
                    emit(f"for {var} in rx_range({a}, {b if op == '<' else '(' + b + ') + 1'}, {step}):")
                pending = "b"
                continue
            if line in ("break;", "continue;"):
                emit(line[:-1])
                continue
            im = re.match(r"^(\w+)(\+\+|--);$", line) or re.match(r"^(\+\+|--)(\w+);$", line)
            if im:
                name, op = (im.group(1), im.group(2)) if im.group(1)[0].isalpha() or im.group(1)[0] == "_" else (im.group(2), im.group(1))
                emit(f"{name} {'+=' if op == '++' else '-='} 1")
                continue
            am = re.match(r"^(\w+)\s*(\+=|-=|\*=|/=|=)\s*(?!=)(.+);$", line)
            if am and not re.match(r"^(var|string|int|double|bool|long|float|decimal)\b", line):
                emit(f"{am.group(1)} {am.group(2)} {_py_expr(am.group(3))}")
                continue
            if line.startswith("return"):
                emit(_py_expr(line))
                continue

            for stmt in self._translate_statement(line):
                emit(stmt)

        out.append("")
        return "\n".join(out)
