"""Static safety checks for generated Ranorex Python modules before execution."""
from __future__ import annotations

import ast

_CTX_CALLS = {
    "click", "double_click", "right_click", "hover", "type_text", "press_keys",
    "delay", "run_app", "screenshot", "log", "validate_exists",
    "validate_not_exists", "validate_text", "get_text", "validate_text_contains", "exists",
    "assert_true", "assert_equal",
}
_HELPERS = {"rx_range", "rx_format", "rx_concat", "len", "str", "int", "float", "abs", "min", "max", "bool"}
_OPS = {
    ast.Add, ast.Sub, ast.Mult, ast.Div, ast.FloorDiv, ast.Mod,
    ast.Eq, ast.NotEq, ast.Lt, ast.LtE, ast.Gt, ast.GtE, ast.In, ast.NotIn,
    ast.Is, ast.IsNot, ast.And, ast.Or, ast.Not, ast.USub, ast.UAdd,
}
_NODES = {
    ast.Module, ast.FunctionDef, ast.arguments, ast.arg, ast.Expr, ast.Constant,
    ast.Call, ast.Attribute, ast.Name, ast.Load, ast.Store, ast.keyword,
    ast.Assign, ast.AugAssign, ast.If, ast.For, ast.Return, ast.Pass, ast.Compare, ast.BoolOp,
    ast.UnaryOp, ast.BinOp, ast.List, ast.Tuple, ast.Set, ast.Dict, ast.Subscript,
    ast.IfExp, ast.Break, ast.Continue, *_OPS,
}
MAX_STATIC_LOOP_ITERATIONS = 100
MAX_SCRIPT_BYTES = 1_000_000
MAX_AST_NODES = 10_000
MAX_NESTED_LOOPS = 2


def _range_is_bounded(call: ast.Call) -> bool:
    if not 1 <= len(call.args) <= 3 or call.keywords:
        return False
    values = []
    for arg in call.args:
        if not isinstance(arg, ast.Constant) or not isinstance(arg.value, int):
            return False
        values.append(arg.value)
    try:
        return len(range(*values)) <= MAX_STATIC_LOOP_ITERATIONS
    except (ValueError, OverflowError):
        return False


def validate_script_tree(tree: ast.AST) -> list[str]:
    """Return safety errors; accepts only one ``run(ctx)`` and a small static subset."""
    errors: list[str] = []
    if not isinstance(tree, ast.Module):
        return ["module source is required"]
    functions = [n for n in tree.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))]
    non_functions = [n for n in tree.body if not isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef, ast.Expr))]
    if non_functions:
        errors.append("module-level executable statements are not allowed")
    if len(functions) != 1 or functions[0].name != "run":
        errors.append("script must define exactly one run(ctx) function")
    elif (len(functions[0].args.args) != 1 or functions[0].args.args[0].arg != "ctx"
          or functions[0].args.posonlyargs or functions[0].args.kwonlyargs
          or functions[0].args.defaults or functions[0].decorator_list):
        errors.append("run must accept only ctx and have no decorators or defaults")

    nodes = list(ast.walk(tree))
    if len(nodes) > MAX_AST_NODES:
        errors.append(f"script is too complex (more than {MAX_AST_NODES} syntax nodes)")
    for node in nodes:
        if type(node) not in _NODES:
            errors.append(f"unsupported Python syntax: {type(node).__name__}")
            continue
        if isinstance(node, ast.Name) and node.id.startswith("__"):
            errors.append("dunder names are not allowed")
        elif isinstance(node, ast.Attribute):
            if not (isinstance(node.value, ast.Name) and node.value.id == "ctx" and node.attr in _CTX_CALLS):
                errors.append("only allowlisted ctx methods may be accessed")
        elif isinstance(node, ast.Call):
            if isinstance(node.func, ast.Attribute):
                if not (isinstance(node.func.value, ast.Name) and node.func.value.id == "ctx"
                        and node.func.attr in _CTX_CALLS):
                    errors.append("only allowlisted ctx methods may be called")
            elif isinstance(node.func, ast.Name) and node.func.id == "range":
                if not _range_is_bounded(node):
                    errors.append("range loops must use integer literals and be limited to 100 iterations")
            elif isinstance(node.func, ast.Name) and node.func.id in _HELPERS:
                pass
            else:
                errors.append("arbitrary function calls are not allowed")
        elif isinstance(node, ast.Assign) and any(not isinstance(t, ast.Name) for t in node.targets):
            errors.append("assignments may target local names only")
        elif isinstance(node, ast.AugAssign) and not isinstance(node.target, ast.Name):
            errors.append("augmented assignments may target local names only")
        elif isinstance(node, ast.For):
            if not isinstance(node.target, ast.Name):
                errors.append("for-loop targets must be local names")
            it = node.iter
            if isinstance(it, ast.Call) and isinstance(it.func, ast.Name) and it.func.id == "range":
                pass
            elif isinstance(it, ast.Call) and isinstance(it.func, ast.Name) and it.func.id == "rx_range":
                pass            # clamped to 10 000 iterations at run time
            elif isinstance(it, (ast.Name, ast.Subscript)):
                pass            # iterating a list a script already holds is bounded by its size
            elif isinstance(it, (ast.List, ast.Tuple, ast.Set)) and len(it.elts) <= MAX_STATIC_LOOP_ITERATIONS:
                pass
            else:
                errors.append("for loops must iterate a static list/tuple/set or bounded range")
        elif isinstance(node, ast.While):
            errors.append("while loops are not allowed because they cannot be bounded safely")

    def check_loop_depth(node: ast.AST, depth: int = 0) -> None:
        current = depth + isinstance(node, (ast.For, ast.While))
        if current > MAX_NESTED_LOOPS:
            errors.append(f"loop nesting may not exceed {MAX_NESTED_LOOPS}")
            return
        for child in ast.iter_child_nodes(node):
            check_loop_depth(child, current)

    check_loop_depth(tree)
    return list(dict.fromkeys(errors))


def validate_script_source(source: str) -> list[str]:
    if len(source.encode("utf-8")) > MAX_SCRIPT_BYTES:
        return [f"script exceeds the {MAX_SCRIPT_BYTES}-byte validation limit"]
    try:
        tree = ast.parse(source)
    except (SyntaxError, ValueError) as exc:
        return [f"invalid Python syntax: {exc}"]
    return validate_script_tree(tree)
