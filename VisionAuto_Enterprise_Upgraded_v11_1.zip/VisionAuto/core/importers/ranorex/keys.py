"""
Ranorex key-sequence parser:  "{LControlKey down}c{LControlKey up}"  ->  [{"type": "hotkey", "keys": "ctrl+c"}]

Output items use VisionAuto step types (type / key / hotkey) so the same
converter feeds both native tests and script mode.
"""
from __future__ import annotations

import re

MODS = ("ctrl", "alt", "win", "shift")

RX_KEYS = {
    "lcontrolkey": "ctrl", "rcontrolkey": "ctrl", "controlkey": "ctrl", "control": "ctrl", "ctrl": "ctrl",
    "lshiftkey": "shift", "rshiftkey": "shift", "shiftkey": "shift", "shift": "shift",
    "lmenu": "alt", "rmenu": "alt", "menu": "alt", "alt": "alt",
    "lwin": "win", "rwin": "win",
    "return": "enter", "enter": "enter", "escape": "esc", "esc": "esc", "back": "backspace",
    "backspace": "backspace", "delete": "delete", "tab": "tab", "space": "space",
    "left": "left", "right": "right", "up": "up", "down": "down", "home": "home", "end": "end",
    "pageup": "pageup", "prior": "pageup", "pagedown": "pagedown", "next": "pagedown", "insert": "insert",
    **{f"f{i}": f"f{i}" for i in range(1, 13)},
}

_TOKEN = re.compile(r"\{[^{}]*\}|.", re.S)


def parse_key_sequence(spec: str) -> list[dict]:
    out: list[dict] = []
    held: list[str] = []
    buf: list[str] = []

    def flush():
        if buf:
            out.append({"type": "type", "params": {"text": "".join(buf)}})
            buf.clear()

    def chord(key: str):
        flush()
        out.append({"type": "hotkey", "params": {"keys": "+".join(held + [key])}})

    for tok in _TOKEN.findall(spec or ""):
        if tok.startswith("{") and tok.endswith("}") and len(tok) > 2:
            parts = tok[1:-1].split()
            name = RX_KEYS.get(parts[0].lower(), parts[0].lower())
            state = parts[1].lower() if len(parts) > 1 else ""
            if name in MODS:
                if state == "down" and name not in held:
                    held.append(name)
                elif state == "up" and name in held:
                    held.remove(name)
                continue
            if state == "up":
                continue
            if held:
                chord(name)
            else:
                flush()
                out.append({"type": "key", "params": {"key": name}})
        else:
            if any(m in held for m in ("ctrl", "alt", "win")):
                chord(tok.lower())
            elif "shift" in held:
                buf.append(tok.upper())
            else:
                buf.append(tok)
    flush()
    return out
