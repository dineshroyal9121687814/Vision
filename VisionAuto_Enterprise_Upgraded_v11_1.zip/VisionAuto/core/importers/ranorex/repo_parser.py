"""
Ranorex repository (.rxrep) parser.

IMPORTANT: this parser is deliberately tolerant and namespace-agnostic, and
it was written WITHOUT access to a real .rxrep file (none was available when
it was built). It assumes the commonly documented structure:

  - nested folder-like elements carrying a `name` attribute
  - an RxPath either as an attribute named `rxpath` or as a child element
    named `RxPath`
  - item RxPaths are relative to their parent folder's RxPath

If your real file differs, run `python -m core.importers.ranorex.cli inspect
--rxrep your.rxrep` and send me the output (or a sanitized sample); the
fix is usually a one-line change in `_own_rxpath`.
"""
from __future__ import annotations

import xml.etree.ElementTree as ET
from pathlib import Path

from core.importers.ranorex.rxpath import parse_rxpath


def _local(tag: str) -> str:
    return tag.rsplit("}", 1)[-1].lower() if isinstance(tag, str) else ""


def _own_rxpath(elem: ET.Element) -> str:
    for k, v in elem.attrib.items():
        if _local(k) == "rxpath" and v:
            return v.strip()
    for child in elem:
        if _local(child.tag) == "rxpath":
            return (child.text or "").strip()
    return ""


def _walk(elem, name_stack, prefix, out):
    name = elem.attrib.get("name") or elem.attrib.get("Name")
    own = _own_rxpath(elem)
    next_stack, next_prefix = name_stack, prefix

    if name:
        next_stack = name_stack + [name]
        if own:
            sep = "" if (not prefix or prefix.endswith("/") or own.startswith("/")) else "/"
            full = own if (own.startswith("/") and not prefix) else (prefix + sep + own)
            has_named_children = any(c.attrib.get("name") or c.attrib.get("Name") for c in elem.iter() if c is not elem)
            if has_named_children:
                next_prefix = full  # folder: children are relative to it
            else:
                out[".".join(next_stack)] = full  # leaf item
    for child in elem:
        _walk(child, next_stack, next_prefix, out)


def parse_rxrep(path: str | Path) -> dict:
    """Returns {"Calculator.Button1": {"rxpath": ..., "window_title": ..., "label": ..., ...}}"""
    raw_content = Path(path).read_text(encoding="utf-8", errors="replace")
    if "<!ENTITY" in raw_content.upper():
        raise ValueError(f"Suspicious XML entity declarations detected in '{path}'")
    parser = ET.XMLParser()
    root = ET.fromstring(raw_content, parser=parser)
    raw_items: dict = {}
    _walk(root, [], "", raw_items)

    repo = {}
    for item_id, rxpath in raw_items.items():
        info = parse_rxpath(rxpath)
        repo[item_id] = {
            "rxpath": rxpath,
            "window_title": info.window_title,
            "process_name": info.process_name,
            "role": info.role,
            "label": info.label,
            "automation_id": info.automation_id,
            "value": info.value,
        }
    return repo
