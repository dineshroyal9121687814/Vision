"""
Ranorex C# recording  ->  native VisionAuto test steps.

Works for straight-line recordings / code modules (the output of the Ranorex
recorder). Elements come from the repository (.rxrep): the RanoreXPath gives
the window title, accessible name/text, role and automation id, which the
resolver uses for its native UI-Automation and OCR tiers.

Anything with control flow or variables (if / foreach / var x = ...) cannot be
a static list of steps -> `needs_script=True` and the importer falls back to
script mode (translated Python run by RxContext).
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field

from core.ai.describe import describe_step
from core.importers.ranorex.keys import parse_key_sequence

UIA_ROLES = {
    "button": "Button", "text": "Text", "checkbox": "CheckBox", "radiobutton": "RadioButton",
    "combobox": "ComboBox", "listitem": "ListItem", "menuitem": "MenuItem", "tabpage": "TabItem",
    "tabitem": "TabItem", "link": "Hyperlink", "hyperlink": "Hyperlink", "treeitem": "TreeItem",
    "input": "Edit", "edit": "Edit", "textbox": "Edit", "slider": "Slider",
}
# roles that are containers / generic: do not constrain the UIA search with them
GENERIC_ROLES = {"form", "container", "element", "cell", "row", "table", "list", "menu", "toolbar", "pane", "group"}

IGNORED = (
    r"^using\s", r"^namespace\b", r"^(public|internal|private|static|partial|sealed|abstract)\b.*\b(class|struct)\b",
    r"^\[", r"^#", r"^//", r"^Mouse\.Default", r"^Keyboard\.Default", r"^Delay\.SpeedFactor",
    r"^Init\(\)", r"^[{}];?$", r"^(public|private|internal|protected|static|void|\w+)\s+(?:ITestModule\.)?Run\s*\(",
    r"^Report\.", r"^repo\.[\w.]+\.(Focus|EnsureVisible)\(",
)
CONTROL_FLOW = re.compile(r"^(if|else|for|foreach|while|do|switch|try|catch|finally|return|throw)\b")
DECLARATION = re.compile(r"^(?:var|string|int|long|double|float|decimal|bool|List<[^>]+>)\s+\w+\s*=")
ATTR_TEXT = ("text", "innertext", "accessiblename", "value")


def repo_path(expr: str) -> str:
    """repo.Calculator.Button1.Self / .SelfInfo / ButtonInfo  ->  'Calculator.Button1'"""
    parts = expr.strip().split(".")
    if parts and parts[0] == "repo":
        parts = parts[1:]
    while parts and parts[-1] in ("Self", "SelfInfo", "Info"):
        parts.pop()
    if parts and parts[-1].endswith("Info") and len(parts[-1]) > 4:
        parts[-1] = parts[-1][:-4]
    return ".".join(parts)


@dataclass
class Conversion:
    steps: list = field(default_factory=list)
    converted: list = field(default_factory=list)
    needs_script: bool = False
    ignored: int = 0
    unsupported: list = field(default_factory=list)
    unsupported_details: list = field(default_factory=list)
    assumptions: list = field(default_factory=list)
    reason: str = ""

    @property
    def ok(self) -> bool:
        return not self.needs_script


def _lit(s: str):
    s = s.strip()
    if s.startswith('@"') and s.endswith('"') and len(s) >= 3:
        return s[2:-1].replace('""', '"')
    if len(s) >= 2 and s[0] == s[-1] == '"':
        try:
            return bytes(s[1:-1], "utf-8").decode("unicode_escape")
        except UnicodeDecodeError:
            raw = s[1:-1]
            for esc, rep in [('\\\\', '\\'), ('\\"', '"'), ('\\n', '\n'), ('\\r', '\r'), ('\\t', '\t')]:
                raw = raw.replace(esc, rep)
            return raw
    return None


def target_for(repo: dict, path: str) -> tuple[dict, dict]:
    """(target, window) for a repository item path. Unknown items still convert, by name."""
    item = repo.get(path, {})
    role = (item.get("role") or "").lower()
    leaf = path.split(".")[-1]
    target = {"x": 0, "y": 0, "name": leaf}
    if role in UIA_ROLES:
        target["role"] = UIA_ROLES[role]
    if item.get("automation_id"):
        target["automation_id"] = item["automation_id"]
    if item.get("label") and item["label"] != leaf:
        target["text"] = item["label"]
    if item.get("value"):
        target["value"] = item["value"]
    target["source_locator"] = {"kind": "ranorex", "path": path}
    if item.get("rxpath"):
        target["xpath"] = item["rxpath"]
        target["xpath_dialect"] = "ranorex"
    window = {"title": item.get("window_title", ""), "process": item.get("process_name", "")}
    return target, window


def convert(cs_source: str, repo: dict, source_name: str = "") -> Conversion:
    conv = Conversion()
    cur_window = {"title": "", "process": ""}
    in_block_comment = False
    current_line_no = 0

    def add(step_type, params=None, target=None, window=None, check=None):
        step = {"id": len(conv.steps) + 1, "type": step_type, "t_ms": 0,
                "window": dict(window or cur_window), "validations": []}
        if params:
            step["params"] = params
        if target:
            step["target"] = target
        if check:
            step["check"] = check
        step["source"] = {"file": source_name, "line": current_line_no}
        step["description"] = describe_step(step)
        conv.steps.append(step)
        conv.converted.append({"source_line": current_line_no, "operation": step_type,
                              "step_id": step["id"], "action": step_type})

    def element(path):
        nonlocal cur_window
        if path not in repo:
            conv.assumptions.append(f"Repository item {path!r} was not found; generated locator uses the logical item name only.")
        tgt, win = target_for(repo, path)
        if win["title"]:
            cur_window = win
        return tgt, (win if win["title"] else cur_window)

    for current_line_no, raw in enumerate(cs_source.splitlines(), 1):
        line = raw.strip()
        if in_block_comment:
            in_block_comment = "*/" not in line
            continue
        if line.startswith("/*"):
            in_block_comment = "*/" not in line
            continue
        if not line:
            continue
        if any(re.match(p, line) for p in IGNORED):
            conv.ignored += 1
            continue
        if CONTROL_FLOW.match(line) or DECLARATION.match(line):
            conv.needs_script, conv.reason = True, f"control flow / variables: {line[:60]}"
            conv.unsupported_details.append({"source_line": current_line_no, "construct": line,
                                             "reason": "Translated through the Ranorex script path rather than static steps."})
            return conv

        m = re.match(r'^Host\.Local\.RunApplication\(\s*(".*?")\s*(?:,\s*(".*?")\s*)?(?:,.*)?\);$', line)
        if m:
            add("launch_app", {"exe": _lit(m[1]), "args": _lit(m[2]) if m[2] else ""})
            continue

        m = re.match(r"^(repo\.[\w.]+?)\.(Click|DoubleClick)\((.*)\);$", line)
        if m:
            tgt, win = element(repo_path(m[1]))
            kind = "double_click" if m[2] == "DoubleClick" else ("right_click" if "Right" in m[3] else "click")
            add(kind, {"button": "right" if kind == "right_click" else "left"}, tgt, win)
            continue

        m = re.match(r"^(repo\.[\w.]+?)\.MoveTo\((.*)\);$", line)
        if m:
            tgt, win = element(repo_path(m[1]))
            add("hover", target=tgt, window=win)
            continue

        m = re.match(r"^(repo\.[\w.]+?)\.PressKeys\((.+)\);$", line)
        if m:
            seq = _lit(m[2])
            if seq is None:
                conv.unsupported.append(line)
                conv.unsupported_details.append({"source_line": current_line_no, "construct": line,
                                                 "reason": "Keyboard sequence is not a supported string literal."})
                continue
            tgt, win = element(repo_path(m[1]))
            add("click", {"button": "left"}, tgt, win)        # PressKeys focuses the element first
            for k in parse_key_sequence(seq):
                add(k["type"], k["params"], tgt if k["type"] == "type" else None, win)
            continue

        m = re.match(r"^Keyboard\.Press\((.+)\);$", line)
        if m:
            seq = _lit(m[1])
            if seq is None:
                conv.unsupported.append(line)
                conv.unsupported_details.append({"source_line": current_line_no, "construct": line,
                                                 "reason": "Keyboard sequence is not a supported string literal."})
                continue
            for k in parse_key_sequence(seq):
                add(k["type"], k["params"])
            continue

        m = re.match(r"^(?:Delay\.Milliseconds|Thread\.Sleep)\((\d+)\);$", line)
        if m:
            add("wait", {"ms": int(m[1])})
            continue
        m = re.match(r"^Delay\.Seconds\((\d+(?:\.\d+)?)\);$", line)
        if m:
            add("wait", {"ms": int(float(m[1]) * 1000)})
            continue

        m = re.match(r"^Validate\.(Exists|NotExists)\((repo\.[\w.]+?)(?:\s*,.*)?\);$", line)
        if m:
            tgt, win = element(repo_path(m[2]))
            add("validate", target=tgt, window=win,
                check={"type": "element_exists" if m[1] == "Exists" else "element_not_exists"})
            continue

        m = re.match(r'^Validate\.Attribute(Equal|Contains)\((repo\.[\w.]+?)\s*,\s*"(\w+)"\s*,\s*(".*?")(?:\s*,.*)?\);$', line)
        if m and m[3].lower() in ATTR_TEXT:
            expected = _lit(m[4])
            tgt, win = element(repo_path(m[2]))
            add("validate", target=tgt, window=win,
                check={"type": "text_equals" if m[1] == "Equal" else "text_contains", "expected": expected})
            continue

        conv.unsupported.append(line)
        conv.unsupported_details.append({"source_line": current_line_no, "construct": line,
                                         "reason": "No supported Ranorex statement rule matched this line."})

    return conv
