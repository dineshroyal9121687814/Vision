"""
Script mode: run a translated Ranorex script (Python with `ctx.*` calls) on the
SAME engine as recorded tests - same Resolver (native -> template -> ORB -> OCR
-> AI -> heal), same Validator, same run.json / HTML report.

Every ctx call becomes a normal step executed by Player._run_step, so the
script gets waits, window activation, settle-wait and failure screenshots.
A failed action or validation raises ValidationError (script stops, like Ranorex).
"""
from __future__ import annotations

import ast
import json
from datetime import datetime
from pathlib import Path
from types import ModuleType

from core import paths
from core.ai.describe import describe_step
from core.importers.ranorex.cs_to_steps import target_for
from core.importers.ranorex.keys import parse_key_sequence
from core.importers.ranorex.script_safety import validate_script_tree
from core.playback.player import Player


def rx_range(a, b=None, step=1):
    """range() that can never run away: at most 10 000 iterations."""
    if b is None:
        a, b = 0, a
    r = range(int(a), int(b), int(step) or 1)
    return r[:10_000]


def rx_format(fmt, *args):
    return str(fmt).format(*[("" if a is None else a) for a in args])


def rx_concat(*parts):
    return "".join("" if p is None else ("true" if p is True else "false" if p is False else str(p)) for p in parts)


HELPERS = {"rx_range": rx_range, "rx_format": rx_format, "rx_concat": rx_concat, "len": len, "str": str,
           "int": int, "float": float, "abs": abs, "min": min, "max": max, "bool": bool}


class ValidationError(AssertionError):
    pass


class RxContext:
    def __init__(self, name: str, repo: dict, project_dir, options=None, dry_run=False,
                 on_step=None, should_stop=None, backend=None, grab=None):
        self.repo = repo
        self.name = name
        self.test = {"name": name, "title": name, "steps": [], "source": {"type": "ranorex_script"}}
        self.player = Player(self.test, options, backend=backend, on_step=on_step,
                             should_stop=should_stop, dry_run=dry_run, grab=grab, base_dir=project_dir)
        self.results: list[dict] = []
        self._window = {"title": "", "process": ""}
        self._started: datetime | None = None

    # ------------------------------------------------------------ plumbing
    def begin(self):
        self._started = self.player.begin()

    def _element(self, path: str):
        tgt, win = target_for(self.repo, path)
        if win["title"]:
            self._window = win
        return tgt, (win if win["title"] else self._window)

    def _do(self, step_type, params=None, target=None, window=None, check=None) -> dict:
        step = {"id": len(self.test["steps"]) + 1, "type": step_type, "t_ms": 0,
                "window": dict(window or self._window), "validations": []}
        if params:
            step["params"] = params
        if target:
            step["target"] = target
        if check:
            step["check"] = check
        step["description"] = describe_step(step)
        self.test["steps"].append(step)
        self.player._emit({"id": step["id"], "status": "running", "description": step["description"]})
        res = self.player._run_step(step)
        self.results.append(res)
        self.player._emit(res)
        if res["status"] in ("failed", "aborted"):
            raise ValidationError(res.get("error") or f"{step['description']} failed")
        return res

    # ------------------------------------------------------------ actions
    def click(self, path):
        t, w = self._element(path)
        self._do("click", {"button": "left"}, t, w)

    def double_click(self, path):
        t, w = self._element(path)
        self._do("double_click", {"button": "left"}, t, w)

    def right_click(self, path):
        t, w = self._element(path)
        self._do("right_click", {"button": "right"}, t, w)

    def hover(self, path):
        t, w = self._element(path)
        self._do("hover", None, t, w)

    def type_text(self, path, text):
        self.click(path)
        self.press_keys(text)

    def press_keys(self, spec):
        for k in parse_key_sequence(str(spec)):
            self._do(k["type"], k["params"])

    def delay(self, ms):
        self._do("wait", {"ms": int(float(ms))})

    def run_app(self, exe, args=""):
        self._do("launch_app", {"exe": exe, "args": args})

    def screenshot(self):
        pass   # failures are screenshotted automatically

    def log(self, level, category, message):
        print(f"[{level}] {category}: {message}")

    # ------------------------------------------------------------ validation
    def validate_exists(self, path):
        t, w = self._element(path)
        self._do("validate", target=t, window=w, check={"type": "element_exists"})

    def validate_not_exists(self, path):
        t, w = self._element(path)
        self._do("validate", target=t, window=w, check={"type": "element_not_exists"})

    def validate_text(self, path, expected):
        t, w = self._element(path)
        self._do("validate", target=t, window=w, check={"type": "text_equals", "expected": str(expected)})

    def get_text(self, path):
        t, w = self._element(path)
        if self.player.dry_run:
            return t.get("name", "")
        actual, _how = self.player.validator._read_text(t, w)
        return actual if actual is not None else t.get("name", "")

    def validate_text_contains(self, path, expected):
        t, w = self._element(path)
        self._do("validate", target=t, window=w, check={"type": "text_contains", "expected": str(expected)})

    def exists(self, path, timeout_s=None):
        """Non-failing existence test (Ranorex ``Exists()``)."""
        if self.player.dry_run:
            return True
        from core.playback.resolver import ElementNotFound
        t, w = self._element(path)
        try:
            self.player.resolver.resolve(t, w, 2.0 if timeout_s is None else float(timeout_s))
            return True
        except ElementNotFound:
            return False

    def assert_true(self, value, message=""):
        self._assert(bool(value), message or "Validate.IsTrue failed")

    def assert_equal(self, a, b):
        self._assert(a == b, f"Validate.AreEqual failed: {a!r} != {b!r}")

    def _assert(self, ok, message):
        row = {"id": 20_000 + len(self.results), "type": "assert", "description": message if not ok else "assertion",
               "status": "passed" if ok else "failed", "method": "", "validations": []}
        if not ok:
            row["error"] = message
        self.results.append(row)
        self.player._emit(row)
        if not ok:
            raise ValidationError(message)

    # ------------------------------------------------------------ finish
    def finish(self, status: str) -> dict:
        return self.player.finish(self.results, status, self._started or datetime.now(), kind="ranorex_script")


def run_script(script, repo_path=None, options=None, dry_run=False, on_step=None, should_stop=None,
               backend=None, grab=None) -> dict:
    script = Path(script)
    source = script.read_text(encoding="utf-8")
    tree = ast.parse(source, filename=str(script))
    safety_errors = validate_script_tree(tree)
    if safety_errors:
        raise ValueError("Imported script failed safety validation: " + "; ".join(safety_errors))
    repo_path = Path(repo_path) if repo_path else script.with_name("repository.json")
    repo = json.loads(repo_path.read_text(encoding="utf-8")) if repo_path.exists() else {}
    mod = ModuleType("rx_imported_" + script.stem)
    safe_globals = {"__builtins__": {"range": range, **HELPERS}, "__name__": mod.__name__, **HELPERS}
    exec(compile(tree, str(script), "exec"), safe_globals, safe_globals)

    ctx = RxContext(f"{script.parent.name}__{script.stem}", repo, script.parent, options, dry_run,
                    on_step, should_stop, backend, grab)
    ctx.begin()
    status = "passed"
    try:
        safe_globals["run"](ctx)
    except ValidationError:
        status = "failed"
    except Exception as e:   # a bug in the translated script must be reported, not crash the GUI
        status = "failed"
        ctx.results.append({"id": len(ctx.results) + 1, "type": "script", "description": "Script error",
                            "status": "failed", "method": "", "validations": [],
                            "error": f"{type(e).__name__}: {e}"})
    if should_stop and should_stop():
        status = "aborted"
    return ctx.finish(status)
