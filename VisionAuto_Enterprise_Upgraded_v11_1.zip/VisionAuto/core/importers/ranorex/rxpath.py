"""
RanoreXPath parser.

RanoreXPath looks like:
    /form[@title='Calculator']/container[@controlname='main']/button[@text='=']

We don't try to implement the full XPath-like query language. We extract
what VisionAuto's locator chain can actually use:
  - window title / process name (from the first segment)
  - leaf role (button, text, checkbox, ...)
  - leaf label (text / accessiblename / title / controlname / automationid)
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field

_SEGMENT = re.compile(r"/{1,2}(?P<role>[\w\*]+)(?P<preds>(?:\[[^\]]*\])*)")
_ATTR = re.compile(r"@(?P<name>\w+)\s*(?P<op>=|~|!=)\s*'(?P<val>(?:[^'\\]|\\.)*)'")

LABEL_ATTRS = ("text", "accessiblename", "title", "caption", "controlname", "automationid", "id", "name")


@dataclass
class Segment:
    role: str
    attrs: dict = field(default_factory=dict)


@dataclass
class RxPathInfo:
    raw: str
    segments: list = field(default_factory=list)
    window_title: str = ""
    process_name: str = ""
    role: str = ""
    label: str = ""
    automation_id: str = ""
    value: str = ""


def parse_rxpath(raw: str) -> RxPathInfo:
    info = RxPathInfo(raw=raw or "")
    for m in _SEGMENT.finditer(raw or ""):
        attrs = {}
        for a in _ATTR.finditer(m.group("preds") or ""):
            if a.group("op") == "!=":
                continue  # negative predicates can't be used to locate anything
            attrs[a.group("name").lower()] = a.group("val").replace("\\'", "'")
        info.segments.append(Segment(role=m.group("role").lower(), attrs=attrs))

    if info.segments:
        top = info.segments[0]
        info.window_title = top.attrs.get("title") or top.attrs.get("text") or top.attrs.get("accessiblename", "")
        info.process_name = top.attrs.get("processname", "")
        leaf = info.segments[-1]
        info.role = leaf.role
        for key in LABEL_ATTRS:
            if leaf.attrs.get(key):
                info.label = leaf.attrs[key]
                break
        # WinForms exposes the control's Name as UIA AutomationId, so controlname is a valid fallback
        info.automation_id = leaf.attrs.get("automationid") or leaf.attrs.get("controlname", "")
        info.value = leaf.attrs.get("value", "")
    return info
