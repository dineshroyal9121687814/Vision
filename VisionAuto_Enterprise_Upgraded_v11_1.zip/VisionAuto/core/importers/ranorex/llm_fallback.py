"""
Optional small-local-LLM fallback for C# lines the rule-based translator
can't handle. Uses Ollama (free, offline) over its local HTTP API.

    ollama pull qwen2.5-coder:1.5b      # ~1 GB, runs on CPU
    python -m core.importers.ranorex.cli import ... --llm

Safety: model output is accepted only when every statement is a direct call to
an allowlisted ``ctx`` method with literal arguments. Imports, attribute
traversal, file/process access, and executable expressions become TODOs.
"""
from __future__ import annotations

import ast
import json
import re
from urllib.parse import urlsplit
import urllib.request

DEFAULT_MODEL = "qwen2.5-coder:1.5b"

PROMPT = """Translate ONE C# statement from a Ranorex test into Python.
Available API (already in scope): ctx.click(path), ctx.double_click(path), ctx.right_click(path),
ctx.type_text(path, text), ctx.press_keys(spec), ctx.delay(ms), ctx.validate_exists(path),
ctx.validate_text(path, expected), ctx.get_text(path), ctx.log(level, category, message),
ctx.screenshot(). `path` is a dotted repository name string,
e.g. "Calculator.Button1". Output ONLY the Python line(s), no markdown, no explanation.
If it cannot be translated, output exactly: SKIP

C#: {line}
Python:"""


class LlmTranslator:
    def __init__(self, model: str = DEFAULT_MODEL, timeout: float = 60.0,
                 base_url: str = "http://localhost:11434"):
        self.model = model
        self.timeout = timeout
        parsed = urlsplit(base_url.strip())
        if parsed.scheme not in {"http", "https"} or not parsed.netloc:
            raise ValueError("Ollama base URL must be an absolute http(s) URL.")
        self.base_url = base_url.rstrip("/")
        self.available = True

    def translate_line(self, line: str) -> str | None:
        if not self.available:
            return None
        body = json.dumps({
            "model": self.model,
            "prompt": PROMPT.format(line=line.strip()),
            "stream": False,
            "options": {"temperature": 0},
        }).encode()
        try:
            req = urllib.request.Request(self.base_url + "/api/generate", data=body,
                                        headers={"Content-Type": "application/json"})
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                text = json.loads(resp.read())["response"]
        except Exception:
            self.available = False  # Ollama not running: stop trying for this run
            return None

        text = re.sub(r"^```(?:python)?|```$", "", text.strip(), flags=re.M).strip()
        if not text or text.upper() == "SKIP":
            return None
        try:
            tree = ast.parse(text)
        except SyntaxError:
            return None
        if not _safe_generated_tree(tree):
            return None
        return text


_ALLOWED_CONTEXT_CALLS = {
    "click", "double_click", "right_click", "type_text", "press_keys", "delay",
    "validate_exists", "validate_text", "get_text", "log", "screenshot",
}


def _literal(node: ast.AST) -> bool:
    if isinstance(node, ast.Constant):
        return True
    if isinstance(node, (ast.List, ast.Tuple, ast.Set)):
        return all(_literal(item) for item in node.elts)
    if isinstance(node, ast.Dict):
        return all(k is None or _literal(k) for k in node.keys) and all(_literal(v) for v in node.values)
    return False


def _safe_generated_tree(tree: ast.AST) -> bool:
    """Accept only direct calls to the narrow RxContext API with literal args."""
    if not isinstance(tree, ast.Module) or not tree.body:
        return False
    for stmt in tree.body:
        if not isinstance(stmt, ast.Expr) or not isinstance(stmt.value, ast.Call):
            return False
        call = stmt.value
        if not (isinstance(call.func, ast.Attribute) and isinstance(call.func.value, ast.Name)
                and call.func.value.id == "ctx" and call.func.attr in _ALLOWED_CONTEXT_CALLS):
            return False
        if not all(_literal(arg) for arg in call.args):
            return False
        if not all(keyword.arg is not None and _literal(keyword.value) for keyword in call.keywords):
            return False
    return True
