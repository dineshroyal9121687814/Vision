"""
Ranorex importer CLI.

  inspect : show what the .rxrep parser extracted (check this on your real file first)
  import  : .rxrep + .cs  ->  native tests and/or scripts in the VisionAuto workspace
  run     : run an imported SCRIPT (native tests run with: python -m core.playback.playback --name X)
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[3]))

from core import paths, settings
from core.importers.ranorex.importer import import_project
from core.importers.ranorex.repo_parser import parse_rxrep
from core.importers.ranorex.runtime import run_script


def cmd_inspect(a):
    repo = parse_rxrep(a.rxrep)
    print(json.dumps(repo, indent=2))
    print(f"\n{len(repo)} repository items found")


def cmd_import(a):
    llm = None
    if a.llm:
        from core.importers.ranorex.llm_fallback import LlmTranslator
        llm = LlmTranslator(model=a.model, base_url=a.base_url or settings.load()["llm_base_url"])
    res = import_project(a.rxrep, a.cs, a.project, llm=llm, force_script=a.script_mode,
                         overwrite=a.overwrite)
    print(f"Project '{res['project']}': {res['repository_items']} repository items")
    for it in res["items"]:
        if it["mode"] == "native":
            print(f"  {it['file']}: NATIVE test '{it['test']}' ({it['steps']} steps, {it['ignored']} ignored)")
            print(f"      run: python -m core.playback.playback --name {it['test']}")
        else:
            print(f"  {it['file']}: SCRIPT {it['script']}  [{it['reason']}]")
            print(f"      run: python -m core.importers.ranorex.cli run --script {it['script']}")
        for u in it["unsupported"]:
            print(f"      TODO: {u}")


def cmd_run(a):
    paths.setup_logging()

    def show(r):
        if r.get("status") != "running":
            print(f"  [{r['id']:>3}] {r['status'].upper():7} {r.get('description', '')}"
                  + (f"\n          {r['error']}" if r.get("error") else ""))

    run = run_script(a.script, a.repo, {"timeout_s": a.timeout}, dry_run=a.dry_run, on_step=show)
    s = run["summary"]
    print(f"\n{run['status'].upper()}: {s['passed']}/{s['total']} steps -> {run['_dir']}")
    raise SystemExit(0 if run["status"] == "passed" else 1)


def main():
    p = argparse.ArgumentParser(description="VisionAuto Ranorex importer")
    sub = p.add_subparsers(dest="cmd", required=True)

    s = sub.add_parser("inspect")
    s.add_argument("--rxrep", required=True)
    s.set_defaults(fn=cmd_inspect)

    s = sub.add_parser("import")
    s.add_argument("--rxrep")
    s.add_argument("--cs", nargs="+", required=True)
    s.add_argument("--project", required=True)
    s.add_argument("--script-mode", action="store_true", help="never convert to native steps")
    s.add_argument("--overwrite", action="store_true", help="replace tests/scripts created by an earlier import")
    s.add_argument("--llm", action="store_true", help="local Ollama model for lines rules can't translate")
    s.add_argument("--model", default="qwen2.5-coder:1.5b")
    s.add_argument("--base-url", default=None, help="Ollama service base URL (defaults to workspace settings)")
    s.set_defaults(fn=cmd_import)

    s = sub.add_parser("run")
    s.add_argument("--script", required=True)
    s.add_argument("--repo")
    s.add_argument("--dry-run", action="store_true")
    s.add_argument("--timeout", type=float, default=10.0)
    s.set_defaults(fn=cmd_run)

    a = p.parse_args()
    a.fn(a)


if __name__ == "__main__":
    main()
