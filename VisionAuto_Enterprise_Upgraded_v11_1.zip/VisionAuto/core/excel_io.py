"""Fast, safe table I/O for data-driven testing: CSV / TSV / XLSX / JSON.

Why this exists: writing a spreadsheet one cell at a time (open -> set one cell -> save -> repeat) costs a whole
file round-trip per cell.  Here a workbook is opened **once**, every value is set in memory and it is saved
**once** (atomically, via a temp file), with progress and cancellation between chunks.

Data integrity rules (speed never wins over these):
* numbers, booleans and dates keep their type; ``None`` stays an empty cell
* a text value that starts with ``=`` is written as *text*, never as a formula (``formulas="text"``, default),
  so test data cannot inject formulas; pass ``formulas="keep"`` to opt in
* control characters that XML cannot store are removed and counted in the result (``sanitized``)
* an existing workbook keeps its cell formatting, column widths and other sheets (a ``.bak`` copy is made first);
  features openpyxl cannot round-trip (charts, pivot tables, images in some cases) are *not* guaranteed, which is
  why the backup exists and why for such files the clipboard/COM path (``core/excel_com.py``) is preferable
* an unreadable / locked / wrong-format file raises ``TableError`` with a message a user can act on
"""
from __future__ import annotations

import csv
import io
import json
import os
import re
import shutil
import tempfile
import zipfile
from pathlib import Path
from typing import Callable, Iterable

MAX_XLSX_ROWS, MAX_XLSX_COLS = 1_048_576, 16_384
CHUNK = 2000
_CTRL = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f]")
SUPPORTED = (".csv", ".tsv", ".txt", ".xlsx", ".xlsm", ".json")


class TableError(ValueError):
    """The data file cannot be read / written (the message is shown to the user)."""


class Cancelled(RuntimeError):
    """The operation was cancelled by the caller (nothing is left half-written)."""


Progress = Callable[[int, int], None]


def _tick(progress: Progress | None, cancel: Callable[[], bool] | None, done: int, total: int) -> None:
    if cancel and cancel():
        raise Cancelled("cancelled")
    if progress:
        progress(done, total)


def _ext(path: Path) -> str:
    ext = path.suffix.casefold()
    if ext not in SUPPORTED:
        raise TableError(f"Unsupported file type '{ext or path.name}'. Use one of: {', '.join(SUPPORTED)}.")
    return ext


# ============================================================================ reading
def read_table(path, sheet: str | int | None = None, progress: Progress | None = None,
               cancel: Callable[[], bool] | None = None, required_columns: Iterable[str] | None = None,
               max_rows: int | None = None) -> list[list]:
    """Return every row (including the header row) as a list of lists. Raw types are kept (int, float, str...)."""
    path = Path(path)
    ext = _ext(path)
    if not path.is_file():
        raise TableError(f"Data file not found: {path}")
    try:
        if ext in (".csv", ".tsv", ".txt"):
            rows = _read_csv(path, ext, progress, cancel, max_rows)
        elif ext == ".json":
            rows = _read_json(path)
        else:
            rows = _read_xlsx(path, sheet, progress, cancel, max_rows)
    except (TableError, Cancelled):
        raise
    except PermissionError as exc:
        raise TableError(f"'{path.name}' is locked or not readable ({exc.strerror or exc}). "
                         "Close it in Excel and check the file permissions.") from exc
    except (zipfile.BadZipFile, KeyError) as exc:
        raise TableError(f"'{path.name}' is not a valid Excel workbook (corrupt, or a different format "
                         "saved with an .xlsx extension).") from exc
    except OSError as exc:
        raise TableError(f"Could not read '{path.name}': {exc.strerror or exc}") from exc
    if not rows:
        raise TableError(f"'{path.name}' contains no data.")
    if required_columns:
        header = [str(c if c is not None else "").strip().casefold() for c in rows[0]]
        missing = [c for c in required_columns if str(c).strip().casefold() not in header]
        if missing:
            raise TableError(f"'{path.name}' is missing required column(s): {', '.join(missing)}. "
                             f"Found: {', '.join(str(c) for c in rows[0] if c not in (None, ''))}")
    return rows


def _read_csv(path: Path, ext: str, progress, cancel, max_rows) -> list[list]:
    raw = path.read_bytes()
    try:
        text = raw.decode("utf-8-sig")
    except UnicodeDecodeError:
        text = raw.decode("cp1252", errors="replace")          # Excel's "CSV (comma delimited)" on Windows
    first = text.split("\n", 1)[0]
    delim = "\t" if ext == ".tsv" else (";" if first.count(";") > first.count(",") else ",")
    rows: list[list] = []
    for i, row in enumerate(csv.reader(io.StringIO(text, newline=""), delimiter=delim), 1):
        rows.append(row)
        if i % CHUNK == 0:
            _tick(progress, cancel, i, 0)
        if max_rows and len(rows) >= max_rows:
            break
    _tick(progress, cancel, len(rows), len(rows))
    return rows


def _read_json(path: Path) -> list[list]:
    try:
        data = json.loads(path.read_text(encoding="utf-8-sig"))
    except ValueError as exc:
        raise TableError(f"Invalid JSON in '{path.name}': {exc}") from exc
    if isinstance(data, dict):
        data = data.get("rows", data.get("data"))
    if not isinstance(data, list) or not data:
        raise TableError(f"'{path.name}' must contain a non-empty list of rows (objects or lists).")
    if all(isinstance(r, dict) for r in data):
        header = list(dict.fromkeys(k for r in data for k in r))
        return [header] + [[r.get(k) for k in header] for r in data]
    if all(isinstance(r, list) for r in data):
        return data
    raise TableError(f"'{path.name}': rows must all be objects or all be lists.")


def _read_xlsx(path: Path, sheet, progress, cancel, max_rows) -> list[list]:
    try:
        from openpyxl import load_workbook
    except ImportError as exc:
        raise TableError("Reading .xlsx needs openpyxl (pip install openpyxl), or export the sheet to CSV.") from exc
    wb = load_workbook(path, read_only=True, data_only=True)
    try:
        ws = _pick_sheet(wb, sheet, path)
        total = ws.max_row or 0
        rows: list[list] = []
        for i, r in enumerate(ws.iter_rows(values_only=True), 1):
            rows.append(list(r))
            if i % CHUNK == 0:
                _tick(progress, cancel, i, total)
            if max_rows and len(rows) >= max_rows:
                break
    finally:
        wb.close()
    while rows and not any(c not in (None, "") for c in rows[-1]):       # trailing empty rows left by Excel
        rows.pop()
    _tick(progress, cancel, len(rows), len(rows))
    return rows


def _pick_sheet(wb, sheet, path: Path):
    if sheet in (None, ""):
        return wb.worksheets[0]
    if isinstance(sheet, int):
        if not 0 <= sheet < len(wb.worksheets):
            raise TableError(f"'{path.name}' has {len(wb.worksheets)} sheet(s); index {sheet} does not exist.")
        return wb.worksheets[sheet]
    if sheet not in wb.sheetnames:
        raise TableError(f"Sheet '{sheet}' not found in '{path.name}'. Sheets: {', '.join(wb.sheetnames)}")
    return wb[sheet]


# ============================================================================ writing
def clean_value(v, formulas: str = "text"):
    """-> (value, was_sanitized, force_text). Keeps numbers/bools/dates; strips XML-illegal control characters."""
    if v is None or isinstance(v, (bool, int, float)):
        return v, False, False
    if isinstance(v, str):
        fixed = _CTRL.sub("", v)
        return fixed, fixed != v, (formulas == "text" and fixed.startswith("="))
    if hasattr(v, "isoformat"):                            # date / datetime / time
        return v, False, False
    return str(v), False, False


def write_table(path, rows: list[list], sheet: str | None = None, start: str = "A1",
                progress: Progress | None = None, cancel: Callable[[], bool] | None = None,
                formulas: str = "text", backup: bool = True, overwrite_sheet: bool = False) -> dict:
    """Write ``rows`` to ``path`` in one open/save cycle. Returns ``{"rows", "cells", "sanitized", "path", "backup"}``."""
    path = Path(path)
    ext = _ext(path)
    if not isinstance(rows, list) or any(not isinstance(r, (list, tuple)) for r in rows):
        raise TableError("rows must be a list of lists.")
    if formulas not in ("text", "keep"):
        raise TableError("formulas must be 'text' or 'keep'.")
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        raise TableError(f"Cannot create the folder for '{path}': {exc.strerror or exc}") from exc
    if ext in (".xlsx", ".xlsm"):
        return _write_xlsx(path, rows, sheet, start, progress, cancel, formulas, backup, overwrite_sheet)
    return _write_text(path, ext, rows, progress, cancel, formulas)


def _atomic_replace(tmp: str, path: Path) -> None:
    try:
        os.replace(tmp, path)
    except PermissionError as exc:
        _silent_unlink(tmp)
        raise TableError(f"'{path.name}' is open in another program (probably Excel). "
                         "Close it and try again; nothing was changed.") from exc


def _silent_unlink(p) -> None:
    try:
        os.unlink(p)
    except OSError:
        pass


def _write_text(path: Path, ext: str, rows, progress, cancel, formulas) -> dict:
    fd, tmp = tempfile.mkstemp(prefix=".va-", suffix=ext, dir=path.parent)
    sanitized, cells = 0, 0
    try:
        with os.fdopen(fd, "w", encoding="utf-8-sig" if ext != ".json" else "utf-8", newline="") as fh:
            if ext == ".json":
                out = []
                for i, r in enumerate(rows, 1):
                    out.append([clean_value(c, "keep")[0] if not hasattr(c, "isoformat") else c.isoformat() for c in r])
                    if i % CHUNK == 0:
                        _tick(progress, cancel, i, len(rows))
                header = out[0] if out else []
                if out and all(isinstance(h, str) and h for h in header) and len(set(header)) == len(header):
                    payload = [dict(zip(header, r)) for r in out[1:]]
                else:
                    payload = out
                json.dump(payload, fh, indent=2, ensure_ascii=False)
                cells = sum(len(r) for r in out)
            else:
                w = csv.writer(fh, delimiter="\t" if ext == ".tsv" else ",")
                for i, r in enumerate(rows, 1):
                    line = []
                    for c in r:
                        v, bad, _ = clean_value(c, formulas)
                        sanitized += bad
                        line.append("" if v is None else (v.isoformat() if hasattr(v, "isoformat") else v))
                    w.writerow(line)
                    cells += len(line)
                    if i % CHUNK == 0:
                        _tick(progress, cancel, i, len(rows))
        _tick(progress, cancel, len(rows), len(rows))
    except BaseException:
        _silent_unlink(tmp)
        raise
    _atomic_replace(tmp, path)
    return {"rows": len(rows), "cells": cells, "sanitized": sanitized, "path": str(path), "backup": None}


def _parse_start(start: str) -> tuple[int, int]:
    from openpyxl.utils.cell import coordinate_from_string, column_index_from_string

    try:
        col, row = coordinate_from_string(start.upper())
        return row, column_index_from_string(col)
    except Exception as exc:
        raise TableError(f"Invalid start cell '{start}'. Use a cell like A1 or C5.") from exc


def _write_xlsx(path: Path, rows, sheet, start, progress, cancel, formulas, backup, overwrite_sheet) -> dict:
    try:
        from openpyxl import Workbook, load_workbook
    except ImportError as exc:
        raise TableError("Writing .xlsx needs openpyxl (pip install openpyxl), or use a .csv file.") from exc
    r0, c0 = _parse_start(start)
    width = max((len(r) for r in rows), default=0)
    if r0 + len(rows) - 1 > MAX_XLSX_ROWS or c0 + width - 1 > MAX_XLSX_COLS:
        raise TableError("The data does not fit in an Excel sheet (max 1,048,576 rows x 16,384 columns).")
    sanitized, cells = 0, 0
    bak = None
    _guard = None
    fd, tmp = tempfile.mkstemp(prefix=".va-", suffix=path.suffix, dir=path.parent)
    os.close(fd)
    try:
        existing = path.is_file()
        if existing:
            try:
                wb = load_workbook(path, keep_vba=path.suffix.casefold() == ".xlsm")
            except PermissionError as exc:
                raise TableError(f"'{path.name}' is locked by another program. Close it and retry.") from exc
            except (zipfile.BadZipFile, KeyError) as exc:
                raise TableError(f"'{path.name}' is not a valid workbook; it was not modified.") from exc
            if sheet in (None, ""):
                ws = wb.worksheets[0]
            elif sheet in wb.sheetnames:
                ws = wb[sheet]
            else:
                ws = wb.create_sheet(str(sheet)[:31])
            if overwrite_sheet:
                ws.delete_rows(1, ws.max_row)
            for i, r in enumerate(rows):
                for j, c in enumerate(r):
                    v, bad, as_text = clean_value(c, formulas)
                    sanitized += bad
                    cell = ws.cell(row=r0 + i, column=c0 + j)
                    cell.value = v
                    if as_text:
                        cell.data_type = "s"
                    cells += 1
                if (i + 1) % CHUNK == 0:
                    _tick(progress, cancel, i + 1, len(rows))
            wb.save(tmp)
            wb.close()
        else:
            wb = Workbook(write_only=True)                       # fastest path: streams rows, new file only
            ws = wb.create_sheet(str(sheet)[:31] if sheet else "Sheet1")
            _guard = wb
            for _ in range(r0 - 1):
                ws.append([])
            for i, r in enumerate(rows):
                line = []
                for c in [None] * (c0 - 1) + list(r):
                    v, bad, as_text = clean_value(c, formulas)
                    sanitized += bad
                    if as_text:
                        from openpyxl.cell import WriteOnlyCell

                        wc = WriteOnlyCell(ws, value=v)
                        wc.data_type = "s"
                        v = wc
                    line.append(v)
                ws.append(line)
                cells += len(r)
                if (i + 1) % CHUNK == 0:
                    _tick(progress, cancel, i + 1, len(rows))
            wb.save(tmp)
        _tick(progress, cancel, len(rows), len(rows))
        if existing and backup:
            bak = str(path) + ".bak"
            try:
                shutil.copy2(path, bak)
            except OSError as exc:
                raise TableError(f"Could not create the backup copy '{bak}': {exc.strerror or exc}") from exc
    except BaseException:
        try:
            if _guard is not None:
                _guard.close()
        except Exception:                                # noqa: BLE001 - already failing; the temp file is removed below
            pass
        _silent_unlink(tmp)
        raise
    _atomic_replace(tmp, path)
    return {"rows": len(rows), "cells": cells, "sanitized": sanitized, "path": str(path), "backup": bak}


# ============================================================================ clipboard text (UI paste path)
def to_clipboard_text(rows: list[list], text_prefix: bool = False) -> str:
    """Tab/newline text that Excel (and any grid) splits into cells on paste.

    A cell containing a tab, newline or quote is quoted with doubled quotes - exactly how Excel itself copies it,
    so special characters survive.  ``text_prefix`` writes a leading apostrophe on values that Excel would
    otherwise reinterpret (leading zeros, formulas, dates): verify this on your Excel version (see manual checklist).
    """
    out = []
    for r in rows:
        cells = []
        for c in r:
            v = "" if c is None else (c.isoformat() if hasattr(c, "isoformat") else str(c))
            v = _CTRL.sub("", v)
            if text_prefix and v and (v.startswith("=") or (v.isdigit() and v.startswith("0") and len(v) > 1)):
                v = "'" + v
            if any(ch in v for ch in ('\t', '\n', '\r', '"')):
                v = '"' + v.replace('"', '""') + '"'
            cells.append(v)
        out.append("\t".join(cells))
    return "\r\n".join(out)
