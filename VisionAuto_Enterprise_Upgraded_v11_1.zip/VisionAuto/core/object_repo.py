"""Object repository: every UI object the recorded tests click, drag to or type into - how it is located, how well that has
worked in real runs, and tools to maintain it.

An object is one ``target`` (or drag destination ``to``) of a step. Nothing is stored twice: the repository is a *view* of
the tests on disk, and edits are written back into the test that owns the object (with the test's history snapshot)."""
from __future__ import annotations

import json
from pathlib import Path

from core import testfile

# Locator strategies, strongest first. (key in the target dict, label)
STRATEGIES = (("automation_id", "Automation ID"), ("name", "Name / text"), ("xpath", "XPath"),
              ("visual_neighbors", "Neighbour pictures"), ("neighbors", "Neighbour elements"),
              ("templates", "Image"), ("zone", "Zone"), ("xy", "Coordinates"))
STRENGTH = {"automation_id": 98, "name": 90, "xpath": 80, "visual_neighbors": 78, "neighbors": 75, "templates": 70, "zone": 50, "xy": 20}
METHOD_SCORE = {"excel": 1.0, "point": 1.0, "uia": 1.0, "anchor": 0.95, "image": 0.85, "nbimg": 0.85, "neighbour-image": 0.85,
                "orb": 0.7, "ocr": 0.5, "ai": 0.4, "heal": 0.4, "scroll": 0.8, "coordinates": 0.2}
IDENTITY = ("name", "automation_id", "role", "class_name", "text", "value", "xpath")


def _value(target: dict, key: str) -> str:
    v = target.get(key)
    if key == "xy":
        return f"({target.get('x')}, {target.get('y')})" if target.get("x") is not None else ""
    if key == "templates":
        return ", ".join(sorted(v)) if isinstance(v, dict) else ""
    if key in ("visual_neighbors", "neighbors"):
        return f"{len(v)} item(s)" if v else ""
    if key == "zone":
        return str(v.get("kind") or v.get("name") or "pane") if isinstance(v, dict) else ""
    return str(v or "")


def strategies_of(target: dict) -> list[dict]:
    out = []
    for key, label in STRATEGIES:
        if key == "xy":
            present = target.get("x") is not None
        else:
            present = bool(target.get(key))
        if present:
            out.append({"key": key, "label": label, "value": _value(target, key), "strength": STRENGTH[key]})
    return out


def _history(test_name: str, runs: list[dict]) -> dict[tuple, list[tuple[str, str, str]]]:
    """(step id, tag) -> [(started_at, status, method)] from real (non-dry) runs of this test."""
    hist: dict[tuple, list] = {}
    for r in runs:
        if r.get("test") != test_name or r.get("dry_run"):
            continue
        for st in r.get("steps") or []:
            if not isinstance(st, dict) or st.get("id") is None:
                continue
            hist.setdefault((st["id"], "src"), []).append((r.get("started_at", ""), st.get("status", ""), str(st.get("method") or "")))
    return hist


def reliability(strategies: list[dict], history: list[tuple[str, str, str]]) -> tuple[int, str]:
    """0-100 and where the number came from. With run history it is measured (pass ratio x quality of the method that
    found it); without, it is the strength of the best recorded locator and says so."""
    if history:
        scores = []
        for _, status, method in history[-20:]:
            if status == "passed":
                scores.append(METHOD_SCORE.get(method.split("+")[-1], 0.7))
            elif status == "failed":
                scores.append(0.0)
        if scores:
            return int(round(100 * sum(scores) / len(scores))), f"measured over {len(scores)} run(s)"
    return (max((s["strength"] for s in strategies), default=0), "estimated from the recorded locators (never run)")


def collect(tests: list[dict] | None = None, runs: list[dict] | None = None) -> list[dict]:
    tests = testfile.list_tests() if tests is None else tests
    runs = testfile.list_runs(300) if runs is None else runs
    out = []
    for t in tests:
        try:
            test, directory = testfile.load_test(t["name"] if "dir" not in t else t["dir"])
        except Exception:
            continue
        hist = _history(test.get("name", t["name"]), runs)
        for st in test.get("steps") or []:
            for tag, key in (("src", "target"), ("dst", "to")):
                tg = st.get(key)
                if not isinstance(tg, dict) or not tg:
                    continue
                strat = strategies_of(tg)
                if not strat:
                    continue
                h = hist.get((st.get("id"), tag), [])
                score, basis = reliability(strat, h)
                ok = [x for x in h if x[1] == "passed"]
                win = st.get("to_window") if tag == "dst" and st.get("to_window") else st.get("window") or {}
                out.append({
                    "id": f"{t['name']}:{st.get('id')}:{tag}", "test": t["name"], "step": st.get("id"), "tag": tag,
                    "name": tg.get("name") or tg.get("automation_id") or st.get("description") or f"step {st.get('id')}",
                    "application": win.get("process") or win.get("title") or "",
                    "window": win.get("title", ""), "type": tg.get("role") or "unknown",
                    "locator": strat[0]["label"], "value": strat[0]["value"], "alternatives": strat[1:],
                    "reliability": score, "reliability_basis": basis, "group": tg.get("group", ""),
                    "last_success": ok[-1][0] if ok else "", "last_method": ok[-1][2] if ok else "",
                    "thumbnail": str(Path(directory) / (tg.get("templates") or {}).get("crop100", {}).get("path", ""))
                    if (tg.get("templates") or {}).get("crop100") else "",
                    "healed_note": tg.get("identity_dropped", ""),
                })
    return out


def search(objs: list[dict], text: str = "", application: str = "", min_reliability: int = 0, group: str = "") -> list[dict]:
    q = text.casefold()
    return [o for o in objs
            if (not q or q in " ".join(str(o.get(k, "")) for k in ("name", "test", "value", "type")).casefold())
            and (not application or application.casefold() in str(o.get("application", "")).casefold())
            and o["reliability"] >= min_reliability and (not group or o.get("group", "") == group)]


def _edit(test_name: str, step_id: int, tag: str, fn) -> None:
    test, directory = testfile.load_test(test_name)
    for st in test.get("steps") or []:
        if st.get("id") == step_id:
            tg = st.get("target" if tag == "src" else "to")
            if not isinstance(tg, dict):
                raise KeyError(f"step {step_id} has no {tag} object")
            fn(tg)
            testfile.save_test(test, directory)            # snapshots the previous version into history/
            return
    raise KeyError(f"test '{test_name}' has no step {step_id}")


def update(test_name: str, step_id: int, tag: str, changes: dict) -> None:
    """Edit name / automation id / group / locator order of one object."""
    allowed = {"name", "automation_id", "group", "locator_order", "search_scope"}
    bad = set(changes) - allowed
    if bad:
        raise ValueError(f"Cannot edit {sorted(bad)}; allowed: {sorted(allowed)}")

    def apply(tg):
        for k, v in changes.items():
            if v in ("", None):
                tg.pop(k, None)
            else:
                tg[k] = v
    _edit(test_name, step_id, tag, apply)


def forget_identity(test_name: str, step_id: int, tag: str) -> None:
    """'Delete' an object's semantic identity (name, id ...): the step keeps position, pictures and neighbours. Used when
    the recorded name is wrong. The previous version stays restorable from the test's history."""
    def apply(tg):
        for k in IDENTITY:
            tg.pop(k, None)
        tg["identity_dropped"] = "removed in Object Repository"
    _edit(test_name, step_id, tag, apply)


def export_json(objs: list[dict], path) -> Path:
    path = Path(path)
    path.write_text(json.dumps([{k: v for k, v in o.items() if k != "thumbnail"} for o in objs], indent=2, ensure_ascii=False),
                    encoding="utf-8")
    return path


def import_json(path) -> dict:
    """Apply names / groups from an exported file back to the tests (matching by test + step + tag). Returns counts."""
    rows = json.loads(Path(path).read_text(encoding="utf-8"))
    if not isinstance(rows, list):
        raise ValueError("Not an object repository export")
    applied, skipped = 0, 0
    for o in rows:
        try:
            changes = {k: o[k] for k in ("name", "group") if o.get(k)}
            update(o["test"], int(o["step"]), o.get("tag", "src"), changes)
            applied += 1
        except (KeyError, ValueError, TypeError, FileNotFoundError):
            skipped += 1
    return {"applied": applied, "skipped": skipped}
