"""
HTML run report: one self-contained file (CSS inline, failure screenshots embedded
as base64) that can be e-mailed, attached to a ticket or archived by CI.

    python -m core.reports.report <test name | run folder>      # newest run of a test, or a specific run
"""
from __future__ import annotations

import base64
import html
import json
import sys
from pathlib import Path

CSS = """
:root{--bg:#f6f7f9;--card:#fff;--ink:#14171c;--mute:#6a7381;--line:#e3e6ea;--ok:#127a43;--okbg:#e4f5ec;
--bad:#b3261e;--badbg:#fdeceb;--warn:#8a5a00;--warnbg:#fff3d6;--skip:#5b6472;--skipbg:#eceff3;--acc:#2b5bd7}
@media(prefers-color-scheme:dark){:root{--bg:#0e1116;--card:#171b22;--ink:#e8ebf0;--mute:#98a2b3;--line:#262c36;
--ok:#4cc38a;--okbg:#12301f;--bad:#ff8a80;--badbg:#3a1714;--warn:#f1c15a;--warnbg:#3a2d0c;--skip:#aab3c2;--skipbg:#222833;--acc:#7aa2ff}}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font:14px/1.5 system-ui,Segoe UI,Roboto,sans-serif}
main{max-width:1080px;margin:0 auto;padding:28px 20px 60px}
h1{font-size:22px;margin:0 0 2px}.sub{color:var(--mute);margin-bottom:22px}
.status{display:inline-block;padding:2px 10px;border-radius:999px;font-weight:600;font-size:12px;letter-spacing:.04em}
.passed{background:var(--okbg);color:var(--ok)}.failed{background:var(--badbg);color:var(--bad)}
.skipped,.aborted,.invalid,.cancelled{background:var(--skipbg);color:var(--skip)}.healed,.inconclusive{background:var(--warnbg);color:var(--warn)}
.cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:12px;margin:18px 0}
.card{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:12px 14px}
.card b{display:block;font-size:24px}.card span{color:var(--mute);font-size:12px}
.bar{display:flex;height:10px;border-radius:6px;overflow:hidden;background:var(--line);margin:6px 0 22px}
.bar i{display:block;min-width:2px}.bar .passed{background:var(--ok)}.bar .failed{background:var(--bad)}
table{width:100%;border-collapse:collapse;background:var(--card);border:1px solid var(--line);border-radius:10px;overflow:hidden}
th,td{text-align:left;padding:9px 12px;border-bottom:1px solid var(--line);vertical-align:top}
th{font-size:11px;text-transform:uppercase;letter-spacing:.06em;color:var(--mute)}
tr:last-child td{border-bottom:0}.mono{font-family:ui-monospace,Consolas,monospace;font-size:12px;color:var(--mute)}
.err{color:var(--bad);margin-top:4px}.val{margin-top:4px;font-size:13px}.val .status{font-size:10px;padding:1px 7px}
img.shot{max-width:100%;border:1px solid var(--line);border-radius:8px;margin-top:8px}
h2{font-size:15px;margin:26px 0 8px}
.retry{margin-top:8px;padding:8px 12px;background:var(--warnbg);border-left:3px solid var(--warn);border-radius:4px;font-size:12px}
.retry .mono{display:block}
"""


def _e(x) -> str:
    return html.escape(str(x if x is not None else ""))


def _chip(status: str) -> str:
    return f'<span class="status {_e(status)}">{_e(status).upper()}</span>'


def _shot(run_dir: Path, name: str | None) -> str:
    if not name:
        return ""
    root = Path(run_dir).resolve()
    p = (root / name).resolve()
    try:
        p.relative_to(root)
    except ValueError:
        return ""
    if not p.is_file():
        return ""
    mime = "image/png" if p.suffix.lower() == ".png" else "image/jpeg"
    return f'<img class="shot" alt="screenshot at failure" src="data:{mime};base64,{base64.b64encode(p.read_bytes()).decode()}">'


def _retry_html(history, run_dir: Path) -> str:
    """Every retry attempt of a step: why it failed, what the diagnosis said, who decided, and the outcome."""
    if not history:
        return ""
    out = []
    for h in history:
        diag = h.get("diagnosis") if isinstance(h.get("diagnosis"), dict) else {}
        out.append(
            f'<div class="retry"><b>Retry attempt {_e(h.get("attempt"))}</b> &middot; decision: <b>{_e(h.get("decision", "-"))}</b> '
            f'(by {_e(h.get("via", "-"))}) &middot; result: {_e(h.get("result", "-"))}'
            f'<span class="mono">at {_e(h.get("at"))} &middot; {_e(h.get("category"))} &middot; '
            f'{"input had been sent" if h.get("input_sent") else "no input was sent"} &middot; '
            f'corrective action: {_e(h.get("corrective_action", "-"))}'
            f'{" &middot; user answer: " + _e(h.get("answer")) if h.get("asked") else ""}</span>'
            f'<span class="err">{_e(h.get("error"))}</span>'
            + (f'<span class="mono">diagnosis: {_e(diag.get("summary", ""))} &mdash; {_e(diag.get("suggestion", ""))}</span>' if diag else "")
            + (f'<span class="mono">{_e(h["note"])}</span>' if h.get("note") else "")
            + _shot(run_dir, h.get("screenshot")) + "</div>")
    return "".join(out)


def build_html(run: dict, run_dir: Path) -> str:
    s = run.get("summary", {})
    total = max(s.get("total", 0), 1)
    rows = []
    for st in run.get("steps", []):
        val_rows = []
        for v in st.get("validations", []):
            expected = f'<span class="mono">expected: {_e(json.dumps(v["expected"], ensure_ascii=False))}</span>' if "expected" in v else ""
            actual = f'<span class="mono">actual: {_e(json.dumps(v["actual"], ensure_ascii=False))}</span>' if "actual" in v else ""
            detail = f'<span class="mono">{_e(v.get("detail"))}</span>' if v.get("detail") else ""
            val_rows.append(f'<div class="val">{_chip(v.get("status", ""))} {_e(v.get("description"))} {expected} {actual} {detail}</div>')
        vals = "".join(val_rows)
        err = f'<div class="err">{_e(st["error"])}</div>' if st.get("error") else ""
        diag = st.get("ai_diagnosis")
        diag_html = ""
        if isinstance(diag, dict):
            diag_html = (
                f'<div style="margin-top:6px;padding:8px 12px;background:rgba(88,166,255,0.08);border-left:3px solid #58a6ff;border-radius:4px;font-size:12px">'
                f'<b style="color:#58a6ff">&#128161; AI Diagnosis ({_e(diag.get("source", "AI"))}):</b> '
                f'<div><b>Issue:</b> {_e(diag.get("summary", ""))}</div>'
                f'<div><b>Likely Cause:</b> {_e(diag.get("likely_cause", ""))}</div>'
                f'<div style="color:var(--ok)"><b>Recommendation:</b> {_e(diag.get("suggestion", ""))}</div>'
                f'</div>'
            )
        retry_html = _retry_html(st.get("retry_history"), run_dir)
        confidence = st.get("locator_confidence")
        evidence = st.get("locator_evidence") or {}
        locator_title = _e(json.dumps(evidence, ensure_ascii=False, sort_keys=True)) if evidence else ""
        locator_text = _e(st.get("method") or "")
        if isinstance(confidence, (int, float)):
            locator_text += f'<br><span class="mono">confidence {_e(f"{confidence:.3f}")}</span>'
        app_badge = f'<span class="status" style="background:var(--line);margin-right:6px;font-size:11px">{_e(st["app"])}</span>' if st.get("app") else ""
        save_badge = f'<div class="mono" style="color:var(--acc);margin-top:2px">&rarr; saved: {_e(json.dumps(st["saved_as"]))}</div>' if st.get("saved_as") else ""
        rows.append(
            f'<tr><td class="mono">{_e(st.get("id"))}</td>'
            f'<td>{app_badge}{_e(st.get("description"))}{save_badge}{vals}{err}{diag_html}{retry_html}{_shot(run_dir, st.get("screenshot"))}</td>'
            f'<td>{_chip(st.get("status", ""))}</td>'
            f'<td class="mono" title="{locator_title}">{locator_text}</td>'
            f'<td class="mono">{_e(st.get("duration_ms", 0))} ms</td></tr>')
    retries = sum(len(st.get("retry_history") or []) for st in run.get("steps", [])) + len(run.get("restarts") or [])
    heal_rows = []
    for h in run.get("heals", []):
        before_after = {"before": h.get("old_locator"), "after": h.get("new_locator")}
        locator_change = _e(json.dumps(before_after, ensure_ascii=False, sort_keys=True)) if any(before_after.values()) else ""
        score = ""
        if isinstance(h.get("confidence"), (int, float)):
            score = f' <span class="mono">confidence {_e(format(h["confidence"], ".3f"))}</span>'
        heal_rows.append(f'<tr><td class="mono">{_e(h.get("step"))}</td><td>{_e(h.get("description"))}</td>'
                         f'<td class="mono">{_e(h.get("method"))}{score}</td><td class="mono">{locator_change}</td></tr>')
    heals = "".join(heal_rows)
    heal_block = (f"<h2>Self-healing ({len(run['heals'])})</h2><table><tr><th>Step</th><th>Element</th><th>Found by</th><th>Locator before / after</th></tr>{heals}</table>"
                  if heals else "")
    passed, failed = s.get("passed", 0), s.get("failed", 0)
    env = run.get("environment") or {}
    env_items = [("Operating system", env.get("os")), ("Python", env.get("python"))]
    env_items.extend((f"{name} version", version) for name, version in sorted((env.get("packages") or {}).items()))
    env_rows = "".join(f"<tr><th>{_e(k)}</th><td>{_e(v)}</td></tr>" for k, v in env_items if v)
    env_block = f"<h2>Environment</h2><table>{env_rows}</table>" if env_rows else ""
    app_block = ""
    app_data = run.get("applications") or {}
    apps_list = app_data.get("applications") if isinstance(app_data, dict) else []
    if apps_list:
        app_rows = [
            f'<tr><td class="mono"><b>{_e(a.get("alias"))}</b></td>'
            f'<td>{_e(a.get("type"))}</td>'
            f'<td>{_e(a.get("mode"))}</td>'
            f'<td>{_chip(a.get("status", ""))}</td>'
            f'<td class="mono">{_e(a.get("pid") or "-")}</td>'
            f'<td class="mono">{_e(a.get("switch_count", 0))}</td>'
            f'<td>{_e(a.get("title") or "")}</td></tr>'
            for a in apps_list
        ]
        app_block = (f"<h2>Target Applications ({len(apps_list)})</h2>"
                     f"<table><tr><th>Alias</th><th>Type</th><th>Mode</th><th>Status</th><th>PID</th><th>Switches</th><th>Window Title</th></tr>"
                     f"{''.join(app_rows)}</table>")

    extra_blocks = ""
    if run.get("video"):
        extra_blocks += f'<h2>Screen video</h2><div><a href="{_e(run["video"])}">{_e(run["video"])}</a> (low frame rate recording of the run)</div>'
    if run.get("error"):
        extra_blocks += f'<h2>Run not executed</h2><div class="err" style="white-space:pre-wrap">{_e(run["error"])}</div>'
    app_errors = [a for a in (apps_list or []) if a.get("error")]
    if app_errors:
        extra_blocks += "<h2>Application launch / attach failures</h2><table><tr><th>Alias</th><th>Error</th></tr>" + "".join(
            f'<tr><td class="mono">{_e(a.get("alias"))}</td><td class="err">{_e(a.get("error"))}</td></tr>' for a in app_errors) + "</table>"
    switches = (app_data.get("switch_history") if isinstance(app_data, dict) else None) or []
    if switches:
        extra_blocks += f"<h2>Application switches ({len(switches)})</h2><table><tr><th>Time</th><th>From</th><th>To</th></tr>" + "".join(
            f'<tr><td class="mono">{_e(w.get("timestamp"))}</td><td>{_e(w.get("from") or "-")}</td><td>{_e(w.get("to"))}</td></tr>' for w in switches) + "</table>"
    warnings = [i for i in (run.get("validation") or []) if i.get("level") == "warning"]
    if warnings:
        extra_blocks += "<h2>Validation warnings</h2><table>" + "".join(f'<tr><td>{_e(i.get("message"))}</td></tr>' for i in warnings) + "</table>"
    if run.get("cleanup"):
        extra_blocks += "<h2>Cleanup</h2><table><tr><th>Application</th><th>Action</th><th>Detail</th></tr>" + "".join(
            f'<tr><td class="mono">{_e(c.get("alias"))}</td><td>{_e(c.get("action"))}</td><td class="mono">{_e(c.get("error") or c.get("pid") or "")}</td></tr>'
            for c in run["cleanup"]) + "</table>"
    restarts = run.get("restarts") or []
    if restarts:
        extra_blocks += f"<h2>Test case restarts ({len(restarts)})</h2><table><tr><th>Attempt</th><th>Iteration</th><th>Steps in abandoned attempt</th><th>Failed</th></tr>" + "".join(
            f'<tr><td class="mono">{_e(r.get("attempt"))}</td><td class="mono">{_e(r.get("iteration") or "-")}</td>'
            f'<td class="mono">{len(r.get("steps") or [])}</td>'
            f'<td class="err">{_e("; ".join(str(x.get("error", "")) for x in (r.get("steps") or []) if x.get("status") == "failed"))}</td></tr>'
            for r in restarts) + "</table>"
    var_block = ""
    variables = run.get("variables") or {}
    if variables:
        var_rows = [f'<tr><td class="mono">${{{_e(k)}}}</td><td class="mono">{_e(v)}</td></tr>' for k, v in variables.items()]
        var_block = f"<h2>Variables ({len(variables)})</h2><table><tr><th>Variable</th><th>Value</th></tr>{''.join(var_rows)}</table>"
    return f"""<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{_e(run.get('title') or run.get('test'))} - VisionAuto report</title><style>{CSS}</style></head><body><main>
<h1>{_e(run.get('title') or run.get('test'))} {_chip(run.get('status', ''))}</h1>
<div class="sub">{_e(run.get('started_at'))} &middot; {_e(s.get('duration_ms', 0) / 1000):.7s} s &middot; run {_e(run.get('run_id'))}
&middot; {'dry run' if run.get('dry_run') else _e(run.get('kind', ''))}</div>
<div class="cards">
<div class="card"><b>{s.get('total', 0)}</b><span>steps</span></div>
<div class="card"><b style="color:var(--ok)">{passed}</b><span>passed</span></div>
<div class="card"><b style="color:var(--bad)">{failed}</b><span>failed</span></div>
<div class="card"><b>{s.get('skipped', 0)}</b><span>skipped</span></div>
<div class="card"><b>{s.get('validations', 0)}</b><span>validations ({s.get('validations_failed', 0)} failed)</span></div>
<div class="card"><b>{s.get('healed', 0)}</b><span>self-healed</span></div>
<div class="card"><b>{retries}</b><span>retry attempts</span></div></div>
<div class="bar" title="step results"><i class="passed" style="flex:{passed}"></i><i class="failed" style="flex:{failed}"></i>
<i style="flex:{max(total - passed - failed, 0)}"></i></div>
<table><tr><th>#</th><th>Step</th><th>Result</th><th>Found by</th><th>Time</th></tr>{''.join(rows)}</table>
{app_block}{extra_blocks}{var_block}{heal_block}{env_block}</main></body></html>"""


def write_report(run_dir) -> Path:
    run_dir = Path(run_dir)
    run = json.loads((run_dir / "run.json").read_text(encoding="utf-8"))
    out = run_dir / "report.html"
    out.write_text(build_html(run, run_dir), encoding="utf-8")
    return out


def latest_run_dir(test_name: str) -> Path | None:
    from core import paths

    base = paths.runs_dir() / test_name
    runs = sorted(p for p in base.glob("*") if (p / "run.json").exists()) if base.exists() else []
    return runs[-1] if runs else None


def main() -> None:
    if len(sys.argv) < 2:
        raise SystemExit("usage: python -m core.reports.report <test name | run folder>")
    ref = Path(sys.argv[1])
    d = ref if (ref / "run.json").exists() else latest_run_dir(sys.argv[1])
    if not d:
        raise SystemExit(f"no run found for '{sys.argv[1]}'")
    print(write_report(d))


if __name__ == "__main__":
    main()
