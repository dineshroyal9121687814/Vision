"""JUnit XML output for CI. One <testcase> per step, classname = application alias."""
from __future__ import annotations

import re
import xml.etree.ElementTree as ET
from pathlib import Path

_BAD_XML = re.compile("[\x00-\x08\x0b\x0c\x0e-\x1f\ud800-\udfff￾￿]")


def _x(v) -> str:
    return _BAD_XML.sub("", str(v if v is not None else ""))


def build_junit(run: dict) -> str:
    steps = run.get("steps", [])
    status = run.get("status", "")
    # inconclusive (dry run) and aborted runs are not passes; CI must not read them as green.
    failures = sum(1 for s in steps if s.get("status") == "failed")
    skipped = sum(1 for s in steps if s.get("status") == "skipped")
    not_run = max(int((run.get("summary") or {}).get("not_run", 0)), 0)
    errors = 1 if status in ("aborted", "invalid") else 0
    suite = ET.Element("testsuite", {
        "name": _x(run.get("title") or run.get("test")), "tests": str(len(steps) + not_run),
        "failures": str(failures), "errors": str(errors), "skipped": str(skipped + not_run),
        "time": f"{(run.get('summary') or {}).get('duration_ms', 0) / 1000:.3f}",
        "timestamp": _x(run.get("started_at")),
    })
    props = ET.SubElement(suite, "properties")
    ET.SubElement(props, "property", {"name": "visionauto.status", "value": _x(status)})
    for a in ((run.get("applications") or {}).get("applications") or []):
        ET.SubElement(props, "property", {"name": f"application.{_x(a.get('alias'))}", "value": _x(a.get("status"))})
    for s in steps:
        case = ET.SubElement(suite, "testcase", {
            "classname": _x(s.get("app") or "default"),
            "name": _x(f"{s.get('id')}: {s.get('description') or s.get('type')}"),
            "time": f"{s.get('duration_ms', 0) / 1000:.3f}",
        })
        st = s.get("status")
        if st == "failed":
            f = ET.SubElement(case, "failure", {"message": _x(s.get("error") or "step failed"), "type": "StepFailed"})
            f.text = _x(s.get("error"))
        elif st == "aborted":
            ET.SubElement(case, "error", {"message": "step aborted", "type": "Aborted"})
        elif st == "skipped":
            ET.SubElement(case, "skipped", {"message": _x(s.get("detail") or "skipped")})
    if status in ("failed", "aborted", "invalid") and not steps:
        case = ET.SubElement(suite, "testcase", {"classname": "validation", "name": "pre-run validation"})
        ET.SubElement(case, "failure", {"message": _x(run.get("error") or status), "type": "Invalid"}).text = _x(run.get("error"))
    ET.indent(suite)
    return '<?xml version="1.0" encoding="UTF-8"?>\n' + ET.tostring(suite, encoding="unicode")


def write_junit(run: dict, run_dir) -> Path:
    out = Path(run_dir) / "junit.xml"
    out.write_text(build_junit(run), encoding="utf-8")
    return out
