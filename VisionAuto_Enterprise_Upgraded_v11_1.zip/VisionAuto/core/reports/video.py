"""Low-rate screen video of a test run (a few frames per second, MJPG .avi, plays everywhere, small).

Frames come from the same ``grab`` the player uses, on a background thread, so a failure can be watched instead of guessed.
Off by default (``record_video``); any error just stops the video - it never affects the run."""
from __future__ import annotations

import logging
import threading
import time
from pathlib import Path

import cv2
import numpy as np

log = logging.getLogger("visionauto.video")


class VideoRecorder:
    def __init__(self, path, fps: int = 4, grab=None, max_width: int = 1280, max_seconds: float = 3600.0,
                 clock=time.monotonic, sleep=time.sleep):
        from core.system import winenv
        self.path, self.fps = Path(path), max(1, min(int(fps), 15))
        self.grab = grab or winenv.grab_screen
        self.max_width, self.max_seconds = max_width, max_seconds
        self.clock, self.sleep = clock, sleep
        self.frames = 0
        self._writer = None
        self._size = None
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None

    def _frame(self):
        img = self.grab()
        img = img[0] if isinstance(img, tuple) else img
        if img is None:
            return None
        if img.ndim == 3 and img.shape[2] == 4:
            img = img[:, :, :3]
        h, w = img.shape[:2]
        if w > self.max_width:
            img = cv2.resize(img, (self.max_width, int(h * self.max_width / w)), interpolation=cv2.INTER_AREA)
        h, w = img.shape[:2]
        return np.ascontiguousarray(img[: h - h % 2, : w - w % 2])

    def capture_once(self) -> bool:
        img = self._frame()
        if img is None:
            return False
        if self._writer is None:
            self._size = (img.shape[1], img.shape[0])
            self._writer = cv2.VideoWriter(str(self.path), cv2.VideoWriter_fourcc(*"MJPG"), self.fps, self._size)
            if not self._writer.isOpened():
                self._writer = None
                raise RuntimeError("video writer could not be opened")
        if (img.shape[1], img.shape[0]) != self._size:
            img = cv2.resize(img, self._size)
        self._writer.write(img)
        self.frames += 1
        return True

    def _loop(self):
        t0, period = self.clock(), 1.0 / self.fps
        while not self._stop.is_set() and self.clock() - t0 < self.max_seconds:
            t = self.clock()
            try:
                self.capture_once()
            except Exception:
                log.debug("video capture stopped", exc_info=True)
                break
            self.sleep(max(0.0, period - (self.clock() - t)))

    def start(self) -> "VideoRecorder":
        self._thread = threading.Thread(target=self._loop, name="video", daemon=True)
        self._thread.start()
        return self

    def stop(self) -> str | None:
        """Finish the file. Returns its name (relative to the run folder) or None when nothing was recorded."""
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=3.0)
        if self._writer is not None:
            self._writer.release()
            self._writer = None
        return self.path.name if self.frames else None
