"""Report management: list / filter / sort / delete runs.

A report is exactly one run folder ``<runs>/<test>/<run_id>/`` (run.json, report.html, junit.xml, screenshots).
Deleting a report removes **only that folder**.  It refuses (without touching anything) when the path

* is not inside the runs folder,
* is not at the ``<test>/<run_id>`` depth (so the runs root or a whole test's history can never be removed by one call),
* does not contain a run.json (an unfinished run, or some unrelated folder).

Tests, recordings, test cases, settings and logs live elsewhere and are never touched.
"""
from __future__ import annotations

import json
import os
import stat
from datetime import datetime, timedelta
from pathlib import Path

from core import paths

STATUS_ORDER = {"failed": 0, "cancelled": 1, "aborted": 2, "invalid": 3, "inconclusive": 4, "skipped": 5, "passed": 6}


def _dir_size(d: Path) -> int:
    total = 0
    for root, _dirs, files in os.walk(d):
        for f in files:
            try:
                total += os.path.getsize(os.path.join(root, f))
            except OSError:
                pass
    return total


def list_reports(limit: int | None = None) -> list[dict]:
    """Newest first. Unreadable run.json files are listed as status 'unreadable' so they can still be deleted."""
    root = paths.runs_dir()
    out: list[dict] = []
    if not root.is_dir():
        return out
    for rj in root.glob("*/*/run.json"):
        d = rj.parent
        try:
            data = json.loads(rj.read_text(encoding="utf-8"))
            if not isinstance(data, dict):
                raise ValueError("not an object")
        except (OSError, ValueError):
            data = {"status": "unreadable", "test": d.parent.name, "run_id": d.name, "summary": {}}
        s = data.get("summary") or {}
        out.append({
            "dir": str(d), "test": data.get("title") or data.get("test") or d.parent.name, "test_name": d.parent.name,
            "run_id": data.get("run_id") or d.name, "status": data.get("status", ""),
            "started_at": data.get("started_at") or datetime.fromtimestamp(d.stat().st_mtime).isoformat(timespec="seconds"),
            "duration_ms": s.get("duration_ms", 0), "total": s.get("total", 0), "passed": s.get("passed", 0),
            "failed": s.get("failed", 0), "skipped": s.get("skipped", 0), "healed": s.get("healed", 0),
            "retries": sum(len(st.get("retry_history") or []) for st in data.get("steps", []) if isinstance(st, dict)),
            "validations": s.get("validations", 0), "validations_failed": s.get("validations_failed", 0),
            "has_report": (d / "report.html").is_file(), "size": _dir_size(d), "dry_run": bool(data.get("dry_run")),
        })
    out.sort(key=lambda r: r["started_at"], reverse=True)
    return out[:limit] if limit else out


def filter_sort(rows: list[dict], text: str = "", status: str = "", sort_by: str = "date",
                descending: bool = True) -> list[dict]:
    t = text.strip().casefold()
    picked = [r for r in rows
              if (not status or r["status"] == status)
              and (not t or t in f"{r['test']} {r['test_name']} {r['run_id']} {r['status']} {r['started_at']}".casefold())]
    keys = {"date": lambda r: r["started_at"], "status": lambda r: STATUS_ORDER.get(r["status"], 99),
            "test": lambda r: r["test"].casefold(), "duration": lambda r: r["duration_ms"],
            "size": lambda r: r["size"]}
    return sorted(picked, key=keys.get(sort_by, keys["date"]), reverse=descending)


def _check_deletable(run_dir) -> Path:
    d = Path(run_dir)
    if not os.path.lexists(d):
        raise FileNotFoundError(str(d))
    root = paths.runs_dir().resolve()
    rd = d.resolve()
    try:
        rel = rd.relative_to(root)
    except ValueError:
        raise PermissionError("Refused: that folder is not inside the reports folder.") from None
    if len(rel.parts) != 2:
        raise PermissionError("Refused: only a single run folder can be deleted.")
    if d.is_symlink():
        raise PermissionError("Refused: the run folder is a link.")
    if not (rd / "run.json").is_file():
        raise PermissionError("Refused: this folder has no run.json (unfinished run or not a report).")
    return rd


def _remove_tree(d: Path) -> list[str]:
    """Delete a folder tree, returning the files that could not be removed (read-only files are retried)."""
    problems: list[str] = []
    for root, dirs, files in os.walk(d, topdown=False):
        for f in files:
            p = Path(root, f)
            try:
                p.unlink()
            except PermissionError:
                try:
                    os.chmod(p, stat.S_IWRITE)
                    p.unlink()
                except OSError as exc:
                    problems.append(f"{p.name}: {exc.strerror or exc}")
            except FileNotFoundError:
                pass
            except OSError as exc:
                problems.append(f"{p.name}: {exc.strerror or exc}")
        for sub in dirs:
            try:
                Path(root, sub).rmdir()
            except FileNotFoundError:
                pass
            except OSError as exc:
                problems.append(f"{sub}: {exc.strerror or exc}")
    try:
        d.rmdir()
    except FileNotFoundError:
        pass
    except OSError as exc:
        problems.append(f"{d.name}: {exc.strerror or exc}")
    return problems


def delete_run(run_dir) -> dict:
    """-> {"dir", "deleted": bool, "bytes": int, "error": str}. Never raises for a missing file or a locked file."""
    res = {"dir": str(run_dir), "deleted": False, "bytes": 0, "error": ""}
    try:
        d = _check_deletable(run_dir)
    except FileNotFoundError:
        res["error"] = "already deleted"
        return res
    except PermissionError as exc:
        res["error"] = str(exc)
        return res
    except OSError as exc:
        res["error"] = f"Cannot access the report folder: {exc.strerror or exc}"
        return res
    res["bytes"] = _dir_size(d)
    problems = _remove_tree(d)
    if problems:
        res["error"] = "Some files could not be deleted (are they open in a browser or another program?): " + "; ".join(problems[:3])
        return res
    res["deleted"] = True
    parent = d.parent
    try:
        if parent.is_dir() and not any(parent.iterdir()):       # an emptied test history folder; nothing else is touched
            parent.rmdir()
    except OSError:
        pass
    return res


def delete_runs(run_dirs) -> dict:
    results = [delete_run(d) for d in dict.fromkeys(str(x) for x in run_dirs)]
    return {"deleted": sum(r["deleted"] for r in results), "failed": [r for r in results if not r["deleted"] and r["error"] != "already deleted"],
            "bytes": sum(r["bytes"] for r in results if r["deleted"]), "results": results}


def find_old(days: int, status: str = "", now: datetime | None = None) -> list[dict]:
    """Reports started more than ``days`` days ago (optionally only one status)."""
    if days < 0:
        raise ValueError("days must be 0 or more.")
    cutoff = (now or datetime.now()) - timedelta(days=days)
    out = []
    for r in list_reports():
        try:
            started = datetime.fromisoformat(r["started_at"])
        except ValueError:
            started = datetime.fromtimestamp(Path(r["dir"]).stat().st_mtime)
        if started < cutoff and (not status or r["status"] == status):
            out.append(r)
    return out


def delete_old(days: int, status: str = "") -> dict:
    return delete_runs([r["dir"] for r in find_old(days, status)])
