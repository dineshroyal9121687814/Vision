"""
Element Inspector - the same idea as Microsoft Inspect / Accessibility Insights, built on VisionAuto's own
UI Automation snapshot, so what you see here is exactly what the player resolves against.

    python -m core.cli inspect --window Calculator                 # tree of one window, with XPaths
    python -m core.cli inspect --window Calculator --find Nine      # only the matching branch
    python -m core.cli inspect --point 640,410                      # what is under this screen point

Everything is scoped to ONE top-level window: Window > Pane > Tab > Group > Button ... Nothing outside it is read.
The pure helpers (``format_tree``, ``find_nodes``, ``path_of``, ``xpath_of``) work on any ``UiaNode`` tree, so they
are unit-tested without Windows.
"""
from __future__ import annotations

from core.xpath.engine import XPathError, generate_xpath
from core.xpath.tree import UiaNode


def path_of(node: UiaNode) -> list[UiaNode]:
    out, cur = [], node
    while cur is not None and cur.control_type != "Desktop":
        out.append(cur)
        cur = cur.parent
    return list(reversed(out))


def breadcrumb(node: UiaNode) -> str:
    return " > ".join((f"{n.name} [{n.control_type}]" if n.name else n.control_type) for n in path_of(node))


def root_of(node: UiaNode) -> UiaNode:
    cur = node
    while cur.parent is not None:
        cur = cur.parent
    return cur


def xpath_of(node: UiaNode, root: UiaNode | None = None, dialect: str = "uia") -> str:
    try:
        return generate_xpath(node, root or root_of(node), dialect)
    except XPathError:
        return ""


def properties(node: UiaNode) -> dict:
    return {"Name": node.name, "ControlType": node.control_type, "AutomationId": node.automation_id,
            "ClassName": node.class_name, "BoundingRectangle": list(node.rect), "Enabled": node.enabled,
            "Visible": node.visible, "Value": "" if node.password else node.value, "Process": node.process}


def iter_nodes(root: UiaNode):
    stack = [root]
    while stack:
        n = stack.pop()
        yield n
        stack.extend(reversed(n.children))


def find_nodes(root: UiaNode, text: str) -> list[UiaNode]:
    t = text.casefold()
    return [n for n in iter_nodes(root) if t and (t in n.name.casefold() or t in n.automation_id.casefold())]


def point_in(node: UiaNode, x: int, y: int) -> bool:
    l, t, r, b = node.rect
    return l <= x <= r and t <= y <= b


def deepest_at(root: UiaNode, x: int, y: int) -> UiaNode | None:
    """Smallest visible element containing the point (what the Pick tool selects)."""
    best, area = None, None
    for n in iter_nodes(root):
        if n.control_type != "Desktop" and n.visible and point_in(n, x, y):
            a = max(1, (n.rect[2] - n.rect[0]) * (n.rect[3] - n.rect[1]))
            if area is None or a <= area:
                best, area = n, a
    return best


def format_tree(root: UiaNode, max_depth: int = 12, only: set | None = None) -> str:
    lines: list[str] = []

    def walk(n: UiaNode, depth: int):
        if depth > max_depth or (only is not None and id(n) not in only):
            return
        if n.control_type != "Desktop":
            bits = [n.control_type]
            if n.name:
                bits.append(f"'{n.name}'")
            if n.automation_id:
                bits.append(f"#{n.automation_id}")
            lines.append("  " * max(0, depth - 1) + " ".join(bits))
        for c in n.children:
            walk(c, depth + 1)

    walk(root, 0)
    return "\n".join(lines)


def branch_ids(root: UiaNode, hits: list[UiaNode]) -> set:
    """ids of every hit and its ancestors - to print only the matching branches."""
    keep: set = set()
    for h in hits:
        cur = h
        while cur is not None:
            keep.add(id(cur))
            cur = cur.parent
    return keep


# --------------------------------------------------------------- live (Windows)
def snapshot(window: str = "") -> UiaNode | None:
    from core.system import uia_tree
    return uia_tree.snapshot_window(window)


def element_under(x: int, y: int) -> UiaNode | None:
    """Snapshot the top-level window under a screen point and return the deepest element there."""
    from core.system import uia_tree, winenv

    w = winenv.window_at(int(x), int(y))
    root = uia_tree.snapshot_window(hwnd=w.get("hwnd", 0)) if w.get("hwnd") else None
    return deepest_at(root, int(x), int(y)) if root else None
