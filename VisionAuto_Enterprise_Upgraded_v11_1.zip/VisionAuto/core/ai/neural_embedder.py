"""
Deep UI Neural Feature Extractor for VisionAuto.
Extracts invariant semantic visual embeddings for UI elements (buttons, inputs, icons, controls).
Optimized for local CPU inference (<20ms).
"""
from __future__ import annotations

import os
from pathlib import Path
from typing import Optional

import cv2
import numpy as np

try:
    import torch
    import torch.nn as nn
    import torch.nn.functional as F
    HAS_TORCH = True
except ImportError:
    HAS_TORCH = False
    torch = None
    nn = None
    F = None


if HAS_TORCH:
    class UIElementEmbedder(nn.Module):
        """Compact convolutional neural network for UI element representation."""

        def __init__(self, embedding_dim: int = 128):
            super().__init__()
            self.stem = nn.Sequential(
                nn.Conv2d(3, 16, kernel_size=5, stride=2, padding=2, bias=True),  # 112x112
                nn.BatchNorm2d(16),
                nn.ReLU(inplace=True),
            )
            self.layer1 = nn.Sequential(
                nn.Conv2d(16, 32, kernel_size=3, stride=2, padding=1, bias=True), # 56x56
                nn.BatchNorm2d(32),
                nn.ReLU(inplace=True),
            )
            self.layer2 = nn.Sequential(
                nn.Conv2d(32, 64, kernel_size=3, stride=2, padding=1, bias=True), # 28x28
                nn.BatchNorm2d(64),
                nn.ReLU(inplace=True),
            )
            self.layer3 = nn.Sequential(
                nn.Conv2d(64, 64, kernel_size=3, stride=2, padding=1, bias=True), # 14x14
                nn.BatchNorm2d(64),
                nn.ReLU(inplace=True),
            )
            self.pool = nn.AdaptiveAvgPool2d((2, 2))
            self.head = nn.Sequential(
                nn.Flatten(),
                nn.Linear(64 * 2 * 2, embedding_dim),
            )
            self._init_weights()

        def _init_weights(self) -> None:
            # Deterministic initialization for consistent cross-session embeddings
            torch.manual_seed(42)
            for m in self.modules():
                if isinstance(m, nn.Conv2d):
                    nn.init.kaiming_normal_(m.weight, mode="fan_out", nonlinearity="relu")
                    if m.bias is not None:
                        nn.init.constant_(m.bias, 0.01)
                elif isinstance(m, nn.Linear):
                    nn.init.orthogonal_(m.weight)
                    if m.bias is not None:
                        nn.init.constant_(m.bias, 0.01)
                elif isinstance(m, nn.BatchNorm2d):
                    nn.init.constant_(m.weight, 1.0)
                    nn.init.constant_(m.bias, 0.01)

        def forward(self, x: torch.Tensor) -> torch.Tensor:
            out = self.stem(x)
            out = self.layer1(out)
            out = self.layer2(out)
            out = self.layer3(out)
            out = self.pool(out)
            emb = self.head(out)
            norm = torch.norm(emb, p=2, dim=1, keepdim=True)
            norm = torch.clamp(norm, min=1e-8)
            return emb / norm


_model_instance = None
_model_failed = False
WEIGHTS_PATH = Path(__file__).resolve().parent / "embedder.pt"


def get_deep_model():
    """Lazy-load the deep neural embedding model singleton."""
    global _model_instance, _model_failed
    if not HAS_TORCH or _model_failed:
        return None
    if _model_instance is not None:
        return _model_instance

    try:
        model = UIElementEmbedder(embedding_dim=128)
        # Initialize with deterministic weights
        model.eval()
        _model_instance = model
        return _model_instance
    except Exception:
        _model_failed = True
        return None


def extract_deep_embedding(img: np.ndarray) -> Optional[np.ndarray]:
    """Extract a 128-dimensional normalized embedding from an image patch (BGR)."""
    model = get_deep_model()
    if model is None:
        return None

    try:
        rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB) if img.ndim == 3 else cv2.cvtColor(img, cv2.COLOR_GRAY2RGB)
        resized = cv2.resize(rgb, (224, 224)).astype(np.float32) / 255.0
        tensor = torch.from_numpy(np.transpose(resized, (2, 0, 1))[None])
        with torch.no_grad():
            emb = model(tensor)
            return emb[0].cpu().numpy().astype(np.float32)
    except Exception:
        return None
