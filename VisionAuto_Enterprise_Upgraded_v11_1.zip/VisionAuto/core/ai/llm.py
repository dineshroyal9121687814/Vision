"""
Optional local language model (Ollama - free, offline). Never required:
every feature has a rule-based path and only *uses* the model when it is running.

    ollama pull qwen2.5-coder:1.5b        (about 1 GB, runs on CPU)
"""
from __future__ import annotations

import json
import re
from urllib.parse import urlsplit
import urllib.request

from core.system import quiet

URL = "http://localhost:11434"


class OllamaClient:
    def __init__(self, model: str = "qwen2.5-coder:1.5b", timeout: float = 60.0,
                 base_url: str = URL):
        self.model = model
        self.timeout = timeout
        parsed = urlsplit(base_url.strip())
        if parsed.scheme not in {"http", "https"} or not parsed.netloc:
            raise ValueError("Ollama base URL must be an absolute http(s) URL.")
        if parsed.username or parsed.password:
            raise ValueError("Do not put credentials in the Ollama base URL.")
        self.base_url = base_url.rstrip("/")
        self._ok: bool | None = None

    def available(self) -> bool:
        if self._ok is None:
            try:
                with urllib.request.urlopen(self.base_url + "/api/tags", timeout=1.5) as r:
                    self._ok = r.status == 200
            except Exception:
                self._ok = False
        return self._ok

    def generate(self, prompt: str) -> str | None:
        if not self.available():
            return None
        body = json.dumps({"model": self.model, "prompt": prompt, "stream": False,
                           "keep_alive": "30m", "options": {"temperature": 0}}).encode()
        try:
            req = urllib.request.Request(self.base_url + "/api/generate", data=body,
                                         headers={"Content-Type": "application/json"})
            with quiet.FocusGuard():                  # a console that flashes while the model answers is hidden at once
                with urllib.request.urlopen(req, timeout=self.timeout) as r:
                    return json.loads(r.read())["response"].strip()
        except Exception:
            self._ok = False
            return None


def extract_json(text: str | None) -> dict | None:
    m = re.search(r"\{.*\}", text or "", re.S)
    if not m:
        return None
    try:
        data = json.loads(m.group(0))
        return data if isinstance(data, dict) else None
    except ValueError:
        return None
