"""AI that LOOKS at the screen during a run (optional, local, off when no vision model is available).

Used only when every deterministic way of finding the target has failed. It gets the screenshot and the step's
meaning ("Click the 'Save' button near the bottom of the dialog"), and answers with a point. The point is NEVER
trusted on its own: the player verifies it (text at that spot) before acting, exactly like any other candidate.
Talks to an Ollama vision model (default ``qwen2.5vl`` / ``llava``); any object with ``locate`` can be plugged in.
"""
from __future__ import annotations

import base64
import json
import logging
import re
import urllib.request

import cv2

log = logging.getLogger("visionauto.vision_advisor")
MAX_SIDE = 1280


class VisionAdvisor:
    PROMPT = ("You are helping a UI test tool. Look at the screenshot. Find: {what}.\n"
              "Reply with ONLY JSON: {{\"found\": true, \"x\": <pixel x>, \"y\": <pixel y>, \"text\": \"<label you see>\"}} "
              "using the coordinates of the screenshot you were given, or {{\"found\": false}} if it is not visible. "
              "Never guess: if two places fit equally, answer found=false.")

    def __init__(self, model: str = "qwen2.5vl:3b", base_url: str = "http://127.0.0.1:11434", timeout: float = 45.0):
        self.model, self.base_url, self.timeout = model, base_url.rstrip("/"), timeout
        self._ok: bool | None = None

    def available(self) -> bool:
        if self._ok is None:
            try:
                with urllib.request.urlopen(self.base_url + "/api/tags", timeout=1.5) as r:
                    names = [m.get("name", "") for m in json.loads(r.read()).get("models", [])]
                self._ok = any(self.model.split(":")[0] in n for n in names)
            except Exception:
                self._ok = False
        return bool(self._ok)

    def locate(self, frame, what: str, hint=None) -> dict | None:
        """-> {"x", "y", "text"} in FRAME pixels, or None. ``hint`` = (x, y) where it used to be (only mentioned in the prompt)."""
        if not self.available():
            return None
        h, w = frame.shape[:2]
        scale = min(1.0, MAX_SIDE / max(h, w))
        small = cv2.resize(frame, (int(w * scale), int(h * scale))) if scale < 1 else frame
        ok, buf = cv2.imencode(".png", small)
        if not ok:
            return None
        prompt = self.PROMPT.format(what=what)
        if hint:
            prompt += f" It used to be near ({int(hint[0] * scale)}, {int(hint[1] * scale)})."
        body = json.dumps({"model": self.model, "prompt": prompt, "stream": False, "images": [base64.b64encode(buf).decode()],
                           "options": {"temperature": 0}}).encode()
        try:
            req = urllib.request.Request(self.base_url + "/api/generate", data=body, headers={"Content-Type": "application/json"})
            with urllib.request.urlopen(req, timeout=self.timeout) as r:
                answer = json.loads(r.read())["response"]
        except Exception as exc:
            log.info("vision advisor unavailable: %s", exc)
            self._ok = False
            return None
        return parse_answer(answer, scale, (w, h))


def parse_answer(answer: str, scale: float, size) -> dict | None:
    m = re.search(r"\{.*\}", answer or "", re.S)
    if not m:
        return None
    try:
        d = json.loads(m.group(0))
    except ValueError:
        return None
    if not d.get("found"):
        return None
    try:
        x, y = float(d["x"]) / scale, float(d["y"]) / scale
    except (KeyError, TypeError, ValueError):
        return None
    if not (0 <= x < size[0] and 0 <= y < size[1]):
        return None
    return {"x": int(x), "y": int(y), "text": str(d.get("text") or "")}
