"""
Plain-English descriptions for steps and validations.

This is what the user sees in the live recording log, in the review screen and
in reports: "Click 'Save' button in 'Untitled - Notepad'", "Drag 'a.txt' list
item and drop on 'Recycle Bin'", "Type 'hello' into 'Search' text box".
Rule based on purpose: instant, offline, deterministic.
"""
from __future__ import annotations

ROLE_WORDS = {
    "button": "button", "edit": "text box", "checkbox": "checkbox", "radiobutton": "radio button",
    "combobox": "dropdown", "listitem": "list item", "list": "list", "menuitem": "menu item",
    "menu": "menu", "menubar": "menu bar", "tabitem": "tab", "tab": "tab bar", "hyperlink": "link",
    "text": "text", "treeitem": "tree item", "tree": "tree", "dataitem": "row", "datagrid": "grid",
    "document": "document", "image": "image", "toolbar": "toolbar", "titlebar": "title bar",
    "slider": "slider", "spinner": "spinner", "splitbutton": "split button", "scrollbar": "scroll bar",
    "window": "window", "pane": "area", "group": "group", "custom": "element",
}


def _clip(s: str, n: int = 40) -> str:
    s = " ".join(str(s).split())
    return s if len(s) <= n else s[: n - 1] + "…"


def label_of(target: dict | None) -> str:
    t = target or {}
    return _clip(t.get("name") or t.get("text") or t.get("value") or t.get("automation_id") or "")


def role_word(target: dict | None) -> str:
    role = ((target or {}).get("role") or "").replace(" ", "").lower()
    return ROLE_WORDS.get(role, role or "")


def element_phrase(target: dict | None) -> str:
    t = target or {}
    label, word = label_of(t), role_word(t)
    if label and word:
        return f"'{label}' {word}"
    if label:
        return f"'{label}'"
    if t.get("x") is not None:
        return f"{word or 'element'} at ({t.get('x')}, {t.get('y')})"
    return word or "element"


def _in(step: dict) -> str:
    title = (step.get("window") or {}).get("title", "")
    return f" in '{_clip(title, 32)}'" if title else ""


def describe_step(step: dict) -> str:
    t = step.get("type")
    p = step.get("params") or {}
    tgt = step.get("target")
    if t in ("loop_start", "loop_end", "if_start", "else", "if_end", "break_loop"):
        return _describe_control(step)
    if t == "wait_until":
        return f"Wait until {_describe_condition(step.get('condition') or {})} (up to {p.get('timeout_s', 10)} s)"
    if t == "scroll_until":
        return f"Scroll {'down' if p.get('dy', -3) < 0 else 'up'} until {_describe_condition(step.get('until') or {})} (at most {p.get('max_scrolls', 20)} times)"
    if t == "window_action":
        return f"{str(p.get('action', 'act on')).replace('_', ' ').capitalize()} window '{(step.get('window') or {}).get('title', '')}'"
    if t == "set_clipboard":
        return "Put text on the clipboard"
    if t == "click":
        return f"Click {element_phrase(tgt)}{_in(step)}"
    if t == "double_click":
        return f"Double-click {element_phrase(tgt)}{_in(step)}"
    if t == "right_click":
        return f"Right-click {element_phrase(tgt)}{_in(step)}"
    if t == "middle_click":
        return f"Middle-click {element_phrase(tgt)}{_in(step)}"
    if t == "drag_drop":
        return f"Drag {element_phrase(tgt)} and drop on {element_phrase(step.get('to'))}{_in(step)}"
    if t == "scroll":
        dy, dx = p.get("dy", 0), p.get("dx", 0)
        if dy:
            return f"Scroll {'up' if dy > 0 else 'down'} {abs(dy)} notch(es){_in(step)}"
        return f"Scroll {'right' if dx > 0 else 'left'} {abs(dx)} notch(es){_in(step)}"
    if t == "type":
        into = label_of(tgt)
        where = f" into '{into}' {role_word(tgt)}".rstrip() if into else ""
        if p.get("redacted"):
            return f"Type [redacted sensitive input]{where}{_in(step)}"
        return f"Type '{_clip(p.get('text', ''), 50)}'{where}{_in(step)}"
    if t == "key":
        return f"Press {str(p.get('key', '')).replace('_', ' ').title()}{_in(step)}"
    if t == "hotkey":
        return "Press " + "+".join(w.title() for w in str(p.get("keys", "")).split("+")) + _in(step)
    if t == "hover":
        return f"Hover over {element_phrase(tgt)}{_in(step)}"
    if t == "wait":
        return f"Wait {p.get('ms', 0)} ms"
    if t == "open_app":
        return f"Open '{p.get('name') or p.get('exe') or 'application'}'"
    if t == "launch_app":
        return f"Launch {p.get('exe', 'application')}" + (f" {p['args']}" if p.get("args") else "")
    if t == "validate":
        return "Verify " + describe_validation(dict(step.get("check") or {}, target=tgt))
    return t or "step"


def describe_validation(v: dict) -> str:
    kind = v.get("type")
    exp = _clip(v.get("expected", ""), 50)
    if kind == "window_title_contains":
        return f"window title contains '{exp}'"
    if kind == "text_equals":
        return f"{element_phrase(v.get('target'))} shows exactly '{exp}'"
    if kind == "text_contains":
        return f"{element_phrase(v.get('target'))} contains '{exp}'"
    if kind == "element_exists":
        return f"{element_phrase(v.get('target'))} is visible"
    if kind == "element_not_exists":
        return f"{element_phrase(v.get('target'))} is not visible"
    if kind == "state":
        return f"{element_phrase(v.get('target'))} is {v.get('expected')}"
    if kind == "image_visible":
        return f"{element_phrase(v.get('target'))} looks the same"
    return str(kind)


def _describe_control(step: dict) -> str:
    t, p = step.get("type"), step.get("params") or {}
    if t == "loop_start":
        if "times" in p:
            return f"Repeat {p['times']} time(s)"
        return f"Repeat while {_describe_condition(p.get('while') or {})} (at most {p.get('max', 100)} times)"
    if t == "loop_end":
        return "End repeat"
    if t == "if_start":
        return f"If {_describe_condition(step.get('condition') or {})}"
    if t == "else":
        return "Otherwise"
    if t == "if_end":
        return "End if"
    return "Exit the loop"


def _describe_condition(c: dict) -> str:
    t = c.get("type")
    if t == "exists":
        return f"{element_phrase(c.get('target'))} exists"
    if t == "not_exists":
        return f"{element_phrase(c.get('target'))} does not exist"
    if t == "text_contains":
        return f"{element_phrase(c.get('target'))} text contains '{c.get('expected', '')}'"
    if t == "text_equals":
        return f"{element_phrase(c.get('target'))} text equals '{c.get('expected', '')}'"
    if t == "variable":
        return f"${{{c.get('name', '?')}}} {str(c.get('op', '')).replace('_', ' ')} {c.get('value', '')}".strip()
    return "condition"
