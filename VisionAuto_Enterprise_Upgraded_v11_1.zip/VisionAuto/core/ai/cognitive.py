"""
Cognitive Reasoning and Natural Language Understanding Engine for VisionAuto.

Acts as the "Brain" of VisionAuto:
  1. Natural Language -> VisionAuto Step: Converts human descriptions into concrete executable steps.
  2. Intelligent Failure Diagnostics: Explains WHY a test step failed and what went wrong in plain English.
  3. Smart Self-Healing Recommendations: Evaluates alternative candidate controls when locators break.
  4. Generative Synthesis: Leverages local SLM (Ollama) when available, with a deterministic semantic parser fallback.
"""
from __future__ import annotations

import json
import logging
import re
from typing import Any, Dict, List, Optional

from core.ai.llm import OllamaClient, extract_json

log = logging.getLogger("visionauto.cognitive")

NL_STEP_PROMPT = """You are an automation test generator. Convert the user instruction into ONE JSON test step for VisionAuto.
Valid step types: "click", "double_click", "right_click", "type", "key", "hotkey", "wait", "launch_app", "switch_app", "validate".
Output ONLY valid JSON.

Examples:
Instruction: Click the 'Save' button in 'Notepad'
JSON: {"type": "click", "target": {"name": "Save", "role": "button"}, "window": {"title": "Notepad"}, "description": "Click 'Save' button"}

Instruction: Type 'admin@domain.com' into 'Email'
JSON: {"type": "type", "params": {"text": "admin@domain.com"}, "target": {"name": "Email", "role": "edit"}, "description": "Type text into 'Email'"}

Instruction: Switch to application 'Chrome'
JSON: {"type": "switch_app", "app": "Chrome", "description": "Switch to Chrome"}

Instruction: Wait 2 seconds
JSON: {"type": "wait", "params": {"ms": 2000}, "description": "Wait 2.0s"}

Instruction: Verify window title contains 'Dashboard'
JSON: {"type": "validate", "check": {"type": "window_title_contains", "expected": "Dashboard"}, "description": "Verify window title contains 'Dashboard'"}

Instruction: {instruction}
JSON:"""

DIAGNOSIS_PROMPT = """Analyze why an automated test step failed and recommend a fix.
Failed Step: {step_json}
Error: {error}
Current Active Window: {active_window}

Output a JSON object with:
"summary": brief summary of the failure,
"likely_cause": root cause explanation,
"suggestion": actionable fix recommendation,
"confidence": float between 0.0 and 1.0.
Output ONLY valid JSON."""


class CognitiveEngine:
    def __init__(self, llm_client: Optional[OllamaClient] = None):
        self.llm = llm_client or OllamaClient()

    # -------------------------------------------------------------------------
    # 1. Natural Language Intent Parsing
    # -------------------------------------------------------------------------
    def parse_intent_to_step(self, instruction: str) -> Dict[str, Any]:
        """Convert a plain English instruction into a VisionAuto step dictionary."""
        text = instruction.strip()
        if not text:
            raise ValueError("Instruction cannot be empty.")

        # Try local LLM if online
        if self.llm.available():
            try:
                resp = self.llm.generate(NL_STEP_PROMPT.format(instruction=text))
                parsed = extract_json(resp)
                if parsed and isinstance(parsed, dict) and "type" in parsed:
                    if "description" not in parsed:
                        parsed["description"] = text
                    return parsed
            except Exception as e:
                log.debug("LLM intent parsing failed, using rule-based engine: %s", e)

        # High-accuracy deterministic semantic parser fallback
        return self._semantic_parse_step(text)

    def _semantic_parse_step(self, text: str) -> Dict[str, Any]:
        """Deterministic semantic parser for offline and instant step generation."""
        s = text.strip()
        lower = s.lower()

        # 1. Wait / Delay
        m_wait = re.search(r"\b(?:wait|delay|sleep)\s+(\d+(?:\.\d+)?)\s*(s|sec|seconds|ms|milliseconds)?\b", lower)
        if m_wait:
            val, unit = float(m_wait.group(1)), m_wait.group(2) or "s"
            ms = int(val if unit == "ms" or unit == "milliseconds" else val * 1000)
            return {"type": "wait", "params": {"ms": ms}, "description": f"Wait {ms/1000:g}s"}

        # 2. Switch app
        m_switch = re.search(r"\b(?:switch to|activate|focus)\s+(?:application|app)?\s*['\"]?([^'\"\n]+)['\"]?", s, re.I)
        if m_switch:
            app_name = m_switch.group(1).strip()
            return {"type": "switch_app", "app": app_name, "description": f"Switch to '{app_name}'"}

        # 3. Launch app
        m_launch = re.search(r"\b(?:launch|start|open|run)\s+(?:application|app|exe)?\s*['\"]?([^'\"\n]+)['\"]?", s, re.I)
        if m_launch and not any(kw in lower for kw in ["window", "tab", "menu"]):
            target_str = m_launch.group(1).strip()
            if target_str.lower().endswith((".exe", ".bat", ".cmd", ".com")) or "\\" in target_str or "/" in target_str:
                return {"type": "launch_app", "params": {"exe": target_str}, "description": f"Launch {target_str}"}

        # 4. Assert / Validate window title
        m_win_val = re.search(r"\b(?:verify|assert|check)\s+(?:active\s+)?window\s+(?:title\s+)?(?:contains|is|has)\s+['\"]([^'\"]+)['\"]", s, re.I)
        if m_win_val:
            expected = m_win_val.group(1).strip()
            return {
                "type": "validate",
                "check": {"type": "window_title_contains", "expected": expected},
                "description": f"Verify window title contains '{expected}'"
            }

        # 5. Assert / Validate element text
        m_elem_val = re.search(r"\b(?:verify|assert|check)\s+(?:element\s+)?['\"]([^'\"]+)['\"]\s+(?:contains|has text|text is)\s+['\"]([^'\"]+)['\"]", s, re.I)
        if m_elem_val:
            name, exp_text = m_elem_val.group(1).strip(), m_elem_val.group(2).strip()
            return {
                "type": "validate",
                "target": {"name": name},
                "check": {"type": "text_contains", "expected": exp_text},
                "description": f"Verify '{name}' contains '{exp_text}'"
            }

        # 6. Assert / Validate element exists
        m_exists = re.search(r"\b(?:verify|assert|check)\s+(?:that\s+)?(?:element\s+)?['\"]([^'\"]+)['\"]\s+exists\b", s, re.I)
        if m_exists:
            name = m_exists.group(1).strip()
            return {
                "type": "validate",
                "target": {"name": name},
                "check": {"type": "element_exists"},
                "description": f"Verify '{name}' exists"
            }

        # 7. Hotkey / Key
        m_hotkey = re.search(r"\b(?:press\s+hotkey|hotkey|press)\s+((?:ctrl|alt|shift|win|\w)\s*\+\s*(?:ctrl|alt|shift|win|\w)(?:\s*\+\s*\w)?)\b", lower)
        if m_hotkey:
            keys = [k.strip() for k in m_hotkey.group(1).split("+")]
            return {"type": "hotkey", "params": {"keys": keys}, "description": f"Hotkey {'+'.join(keys)}"}

        m_key = re.search(r"\b(?:press|hit)\s+(?:key\s+)?['\"]?(enter|tab|escape|backspace|delete|space|up|down|left|right)['\"]?\b", lower)
        if m_key:
            k = m_key.group(1).strip()
            return {"type": "key", "params": {"key": k}, "description": f"Press '{k}'"}

        # 8. Type text into target
        m_type = re.search(r"\b(?:type|enter|input|write)\s+['\"]([^'\"]+)['\"]\s+(?:into|in|to)\s+(?:['\"]([^'\"]+)['\"]|(\w+))", s, re.I)
        if m_type:
            typed_text = m_type.group(1)
            target_name = (m_type.group(2) or m_type.group(3) or "").strip()
            return {
                "type": "type",
                "params": {"text": typed_text},
                "target": {"name": target_name, "role": "edit"},
                "description": f"Type '{typed_text}' into '{target_name}'"
            }

        # 9. Click / Double-click / Right-click
        click_type = "click"
        if "double" in lower:
            click_type = "double_click"
        elif "right" in lower:
            click_type = "right_click"

        # Extract quoted element name if any: click 'Save' button in 'Notepad'
        m_quoted = re.search(r"['\"]([^'\"]+)['\"](?:\s+(button|link|checkbox|tab|item|menu|icon))?", s, re.I)
        target: Dict[str, Any] = {}
        window: Dict[str, Any] = {}

        m_in_win = re.search(r"\bin\s+['\"]([^'\"]+)['\"]", s, re.I)
        if m_in_win:
            window["title"] = m_in_win.group(1).strip()

        if m_quoted:
            target["name"] = m_quoted.group(1).strip()
            if m_quoted.group(2):
                target["role"] = m_quoted.group(2).lower()
        else:
            # Fallback unquoted
            words = [w for w in s.split() if w.lower() not in {"click", "double", "right", "the", "on", "button", "link", "in"}]
            if words:
                target["name"] = " ".join(words)

        res: Dict[str, Any] = {"type": click_type, "target": target, "description": s}
        if window:
            res["window"] = window
        return res

    # -------------------------------------------------------------------------
    # 2. Intelligent Failure Diagnostics
    # -------------------------------------------------------------------------
    def diagnose_failure(
        self,
        step: Dict[str, Any],
        error_msg: str,
        active_window: str = "",
        screen_ocr: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        """Produce an actionable, intelligent root-cause diagnostic report for a failed step."""
        # Try LLM if available
        if self.llm.available():
            try:
                resp = self.llm.generate(DIAGNOSIS_PROMPT.format(
                    step_json=json.dumps(step),
                    error=error_msg,
                    active_window=active_window or "Unknown"
                ))
                parsed = extract_json(resp)
                if parsed and isinstance(parsed, dict) and "summary" in parsed:
                    parsed["source"] = "llm"
                    return parsed
            except Exception as e:
                log.debug("LLM failure diagnosis failed, falling back to cognitive rules: %s", e)

        # Deterministic Expert Diagnostic Engine
        return self._rule_diagnose_failure(step, error_msg, active_window, screen_ocr)

    def _rule_diagnose_failure(
        self,
        step: Dict[str, Any],
        error_msg: str,
        active_window: str = "",
        screen_ocr: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        step_type = step.get("type", "unknown")
        target = step.get("target") or {}
        expected_window = (step.get("window") or {}).get("title", "")
        err_lower = error_msg.lower()

        # Case 1: Window activation or title mismatch
        if "could not activate" in err_lower or "window" in err_lower:
            if active_window and expected_window and active_window.lower() != expected_window.lower():
                return {
                    "summary": f"Window mismatch: Expected '{expected_window}', but active window is '{active_window}'.",
                    "likely_cause": "The previous action opened a modal dialog or navigation changed the active window.",
                    "suggestion": f"Update the step window title to '{active_window}', or insert a step to dismiss the unexpected dialog.",
                    "confidence": 0.95,
                    "source": "cognitive_rules",
                }

        # Case 2: Element not found
        if "not found" in err_lower or "element" in err_lower:
            target_name = target.get("name") or target.get("text") or "element"
            # Check if text exists anywhere in OCR on screen
            if screen_ocr and any(target_name.lower() in t.lower() for t in screen_ocr):
                return {
                    "summary": f"Control '{target_name}' is visible on screen but inaccessible via UI Automation.",
                    "likely_cause": "The element is rendered via custom canvas, OpenGL, Qt, or web canvas rather than standard Win32/UIA.",
                    "suggestion": "Enable 'use_ocr' or 'use_ai' similarity locator tiers in Settings, or use visual template matching.",
                    "confidence": 0.90,
                    "source": "cognitive_rules",
                }
            return {
                "summary": f"Target control '{target_name}' was not detected within timeout.",
                "likely_cause": "The application was loading slowly, the element was scrolled out of view, or its locator changed.",
                "suggestion": "Increase 'timeout_s' in Settings, add a scroll action, or enable 'auto_heal_update'.",
                "confidence": 0.85,
                "source": "cognitive_rules",
            }

        # Case 3: Validation failure
        if step_type == "validate" or "validation failed" in err_lower:
            check = step.get("check") or {}
            check_type = check.get("type", "")
            expected = check.get("expected", "")
            return {
                "summary": f"Assertion failed for check '{check_type}'.",
                "likely_cause": f"Expected '{expected}' did not match actual application state.",
                "suggestion": "Verify test data preconditions or adjust expected assertion value.",
                "confidence": 0.88,
                "source": "cognitive_rules",
            }

        # Case 4: Redaction / Secret protection
        if "redacted" in err_lower or (step.get("params") or {}).get("redacted"):
            return {
                "summary": "Step blocked due to redacted sensitive input.",
                "likely_cause": "The recorded text was masked as a password/secret during recording.",
                "suggestion": "Configure a secure test credential variable or supply a non-redacted parameter.",
                "confidence": 1.0,
                "source": "cognitive_rules",
            }

        # Generic fallback diagnosis
        return {
            "summary": f"Step '{step_type}' encountered error: {error_msg}",
            "likely_cause": "Unexpected application state or input backend restriction.",
            "suggestion": "Review execution screenshot and ensure application is in expected state before running step.",
            "confidence": 0.70,
            "source": "cognitive_rules",
        }

    # -------------------------------------------------------------------------
    # 3. Smart Self-Healing Candidate Evaluator
    # -------------------------------------------------------------------------
    def suggest_healing(self, failed_target: Dict[str, Any], candidates: List[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
        """Rank candidate elements and recommend the best self-healing replacement."""
        if not candidates:
            return None

        target_name = (failed_target.get("name") or failed_target.get("text") or "").strip().lower()
        target_role = (failed_target.get("role") or "").strip().lower()

        scored = []
        for cand in candidates:
            cand_name = (cand.get("name") or cand.get("text") or "").strip().lower()
            cand_role = (cand.get("role") or "").strip().lower()

            score = 0.0
            # Exact name match
            if target_name and cand_name:
                if target_name == cand_name:
                    score += 0.6
                elif target_name in cand_name or cand_name in target_name:
                    score += 0.4
                else:
                    # Token overlap
                    t_words = set(target_name.split())
                    c_words = set(cand_name.split())
                    if t_words and c_words:
                        overlap = len(t_words & c_words) / max(len(t_words | c_words), 1)
                        score += 0.3 * overlap

            # Role match
            if target_role and cand_role and target_role == cand_role:
                score += 0.25

            # Visual confidence if present
            if "confidence" in cand:
                score += 0.15 * float(cand["confidence"])

            scored.append((score, cand))

        scored.sort(key=lambda x: x[0], reverse=True)
        best_score, best_cand = scored[0]
        if best_score >= 0.5:
            return {
                "replacement": best_cand,
                "confidence": min(best_score, 0.99),
                "reason": f"Highest similarity match (score: {best_score:.2f}) based on name and role congruence."
            }
        return None

