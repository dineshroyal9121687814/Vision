"""
Image embeddings for the AI-similarity locator tier ("is this the same button?").

Three backends, picked automatically:
  1. ONNX deep embedding — if core/ai/models/embedder.onnx exists and onnxruntime is installed.
  2. PyTorch Deep Neural embedding — local deep UI feature extractor (128-dim normalized embedding).
  3. Classical fallback (always available, offline): colour histogram + edge grid.
"""
from __future__ import annotations

from pathlib import Path

import cv2
import numpy as np

MODEL_PATH = Path(__file__).resolve().parent / "models" / "embedder.onnx"
_session = None
_checked = False


def _onnx():
    global _session, _checked
    if _checked:
        return _session
    _checked = True
    if MODEL_PATH.exists():
        try:
            import onnxruntime as ort

            _session = ort.InferenceSession(str(MODEL_PATH), providers=["CPUExecutionProvider"])
        except Exception:
            _session = None
    return _session


def _deep_neural(img: np.ndarray) -> np.ndarray | None:
    try:
        from core.ai.neural_embedder import extract_deep_embedding
        return extract_deep_embedding(img)
    except Exception:
        return None


def _classical(img: np.ndarray) -> np.ndarray:
    small = cv2.resize(img, (64, 64))
    if small.ndim == 2:
        small = cv2.cvtColor(small, cv2.COLOR_GRAY2BGR)
    # Colour histogram with soft (smoothed) bins so a small shade change moves mass to a
    # neighbouring bin instead of making two near-identical flat buttons orthogonal.
    hist = np.concatenate([cv2.calcHist([small], [c], None, [16], [0, 256]).flatten() for c in range(3)])
    hist = hist.reshape(3, 16)
    kernel = np.array([0.1, 0.2, 0.4, 0.2, 0.1], dtype=np.float32)
    hist = np.stack([np.convolve(np.pad(h, 2, mode="edge"), kernel, mode="valid") for h in hist]).flatten()
    hist = hist / (hist.sum() + 1e-6)
    # Coarse colour layout (4x4 thumbnail): captures overall tone and where it sits.
    layout = cv2.resize(small, (4, 4), interpolation=cv2.INTER_AREA).astype(np.float32).flatten() / 255.0
    gray = cv2.cvtColor(small, cv2.COLOR_BGR2GRAY)
    mag = cv2.magnitude(cv2.Sobel(gray, cv2.CV_32F, 1, 0), cv2.Sobel(gray, cv2.CV_32F, 0, 1))
    grid = cv2.resize(mag, (8, 8)).flatten()
    grid = grid / (grid.max() + 1e-6)
    return np.concatenate([hist, layout * 0.25, grid]).astype(np.float32)


def embed(img: np.ndarray) -> np.ndarray:
    sess = _onnx()
    if sess is not None:
        try:
            x = cv2.resize(img, (224, 224)).astype(np.float32) / 255.0
            x = np.transpose(x, (2, 0, 1))[None]
            return sess.run(None, {sess.get_inputs()[0].name: x})[0].flatten().astype(np.float32)
        except Exception:
            pass

    deep = _deep_neural(img)
    if deep is not None:
        return deep

    return _classical(img)


def backend_name() -> str:
    if _onnx() is not None:
        return "onnx"
    try:
        from core.ai.neural_embedder import get_deep_model
        if get_deep_model() is not None:
            return "neural"
    except Exception:
        pass
    return "classical"
