"""
AI-similarity locator tier: finds the region that *looks most like* the recorded
element even when pixels differ (theme / colour / small restyle).

It is the slowest tier (sliding window of embeddings), so the resolver only
calls it after template, ORB and OCR have failed, and over a limited region.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from core.ai import embedder


@dataclass
class AIMatch:
    found: bool
    x: int = 0
    y: int = 0
    score: float = 0.0
    backend: str = ""
    margin: float = 0.0   # best score minus the best score elsewhere: how unambiguous the match is


def _cosine(a: np.ndarray, b: np.ndarray) -> float:
    return float(np.dot(a, b) / ((np.linalg.norm(a) * np.linalg.norm(b)) + 1e-8))


class AIMatcher:
    DEFAULT_THRESHOLD = 0.90  # classical embeddings are coarse: keep this high to avoid false hits

    def is_same_element(self, a: np.ndarray, b: np.ndarray, threshold: float | None = None) -> tuple[bool, float]:
        score = _cosine(embedder.embed(a), embedder.embed(b))
        return score >= (threshold or self.DEFAULT_THRESHOLD), score

    def find_similar(self, screen: np.ndarray, template: np.ndarray, stride: int = 24,
                     threshold: float | None = None, min_margin: float = 0.02) -> AIMatch:
        """Best-matching window, accepted only if it is clearly better than every other
        region (min_margin). A match that is merely 'similar to lots of things' is rejected:
        clicking the wrong control is worse than failing."""
        th, tw = template.shape[:2]
        sh, sw = screen.shape[:2]
        if th > sh or tw > sw:
            return AIMatch(False)
        thr = threshold or self.DEFAULT_THRESHOLD
        target = embedder.embed(template)
        scores = []
        for y in range(0, sh - th + 1, stride):
            for x in range(0, sw - tw + 1, stride):
                scores.append((_cosine(embedder.embed(screen[y:y + th, x:x + tw]), target), x + tw // 2, y + th // 2))
        if not scores:
            return AIMatch(False)
        best = max(scores)
        second = max((s for s, cx, cy in scores if abs(cx - best[1]) >= tw or abs(cy - best[2]) >= th), default=0.0)
        margin = best[0] - second
        return AIMatch(best[0] >= thr and margin >= min_margin, best[1], best[2], max(best[0], 0.0),
                       embedder.backend_name(), margin)
