"""
Post-recording analysis ("AI understands the recording and generates the JSON").

Runs once after the user stops recording, before the review screen:

  1. OCR-label elements that have no accessible name (non-native apps, canvases,
     Citrix) so the step list reads "Click 'Login' button", not "element at (523, 410)".
  2. Re-describe every step in plain English.
  3. Suggest validation points (window changed, text typed, item selected, checkbox toggled).
     The user accepts/edits them in the review dialog - nothing is added silently.
  4. Title + summary (local LLM if running, otherwise a deterministic summary).
"""
from __future__ import annotations

import logging
from typing import Callable

from core.ai.describe import describe_step, describe_validation, label_of
from core.ai.llm import OllamaClient, extract_json
from core.system.imageio import imread

log = logging.getLogger("visionauto.analyze")

CLICKISH = ("click", "double_click", "right_click", "middle_click", "key", "hotkey")
SELECTABLE = {"radiobutton", "tabitem", "listitem", "treeitem", "dataitem"}
Progress = Callable[[str, float], None]


def _noop(msg: str, frac: float) -> None:
    pass


def _norm_title(t: str) -> str:
    return (t or "").lstrip("*• ").strip()


def suggest_validations(test: dict) -> int:
    """Attach rule-based validation suggestions to steps. Returns how many."""
    steps = test.get("steps", [])
    total = 0
    for i, s in enumerate(steps):
        sugg: list[dict] = []
        cur = (s.get("window") or {}).get("title", "")
        t = s.get("type")
        tgt = s.get("target") or {}

        if t in CLICKISH:
            nxt = next((x for x in steps[i + 1:i + 4] if (x.get("window") or {}).get("title")), None)
            if nxt:
                nt = nxt["window"]["title"]
                if _norm_title(nt) != _norm_title(cur):
                    sugg.append({"type": "window_title_contains", "expected": nt, "confidence": 0.85,
                                 "reason": f"The active window changed to '{nt}' after this step."})

        if t == "type" and s.get("params", {}).get("text"):
            sugg.append({"type": "text_contains", "expected": s["params"]["text"], "target": tgt,
                         "confidence": 0.8, "reason": "The typed text should be present in the field."})

        if t in ("click", "double_click"):
            role = (tgt.get("role") or "").replace(" ", "").lower()
            toggle = (tgt.get("state") or {}).get("toggle")
            if role == "checkbox" and toggle in ("on", "off"):
                sugg.append({"type": "state", "expected": "off" if toggle == "on" else "on", "target": tgt,
                             "confidence": 0.8, "reason": f"Checkbox was {toggle} before the click, so it should have flipped."})
            elif role in SELECTABLE and label_of(tgt):
                sugg.append({"type": "state", "expected": "selected", "target": tgt, "confidence": 0.7,
                             "reason": "The clicked item should now be selected."})

        for v in sugg:
            v["description"] = describe_validation(v)
        s["suggestions"] = sugg
        total += len(sugg)
    return total


def _ocr_label(test: dict, directory, progress: Progress) -> int:
    from core.ocr import ocr_engine

    todo = []
    for s in test.get("steps", []):
        if s.get("type") in ("click", "double_click", "right_click", "drag_drop", "validate"):
            tgt = s.get("target") or {}
            if not (tgt.get("name") or tgt.get("text") or tgt.get("value") or tgt.get("automation_id")):
                todo.append(tgt)
    done = 0
    for n, tgt in enumerate(todo):
        tpl = (tgt.get("templates") or {}).get("crop100")
        if not tpl:
            continue
        img = imread(directory / tpl["path"])
        if img is None:
            continue
        try:
            text = ocr_engine.read_text(img, near=tuple(tpl["click"]))
        except Exception as e:   # EasyOCR missing / model not downloadable: stop trying
            log.info("OCR labelling skipped: %s", e)
            progress(f"OCR not available ({type(e).__name__}); using window/position labels", 0.4)
            return done
        if text:
            tgt["text"], tgt["text_source"] = text, "ocr"
            done += 1
        progress(f"Reading element labels ({n + 1}/{len(todo)})", 0.1 + 0.3 * (n + 1) / len(todo))
    return done


def _rule_summary(test: dict) -> tuple[str, str]:
    steps = test.get("steps", [])
    app = (test.get("app") or {}).get("title") or next(
        ((s.get("window") or {}).get("title") for s in steps if (s.get("window") or {}).get("title")), "")
    app = app.split(" - ")[-1] if app else "application"
    kinds = {}
    for s in steps:
        kinds[s["type"]] = kinds.get(s["type"], 0) + 1
    bits = [f"{n} {k.replace('_', ' ')}" for k, n in sorted(kinds.items(), key=lambda kv: -kv[1])]
    return f"{app} test", f"{len(steps)} steps in {app}: " + ", ".join(bits) + "."


def _llm_summary(test: dict, llm: OllamaClient) -> tuple[str, str] | None:
    lines = "\n".join(f"{s['id']}. {s['description']}" for s in test["steps"][:60])
    reply = llm.generate(
        "Below are the recorded steps of a desktop UI test. Reply with ONLY a JSON object "
        '{"title": "<max 8 words>", "summary": "<one sentence>"}.\n\n' + lines)
    data = extract_json(reply)
    if data and data.get("title"):
        return str(data["title"])[:80], str(data.get("summary", ""))[:300]
    return None


def analyze(test: dict, directory, use_ocr: bool = True, llm: OllamaClient | None = None,
            progress: Progress = _noop) -> dict:
    progress("Analysing recording", 0.05)
    if use_ocr:
        _ocr_label(test, directory, progress)
    for s in test.get("steps", []):
        s["description"] = describe_step(s)
    progress("Suggesting validation points", 0.6)
    suggest_validations(test)
    progress("Summarising", 0.8)
    result = _llm_summary(test, llm) if llm and llm.available() else None
    title, summary = result or _rule_summary(test)
    if not test.get("title") or test.get("title") == test.get("name"):
        test["title"] = title
    test["summary"] = summary
    progress("Done", 1.0)
    return test


def apply_suggestions(test: dict, accepted: dict[int, list[int]]) -> dict:
    """Move accepted suggestions into step['validations'] and drop the rest.
    `accepted` maps step id -> indexes of accepted suggestions."""
    for s in test.get("steps", []):
        sugg = s.pop("suggestions", [])
        for idx in accepted.get(s["id"], []):
            if 0 <= idx < len(sugg):
                v = {k: val for k, val in sugg[idx].items() if k not in ("confidence", "reason")}
                s.setdefault("validations", []).append(v)
    return test
