"""
Local AI without manual setup: find / install / start Ollama and fetch the model - all from inside VisionAuto.

    status = ollama_manager.status(base_url, model)           # what is missing right now
    ollama_manager.ensure_ready(model, base_url, progress, allow_install=True)

Safety rules (this downloads and runs an installer, so it is deliberately strict):
 * **Only on explicit consent** - ``allow_install`` is True only after the user clicks "Set up local AI" (GUI) or passes
   ``--yes`` (CLI). Starting an already-installed Ollama needs no consent; installing does.
 * The installer comes from one fixed official URL, over HTTPS, and is **not run unless Windows reports a valid
   Authenticode signature whose signer is Ollama**.
 * Nothing here is required: every AI feature has a rule-based path (see core/ai/llm.py).
Windows only for install/start; on other OSes ``status`` still reports and ``ensure_ready`` explains what to do.
"""
from __future__ import annotations

import json
import logging
import os
import shutil
import subprocess
import tempfile
import time
import urllib.request
from pathlib import Path
from urllib.parse import urlsplit

from core.system import quiet
from core.system.winenv import IS_WINDOWS

log = logging.getLogger("visionauto.ollama")

INSTALLER_URL = "https://ollama.com/download/OllamaSetup.exe"
MIN_INSTALLER_BYTES = 50 * 1024 * 1024
Progress = "callable[[str], None]"


def _noop(_msg: str) -> None:
    pass


def find_ollama() -> str | None:
    """Path of ollama(.exe) if it is installed."""
    hit = shutil.which("ollama")
    if hit:
        return hit
    if IS_WINDOWS:
        for base in (os.environ.get("LOCALAPPDATA"), os.environ.get("ProgramFiles")):
            if base:
                p = Path(base) / ("Programs/Ollama/ollama.exe" if base == os.environ.get("LOCALAPPDATA") else "Ollama/ollama.exe")
                if p.exists():
                    return str(p)
    return None


def _tags(base_url: str, timeout: float = 1.5) -> list[str] | None:
    """Installed model names, or None when the service is not answering."""
    try:
        with urllib.request.urlopen(base_url.rstrip("/") + "/api/tags", timeout=timeout) as r:
            return [m.get("name", "") for m in json.loads(r.read()).get("models", [])]
    except Exception:
        return None


def has_model(installed: list[str], model: str) -> bool:
    want = model.strip().casefold()
    want_latest = want if ":" in want else want + ":latest"
    return any(n.casefold() in (want, want_latest) for n in installed)


def status(base_url: str, model: str) -> dict:
    exe = find_ollama()
    tags = _tags(base_url)
    return {"installed": bool(exe), "exe": exe, "running": tags is not None,
            "model_ready": tags is not None and has_model(tags, model),
            "model": model, "base_url": base_url}


# ------------------------------------------------------------------ install
def _local_url(base_url: str) -> bool:
    return (urlsplit(base_url).hostname or "") in ("localhost", "127.0.0.1", "::1")


def verify_signature(path: str, runner=subprocess.run) -> tuple[bool, str]:
    """Valid Authenticode signature + signer mentions Ollama. Returns (ok, detail)."""
    if not IS_WINDOWS:
        return False, "signature check needs Windows"
    ps = ("$s = Get-AuthenticodeSignature -LiteralPath $env:VA_FILE; "
          "@{Status=[string]$s.Status; Subject=[string]$s.SignerCertificate.Subject} | ConvertTo-Json -Compress")
    cp = runner(["powershell", "-NoProfile", "-NonInteractive", "-Command", ps], capture_output=True, text=True,
                timeout=60, env={**os.environ, "VA_FILE": path}, creationflags=quiet.flags())
    try:
        d = json.loads(cp.stdout or "{}")
    except ValueError:
        return False, "could not read the signature"
    ok = d.get("Status") == "Valid" and "ollama" in str(d.get("Subject", "")).casefold()
    return ok, f"{d.get('Status')} / {d.get('Subject')}"


def download_installer(progress=_noop, url: str = INSTALLER_URL) -> str:
    if not url.startswith("https://ollama.com/"):
        raise ValueError("refusing to download an installer from an unexpected address")
    dest = Path(tempfile.mkdtemp(prefix="va_ollama_")) / "OllamaSetup.exe"
    with urllib.request.urlopen(url, timeout=30) as r, open(dest, "wb") as f:
        total = int(r.headers.get("Content-Length") or 0)
        done, last = 0, 0.0
        while True:
            chunk = r.read(1 << 20)
            if not chunk:
                break
            f.write(chunk)
            done += len(chunk)
            if time.monotonic() - last > 0.5:
                last = time.monotonic()
                progress(f"Downloading Ollama installer… {done // (1 << 20)} MB" + (f" ({100 * done // total}%)" if total else ""))
    if dest.stat().st_size < MIN_INSTALLER_BYTES:
        raise RuntimeError("downloaded installer is much smaller than expected; not running it")
    return str(dest)


def install(progress=_noop, downloader=download_installer, verifier=verify_signature, runner=subprocess.run) -> str:
    """Download, verify and silently install Ollama (per-user, no admin prompt). Returns the exe path."""
    if not IS_WINDOWS:
        raise RuntimeError("Automatic install is for Windows. On this OS install Ollama from https://ollama.com/download")
    path = downloader(progress)
    ok, detail = verifier(path)
    if not ok:
        raise RuntimeError(f"installer signature not trusted ({detail}); it was NOT run")
    progress("Installing Ollama (a minute or two)…")
    cp = runner([path, "/SILENT", "/NORESTART"], timeout=900)
    exe = None
    for _ in range(60):                                   # the installer returns before files are always visible
        exe = find_ollama()
        if exe:
            break
        time.sleep(1)
    if not exe:
        raise RuntimeError(f"Ollama installer finished (code {getattr(cp, 'returncode', '?')}) but ollama.exe was not found")
    return exe


# ------------------------------------------------------------------ run + model
def start_server(base_url: str, progress=_noop, exe: str | None = None, timeout: float = 40.0) -> bool:
    if _tags(base_url) is not None:
        return True
    if not _local_url(base_url):
        return False                                       # never try to "start" a remote server
    exe = exe or find_ollama()
    if not exe:
        return False
    progress("Starting the local AI service…")
    with quiet.FocusGuard():                      # a console that flashes while the service starts is hidden at once
        quiet.popen([exe, "serve"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, stdin=subprocess.DEVNULL,
                    detached=True)
        end = time.monotonic() + timeout
        while time.monotonic() < end:
            if _tags(base_url) is not None:
                return True
            time.sleep(0.5)
    return False


def warm_up(base_url: str, model: str, keep_alive: str = "30m", timeout: float = 90.0) -> bool:
    """Load the model into memory ONCE, before the first test step, and keep it there.
    Loading is when Ollama starts its runner process (the moment a console can flash); doing it up front, under a focus
    guard, means no step is ever interrupted by it. Never installs or downloads anything. True = model is loaded."""
    try:
        if not start_server(base_url):
            return False
        if not has_model(_tags(base_url) or [], model):
            return False
        body = json.dumps({"model": model, "prompt": "", "stream": False, "keep_alive": keep_alive}).encode()
        req = urllib.request.Request(base_url.rstrip("/") + "/api/generate", data=body,
                                     headers={"Content-Type": "application/json"})
        with quiet.FocusGuard():
            with urllib.request.urlopen(req, timeout=timeout) as r:
                r.read()
        return True
    except Exception:
        log.debug("model warm-up failed", exc_info=True)
        return False


def pull_model(base_url: str, model: str, progress=_noop) -> None:
    body = json.dumps({"name": model, "stream": True}).encode()
    req = urllib.request.Request(base_url.rstrip("/") + "/api/pull", data=body, method="POST",
                                 headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=60) as resp:
        for raw in resp:
            if not raw.strip():
                continue
            item = json.loads(raw)
            if item.get("error"):
                raise RuntimeError(item["error"])
            msg = item.get("status", "Downloading model")
            if item.get("total"):
                msg += f" ({100 * item.get('completed', 0) // item['total']}%)"
            progress(msg)


def ensure_running(base_url: str, progress=_noop) -> bool:
    """Start an *installed* Ollama if it is not answering. Never installs anything."""
    return start_server(base_url, progress)


def ensure_ready(model: str, base_url: str, progress=_noop, allow_install: bool = False) -> dict:
    """installed? -> (install if allowed) -> running? -> model present? -> pull. Returns the final status."""
    st = status(base_url, model)
    if not st["installed"] and not st["running"]:
        if not allow_install:
            raise RuntimeError("Ollama is not installed. Use 'Set up local AI' to install it (needs your consent).")
        st["exe"] = install(progress)
    if not start_server(base_url, progress, st.get("exe")):
        raise RuntimeError("The local AI service did not start. Check that nothing blocks ollama.exe, then try again.")
    tags = _tags(base_url) or []
    if not has_model(tags, model):
        progress(f"Downloading model {model} (one time)…")
        pull_model(base_url, model, progress)
    st = status(base_url, model)
    if not st["model_ready"]:
        raise RuntimeError(f"Model {model} is still not available after download.")
    progress("Local AI is ready.")
    return st
