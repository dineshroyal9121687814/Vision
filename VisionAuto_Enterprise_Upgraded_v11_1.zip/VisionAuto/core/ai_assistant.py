"""AI Assistant: everything here works WITHOUT a model (rules); a local model (Ollama) only improves the wording and fills gaps.

* ``requirements_to_cases``  requirement text -> positive / negative / boundary cases, duplicates and coverage gaps removed or
                             reported (core.testgen)
* ``nl_to_steps``            plain sentences -> executable steps, every step checked by core.validation BEFORE it is returned
* ``explain_failure``        a failed run -> category, likely cause, concrete fixes (rules from the run's own evidence)
* ``summarize_run``          one paragraph for people
* ``regression_suggestions`` which tests to run again, and why
Generated content is never saved or run by this module."""
from __future__ import annotations

import json
import re
from pathlib import Path

from core import retry, testgen, validation

# --------------------------------------------------------------------------------------------- requirements -> cases


def requirements_to_cases(text: str, topic: str | None = None, llm=None, existing: list[dict] | None = None) -> dict:
    out = testgen.generate(text, topic=topic, llm=llm if (llm and llm.available()) else None, existing=existing)
    out["ai_used"] = bool(llm and llm.available())
    return out


# --------------------------------------------------------------------------------------------- sentences -> steps
_KEYS = {"enter": "enter", "return": "enter", "tab": "tab", "escape": "esc", "esc": "esc", "delete": "delete",
         "backspace": "backspace", "space": "space", "home": "home", "end": "end", "page down": "page_down",
         "page up": "page_up", "up": "up", "down": "down", "left": "left", "right": "right"}
_RULES = [
    (re.compile(r"^(?:open|launch|start)\s+(?:the\s+)?(?:app(?:lication)?\s+)?(?P<name>.+?)(?:\s+app(?:lication)?)?$", re.I), "open"),
    (re.compile(r"^(?:type|enter|input|write)\s+[\"'“](?P<text>.*?)[\"'”](?:\s+(?:in|into|on)\s+(?:the\s+)?(?P<into>.+?))?$", re.I), "type"),
    (re.compile(r"^(?:press|hit)\s+(?P<keys>[\w +]+?)(?:\s+key)?$", re.I), "key"),
    (re.compile(r"^wait\s+(?:for\s+)?(?P<n>\d+(?:\.\d+)?)\s*(?P<unit>ms|milliseconds?|s|secs?|seconds?)?$", re.I), "wait"),
    (re.compile(r"^(?P<kind>double[- ]click|right[- ]click|click|tap|select|choose|press)\s+(?:on\s+)?(?:the\s+)?(?P<name>.+?)"
                r"(?:\s+(?:button|link|menu|item|tab|checkbox|option))?$", re.I), "click"),
    (re.compile(r"^(?:verify|check|assert|expect)\s+(?:that\s+)?(?:the\s+)?(?P<name>.+?)\s+(?:contains?|shows?|is|has)\s+[\"'“]?(?P<text>.+?)[\"'”]?$", re.I), "verify"),
]


def _step(i: int, kind: str, m: re.Match, line: str) -> dict | None:
    if kind == "open":
        return {"type": "open_app", "params": {"name": m["name"].strip()}, "description": f"Open {m['name'].strip()}"}
    if kind == "type":
        s = {"type": "type", "params": {"text": m["text"]}, "description": f"Type '{m['text']}'"}
        if m["into"]:
            s["target"] = {"name": m["into"].strip(), "role": "Edit"}
            s["description"] += f" into {m['into'].strip()}"
        return s
    if kind == "key":
        raw = m["keys"].strip().casefold()
        if "+" in raw or " + " in raw:
            return {"type": "hotkey", "params": {"keys": "+".join(p.strip() for p in raw.split("+"))}, "description": f"Press {raw}"}
        if raw in _KEYS:
            return {"type": "key", "params": {"key": _KEYS[raw]}, "description": f"Press {raw}"}
        return None                                           # "press the Save button" is a click, handled by the next rule
    if kind == "wait":
        n = float(m["n"])
        ms = int(n if (m["unit"] or "").lower().startswith("m") else n * 1000)
        return {"type": "wait", "params": {"ms": ms}, "description": f"Wait {n:g} {m['unit'] or 's'}"}
    if kind == "click":
        k = m["kind"].casefold().replace(" ", "_").replace("-", "_")
        t = {"double_click": "double_click", "right_click": "right_click"}.get(k, "click")
        return {"type": t, "target": {"name": m["name"].strip()}, "description": f"{m['kind'].capitalize()} '{m['name'].strip()}'"}
    if kind == "verify":
        return {"type": "validate", "params": {"validation": {"type": "text_contains", "expected": m["text"].strip(),
                                                              "target": {"name": m["name"].strip()}}},
                "description": f"Verify {m['name'].strip()} contains '{m['text'].strip()}'"}
    return None


def nl_to_steps(text: str, llm=None) -> dict:
    """-> {"steps": [...], "unparsed": [lines], "issues": [validation issues]}. One sentence per line, or separated by
    'then' / semicolons. ``llm`` (optional) is asked ONLY for lines the rules could not read, and its answer must pass
    the same validation or it is dropped."""
    parts = [p.strip(" .") for chunk in re.split(r"[\n;]+", text or "") for p in re.split(r"\bthen\b|,\s*and then\b", chunk, flags=re.I)]
    steps, unparsed = [], []
    for line in (p for p in parts if p):
        line = re.sub(r"^\s*(?:\d+[.)]|[-*•])\s*", "", line)
        made = None
        for rx, kind in _RULES:
            m = rx.match(line)
            if m:
                made = _step(len(steps) + 1, kind, m, line)
                if made:
                    break
        if made is None and llm is not None and llm.available():
            made = _llm_step(line, llm)
        if made is None:
            unparsed.append(line)
            continue
        made["id"] = len(steps) + 1
        steps.append(made)
    test = {"name": "generated", "steps": steps}
    issues = validation.validate_test(test) if steps else []
    return {"steps": steps, "unparsed": unparsed, "issues": issues, "ai_used": any(s.get("source") == "ai" for s in steps)}


def _llm_step(line: str, llm) -> dict | None:
    from core.ai.llm import extract_json

    prompt = ("Convert ONE test instruction into a JSON step. Allowed types: click, double_click, right_click, type, key, hotkey, "
              "wait, open_app. Reply with JSON only, e.g. {\"type\":\"click\",\"target\":{\"name\":\"Save\"}} or "
              "{\"type\":\"type\",\"params\":{\"text\":\"abc\"},\"target\":{\"name\":\"Name\"}}.\nInstruction: " + line)
    data = extract_json(llm.generate(prompt))
    if not isinstance(data, dict) or data.get("type") not in ("click", "double_click", "right_click", "type", "key", "hotkey", "wait", "open_app"):
        return None
    probe = {"name": "probe", "steps": [{**data, "id": 1}]}
    if validation.errors_only(validation.validate_test(probe)):
        return None
    data["description"] = line
    data["source"] = "ai"
    return data


# --------------------------------------------------------------------------------------------- failures
_ADVICE = {
    "not_found": ["The element was not found: re-record the step, or open Object Repository and check its locator.",
                  "If the window was still loading, raise the step timeout (Settings -> timeout)."],
    "validation": ["The action ran but the check failed: compare the screenshot with the expected value.",
                   "If the application needs time to update, add a Wait-until step before the check."],
    "permanent": ["The step itself is invalid or was blocked; fix the step (see the message) - retrying cannot help."],
    "unexpected": ["Unexpected error after input was sent: check the application state; consider adding a recovery step."],
}


def explain_failure(run: dict, llm=None) -> dict:
    """-> {"failed_step", "category", "recoverable", "cause", "fixes": [...], "evidence": {...}}"""
    failed = next((s for s in run.get("steps") or [] if s.get("status") == "failed"), None)
    if not failed:
        return {"failed_step": None, "category": "none", "recoverable": False, "cause": "No step failed in this run.",
                "fixes": [], "evidence": {}}
    cls = retry.classify(failed)
    fixes = list(_ADVICE.get(cls["category"], []))
    err = str(failed.get("error") or "")
    if failed.get("method", "").startswith(("ocr", "ai", "heal")):
        fixes.append("This element was only found by OCR / AI: add a name or a picture so it can be found reliably.")
    if "G14" in err or re.search(r"could not find '?[A-Z]{1,3}\d+'?", err, re.I):
        fixes.append("A spreadsheet cell could not be located: make sure the same workbook and sheet are open.")
    if any(v.get("status") == "failed" for v in failed.get("validations") or []):
        v = next(v for v in failed["validations"] if v.get("status") == "failed")
        fixes.append(f"Validation detail: {v.get('detail', '')}")
    out = {"failed_step": failed.get("id"), "description": failed.get("description", ""), "category": cls["category"],
           "recoverable": cls["recoverable"], "cause": cls["reason"], "fixes": fixes,
           "evidence": {"error": err[:400], "method": failed.get("method", ""), "retries": len(failed.get("retry_history") or [])}}
    if llm is not None and llm.available():
        txt = llm.generate("In two sentences, explain to a tester why this automated step failed and what to try. "
                           f"Step: {failed.get('description')}. Error: {err[:300]}. Category: {cls['category']}.")
        if txt:
            out["ai_explanation"] = txt.strip()
    return out


def summarize_run(run: dict) -> str:
    s = run.get("summary") or {}
    dur = round((s.get("duration_ms") or 0) / 1000, 1)
    text = (f"'{run.get('title') or run.get('test')}' {run.get('status')}: {s.get('passed', 0)} of {s.get('total', 0)} steps passed"
            f"{', ' + str(s.get('failed')) + ' failed' if s.get('failed') else ''}"
            f"{', ' + str(s.get('skipped')) + ' skipped' if s.get('skipped') else ''} in {dur}s.")
    if s.get("healed"):
        text += f" {s['healed']} locator(s) were repaired automatically and need review."
    if run.get("status") == "failed":
        e = explain_failure(run)
        text += f" First failure at step {e['failed_step']}: {e['cause']}"
    return text


def regression_suggestions(rows: list[dict]) -> list[dict]:
    """``rows`` = core.reports.manage.list_reports(): recently failed, healed or never-green tests first."""
    latest: dict[str, dict] = {}
    for r in rows:
        if not r.get("dry_run"):
            latest.setdefault(r["test_name"], r)
    out = []
    for name, r in latest.items():
        if r["status"] == "failed":
            out.append({"test": name, "priority": 1, "reason": "failed in its latest run"})
        elif r.get("healed"):
            out.append({"test": name, "priority": 2, "reason": f"{r['healed']} locator(s) were healed; confirm they still work"})
        elif r.get("retries"):
            out.append({"test": name, "priority": 3, "reason": "needed retries (possible flakiness)"})
    return sorted(out, key=lambda x: x["priority"])


def locator_fixes(objs: list[dict], threshold: int = 60) -> list[dict]:
    """Objects from core.object_repo.collect() that deserve attention, with what to do."""
    out = []
    for o in objs:
        if o["reliability"] >= threshold:
            continue
        tip = ("Only coordinates/zone are recorded: re-record this step while the element is visible."
               if o["locator"] in ("Coordinates", "Zone") else
               "Add an Automation ID or a clearer name; the picture-only locator breaks when the look changes."
               if o["locator"] in ("Image",) else "Verify the name is unique in its window.")
        out.append({"object": o["name"], "test": o["test"], "step": o["step"], "reliability": o["reliability"], "fix": tip})
    return sorted(out, key=lambda x: x["reliability"])
