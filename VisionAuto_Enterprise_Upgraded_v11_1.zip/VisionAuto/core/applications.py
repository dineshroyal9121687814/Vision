"""
Application Registry and Discovery for VisionAuto.

Allows registering, managing, configuring, and discovering applications
(Desktop Win32/WPF/Qt/UIA, Web Browsers, Running Processes) for multi-application
test automation workflows comparable to Ranorex Studio.
"""
from __future__ import annotations

import json
import logging
import os
import re
import sys
import uuid
from copy import deepcopy
from pathlib import Path
from typing import Any

from core import paths

log = logging.getLogger("visionauto.applications")

DANGEROUS_BINARIES = {
    "cmd", "cmd.exe", "powershell", "powershell.exe", "pwsh", "pwsh.exe",
    "bash", "sh", "wscript", "cscript", "mshta", "regsvr32", "rundll32",
}

SUPPORTED_TYPES = ("desktop", "web", "running")
SUPPORTED_ADAPTERS = ("desktop", "web", "uia", "auto")
SUPPORTED_BROWSERS = ("chrome", "msedge", "edge", "firefox", "brave", "opera", "vivaldi")


def _sanitize_identifier(value: str) -> str:
    return re.sub(r"[^\w\-. ]+", "_", value or "").strip(" .")


def validate_app_def(data: dict) -> list[str]:
    """Validate application definition properties, returning a list of validation errors."""
    errors = []
    if not isinstance(data, dict):
        return ["Application definition must be a dictionary."]

    name = str(data.get("name", "")).strip()
    if not name:
        errors.append("Application 'name' is required.")

    app_type = str(data.get("type", "desktop")).strip().lower()
    if app_type not in SUPPORTED_TYPES:
        errors.append(f"Application 'type' must be one of: {', '.join(SUPPORTED_TYPES)} (got '{app_type}').")

    alias = str(data.get("alias", "")).strip()
    if not alias:
        errors.append("Application 'alias' is required (e.g. 'web', 'calc', 'crm').")
    elif not re.match(r"^[a-zA-Z0-9_\-]+$", alias):
        errors.append(f"Application 'alias' '{alias}' must contain only letters, numbers, hyphens, and underscores.")

    if app_type == "desktop":
        exe = str(data.get("exe_path", "")).strip()
        if not exe:
            errors.append("Desktop application requires 'exe_path'.")
        else:
            base_exe = Path(exe).name.lower()
            if base_exe in DANGEROUS_BINARIES or any(char in exe for char in [";", "&", "|", "`", "$"]):
                errors.append(f"Executable '{exe}' contains restricted characters or commands.")

    elif app_type == "web":
        browser = str(data.get("browser", "chrome")).strip().lower()
        if browser not in SUPPORTED_BROWSERS:
            errors.append(f"Browser '{browser}' is not in supported list: {', '.join(SUPPORTED_BROWSERS)}.")
        url = str(data.get("url") or data.get("base_url") or "").strip()
        if not url:
            errors.append("Web application requires 'url' or 'base_url'.")

    elif app_type == "running":
        proc = str(data.get("process_name", "")).strip()
        title = str(data.get("window_title", "")).strip()
        if not proc and not title:
            errors.append("Running application target requires either 'process_name' or 'window_title'.")

    timeout = data.get("timeout_s")
    if timeout is not None:
        try:
            t_val = float(timeout)
            if t_val <= 0 or t_val > 600:
                errors.append("Application 'timeout_s' must be between 0 and 600 seconds.")
        except (ValueError, TypeError):
            errors.append("Application 'timeout_s' must be a valid number.")

    return errors


def default_app_def(name: str = "", app_type: str = "desktop", alias: str = "") -> dict:
    clean_name = name.strip() or "New Application"
    clean_alias = alias.strip() or _sanitize_identifier(clean_name.lower().replace(" ", "_"))
    return {
        "id": f"app_{uuid.uuid4().hex[:8]}",
        "name": clean_name,
        "alias": clean_alias,
        "type": app_type,
        "adapter": "web" if app_type == "web" else "desktop",
        "exe_path": "",
        "args": [],
        "working_dir": "",
        "window_title": "",
        "process_name": "",
        "browser": "chrome" if app_type == "web" else "",
        "url": "" if app_type == "web" else "",
        "timeout_s": 15.0,
        "close_on_exit": True,
        "description": "",
    }


def load_registry(path: Path | None = None) -> dict[str, dict]:
    """Load the application registry from disk. Returns a dictionary mapping app_id -> app_def."""
    reg_path = Path(path) if path else paths.applications_file()
    if not reg_path.exists():
        return {}
    try:
        content = reg_path.read_text(encoding="utf-8")
        data = json.loads(content)
        if isinstance(data, dict):
            # Keyed by app_id
            return data
        elif isinstance(data, list):
            # Backward-compat or list format: convert to id-keyed dict
            return {item["id"]: item for item in data if isinstance(item, dict) and "id" in item}
    except Exception as e:
        log.warning("Failed to load applications registry from %s: %s", reg_path, e)
    return {}


def save_registry(registry: dict[str, dict], path: Path | None = None) -> None:
    """Save the application registry atomically to disk."""
    reg_path = Path(path) if path else paths.applications_file()
    reg_path.parent.mkdir(parents=True, exist_ok=True)
    tmp = reg_path.with_suffix(reg_path.suffix + ".tmp")
    try:
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(registry, f, indent=2, ensure_ascii=False)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, reg_path)
    except Exception:
        if tmp.exists():
            try:
                tmp.unlink()
            except OSError:
                pass
        raise


def register_app(app_def: dict, path: Path | None = None) -> dict:
    """Register or update an application definition. Validates definition and checks alias uniqueness."""
    errors = validate_app_def(app_def)
    if errors:
        raise ValueError("; ".join(errors))

    registry = load_registry(path)
    entry = deepcopy(app_def)
    app_id = str(entry.get("id") or f"app_{uuid.uuid4().hex[:8]}")
    entry["id"] = app_id

    # Check alias uniqueness across other entries
    alias = entry["alias"].strip().lower()
    for existing_id, existing in registry.items():
        if existing_id != app_id and str(existing.get("alias", "")).strip().lower() == alias:
            raise ValueError(f"Application alias '{entry['alias']}' is already in use by '{existing.get('name')}'.")

    registry[app_id] = entry
    save_registry(registry, path)
    return entry


def get_app(identifier: str, path: Path | None = None) -> dict | None:
    """Lookup an application by ID or Alias."""
    if not identifier:
        return None
    registry = load_registry(path)
    # Direct ID match
    if identifier in registry:
        return deepcopy(registry[identifier])
    # Alias match (case-insensitive)
    ident_lower = identifier.strip().lower()
    for entry in registry.values():
        if str(entry.get("alias", "")).strip().lower() == ident_lower:
            return deepcopy(entry)
    # Name match fallback
    for entry in registry.values():
        if str(entry.get("name", "")).strip().lower() == ident_lower:
            return deepcopy(entry)
    return None


def remove_app(app_id: str, path: Path | None = None) -> bool:
    """Remove an application by ID."""
    registry = load_registry(path)
    if app_id in registry:
        del registry[app_id]
        save_registry(registry, path)
        return True
    return False


def list_apps(path: Path | None = None) -> list[dict]:
    """List all registered applications sorted by name."""
    registry = load_registry(path)
    apps = list(registry.values())
    apps.sort(key=lambda x: str(x.get("name", "")).lower())
    return apps


# --------------------------------------------------------------------- Discovery
def discover_running_apps() -> list[dict]:
    """Discover currently running top-level applications with visible windows."""
    results: list[dict] = []
    if sys.platform != "win32":
        return results

    try:
        import ctypes
        from core.system import winenv

        u = ctypes.windll.user32
        proc_t = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p)
        discovered_hwnds: list[int] = []

        def enum_cb(hwnd, _):
            if u.IsWindowVisible(hwnd) and not u.GetParent(hwnd):
                # Check style for WS_VISIBLE and not tool window
                style = u.GetWindowLongW(hwnd, -16)  # GWL_STYLE
                ex_style = u.GetWindowLongW(hwnd, -20)  # GWL_EXSTYLE
                WS_VISIBLE = 0x10000000
                WS_EX_TOOLWINDOW = 0x00000080
                if (style & WS_VISIBLE) and not (ex_style & WS_EX_TOOLWINDOW):
                    discovered_hwnds.append(hwnd)
            return True

        u.EnumWindows(proc_t(enum_cb), 0)

        for hwnd in discovered_hwnds:
            info = winenv.window_info(hwnd)
            title = info.get("title", "").strip()
            # Ignore empty titles or common OS background helper windows
            if not title or title in ("Program Manager", "Settings", "Windows Input Experience"):
                continue

            # Determine probable application type
            proc_name = (info.get("process") or "").lower()
            is_browser = any(b in proc_name for b in ("chrome", "msedge", "firefox", "brave", "opera"))
            app_type = "web" if is_browser else "desktop"

            results.append({
                "title": title,
                "process": info.get("process", ""),
                "pid": info.get("pid", 0),
                "hwnd": info.get("hwnd", 0),
                "type": app_type,
                "adapter": "web" if is_browser else "desktop",
            })
    except Exception as e:
        log.debug("discover_running_apps error: %s", e)

    return results


def inspect_window_hierarchy(hwnd: int) -> dict:
    """Inspect UI Automation controls inside a given top-level window handle."""
    result: dict = {
        "hwnd": hwnd,
        "title": "",
        "process": "",
        "controls": [],
    }
    if sys.platform != "win32" or not hwnd:
        return result

    try:
        from core.system import winenv
        info = winenv.window_info(hwnd)
        result["title"] = info.get("title", "")
        result["process"] = info.get("process", "")

        from pywinauto import Desktop
        d = Desktop(backend="uia")
        # Find window by handle
        win = d.window(handle=hwnd)
        if not win or not win.exists():
            return result

        controls = []
        for child in win.descendants()[:100]:  # Cap at 100 controls for performance
            try:
                el_info = child.element_info
                name = el_info.name or ""
                role = el_info.control_type or ""
                auto_id = el_info.automation_id or ""
                rect = el_info.rectangle
                if name or auto_id or role:
                    controls.append({
                        "name": name,
                        "role": role,
                        "automation_id": auto_id,
                        "rect": [int(rect.left), int(rect.top), int(rect.right), int(rect.bottom)],
                    })
            except Exception:
                continue
        result["controls"] = controls
    except Exception as e:
        log.debug("inspect_window_hierarchy failed for hwnd %s: %s", hwnd, e)

    return result

