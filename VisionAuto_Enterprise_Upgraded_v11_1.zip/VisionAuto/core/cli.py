"""VisionAuto command line - run tests and suites, edit locators / data / loops without the GUI.

    python -m core.cli run MyTest [--data users.csv] [--rows 1-3,5] [--dry-run] [--timeout 10]
    python -m core.cli suite suite.json [--tag smoke] [--exclude-tag slow] [--dry-run]
    python -m core.cli edit show      MyTest STEP
    python -m core.cli edit locator   MyTest STEP KIND VALUE [--x N --y N --w N --h N] [--dialect ranorex] [--exact]
    python -m core.cli edit order     MyTest STEP xpath,uia,image,ocr,coordinates
    python -m core.cli edit data      MyTest --file users.csv [--select 1-3] [--secret password] [--on-row-failure stop]
    python -m core.cli edit zone      MyTest STEP --rect L,T,R,B [--name terminal]
    python -m core.cli edit drag      MyTest STEP [--hold-ms N --hover-ms N --steps N --drop-mode position --modifiers ctrl]
    python -m core.cli edit modifiers MyTest STEP ctrl,shift
    python -m core.cli edit limit     MyTest STEP --ms 2000
    python -m core.cli edit recovery  MyTest --window "Update available" --action click_text --value Later
    python -m core.cli fix        MyTest [--dry]          # merge "Start -> type -> click result" into one open_app step
    python -m core.cli ai status | setup [--yes]     # local AI (Ollama): check / install + start + model, no manual steps
    python -m core.cli dataset stats | export FILE.zip   # training data collected from every recording / run
    python -m core.cli inspect    --window Calculator [--find Nine | --xpath] | --point X,Y
    python -m core.cli edit loop      MyTest FIRST LAST --times 3
    python -m core.cli edit if        MyTest FIRST LAST --variable role=equals=admin [--else-from ID]

Exit code: 0 passed/inconclusive, 1 failed, 2 invalid / usage error.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

OK = ("passed", "inconclusive")


def _print_step(r: dict) -> None:
    if r.get("status") != "running":
        print(f"  [{r.get('status')}] {r.get('description', '')}")


def cmd_run(a) -> int:
    from core.playback.player import Player

    opts = {"timeout_s": a.timeout}
    run = Player(a.test, opts, on_step=_print_step, dry_run=a.dry_run, data=a.data, data_select=a.rows).run()
    print(f"\nStatus: {run['status']}  {run.get('summary', {})}")
    if run.get("data"):
        d = run["data"]
        print(f"Data rows: {d['rows_passed']} passed, {d['rows_failed']} failed of {d['rows_run']} run")
    if run.get("error"):
        print(f"Error: {run['error']}")
    print(f"Report: {run.get('_dir')}")
    return 0 if run["status"] in OK else (2 if run["status"] == "invalid" else 1)


def cmd_suite(a) -> int:
    from core.suite import SuiteError, run_suite

    try:
        res = run_suite(a.suite, a.tag, a.exclude_tag, dry_run=a.dry_run, options={"timeout_s": a.timeout}, shard=a.shard,
                        on_test=lambda r: print(f"[{r['status']}] {r['role']}: {r['test']}"))
    except SuiteError as exc:
        print(f"Suite error: {exc}")
        return 2
    t = res["totals"]
    print(f"\nSuite {res['suite']}: {res['status']} - {t['passed']} passed, {t['failed']} failed, {t['skipped']} skipped")
    print(f"Results: {res['_dir']}")
    return 0 if res["status"] in OK else 1


def cmd_patterns(a) -> int:
    """Say in plain words what the recording does; --apply N turns repeated block N into a loop over its values."""
    from core import testfile
    from core.recorder import patterns

    test, directory = testfile.load_test(a.test)
    found = patterns.analyze(test.get("steps") or [])
    if not found:
        print("No repeated or form-like pattern found: the recording is a plain sequence of actions.")
        return 0
    for n, f in enumerate(found, 1):
        last = f["start"] + f["length"] * f.get("repeats", 1)
        print(f"{n}. steps {f['start'] + 1}-{last}: {f['title']}" + (f"\n     -> {f['advice']}" if f.get("advice") else ""))
    if a.apply:
        f = found[a.apply - 1]
        try:
            new = patterns.apply_data_loop(test, f)
        except ValueError as exc:
            print(f"Not changed: {exc}")
            return 2
        testfile.save_test(new, directory)
        print(f"Saved: repeated block now runs as a loop ({f['repeats']} rounds); values are in the 'field_N_list' steps.")
    return 0


def cmd_schedule(a) -> int:
    """Print (or with --create install) the command that runs a test or suite on a schedule."""
    import shlex
    import subprocess
    import sys as _sys

    cmd = [_sys.executable, "-m", "core.cli", "suite" if a.suite else "run", a.suite or a.test]
    if _sys.platform.startswith("win"):
        when = {"daily": "DAILY", "weekly": "WEEKLY", "once": "ONCE"}[a.every]
        line = ["schtasks", "/Create", "/TN", f"VisionAuto_{a.suite or a.test}", "/SC", when, "/ST", a.at,
                "/TR", subprocess.list2cmdline(cmd), "/F"]
    else:
        hh, mm = a.at.split(":")
        dow = "1" if a.every == "weekly" else "*"
        print(f"{int(mm)} {int(hh)} * * {dow} {' '.join(shlex.quote(c) for c in cmd)}   # add to crontab -e")
        return 0
    print(subprocess.list2cmdline(line))
    if a.create:
        return subprocess.run(line).returncode
    print("(not installed - add --create to install it)")
    return 0


def _edit(a) -> int:
    from core import editing, testfile

    test, directory = testfile.load_test(a.test)
    try:
        if a.what == "show":
            print(json.dumps(editing.show_locators(test, a.step), indent=2))
            return 0
        if a.what == "locator":
            editing.set_locator(test, a.step, a.kind, a.value, directory=directory, x=a.x, y=a.y, w=a.w, h=a.h,
                                dialect=a.dialect, exact=a.exact)
        elif a.what == "order":
            editing.set_locator_order(test, a.step, [t.strip() for t in a.order.split(",") if t.strip()])
        elif a.what == "data":
            editing.set_data(test, directory, file=a.file, select=a.select, on_row_failure=a.on_row_failure,
                             restart_apps=a.restart_apps, secret_columns=a.secret or None)
        elif a.what == "zone":
            editing.set_zone(test, a.step, [int(v) for v in a.rect.split(",")], a.name)
        elif a.what == "drag":
            editing.set_drag_options(test, a.step, steps=a.steps, hold_ms=a.hold_ms, hover_ms=a.hover_ms,
                                     drop_mode=a.drop_mode, modifiers=a.modifiers.split(",") if a.modifiers else None)
        elif a.what == "modifiers":
            editing.set_click_modifiers(test, a.step, [m for m in a.keys.split(",") if m])
        elif a.what == "limit":
            editing.set_max_duration(test, a.step, a.ms)
        elif a.what == "recovery":
            editing.set_recovery(test, list(test.get("recovery") or []) + [{"window": a.window, "action": a.action, "value": a.value or ""}])
        elif a.what == "loop":
            editing.wrap_in_loop(test, a.first, a.last, times=a.times)
        elif a.what == "if":
            name, op, value = (a.variable.split("=", 2) + ["", ""])[:3]
            editing.wrap_in_if(test, a.first, a.last, {"type": "variable", "name": name, "op": op, "value": value},
                               else_first_id=a.else_from)
        editing.save(test, directory)
    except ValueError as exc:
        print(f"Not changed: {exc}")
        return 2
    print("Saved.")
    return 0


def cmd_inputs(a) -> int:
    from core import inputs, testfile

    test, directory = testfile.load_test(a.test)
    plan = inputs.collect(test)
    print(f"Test '{test.get('name')}': {len(plan['clicks'])} click(s)/drag(s), {len(plan['inputs'])} typed input(s).")
    for c in plan["clicks"]:
        mark = "  !" if c["found_by"] == "position only" else "   "
        print(f"{mark} step {c['step']:>3}  found by {c['found_by']:<13} ({c['neighbours']} neighbours)  {c['label']}")
    if plan["weak"]:
        print(f"\n{len(plan['weak'])} step(s) can only be found by screen position: {plan['weak']}. Re-record them or add a name/picture.")
    for i in plan["inputs"]:
        print(f"   input step {i['step']:>3}: {i['label']}  [{'secret' if i['secret'] else repr(i['value'])}]")
    if a.ask:
        values = inputs.ask(plan)
        path = inputs.write(directory, test)
        doc = json.loads(path.read_text(encoding="utf-8"))
        doc["values"].update({str(k): v for k, v in values.items()})
        path.write_text(json.dumps(doc, indent=2, ensure_ascii=False), encoding="utf-8")
        print(f"Saved your values to {path}")
    elif a.write:
        print(f"Wrote {inputs.write(directory, test)} - edit it, playback uses it automatically.")
    return 0


def cmd_versions(a) -> int:
    from core import testfile

    if a.restore:
        testfile.restore_version(a.test, a.restore)
        print(f"Restored version {a.restore} of {a.test}.")
        return 0
    rows = testfile.list_versions(a.test)
    for r in rows:
        print(f"{r['id']}  {r['steps']} steps")
    if not rows:
        print("No earlier versions saved yet.")
    return 0


def cmd_steps(a) -> int:
    from core.steplib import catalog, custom
    if a.action == "palette":
        for cat, items in catalog.grouped().items():
            print(f"\n{cat}")
            for e in items:
                print(f"  {e['type']:<16} {e['label']}")
    elif a.action == "list":
        for d in custom.list_steps() or []:
            print(f"{d['name']:<24} {d['status']:<9} {d.get('description', '')}")
        if not custom.list_steps():
            print("No custom steps yet. Create one with: visionauto steps new NAME \"what it should do\"")
    elif a.action == "new":
        if not (a.name and a.text):
            raise ValueError("usage: steps new NAME \"what the step should do\"  [--code file.py to add your own code]")
        if a.code:
            meta = custom.save(a.name, Path(a.code).read_text(encoding="utf-8"), a.text, author="user")
        else:
            meta = custom.generate(a.text, a.name)
        print(f"Saved '{meta['name']}' as {meta['status']}. Review it ('steps show {a.name}'), then 'steps approve {a.name}'.")
    elif a.action == "show":
        print(custom.source_of(a.name))
    elif a.action == "approve":
        print(custom.approve(a.name)["status"])
    elif a.action == "delete":
        print("deleted" if custom.delete(a.name) else "not found")
    return 0


def cmd_fix(a) -> int:
    """Repair a recording made before open_app existed (or by hand): Start-menu launches become one reliable step."""
    from core import testfile
    from core.recorder.launch_detect import compact_test

    test, directory = testfile.load_test(a.test)
    changes = compact_test(test)
    if not changes:
        print("Nothing to fix: no Start-menu launch sequence found.")
        return 0
    for c in changes:
        print(f"  steps {c['replaced_steps']} -> open_app '{c['name']}' (typed '{c['query']}')")
    if a.dry:
        print("(dry: nothing written)")
        return 0
    bak = directory / "test.json.pre_fix.bak"
    if not bak.exists() and (directory / "test.json").exists():
        bak.write_bytes((directory / "test.json").read_bytes())
    testfile.save_test(testfile.renumber(test), directory)
    print(f"Saved. Original kept as {bak.name}")
    return 0


def cmd_inspect(a) -> int:
    from core import inspector

    if a.point:
        x, y = (int(v) for v in a.point.split(","))
        node = inspector.element_under(x, y)
        if node is None:
            print("No element found (Windows + pywinauto required).")
            return 1
        print(inspector.breadcrumb(node))
        for k, v in inspector.properties(node).items():
            print(f"  {k}: {v}")
        print("  XPath:", inspector.xpath_of(node))
        return 0
    root = inspector.snapshot(a.window or "")
    if root is None:
        print("Could not read the window tree (Windows + pywinauto required, window must be open).")
        return 1
    hits = inspector.find_nodes(root, a.find) if a.find else None
    if hits is not None and not hits:
        print(f"Nothing matches '{a.find}'.")
        return 1
    print(inspector.format_tree(root, a.depth, inspector.branch_ids(root, hits) if hits else None))
    if hits and a.xpath:
        print()
        for h in hits[:20]:
            print(f"{inspector.breadcrumb(h)}\n    {inspector.xpath_of(h, root)}")
    return 0


def cmd_ai(a) -> int:
    from core import settings
    from core.ai import ollama_manager as om

    o = settings.load()
    if a.action == "status":
        print(json.dumps(om.status(o["llm_base_url"], o["llm_model"]), indent=1))
        return 0
    if not a.yes and not om.status(o["llm_base_url"], o["llm_model"])["installed"]:
        print("Ollama is not installed. Setup will download the official installer (about 1 GB) and the model "
              f"'{o['llm_model']}' (about 1 GB). Re-run with --yes to allow it.")
        return 2
    om.ensure_ready(o["llm_model"], o["llm_base_url"], print, allow_install=a.yes)
    settings.save({**o, "use_llm": True})
    print("Local AI ready and enabled.")
    return 0


def cmd_dataset(a) -> int:
    from core import dataset

    if a.action == "stats":
        print(json.dumps(dataset.stats(), indent=1))
    else:
        print("Exported to", dataset.export(a.file or "visionauto_dataset.zip"))
    return 0


def main(argv=None) -> int:
    p = argparse.ArgumentParser(prog="visionauto", description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="cmd", required=True)
    r = sub.add_parser("run")
    r.add_argument("test")
    r.add_argument("--data")
    r.add_argument("--rows")
    r.add_argument("--dry-run", action="store_true")
    r.add_argument("--timeout", type=float, default=10.0)
    r.set_defaults(fn=cmd_run)
    s = sub.add_parser("suite")
    s.add_argument("suite")
    s.add_argument("--tag", action="append")
    s.add_argument("--exclude-tag", action="append")
    s.add_argument("--shard", help="INDEX/COUNT: run only this machine's share of the suite, e.g. 2/4")
    s.add_argument("--dry-run", action="store_true")
    s.add_argument("--timeout", type=float, default=10.0)
    s.set_defaults(fn=cmd_suite)
    pt = sub.add_parser("patterns", help="what the recording is really doing (forms, logins, repeated blocks); --apply N makes a loop")
    pt.add_argument("test")
    pt.add_argument("--apply", type=int, default=0)
    pt.set_defaults(fn=cmd_patterns)
    sc = sub.add_parser("schedule", help="run a test or suite every day / week at a time (Windows Task Scheduler / cron line)")
    g = sc.add_mutually_exclusive_group(required=True)
    g.add_argument("--test")
    g.add_argument("--suite")
    sc.add_argument("--at", default="09:00")
    sc.add_argument("--every", choices=["daily", "weekly", "once"], default="daily")
    sc.add_argument("--create", action="store_true")
    sc.set_defaults(fn=cmd_schedule)
    n = sub.add_parser("inputs", help="what a test types and how each click is found; --ask to choose the values")
    n.add_argument("test")
    n.add_argument("--ask", action="store_true", help="prompt for every typed value (Enter keeps the recorded one)")
    n.add_argument("--write", action="store_true", help="write inputs.json next to the test to edit by hand")
    n.set_defaults(fn=cmd_inputs)

    v = sub.add_parser("versions", help="list or restore earlier saved versions of a test")
    v.add_argument("test")
    v.add_argument("--restore", metavar="ID")
    v.set_defaults(fn=cmd_versions)

    f = sub.add_parser("fix")
    f.add_argument("test")
    f.add_argument("--dry", action="store_true")
    f.set_defaults(fn=cmd_fix)
    i = sub.add_parser("inspect")
    i.add_argument("--window", default="")
    i.add_argument("--find")
    i.add_argument("--xpath", action="store_true")
    i.add_argument("--point")
    i.add_argument("--depth", type=int, default=12)
    i.set_defaults(fn=cmd_inspect)
    ai = sub.add_parser("ai")
    ai.add_argument("action", choices=["status", "setup"])
    ai.add_argument("--yes", action="store_true")
    ai.set_defaults(fn=cmd_ai)
    ds = sub.add_parser("dataset")
    ds.add_argument("action", choices=["stats", "export"])
    ds.add_argument("file", nargs="?")
    ds.set_defaults(fn=cmd_dataset)
    e = sub.add_parser("edit")
    es = e.add_subparsers(dest="what", required=True)
    for name in ("show", "locator", "order", "data", "loop", "if", "zone", "drag", "modifiers", "limit", "recovery"):
        x = es.add_parser(name)
        x.add_argument("test")
        if name in ("show", "locator", "order", "zone", "drag", "modifiers", "limit"):
            x.add_argument("step", type=int)
        if name == "zone":
            x.add_argument("--rect", required=True)
            x.add_argument("--name", default="custom")
        if name == "drag":
            x.add_argument("--steps", type=int)
            x.add_argument("--hold-ms", type=int)
            x.add_argument("--hover-ms", type=int)
            x.add_argument("--drop-mode")
            x.add_argument("--modifiers")
        if name == "modifiers":
            x.add_argument("keys")
        if name == "limit":
            x.add_argument("--ms", type=int, required=True)
        if name == "recovery":
            x.add_argument("--window", required=True)
            x.add_argument("--action", required=True)
            x.add_argument("--value")
        if name == "locator":
            x.add_argument("kind")
            x.add_argument("value", nargs="?")
            for k in "xywh":
                x.add_argument(f"--{k}", type=int)
            x.add_argument("--dialect", default="uia")
            x.add_argument("--exact", action="store_true")
        if name == "order":
            x.add_argument("order")
        if name == "data":
            x.add_argument("--file", required=True)
            x.add_argument("--select")
            x.add_argument("--secret", action="append")
            x.add_argument("--on-row-failure", default="continue")
            x.add_argument("--restart-apps", action="store_true")
        if name in ("loop", "if"):
            x.add_argument("first", type=int)
            x.add_argument("last", type=int)
        if name == "loop":
            x.add_argument("--times", type=int, required=True)
        if name == "if":
            x.add_argument("--variable", required=True, help="name=op=value, e.g. role=equals=admin")
            x.add_argument("--else-from", type=int)
    e.set_defaults(fn=_edit)
    st = sub.add_parser("steps", help="step palette and custom (AI-written) steps")
    st.add_argument("action", choices=["palette", "list", "new", "show", "approve", "delete"])
    st.add_argument("name", nargs="?")
    st.add_argument("text", nargs="?", help="for 'new': describe what the step must do")
    st.add_argument("--code", help="for 'new': use your own .py file instead of asking the AI")
    st.set_defaults(fn=cmd_steps)
    a = p.parse_args(argv)
    try:
        return a.fn(a)
    except Exception as exc:                # clear message instead of a traceback for user mistakes
        print(f"Error: {type(exc).__name__}: {exc}")
        return 2


if __name__ == "__main__":
    sys.exit(main())
