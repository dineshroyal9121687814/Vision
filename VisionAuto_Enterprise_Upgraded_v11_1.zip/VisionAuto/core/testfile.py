"""
Test file format (schema "visionauto.test/2") and the library of saved tests.

    workspace/tests/<name>/
        test.json       the test (human readable, git-friendly)
        steps.jsonl     crash-safe journal written WHILE recording
        assets/         screenshots / template crops (paths in test.json are relative)

Why a journal: the first real run lost a whole recording because the process
was killed before the final save. Every step is appended to steps.jsonl the
moment it is finalised, and load_test() can rebuild test.json from it.
"""
from __future__ import annotations

import json
import logging
import os
import re
import shutil
from datetime import datetime
from pathlib import Path

from core import paths

log = logging.getLogger("visionauto.testfile")

SCHEMA = "visionauto.test/2"
SCHEMA_VERSION = 3          # 3 = multi-application tests (applications[], step.app, failure_policy)
SCHEMA_PREFIX = "visionauto.test/"


class TestFormatError(ValueError):
    """The file is not a VisionAuto test, or is from an unsupported future version."""

    __test__ = False   # not a pytest test class
POINTER_TYPES = ("click", "double_click", "right_click", "middle_click", "drag_drop", "scroll", "validate")


def safe_name(name: str) -> str:
    return re.sub(r"[^\w\-. ]+", "_", name or "").strip(" .") or "test"


def test_dir(name: str) -> Path:
    return paths.tests_dir() / safe_name(name)


def new_test(name: str, screen: dict | None = None) -> dict:
    return {
        "schema": SCHEMA,
        "name": safe_name(name),
        "title": name,
        "summary": "",
        "created_at": datetime.now().isoformat(timespec="seconds"),
        "screen": screen or {},
        "schema_version": SCHEMA_VERSION,
        "app": {},
        "applications": [],
        "variables": {},
        "steps": [],
    }


def _normalize_test(test: dict) -> dict:
    """Validate the envelope and migrate older tests IN MEMORY (the file on disk is untouched until saved)."""
    if not isinstance(test, dict):
        raise TestFormatError("A VisionAuto test must be a JSON object.")
    schema = test.get("schema")
    if schema is not None and not (isinstance(schema, str) and schema.startswith(SCHEMA_PREFIX)):
        raise TestFormatError(f"Unrecognised test schema {schema!r}.")
    if "steps" in test and not isinstance(test["steps"], list):
        raise TestFormatError("Test 'steps' must be a list.")
    version = test.get("schema_version", 2)
    if not isinstance(version, int) or isinstance(version, bool) or version > SCHEMA_VERSION:
        raise TestFormatError(f"Test schema_version {version!r} is not supported by this VisionAuto (max {SCHEMA_VERSION}).")
    if version < SCHEMA_VERSION:
        test["migrated_from"] = version
    test["schema_version"] = SCHEMA_VERSION
    if "applications" not in test:
        legacy_app = test.get("app") or {}
        if legacy_app.get("process") or legacy_app.get("title"):
            test["applications"] = [{
                "alias": "default",
                "id": "default",
                "name": legacy_app.get("title") or legacy_app.get("process") or "Default App",
                "type": "desktop",
                "process_name": legacy_app.get("process", ""),
                "window_title": legacy_app.get("title", ""),
                "mode": "attach_or_launch",
            }]
        else:
            test["applications"] = []
    if "variables" not in test or not isinstance(test["variables"], dict):
        test["variables"] = {}
    for entry in test.get("applications") or []:
        if isinstance(entry, dict):
            entry.setdefault("mode", "attach_or_launch")
    return test


def write_json_atomic(path: Path, data) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    try:
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, path)
    except Exception:
        if tmp.exists():
            try:
                tmp.unlink()
            except OSError:
                pass
        raise


def renumber(test: dict) -> dict:
    for i, s in enumerate(test.get("steps", []), 1):
        s["id"] = i
    return test


def save_test(test: dict, directory: Path | None = None) -> Path:
    directory = Path(directory) if directory else test_dir(test["name"])
    target = directory / "test.json"
    test = {k: v for k, v in test.items() if k != "migrated_from"}
    test["schema_version"] = SCHEMA_VERSION
    if target.exists():
        # First save over an older-format file: keep the original byte-for-byte.
        try:
            old = json.loads(target.read_text(encoding="utf-8"))
            old_version = old.get("schema_version", 2) if isinstance(old, dict) else None
        except ValueError:
            old_version = None
        legacy = directory / "test.pre-v3.json"
        if old_version is not None and old_version < SCHEMA_VERSION and not legacy.exists():
            shutil.copy2(target, legacy)
    _snapshot(target, test)
    write_json_atomic(target, test)
    return target


HISTORY_KEEP = 30


def _snapshot(target: Path, new: dict) -> None:
    """Object-repository history: before test.json is overwritten with DIFFERENT content, the old file is kept as
    ``history/test.<timestamp>.json`` (last ``HISTORY_KEEP`` versions). A heal, an edit or a re-record can always be undone."""
    try:
        if not target.is_file():
            return
        old_text = target.read_text(encoding="utf-8")
        if json.loads(old_text) == new:
            return
        hist = target.parent / "history"
        hist.mkdir(exist_ok=True)
        stamp = datetime.now().strftime("%Y%m%d-%H%M%S-%f")
        (hist / f"test.{stamp}.json").write_text(old_text, encoding="utf-8")
        for old in sorted(hist.glob("test.*.json"))[:-HISTORY_KEEP]:
            old.unlink(missing_ok=True)
    except Exception:
        log.debug("history snapshot failed", exc_info=True)


def list_versions(ref) -> list[dict]:
    """Saved earlier versions of a test, newest first: ``[{'id', 'saved_at', 'steps'}]``."""
    p = Path(str(ref))
    directory = p if p.is_dir() else (p.parent if p.is_file() else test_dir(str(ref)))
    out = []
    for f in sorted((directory / "history").glob("test.*.json"), reverse=True) if (directory / "history").is_dir() else []:
        try:
            data = json.loads(f.read_text(encoding="utf-8"))
            out.append({"id": f.stem[5:], "saved_at": f.stem[5:20], "steps": len(data.get("steps") or [])})
        except Exception:
            continue
    return out


def restore_version(ref, version_id: str) -> Path:
    """Put an earlier version back (the current one is kept in the history first)."""
    p = Path(str(ref))
    directory = p if p.is_dir() else (p.parent if p.is_file() else test_dir(str(ref)))
    f = directory / "history" / f"test.{version_id}.json"
    if not f.is_file():
        raise FileNotFoundError(f"No saved version '{version_id}' for {directory.name}")
    data = json.loads(f.read_text(encoding="utf-8"))
    if not isinstance(data, dict) or not isinstance(data.get("steps"), list):
        raise ValueError(f"Invalid saved version: {f}")
    return save_test(data, directory)


def recover_from_journal(directory: Path) -> dict:
    directory = Path(directory)
    base = {}
    tj = directory / "test.json"
    if tj.exists():
        try:
            base = json.loads(tj.read_text(encoding="utf-8"))
        except ValueError:
            base = {}
    test = base or new_test(directory.name)
    steps = []
    jl = directory / "steps.jsonl"
    if jl.exists():
        for line in jl.read_text(encoding="utf-8", errors="replace").splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                steps.append(json.loads(line))
            except ValueError:
                break  # torn last line after a crash
    if steps:
        test["steps"] = steps
        test["recovered"] = True
    return renumber(_normalize_test(test))


def load_test(ref) -> tuple[dict, Path]:
    """`ref` = test name, test directory, or path to test.json."""
    p = Path(str(ref))
    if p.is_file() and p.name == "test.json":
        directory = p.parent
    elif p.is_dir():
        directory = p
    else:
        directory = test_dir(str(ref))
    tj = directory / "test.json"
    test = None
    if tj.exists():
        try:
            test = json.loads(tj.read_text(encoding="utf-8"))
        except ValueError:
            test = None
        if test is not None and not isinstance(test, dict):
            raise TestFormatError(f"{tj} is not a VisionAuto test (top level must be a JSON object).")
    if test is None or (not test.get("steps") and (directory / "steps.jsonl").exists()):
        if not (directory / "steps.jsonl").exists() and test is None:
            raise FileNotFoundError(f"No test found for '{ref}' (looked in {directory})")
        test = recover_from_journal(directory)
    test = _normalize_test(test)
    return test, directory


def restore_backup(ref) -> Path:
    """Restore the most recent pre-heal test.json backup; leaves the backup intact."""
    p = Path(str(ref))
    if p.is_dir() or (p.is_file() and p.name in ("test.json", "test.json.bak")):
        directory = p if p.is_dir() else p.parent
    else:
        directory = test_dir(str(ref))
    backup = directory / "test.json.bak"
    if not backup.is_file():
        raise FileNotFoundError(f"No test backup exists at {backup}")
    data = json.loads(backup.read_text(encoding="utf-8"))
    if not isinstance(data, dict) or not isinstance(data.get("steps"), list):
        raise ValueError(f"Invalid VisionAuto test backup: {backup}")
    return save_test(data, directory)


def backup_test(ref) -> Path | None:
    """Atomically preserve the current test definition before an explicit edit."""
    p = Path(str(ref))
    if p.is_dir() or (p.is_file() and p.name == "test.json"):
        directory = p if p.is_dir() else p.parent
    else:
        directory = test_dir(str(ref))
    current = directory / "test.json"
    if not current.is_file():
        return None
    backup = directory / "test.json.bak"
    tmp = backup.with_suffix(backup.suffix + ".tmp")
    tmp.write_bytes(current.read_bytes())
    tmp.replace(backup)
    return backup


def asset(directory: Path, rel: str) -> Path:
    return Path(directory) / rel


def delete_test(name: str) -> None:
    shutil.rmtree(test_dir(name), ignore_errors=True)


def list_tests() -> list[dict]:
    """Recorded (native) tests."""
    out = []
    root = paths.tests_dir()
    if not root.exists():
        return out
    for d in sorted(root.iterdir()):
        if not d.is_dir():
            continue
        if not ((d / "test.json").exists() or (d / "steps.jsonl").exists()):
            continue
        try:
            t, _ = load_test(d)
        except Exception:
            continue
        out.append({
            "kind": "native", "name": d.name, "title": t.get("title", d.name),
            "steps": len(t.get("steps", [])), "created_at": t.get("created_at", ""),
            "dir": str(d), "recovered": bool(t.get("recovered")),
        })
    return out


def list_imported() -> list[dict]:
    """Imported Ranorex scripts (one entry per translated .py)."""
    out = []
    root = paths.imported_dir()
    if not root.exists():
        return out
    for proj in sorted(root.iterdir()):
        if not proj.is_dir():
            continue
        for script in sorted(proj.glob("*.py")):
            out.append({
                "kind": "ranorex", "name": f"{proj.name}/{script.stem}", "title": script.stem,
                "steps": 0, "created_at": "", "dir": str(proj), "script": str(script),
                "repo": str(proj / "repository.json"),
            })
        for script in sorted(proj.glob("*.vbs")):
            if ".action." in script.name:
                continue
            out.append({
                "kind": "uft", "name": f"{proj.name}/{script.stem}", "title": script.stem,
                "steps": 0, "created_at": "", "dir": str(proj), "script": str(script),
                "repo": str(proj / "repository.xml"),
            })
    return out


def list_runnable() -> list[dict]:
    return list_tests() + list_imported()


def list_runs(limit: int = 200) -> list[dict]:
    """Newest first. Each item = parsed run.json + its folder."""
    out = []
    root = paths.runs_dir()
    if not root.exists():
        return out
    for rj in root.glob("*/*/run.json"):
        try:
            data = json.loads(rj.read_text(encoding="utf-8"))
        except ValueError:
            continue
        data["_dir"] = str(rj.parent)
        out.append(data)
    out.sort(key=lambda r: r.get("started_at", ""), reverse=True)
    return out[:limit]
