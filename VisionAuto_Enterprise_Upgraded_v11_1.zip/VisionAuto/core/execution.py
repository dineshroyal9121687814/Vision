"""Run controller: one thread-safe state machine for Start / Pause / Resume / Stop / Cancel / Close.

States and legal transitions::

    IDLE --start--> RUNNING <--pause/resume--> PAUSED
    RUNNING | PAUSED --stop--> STOPPING --finish--> STOPPED
    RUNNING | PAUSED | STOPPING --cancel--> CANCELLING --finish--> CANCELLED
    RUNNING --finish--> FINISHED

* **Pause** takes effect at the next step boundary: the step that is running finishes first, because
  interrupting a click or a typed sequence half way would leave the application in an unknown state.
* **Resume** continues with the step that follows the last finished one (nothing is repeated or skipped).
* **Stop** ends the run safely after the current step; the partial report is kept (status ``aborted``).
* **Cancel** also ends the run but is final: the report is marked ``cancelled`` and any pending question to the
  user (retry prompt) is answered with "no".  Neither leaves a worker running: both only set a flag that the
  player polls, and ``wait_finished`` lets the owner join the worker before closing.
"""
from __future__ import annotations

import threading
import time

IDLE, RUNNING, PAUSED, STOPPING, CANCELLING = "idle", "running", "paused", "stopping", "cancelling"
STOPPED, CANCELLED, FINISHED = "stopped", "cancelled", "finished"
TERMINAL = {STOPPED, CANCELLED, FINISHED}


class RunController:
    def __init__(self) -> None:
        self._cv = threading.Condition()
        self._state = IDLE
        self._history: list[tuple[float, str]] = []

    # ------------------------------------------------------------------ queries
    @property
    def state(self) -> str:
        with self._cv:
            return self._state

    def history(self) -> list[tuple[float, str]]:
        with self._cv:
            return list(self._history)

    def is_active(self) -> bool:
        return self.state in (RUNNING, PAUSED, STOPPING, CANCELLING)

    def should_stop(self) -> bool:
        """True once Stop or Cancel was requested (the player polls this everywhere it can block)."""
        return self.state in (STOPPING, CANCELLING, STOPPED, CANCELLED)

    def is_cancelled(self) -> bool:
        return self.state in (CANCELLING, CANCELLED)

    # ------------------------------------------------------------------ transitions
    def _go(self, new: str, allowed: tuple[str, ...]) -> bool:
        with self._cv:
            if self._state not in allowed:
                return False
            self._state = new
            self._history.append((time.monotonic(), new))
            self._cv.notify_all()
            return True

    def start(self) -> bool:
        """Only legal from IDLE or a terminal state (a controller can be reused for a new run)."""
        return self._go(RUNNING, (IDLE, *TERMINAL))

    def pause(self) -> bool:
        return self._go(PAUSED, (RUNNING,))

    def resume(self) -> bool:
        return self._go(RUNNING, (PAUSED,))

    def stop(self) -> bool:
        return self._go(STOPPING, (RUNNING, PAUSED))

    def cancel(self) -> bool:
        return self._go(CANCELLING, (RUNNING, PAUSED, STOPPING))

    def finish(self) -> str:
        """Called by the worker when the run ended. Returns the terminal state."""
        with self._cv:
            final = {STOPPING: STOPPED, CANCELLING: CANCELLED}.get(self._state, FINISHED)
            if self._state in (IDLE, *TERMINAL):
                return self._state
            self._state = final
            self._history.append((time.monotonic(), final))
            self._cv.notify_all()
            return final

    # ------------------------------------------------------------------ worker side
    def wait_if_paused(self, poll_s: float = 0.1) -> bool:
        """Block while paused. Returns False if the run must end (stop/cancel arrived while paused)."""
        with self._cv:
            while self._state == PAUSED:
                self._cv.wait(timeout=poll_s)
            return self._state not in (STOPPING, CANCELLING, STOPPED, CANCELLED)

    def wait_finished(self, timeout: float | None = None) -> bool:
        """Block until the run reached a terminal state (used on application close)."""
        end = None if timeout is None else time.monotonic() + timeout
        with self._cv:
            while self._state in (RUNNING, PAUSED, STOPPING, CANCELLING):
                left = None if end is None else end - time.monotonic()
                if left is not None and left <= 0:
                    return False
                self._cv.wait(timeout=0.1 if left is None else min(0.1, left))
            return True
