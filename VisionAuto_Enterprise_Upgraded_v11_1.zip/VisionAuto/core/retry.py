"""Failure recovery policy: classify a failed step, diagnose it, ask the user (optionally) and retry safely.

Safety rules (they are what makes retrying correct and not just "try again"):

* A **permanent** failure (invalid step, redacted secret, undefined variable, bad parameter) is never retried.
* A failure that provably sent **no input** (target not found, window could not be activated) is always safe to retry.
* A failure that happened **after input was sent** (a validation failed, the step crashed half way) may repeat a
  side effect (a second click on "Pay").  It is retried only when the user approves *or* ``retry_allow_after_input``
  is on.  If the user does not answer in time the configured ``retry_timeout_action`` applies, but for these
  failures a timed-out question is never turned into a blind retry unless ``retry_allow_after_input`` is on.
* Attempts are bounded (``retry_max_attempts``) and every attempt is recorded in ``retry_history``.
"""
from __future__ import annotations

from dataclasses import dataclass

MODES = ("retry_step", "restart_test", "stop")
TIMEOUT_ACTIONS = ("retry", "skip", "stop")

_PERMANENT_MARKERS = (
    "redacted", "unknown type", "undefined variable", "requires a non-empty", "is restricted", "invalid",
    "not a whole number", "must be", "no such file", "path does not exist", "permission denied", "not allowed",
    "unsupported", "refused",
)
_NO_INPUT_MARKERS = ("not found", "could not activate", "no input was sent", "did not appear", "timed out waiting")


@dataclass(frozen=True)
class RetryPolicy:
    enabled: bool = True
    max_attempts: int = 2
    delay_s: float = 1.0
    ask_timeout_s: float = 30.0
    ask_before: bool = True
    auto: bool = False                 # retry without asking (used when ask_before is off)
    mode: str = "retry_step"           # retry_step | restart_test | stop
    timeout_action: str = "retry"      # what to do when the user does not answer: retry | skip | stop
    allow_after_input: bool = False
    stop_after_failures: int = 0       # 0 = never; N = stop the run after N steps failed for good in a row

    @classmethod
    def from_options(cls, opts: dict) -> "RetryPolicy":
        return cls(
            enabled=bool(opts.get("retry_enabled", True)),
            max_attempts=int(opts.get("retry_max_attempts", 2)),
            delay_s=float(opts.get("retry_delay_s", 1.0)),
            ask_timeout_s=float(opts.get("retry_timeout_s", 30.0)),
            ask_before=bool(opts.get("retry_ask_before", True)),
            auto=bool(opts.get("retry_auto", False)),
            mode=str(opts.get("retry_mode", "retry_step")),
            timeout_action=str(opts.get("retry_timeout_action", "retry")),
            allow_after_input=bool(opts.get("retry_allow_after_input", False)),
            stop_after_failures=int(opts.get("retry_stop_after_failures", 0)),
        )


def classify(res: dict) -> dict:
    """-> {"recoverable": bool, "input_sent": bool, "category": str, "reason": str}"""
    err = str(res.get("error") or "").casefold()
    if res.get("status") != "failed":
        return {"recoverable": False, "input_sent": False, "category": "none", "reason": "step did not fail"}
    if any(m in err for m in _PERMANENT_MARKERS) and not any(m in err for m in _NO_INPUT_MARKERS):
        return {"recoverable": False, "input_sent": False, "category": "permanent",
                "reason": "the step itself is invalid or blocked; retrying cannot change the outcome"}
    if res.get("retryable") or any(m in err for m in _NO_INPUT_MARKERS):
        return {"recoverable": True, "input_sent": False, "category": "not_found",
                "reason": "the target or window was not available yet; no input was sent"}
    if "validation failed" in err or "too slow" in err:
        return {"recoverable": True, "input_sent": True, "category": "validation",
                "reason": "the action ran but its check failed; the application may still be updating"}
    return {"recoverable": True, "input_sent": True, "category": "unexpected",
            "reason": "unexpected error after the action may have started"}


def corrective_action(diagnosis: dict | None, cls: dict) -> str:
    """The recovery action VisionAuto itself can perform before retrying (never a guess at app internals)."""
    text = " ".join(str((diagnosis or {}).get(k, "")) for k in ("summary", "likely_cause", "suggestion")).casefold()
    if "window" in text and ("active" in text or "mismatch" in text or "activate" in text):
        return "refocus_window"
    if cls["category"] in ("not_found", "validation"):
        return "wait_longer"
    return "retry_as_is"


def decide(policy: RetryPolicy, cls: dict, answer: str | None, asked: bool) -> tuple[str, str]:
    """-> (action, via). action: retry | skip (do not retry; step stays failed) | stop (end the run).
    ``answer`` is the user's reply (None = no reply)."""
    if answer in ("retry", "skip", "stop"):
        return answer, "user"
    if asked:                                           # question was shown but nobody answered in time
        fallback = policy.timeout_action
        if fallback == "retry" and cls["input_sent"] and not policy.allow_after_input:
            return "skip", "timeout-no-blind-retry"       # give up on retrying; the failure policy decides the rest
        return fallback, "timeout"
    if cls["input_sent"] and not policy.allow_after_input:
        return "skip", "auto-retry-unsafe"
    return "retry", "auto"


class NoLLM:
    """Offline stand-in so the rule-based diagnosis never probes a network port when AI/LLM is switched off."""

    def available(self) -> bool:
        return False

    def generate(self, prompt: str):
        return None


def make_engine(opts: dict):
    """The diagnosis engine for the configured provider (local Ollama only when ``use_llm`` is on)."""
    from core.ai.cognitive import CognitiveEngine

    if opts.get("use_llm"):
        from core.ai.llm import OllamaClient

        return CognitiveEngine(OllamaClient(opts["llm_model"], base_url=opts["llm_base_url"], timeout=6.0))
    return CognitiveEngine(NoLLM())
