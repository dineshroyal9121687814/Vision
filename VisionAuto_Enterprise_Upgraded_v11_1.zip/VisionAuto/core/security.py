"""Small, dependency-free security helpers used across the product.

* ``safe_join``      a path built from user input can never leave its base folder (``..``, absolute paths, drive switches)
* ``mask``           secrets in any text (password=..., api_key: ..., Bearer ..., URLs with user:pass@) become ``***``
* ``MaskingFilter``  logging filter that applies ``mask`` to every log line, so a secret that reaches a log call never reaches
                     the log file
* ``private_file``   writes a file only the current user can read (settings with endpoints, exported secrets lists)
* ``command_ok``     an executable launched on behalf of a test must be an existing file, not a shell string
"""
from __future__ import annotations

import logging
import os
import re
from pathlib import Path

_PATTERNS = [
    (re.compile(r"(?i)\b(bearer|basic)\s+[A-Za-z0-9._~+/=-]{8,}"), r"\1 ***"),
    (re.compile(r"(?i)\b(pass(?:word|wd)?|pwd|secret|token|api[_-]?key|authorization)\b(\s*[:=]\s*)(\"[^\"]*\"|'[^']*'|[^\s,;&]+)"),
     r"\1\2***"),
    (re.compile(r"(://[^/\s:@]+):([^@\s/]+)@"), r"\1:***@"),
    (re.compile(r"\bsk-[A-Za-z0-9_-]{16,}"), "sk-***"),
]


def mask(text) -> str:
    s = str(text)
    for rx, rep in _PATTERNS:
        s = rx.sub(rep, s)
    return s


class MaskingFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        try:
            record.msg = mask(record.getMessage())
            record.args = ()
        except Exception:
            pass
        return True


def safe_join(base, *parts) -> Path:
    """``base / parts`` that is guaranteed to stay inside ``base`` (raises ValueError otherwise)."""
    root = Path(base).resolve()
    target = root.joinpath(*[str(p) for p in parts]).resolve()
    try:
        target.relative_to(root)
    except ValueError:
        raise ValueError(f"Path escapes its folder: {Path(*[str(p) for p in parts])}") from None
    return target


def private_file(path, text: str) -> Path:
    p = Path(path)
    p.write_text(text, encoding="utf-8")
    try:
        os.chmod(p, 0o600)                      # POSIX; on Windows the file inherits the user-profile ACL
    except OSError:
        pass
    return p


def command_ok(exe: str) -> tuple[bool, str]:
    """A launch target must be one existing file (no shell metacharacters, no argument smuggling in the path)."""
    if not exe or any(c in exe for c in "&|;<>`\n\r"):
        return False, "The program path contains characters that are not allowed."
    p = Path(exe.strip('"'))
    if not p.is_file():
        return False, f"The program was not found: {p}"
    return True, ""
