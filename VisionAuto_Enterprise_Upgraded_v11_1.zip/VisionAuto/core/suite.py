"""Test suites: run several tests in order with setup/teardown, tags, per-test data and an aggregated report.

suite.json::

    {"schema": "visionauto.suite/1", "name": "Smoke",
     "stop_on_failure": false,
     "setup":    ["OpenApp"],
     "teardown": ["CloseApp"],
     "tests": [
        {"test": "Login",  "data": "data/users.csv", "select": "1-5", "tags": ["smoke", "login"]},
        {"test": "Search", "tags": ["smoke"]},
        {"test": "Export", "enabled": false}
     ]}

A test is a workspace test name, or a path (relative to the suite file) to a test folder / test.json.
Setup failing skips the tests but teardown still runs. Result: ``suite_result.json`` + ``suite_junit.xml``.
"""
from __future__ import annotations

import json
import time
from datetime import datetime
from pathlib import Path
from xml.sax.saxutils import quoteattr

from core import paths, testfile

SCHEMA = "visionauto.suite/1"
MAX_TESTS = 500


class SuiteError(ValueError):
    pass


def load_suite(path: str | Path) -> dict:
    path = Path(path)
    try:
        suite = json.loads(path.read_text(encoding="utf-8-sig"))
    except (OSError, ValueError) as exc:
        raise SuiteError(f"Cannot read suite {path}: {exc}") from exc
    if not isinstance(suite, dict) or not isinstance(suite.get("tests"), list) or not suite["tests"]:
        raise SuiteError("A suite needs a non-empty 'tests' list.")
    if len(suite["tests"]) > MAX_TESTS:
        raise SuiteError(f"A suite can hold at most {MAX_TESTS} tests.")
    for i, entry in enumerate(suite["tests"], 1):
        if isinstance(entry, str):
            suite["tests"][i - 1] = entry = {"test": entry}
        if not isinstance(entry, dict) or not entry.get("test"):
            raise SuiteError(f"Suite entry {i} needs a 'test'.")
        if entry.get("tags") is not None and not (isinstance(entry["tags"], list) and all(isinstance(t, str) for t in entry["tags"])):
            raise SuiteError(f"Suite entry {i}: 'tags' must be a list of strings.")
    for key in ("setup", "teardown"):
        if suite.get(key) is not None and not (isinstance(suite[key], list) and all(isinstance(t, str) for t in suite[key])):
            raise SuiteError(f"'{key}' must be a list of test names.")
    suite.setdefault("name", path.stem)
    return suite


def _ref(base: Path, name: str):
    cand = (base / name)
    if cand.is_dir() and (cand / "test.json").exists():
        return cand
    if cand.is_file() and cand.name == "test.json":
        return cand.parent
    return name


def select_tests(suite: dict, include=None, exclude=None) -> list[dict]:
    inc, exc = {t.casefold() for t in include or ()}, {t.casefold() for t in exclude or ()}
    out = []
    for e in suite["tests"]:
        if e.get("enabled", True) is False:
            continue
        tags = {t.casefold() for t in e.get("tags") or ()}
        if inc and not (tags & inc):
            continue
        if exc and (tags & exc):
            continue
        out.append(e)
    return out


def parse_shard(text) -> tuple[int, int] | None:
    """'2/4' -> (2, 4): this machine runs the 2nd of 4 equal parts. One desktop can only run one GUI test at a time, so
    parallel runs mean several machines / agents / VMs, each given a different shard by the CI job."""
    if not text:
        return None
    try:
        i, n = (int(x) for x in str(text).split("/"))
    except ValueError:
        raise SuiteError(f"Bad shard {text!r}; use INDEX/COUNT, for example 2/4.")
    if not (1 <= i <= n):
        raise SuiteError(f"Bad shard {text!r}; INDEX must be between 1 and COUNT.")
    return i, n


def select_shard(tests: list[dict], shard) -> list[dict]:
    """Every n-th test starting at i (round-robin keeps the shards the same size and the split stable between runs)."""
    sh = parse_shard(shard) if not isinstance(shard, tuple) else shard
    if not sh:
        return tests
    i, n = sh
    return [t for k, t in enumerate(tests) if k % n == i - 1]


def run_suite(path: str | Path, include=None, exclude=None, dry_run: bool = False, options: dict | None = None,
              on_test=None, should_stop=None, backend=None, grab=None, shard=None) -> dict:
    from core.playback.player import Player

    path = Path(path).resolve()
    suite = load_suite(path)
    base = path.parent
    chosen = select_shard(select_tests(suite, include, exclude), shard)
    if not chosen:
        raise SuiteError("No tests match the suite's enabled flags and tag filters.")
    started = datetime.now()
    t0 = time.monotonic()
    out_dir = paths.runs_dir() / "_suites" / testfile.safe_name(suite["name"]) / started.strftime("%Y%m%d-%H%M%S")
    out_dir.mkdir(parents=True, exist_ok=True)
    stop = should_stop or (lambda: False)
    rows: list[dict] = []

    def run_one(name: str, role: str, data=None, select=None, entry_dry=None) -> dict:
        t1 = time.monotonic()
        row = {"test": name, "role": role, "tags": []}
        try:
            player = Player(_ref(base, name), options, backend, None, stop, dry_run if entry_dry is None else entry_dry,
                            grab, data=(base / data) if data else None, data_select=select)
            run = player.run()
            row.update(status=run["status"], run_dir=run.get("_dir"), summary=run.get("summary"),
                       iterations=run.get("data"), error=run.get("error", ""))
        except Exception as exc:         # a broken test must not take the whole suite down
            row.update(status="error", error=f"{type(exc).__name__}: {exc}")
        row["duration_ms"] = int((time.monotonic() - t1) * 1000)
        rows.append(row)
        if on_test:
            on_test(row)
        return row

    ok_status = ("passed", "inconclusive")
    setup_failed = False
    for name in suite.get("setup") or []:
        if stop():
            break
        if run_one(name, "setup")["status"] not in ok_status:
            setup_failed = True
            break
    aborted = False
    if not setup_failed:
        for entry in chosen:
            if stop():
                aborted = True
                break
            row = run_one(entry["test"], "test", entry.get("data"), entry.get("select"), entry.get("dry_run"))
            row["tags"] = entry.get("tags") or []
            if row["status"] == "aborted":
                aborted = True
                break
            if row["status"] not in ok_status and suite.get("stop_on_failure"):
                break
    else:
        for entry in chosen:
            rows.append({"test": entry["test"], "role": "test", "status": "skipped", "tags": entry.get("tags") or [],
                         "error": "setup failed", "duration_ms": 0})
    for name in suite.get("teardown") or []:          # teardown always runs
        run_one(name, "teardown")

    tests = [r for r in rows if r["role"] == "test"]
    count = lambda st: sum(1 for r in tests if r["status"] == st)  # noqa: E731
    bad = [r for r in rows if r["status"] not in ok_status + ("skipped",)]
    status = "aborted" if aborted else "failed" if bad else ("inconclusive" if tests and all(r["status"] == "inconclusive" for r in tests) else "passed")
    result = {"schema": "visionauto.suite-result/1", "suite": suite["name"], "status": status, "dry_run": dry_run,
              "started_at": started.isoformat(timespec="seconds"), "duration_ms": int((time.monotonic() - t0) * 1000),
              "totals": {"tests": len(tests), "passed": count("passed"), "inconclusive": count("inconclusive"),
                         "failed": count("failed") + count("error") + count("invalid"), "skipped": count("skipped"),
                         "aborted": count("aborted")},
              "results": rows}
    testfile.write_json_atomic(out_dir / "suite_result.json", result)
    (out_dir / "suite_junit.xml").write_text(_junit(result), encoding="utf-8")
    result["_dir"] = str(out_dir)
    return result


def _junit(result: dict) -> str:
    rows = result["results"]
    fails = sum(1 for r in rows if r["status"] in ("failed", "error", "invalid", "aborted"))
    skips = sum(1 for r in rows if r["status"] == "skipped")
    out = ['<?xml version="1.0" encoding="UTF-8"?>',
           f'<testsuite name={quoteattr(result["suite"])} tests="{len(rows)}" failures="{fails}" skipped="{skips}" '
           f'time="{result["duration_ms"] / 1000:.3f}">']
    for r in rows:
        out.append(f'  <testcase classname={quoteattr(result["suite"])} name={quoteattr(r["test"])} time="{r.get("duration_ms", 0) / 1000:.3f}">')
        if r["status"] in ("failed", "error", "invalid", "aborted"):
            out.append(f'    <failure message={quoteattr(str(r.get("error") or r["status"])[:500])}/>')
        elif r["status"] == "skipped":
            out.append("    <skipped/>")
        out.append("  </testcase>")
    out.append("</testsuite>")
    return "\n".join(out) + "\n"
