"""Dashboard numbers. Everything is computed from the runs and tests on disk - no sample data, no estimates.

``snapshot()`` returns plain dicts so the GUI, the CLI and the tests use the same source of truth."""
from __future__ import annotations

import json
from collections import Counter, defaultdict
from datetime import datetime, timedelta
from pathlib import Path

from core import retry, testfile
from core.reports import manage

STATUSES = ("passed", "failed", "skipped")


def _day(iso: str) -> str:
    return (iso or "")[:10]


def snapshot(runs: list[dict] | None = None, tests: list[dict] | None = None, days: int = 14, now: datetime | None = None,
             insight_runs: int = 25) -> dict:
    rows = manage.list_reports() if runs is None else runs
    tests = testfile.list_runnable() if tests is None else tests
    real = [r for r in rows if not r.get("dry_run") and r.get("status") != "unreadable"]
    now = now or datetime.now()

    latest: dict[str, dict] = {}                                   # newest real run per test (rows are newest first)
    for r in real:
        latest.setdefault(r.get("test_name") or r.get("test"), r)
    names = {t["name"] for t in tests}
    by_status = Counter(latest[n]["status"] if n in latest else "never_run" for n in names)

    decided = [r for r in real[:50] if r.get("status") in ("passed", "failed")]
    rate = round(100 * sum(1 for r in decided if r["status"] == "passed") / len(decided), 1) if decided else None

    trend = []
    for i in range(days - 1, -1, -1):
        d = (now - timedelta(days=i)).strftime("%Y-%m-%d")
        todays = [r for r in real if _day(r.get("started_at", "")) == d]
        trend.append({"date": d, "passed": sum(1 for r in todays if r["status"] == "passed"),
                      "failed": sum(1 for r in todays if r["status"] == "failed"), "total": len(todays)})

    return {
        "tests": len(names),
        "executions": len(real),
        "passed": by_status.get("passed", 0), "failed": by_status.get("failed", 0),
        "skipped": by_status.get("skipped", 0) + by_status.get("aborted", 0) + by_status.get("cancelled", 0),
        "never_run": by_status.get("never_run", 0),
        "success_rate": rate,
        "healed": sum(r.get("healed", 0) for r in real),
        "retries": sum(r.get("retries", 0) for r in real),
        "avg_duration_ms": int(sum(r.get("duration_ms", 0) for r in real) / len(real)) if real else 0,
        "trend": trend,
        "recent_runs": rows[:10],
        "app_health": app_health(real),
        "failed_insights": failed_insights([r for r in real if r.get("status") == "failed"][:insight_runs]),
    }


def app_health(real_rows: list[dict], limit: int = 50) -> list[dict]:
    """Pass rate per application. The application of a run is read from its run.json (``applications`` telemetry)."""
    seen: dict[str, list[str]] = defaultdict(list)
    for r in real_rows[:limit]:
        try:
            data = json.loads((Path(r["dir"]) / "run.json").read_text(encoding="utf-8"))
        except (OSError, ValueError, KeyError):
            continue
        apps = data.get("applications") or {}
        for name in (apps.keys() if isinstance(apps, dict) else [a.get("alias") or a.get("name") for a in apps if isinstance(a, dict)]):
            if name:
                seen[str(name)].append(r.get("status", ""))
    out = [{"app": a, "runs": len(s), "pass_rate": round(100 * s.count("passed") / len(s), 1),
            "last": s[0]} for a, s in seen.items()]
    out.sort(key=lambda x: (x["pass_rate"], -x["runs"]))
    return out


def failed_insights(failed_rows: list[dict], top: int = 8) -> list[dict]:
    """The steps that fail most often across the given failed runs, with the category retry.classify gives them."""
    groups: dict[tuple, dict] = {}
    for r in failed_rows:
        try:
            data = json.loads((Path(r["dir"]) / "run.json").read_text(encoding="utf-8"))
        except (OSError, ValueError, KeyError):
            continue
        for st in data.get("steps") or []:
            if st.get("status") != "failed":
                continue
            key = (r.get("test_name"), st.get("id"), st.get("description"))
            g = groups.setdefault(key, {"test": r.get("test_name"), "step": st.get("id"), "description": st.get("description", ""),
                                        "count": 0, "last_error": "", "category": "", "run": r.get("dir")})
            g["count"] += 1
            if not g["last_error"]:
                g["last_error"] = str(st.get("error") or "")[:240]
                g["category"] = retry.classify(st)["category"]
    return sorted(groups.values(), key=lambda g: -g["count"])[:top]
