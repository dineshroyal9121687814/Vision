"""
Ranorex / UFT process killer.

Stuck Ranorex Studio, Ranorex Spy, Ranorex Agent, UFT One and their automation
agents often keep UI Automation hooks, licences or browser add-ins locked, which
blocks a migration run or a VisionAuto replay. This tool finds those processes
and stops them.

Safety rules (deliberate, tested):
  * Only processes whose executable name is in the known vendor list (or an
    explicit --extra-name the caller typed) are ever touched. Matching is on the
    exact process name, never on a substring of the command line or window title.
  * The default is a DRY RUN that only lists. Nothing is stopped without --kill.
  * VisionAuto's own process, its parent and its children are never touched.
  * Graceful terminate first, hard kill only for processes that survive the grace
    period. Every outcome is reported per process.

    python -m core.tools.process_killer                       # list only
    python -m core.tools.process_killer --kill                # stop Ranorex + UFT
    python -m core.tools.process_killer --product ranorex --kill
    python -m core.tools.process_killer --kill --yes          # no confirmation prompt
"""
from __future__ import annotations

import argparse
import json
import logging
import os
import sys
import time
from dataclasses import asdict, dataclass

log = logging.getLogger("visionauto.process_killer")

# Exact executable names (lower-case). Ranorex names also match the documented
# "Ranorex*" family prefix because every Ranorex product binary carries it.
# These lists describe the products' documented binaries; confirm against your
# own installation with the default list-only mode before using --kill.
RANOREX_NAMES = frozenset({
    "ranorex studio.exe", "ranorexstudio.exe", "ranorexspy.exe", "ranorexrecorder.exe",
    "ranorex.agent.exe", "ranorexagent.exe", "ranorexpad.exe", "ranorex.studio.exe",
})
RANOREX_PREFIX = "ranorex"
UFT_NAMES = frozenset({
    "uft.exe", "qtpro.exe", "qtpautomationagent.exe", "uftremoteagent.exe",
    "qtpagent.exe", "uftbrowseragent.exe",
})
PRODUCTS = {"ranorex": "Ranorex", "uft": "UFT"}


@dataclass
class Found:
    pid: int
    name: str
    product: str
    exe: str = ""
    started: float = 0.0


def _protected_pids() -> set[int]:
    """This process, its ancestors and its descendants must never be killed."""
    protected = {os.getpid()}
    try:
        import psutil

        me = psutil.Process(os.getpid())
        protected.update(p.pid for p in me.parents())
        protected.update(c.pid for c in me.children(recursive=True))
    except Exception:  # psutil missing / access denied: own pid is still protected
        pass
    return protected


def classify(name: str, extra_names: frozenset[str] = frozenset()) -> str | None:
    """Return 'ranorex' / 'uft' / 'custom' for a process name, or None if it is not ours to touch."""
    n = (name or "").strip().lower()
    if not n:
        return None
    if n in RANOREX_NAMES or n.startswith(RANOREX_PREFIX):
        return "ranorex"
    if n in UFT_NAMES:
        return "uft"
    if n in extra_names:
        return "custom"
    return None


def find_processes(products=("ranorex", "uft"), extra_names=(), process_iter=None) -> list[Found]:
    """List matching processes. `process_iter` is injectable so tests never touch real processes."""
    if process_iter is None:
        import psutil

        process_iter = psutil.process_iter
    extra = frozenset(str(n).strip().lower() for n in extra_names if str(n).strip())
    wanted = set(products) | ({"custom"} if extra else set())
    protected = _protected_pids()
    found: list[Found] = []
    for proc in process_iter(["pid", "name", "exe", "create_time"]):
        info = getattr(proc, "info", None) or {}
        pid = info.get("pid", getattr(proc, "pid", None))
        kind = classify(info.get("name") or "", extra)
        if kind is None or kind not in wanted or pid is None or pid in protected:
            continue
        found.append(Found(int(pid), info.get("name") or "", kind, info.get("exe") or "", info.get("create_time") or 0.0))
    return sorted(found, key=lambda f: (f.product, f.name.lower(), f.pid))


def kill_processes(found: list[Found], grace_s: float = 3.0, process_factory=None) -> list[dict]:
    """Terminate, wait, then kill survivors. Returns one result dict per process."""
    if process_factory is None:
        import psutil

        process_factory = psutil.Process
        gone_exc: tuple = (psutil.NoSuchProcess,)
        denied_exc: tuple = (psutil.AccessDenied,)
    else:
        gone_exc, denied_exc = (ProcessLookupError,), (PermissionError,)
    protected = _protected_pids()
    results: list[dict] = []
    procs = []
    for f in found:
        if f.pid in protected:
            results.append({**asdict(f), "result": "skipped", "detail": "protected (VisionAuto itself)"})
            continue
        try:
            p = process_factory(f.pid)
            p.terminate()
            procs.append((f, p))
        except gone_exc:
            results.append({**asdict(f), "result": "already_gone"})
        except denied_exc as e:
            results.append({**asdict(f), "result": "denied", "detail": str(e) or "access denied (try an elevated shell)"})
        except Exception as e:  # noqa: BLE001 - report, never crash the whole sweep
            results.append({**asdict(f), "result": "error", "detail": f"{type(e).__name__}: {e}"})
    deadline = time.monotonic() + max(grace_s, 0.0)
    pending = list(procs)
    while pending and time.monotonic() < deadline:
        pending = [(f, p) for f, p in pending if _alive(p)]
        if pending:
            time.sleep(0.1)
    for f, p in procs:
        if not _alive(p):
            results.append({**asdict(f), "result": "terminated"})
            continue
        try:
            p.kill()
            results.append({**asdict(f), "result": "killed"})
        except gone_exc:
            results.append({**asdict(f), "result": "terminated"})
        except denied_exc as e:
            results.append({**asdict(f), "result": "denied", "detail": str(e) or "access denied"})
        except Exception as e:  # noqa: BLE001
            results.append({**asdict(f), "result": "error", "detail": f"{type(e).__name__}: {e}"})
    return sorted(results, key=lambda r: r["pid"])


def _alive(p) -> bool:
    try:
        return bool(p.is_running())
    except Exception:
        return False


def _selected_products(arg: str) -> tuple[str, ...]:
    return ("ranorex", "uft") if arg == "all" else (arg,)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="List or stop stuck Ranorex / UFT processes.")
    ap.add_argument("--product", choices=("all", "ranorex", "uft"), default="all")
    ap.add_argument("--extra-name", action="append", default=[], help="additional exact process name to include")
    ap.add_argument("--kill", action="store_true", help="actually stop the processes (default: list only)")
    ap.add_argument("--yes", action="store_true", help="skip the confirmation prompt")
    ap.add_argument("--grace", type=float, default=3.0, help="seconds to wait after terminate before force kill")
    ap.add_argument("--json", action="store_true", help="machine-readable output")
    args = ap.parse_args(argv)

    try:
        found = find_processes(_selected_products(args.product), args.extra_name)
    except ImportError:
        print("psutil is required: pip install psutil", file=sys.stderr)
        return 2
    if args.json and not args.kill:
        print(json.dumps([asdict(f) for f in found], indent=2))
        return 0
    if not found:
        print("No Ranorex or UFT processes found.")
        return 0
    for f in found:
        print(f"  {PRODUCTS.get(f.product, f.product):8} pid {f.pid:<7} {f.name}  {f.exe}")
    if not args.kill:
        print(f"{len(found)} process(es) found. Re-run with --kill to stop them.")
        return 0
    if not args.yes:
        try:
            answer = input(f"Stop {len(found)} process(es)? Unsaved work in them will be lost. [y/N] ")
        except EOFError:
            answer = ""
        if answer.strip().lower() not in ("y", "yes"):
            print("Cancelled; nothing was stopped.")
            return 1
    results = kill_processes(found, grace_s=args.grace)
    if args.json:
        print(json.dumps(results, indent=2))
    else:
        for r in results:
            print(f"  pid {r['pid']:<7} {r['name']:<28} {r['result']}" + (f"  ({r['detail']})" if r.get("detail") else ""))
    bad = [r for r in results if r["result"] in ("denied", "error")]
    return 3 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
