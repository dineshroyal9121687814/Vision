"""Bulk write into an Excel workbook that is OPEN in Excel (Windows, COM) - one assignment instead of one per cell.

Why: typing or setting cells one by one makes Excel recalculate and repaint after every cell.  This writes a whole
block through ``Range.Value2`` in a single COM call, with screen updating, events and automatic recalculation
switched off while it runs and **always restored afterwards** (even on error).

Needs ``pywin32`` on Windows.  This module is unit-tested with a fake COM object model; it has NOT been run against a
real Excel in the development environment (no Windows) - see the manual checklist in docs/IMPLEMENTATION_REPORT.md.
"""
from __future__ import annotations

import re
import sys

from core.excel_io import MAX_XLSX_COLS, MAX_XLSX_ROWS, TableError, clean_value

_CELL = re.compile(r"^([A-Za-z]{1,3})(\d{1,7})$")


def _excel_app():
    if sys.platform != "win32":
        raise TableError("Writing into an open Excel needs Windows.")
    try:
        import win32com.client                       # type: ignore[import-not-found]
    except ImportError as exc:
        raise TableError("Writing into an open Excel needs pywin32 (pip install pywin32).") from exc
    try:
        return win32com.client.GetActiveObject("Excel.Application")
    except Exception as exc:                          # noqa: BLE001 - pywintypes.com_error
        raise TableError("Excel is not running. Open the workbook in Excel first.") from exc


def _col_index(letters: str) -> int:
    n = 0
    for ch in letters.upper():
        n = n * 26 + ord(ch) - 64
    return n


def write_block(rows: list[list], sheet: str | None = None, start: str = "A1", workbook: str | None = None,
                app=None, formulas: str = "text") -> dict:
    """Write ``rows`` starting at ``start`` in the open workbook. ``app`` can be injected (tests)."""
    m = _CELL.match(start.strip())
    if not m:
        raise TableError(f"Invalid start cell '{start}'. Use a cell like A1 or C5.")
    if not rows or any(not isinstance(r, (list, tuple)) for r in rows):
        raise TableError("rows must be a non-empty list of lists.")
    r0, c0 = int(m.group(2)), _col_index(m.group(1))
    width = max(len(r) for r in rows)
    if r0 + len(rows) - 1 > MAX_XLSX_ROWS or c0 + width - 1 > MAX_XLSX_COLS:
        raise TableError("The data does not fit in an Excel sheet.")
    sanitized = 0
    grid = []
    for r in rows:
        line = []
        for c in list(r) + [None] * (width - len(r)):
            v, bad, as_text = clean_value(c, formulas)
            sanitized += bad
            line.append(("'" + v) if as_text else v)       # leading apostrophe = text, not a formula
        grid.append(tuple(line))
    app = app or _excel_app()
    try:
        wb = app.Workbooks(workbook) if workbook else app.ActiveWorkbook
        ws = wb.Worksheets(sheet) if sheet else wb.ActiveSheet
    except Exception as exc:                              # noqa: BLE001
        raise TableError(f"Could not find the workbook/sheet in Excel: {exc}") from exc
    saved = {}
    try:
        for prop, value in (("ScreenUpdating", False), ("EnableEvents", False), ("Calculation", -4135)):   # -4135 = manual
            try:
                saved[prop] = getattr(app, prop)
                setattr(app, prop, value)
            except Exception:                             # noqa: BLE001 - a setting Excel refuses must not block the write
                saved.pop(prop, None)
        target = ws.Range(ws.Cells(r0, c0), ws.Cells(r0 + len(grid) - 1, c0 + width - 1))
        target.Value2 = tuple(grid)
    finally:
        for prop, value in saved.items():                 # ALWAYS restore the user's Excel settings
            try:
                setattr(app, prop, value)
            except Exception:                             # noqa: BLE001
                pass
    return {"rows": len(grid), "cells": len(grid) * width, "sanitized": sanitized}
