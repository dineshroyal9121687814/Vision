"""
Training-data store: every recording and every run leaves a compact, privacy-reduced record that can later be used to
train / evaluate automation models (locator choice, recording -> semantic steps, failure diagnosis, validation hints).

Files under ``workspace/dataset/`` (JSON Lines, append-only, local only - VisionAuto never uploads them):

    recordings.jsonl   one line per recording: steps + what the compaction merged (raw -> semantic labels)
    steps.jsonl        one line per executed step: target features, which locator tier found it, confidence, healed?,
                       result, error, duration, validation outcomes, AI diagnosis
    runs.jsonl         one line per run: status, counts, environment
    images/            (only if ``dataset_include_images``) 300px crops of healed / failed targets

Privacy defaults: typed text is NOT stored (only its length) unless ``dataset_include_text``; redacted / secret values
and data-row values are never stored; no screenshots unless opted in; a size cap (``dataset_max_mb``) stops writing.
Disable everything with ``collect_training_data = false``. Writing never raises into a run.
"""
from __future__ import annotations

import hashlib
import json
import logging
import shutil
import threading
import zipfile
from datetime import datetime
from pathlib import Path

from core import paths, settings

log = logging.getLogger("visionauto.dataset")
SCHEMA = "visionauto.dataset/1"
_lock = threading.Lock()
TARGET_KEYS = ("name", "role", "automation_id", "class_name", "path", "inspect_xpath", "xpath", "rect", "rel", "text")


def root() -> Path:
    return paths.workspace() / "dataset"


def _opts() -> dict:
    try:
        return settings.load()
    except Exception:
        return dict(settings.DEFAULTS)


def _size_mb() -> float:
    d = root()
    return sum(f.stat().st_size for f in d.rglob("*") if f.is_file()) / (1 << 20) if d.exists() else 0.0


def _append(name: str, rows: list[dict], opts: dict) -> int:
    if not rows:
        return 0
    if _size_mb() >= opts.get("dataset_max_mb", 500):
        log.info("dataset is at its size cap; not writing")
        return 0
    root().mkdir(parents=True, exist_ok=True)
    with _lock, open(root() / name, "a", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps({"schema": SCHEMA, **r}, ensure_ascii=False) + "\n")
    return len(rows)


def _target(t: dict | None) -> dict:
    return {k: t[k] for k in TARGET_KEYS if t and t.get(k) not in (None, "", [])}


def _params(step: dict, include_text: bool) -> dict:
    p = step.get("params") or {}
    out = {k: v for k, v in p.items() if k not in ("text", "redacted") and isinstance(v, (int, float, bool))}
    if "text" in p:
        text = str(p["text"])
        out["text_len"] = len(text)
        if include_text and not p.get("redacted") and "${" not in text:
            out["text"] = text
        elif "${" in text:
            out["text_template"] = text                    # a variable reference, never the row's real value
    for k in ("name", "window_title", "query", "key", "keys", "button"):
        if isinstance(p.get(k), str):                       # app names / keys / templates like ${app}; never row values
            out[k] = p[k]
    return out


def _copy_image(test_dir: Path, rel: str | None, opts: dict) -> str | None:
    if not (opts.get("dataset_include_images") and rel and test_dir):
        return None
    src = Path(test_dir) / rel
    if not src.exists():
        return None
    h = hashlib.sha1(src.read_bytes()).hexdigest()[:16]
    dst = root() / "images" / f"{h}{src.suffix}"
    if not dst.exists():
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(src, dst)
    return f"images/{dst.name}"


def record_recording(test: dict, changes: list[dict] | None = None, test_dir=None) -> int:
    """After Stop: the semantic steps plus what was merged (raw Start-menu clicks -> open_app, ...)."""
    try:
        opts = _opts()
        if not opts.get("collect_training_data", True):
            return 0
        steps = []
        for s in test.get("steps", []):
            tg = s.get("target") or {}
            steps.append({"id": s.get("id"), "type": s.get("type"), "description": s.get("description", ""),
                          "window": {k: (s.get("window") or {}).get(k, "") for k in ("title", "process")},
                          "params": _params(s, bool(opts.get("dataset_include_text"))), "target": _target(tg),
                          "image": _copy_image(test_dir, ((tg.get("templates") or {}).get("crop300") or {}).get("path"), opts)})
        row = {"kind": "recording", "test": test.get("name"), "at": datetime.now().isoformat(timespec="seconds"),
               "screen": test.get("screen"), "steps": steps,
               "compaction": [{k: c.get(k) for k in ("replaced_steps", "name", "reason")} for c in (changes or [])]}
        return _append("recordings.jsonl", [row], opts)
    except Exception:
        log.exception("dataset: recording not stored")
        return 0


def record_run(run: dict, test: dict, test_dir=None) -> int:
    """After a run (``run`` is already secret-redacted). One line per step + one summary line."""
    try:
        opts = _opts()
        if not opts.get("collect_training_data", True) or run.get("dry_run"):
            return 0
        include_text = bool(opts.get("dataset_include_text"))
        by_id = {s.get("id"): s for s in test.get("steps", [])}
        rows = []
        for r in run.get("steps", []):
            src = by_id.get(r.get("id")) or {}
            tg = src.get("target") or {}
            rows.append({
                "kind": "step", "test": run.get("test"), "run_id": run.get("run_id"), "iteration": r.get("iteration"),
                "id": r.get("id"), "type": r.get("type"), "description": src.get("description", r.get("description", "")),
                "window": {k: (src.get("window") or {}).get(k, "") for k in ("title", "process")},
                "params": _params(src, include_text), "target": _target(tg),
                "status": r.get("status"), "method": r.get("method"), "confidence": r.get("locator_confidence"),
                "healed": bool(r.get("healed") or str(r.get("method", "")).startswith(("orb", "ocr", "ai", "heal"))),
                "duration_ms": r.get("duration_ms"), "error": r.get("error"), "ai_diagnosis": r.get("ai_diagnosis"),
                "validations": [{"type": v.get("type"), "status": v.get("status")} for v in r.get("validations", [])],
                "image": _copy_image(test_dir, ((tg.get("templates") or {}).get("crop300") or {}).get("path"), opts)
                if r.get("status") == "failed" or str(r.get("method", "")).startswith(("orb", "ocr", "ai", "heal")) else None,
            })
        n = _append("steps.jsonl", rows, opts)
        _append("runs.jsonl", [{"kind": "run", "test": run.get("test"), "run_id": run.get("run_id"), "status": run.get("status"),
                                "summary": run.get("summary"), "environment": run.get("environment"),
                                "finished_at": run.get("finished_at")}], opts)
        return n
    except Exception:
        log.exception("dataset: run not stored")
        return 0


def stats() -> dict:
    d = root()
    out = {"path": str(d), "size_mb": round(_size_mb(), 2)}
    for name in ("recordings", "steps", "runs"):
        f = d / f"{name}.jsonl"
        out[name] = sum(1 for _ in open(f, encoding="utf-8")) if f.exists() else 0
    return out


def export(dest: str | Path) -> Path:
    """Zip the dataset (for training elsewhere)."""
    dest = Path(dest)
    with zipfile.ZipFile(dest, "w", zipfile.ZIP_DEFLATED) as z:
        for f in root().rglob("*"):
            if f.is_file():
                z.write(f, f.relative_to(root()))
    return dest
