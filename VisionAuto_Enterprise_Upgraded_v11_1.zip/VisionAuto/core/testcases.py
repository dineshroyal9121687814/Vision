"""Test case management: one JSON file per topic + category, in topic folders.

    <testcases root>/
      Login/login_positive.json, login_negative.json, login_boundary.json
      Payment/payment_positive.json ...
      _shared/steps.json                  reusable step blocks (referenced from cases as {"use": "<name>"})

A file is ``{"schema": "visionauto.testcases/1", "topic", "category", "cases": [...]}``. A case never carries an
execution result: ``status`` is ``not_run`` until a real run says otherwise.
The root folder is configurable (Settings -> ``testcases_dir``); changing it copies the existing cases and never
deletes the old folder.
"""
from __future__ import annotations

import csv
import json
import os
import re
import shutil
import tempfile
from copy import deepcopy
from datetime import datetime
from pathlib import Path

from core import paths, settings

SCHEMA = "visionauto.testcases/1"
SHARED_DIR = "_shared"
CATEGORIES = ("positive", "negative", "boundary", "validation", "ui", "error_handling", "regression")
PRIORITIES = ("High", "Medium", "Low")
CASE_FIELDS = ("id", "title", "description", "preconditions", "test_data", "steps", "expected_results",
               "priority", "category")


class CaseError(ValueError):
    """A user-facing problem with a test case / folder / path."""


def safe_name(name: str, fallback: str = "untitled") -> str:
    name = re.sub(r"[^\w\- ]+", "", str(name or ""), flags=re.UNICODE).strip().replace(" ", "_")
    return (name[:60] or fallback)


# ============================================================================ storage root
def root() -> Path:
    custom = str(settings.load().get("testcases_dir") or "").strip()
    return Path(custom).expanduser() if custom else paths.testcases_dir()


def validate_dir(path) -> Path:
    """Create the folder if needed and prove it is writable. Raises CaseError with an actionable message."""
    raw = str(path or "").strip()
    if not raw:
        raise CaseError("Choose a folder for the test cases.")
    p = Path(raw).expanduser()
    if p.exists() and not p.is_dir():
        raise CaseError(f"'{p}' is a file, not a folder.")
    try:
        p.mkdir(parents=True, exist_ok=True)
        fd, probe = tempfile.mkstemp(prefix=".va-write-test-", dir=p)
        os.close(fd)
        os.unlink(probe)
    except OSError as exc:
        raise CaseError(f"Cannot use '{p}': {exc.strerror or exc}. Check the path and your permissions.") from exc
    return p.resolve()


def change_root(new_dir, migrate: bool = True) -> dict:
    """Point VisionAuto at another folder. Existing cases are COPIED (nothing is deleted or overwritten)."""
    new = validate_dir(new_dir)
    old = root()
    copied, skipped = 0, 0
    if migrate and old.exists() and old.resolve() != new:
        if new == old.resolve() or old.resolve() in new.parents:
            raise CaseError("The new folder cannot be inside the current test case folder.")
        for src in old.rglob("*.json"):
            dst = new / src.relative_to(old)
            if dst.exists():
                skipped += 1                              # never overwrite something already there
                continue
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dst)
            copied += 1
    opts = settings.load()
    opts["testcases_dir"] = str(new)
    settings.save(opts)
    return {"root": str(new), "copied": copied, "skipped_existing": skipped, "old_root": str(old)}


# ============================================================================ files
def _write_json(path: Path, data) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=".va-", suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            json.dump(data, fh, indent=2, ensure_ascii=False)
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(tmp, path)
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


def _inside(path: Path, base: Path) -> Path:
    p = path.resolve()
    try:
        p.relative_to(base.resolve())
    except ValueError:
        raise CaseError("That path is outside the test case folder.") from None
    return p


def file_for(topic: str, category: str, base: Path | None = None) -> Path:
    base = base or root()
    t = safe_name(topic, "General")
    return base / t / f"{safe_name(t).lower()}_{safe_name(category, 'general').lower()}.json"


def load_file(path: Path) -> dict:
    try:
        doc = json.loads(Path(path).read_text(encoding="utf-8-sig"))
    except (OSError, ValueError) as exc:
        raise CaseError(f"Cannot read test case file '{Path(path).name}': {exc}") from exc
    if not isinstance(doc, dict) or not isinstance(doc.get("cases"), list):
        raise CaseError(f"'{Path(path).name}' is not a VisionAuto test case file (no 'cases' list).")
    return doc


def save_file(path: Path, topic: str, category: str, cases: list[dict]) -> None:
    _write_json(path, {"schema": SCHEMA, "topic": topic, "category": category,
                       "updated_at": datetime.now().isoformat(timespec="seconds"), "cases": cases})


def normalize_case(case: dict, topic: str = "", category: str = "") -> dict:
    """Fill every standard field, coerce types, and refuse anything that would fake a result."""
    if not isinstance(case, dict):
        raise CaseError("A test case must be an object.")
    c = dict(case)
    c["title"] = str(c.get("title") or "").strip()
    if not c["title"]:
        raise CaseError("A test case needs a title.")
    c["id"] = str(c.get("id") or "").strip()
    c["description"] = str(c.get("description") or "")
    for key in ("preconditions", "steps", "expected_results"):
        v = c.get(key) or []
        c[key] = [str(x) for x in v] if isinstance(v, list) else [str(v)]
    td = c.get("test_data")
    c["test_data"] = td if isinstance(td, (dict, list)) else ({} if td in (None, "") else {"value": td})
    pr = str(c.get("priority") or "Medium").title()
    c["priority"] = pr if pr in PRIORITIES else "Medium"
    cat = str(c.get("category") or category or "positive").casefold().replace(" ", "_")
    c["category"] = cat
    c["topic"] = str(c.get("topic") or topic or "General")
    c["status"] = "not_run"                        # a stored case is never "passed" until a real run says so
    c.setdefault("source", "manual")
    c.setdefault("created_at", datetime.now().isoformat(timespec="seconds"))
    c.pop("result", None)
    return c


# ============================================================================ listing / lookup
def iter_files(base: Path | None = None):
    base = base or root()
    if not base.exists():
        return
    for f in sorted(base.rglob("*.json")):
        if SHARED_DIR in f.relative_to(base).parts or f.name.startswith("."):
            continue
        yield f


def list_topics(base: Path | None = None) -> list[str]:
    base = base or root()
    return sorted(d.name for d in base.iterdir() if d.is_dir() and d.name != SHARED_DIR) if base.exists() else []


def list_cases(base: Path | None = None) -> list[dict]:
    """Every case in the tree with ``_file`` (path) added. Unreadable files are reported via ``_errors``."""
    base = base or root()
    out: list[dict] = []
    for f in iter_files(base):
        try:
            doc = load_file(f)
        except CaseError:
            continue
        for c in doc["cases"]:
            if isinstance(c, dict):
                item = dict(c)
                item.setdefault("topic", doc.get("topic") or f.parent.name)
                item.setdefault("category", doc.get("category") or "")
                item["_file"] = str(f)
                out.append(item)
    return out


def find(case_id: str, base: Path | None = None) -> dict | None:
    return next((c for c in list_cases(base) if c.get("id") == case_id), None)


def next_id(topic: str, category: str, base: Path | None = None) -> str:
    prefix = f"{re.sub(r'[^A-Za-z]', '', topic).upper()[:3] or 'TC'}-{category[:3].upper()}-"
    used = [int(m.group(1)) for c in list_cases(base) if (m := re.fullmatch(re.escape(prefix) + r"(\d+)", str(c.get("id", ""))))]
    return f"{prefix}{(max(used) + 1 if used else 1):03d}"


def search(cases: list[dict], text: str = "", topic: str = "", category: str = "", priority: str = "",
           status: str = "", sort_by: str = "id", descending: bool = False) -> list[dict]:
    t = text.strip().casefold()
    out = []
    for c in cases:
        if topic and c.get("topic") != topic:
            continue
        if category and c.get("category") != category:
            continue
        if priority and c.get("priority") != priority:
            continue
        if status and c.get("status") != status:
            continue
        if t:
            hay = " ".join([str(c.get("id", "")), str(c.get("title", "")), str(c.get("description", "")),
                            " ".join(map(str, c.get("steps", []))), " ".join(map(str, c.get("tags", [])))]).casefold()
            if t not in hay:
                continue
        out.append(c)
    order = {"High": 0, "Medium": 1, "Low": 2}
    key = (lambda c: order.get(c.get("priority"), 9)) if sort_by == "priority" else (lambda c: str(c.get(sort_by, "")).casefold())
    return sorted(out, key=key, reverse=descending)


# ============================================================================ CRUD
def add_case(case: dict, topic: str | None = None, base: Path | None = None) -> dict:
    base = base or root()
    c = normalize_case(case, topic or "")
    topic = topic or c["topic"]
    c["topic"] = topic
    if not c["id"]:
        c["id"] = next_id(topic, c["category"], base)
    elif find(c["id"], base):
        raise CaseError(f"A test case with id '{c['id']}' already exists.")
    path = file_for(topic, c["category"], base)
    doc = load_file(path) if path.is_file() else {"cases": []}
    save_file(path, topic, c["category"], doc["cases"] + [c])
    return c


def update_case(case_id: str, changes: dict, base: Path | None = None) -> dict:
    cur = find(case_id, base)
    if not cur:
        raise CaseError(f"Test case '{case_id}' was not found.")
    src = Path(cur.pop("_file"))
    merged = normalize_case({**cur, **changes, "id": case_id}, cur.get("topic", ""), cur.get("category", ""))
    doc = load_file(src)
    cases = [merged if c.get("id") == case_id else c for c in doc["cases"]]
    new_path = file_for(merged["topic"], merged["category"], base or root())
    if new_path.resolve() == src.resolve():
        save_file(src, merged["topic"], merged["category"], cases)
    else:                                              # topic/category changed -> the case moves to another file
        remaining = [c for c in doc["cases"] if c.get("id") != case_id]
        _store(src, doc, remaining)
        target = load_file(new_path)["cases"] if new_path.is_file() else []
        save_file(new_path, merged["topic"], merged["category"], target + [merged])
    return merged


def _store(path: Path, doc: dict, cases: list[dict]) -> None:
    """Write ``cases`` back, deleting the file (never the folder) when it became empty."""
    if cases:
        save_file(path, doc.get("topic", path.parent.name), doc.get("category", ""), cases)
    else:
        path.unlink(missing_ok=True)


def delete_case(case_id: str, base: Path | None = None) -> bool:
    cur = find(case_id, base)
    if not cur:
        return False
    src = Path(cur["_file"])
    _inside(src, base or root())
    doc = load_file(src)
    _store(src, doc, [c for c in doc["cases"] if c.get("id") != case_id])
    return True


def clone_case(case_id: str, base: Path | None = None) -> dict:
    cur = find(case_id, base)
    if not cur:
        raise CaseError(f"Test case '{case_id}' was not found.")
    cur.pop("_file", None)
    copy = deepcopy(cur)
    copy["id"] = ""
    copy["title"] = f"{cur['title']} (copy)"
    copy["status"] = "not_run"
    return add_case(copy, cur.get("topic"), base)


def delete_topic(topic: str, base: Path | None = None) -> int:
    """Delete one topic folder and its case files (nothing outside it). Returns the number of cases removed."""
    base = base or root()
    d = _inside(base / safe_name(topic), base)
    if d == base.resolve() or not d.is_dir():
        return 0
    n = sum(len(load_file(f)["cases"]) for f in d.glob("*.json") if f.is_file())
    shutil.rmtree(d)
    return n


# ============================================================================ reusable steps / variables
def shared_steps(base: Path | None = None) -> dict[str, list[str]]:
    f = (base or root()) / SHARED_DIR / "steps.json"
    if not f.is_file():
        return {}
    try:
        data = json.loads(f.read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        raise CaseError(f"Cannot read the reusable steps file: {exc}") from exc
    return {str(k): [str(s) for s in v] for k, v in data.items() if isinstance(v, list)}


def save_shared_step(name: str, steps: list[str], base: Path | None = None) -> None:
    allsteps = shared_steps(base)
    allsteps[safe_name(name)] = [str(s) for s in steps]
    _write_json((base or root()) / SHARED_DIR / "steps.json", allsteps)


_VAR = re.compile(r"\$\{([A-Za-z_][\w\-]*)\}")


def expand(case: dict, base: Path | None = None, variables: dict | None = None) -> dict:
    """Resolve ``{"use": "<shared step>"}`` references and ``${variable}`` placeholders (case.test_data + variables)."""
    shared = shared_steps(base)
    data = case.get("test_data") if isinstance(case.get("test_data"), dict) else {}
    values = {**{k: str(v) for k, v in data.items()}, **{k: str(v) for k, v in (variables or {}).items()}}
    steps: list[str] = []
    for s in case.get("steps", []):
        if isinstance(s, dict) and "use" in s:
            if s["use"] not in shared:
                raise CaseError(f"Reusable step '{s['use']}' does not exist.")
            steps.extend(shared[s["use"]])
        else:
            steps.append(str(s))

    def sub(text: str) -> str:
        return _VAR.sub(lambda m: values.get(m.group(1), m.group(0)), text)

    out = deepcopy(case)
    out["steps"] = [sub(s) for s in steps]
    out["expected_results"] = [sub(s) for s in case.get("expected_results", [])]
    return out


# ============================================================================ import / export
def export_cases(dest, topics: list[str] | None = None, fmt: str = "json", base: Path | None = None) -> dict:
    """Export to one file (json / csv) or, with fmt='tree', as a topic folder tree. Returns what was written."""
    base = base or root()
    cases = [c for c in list_cases(base) if not topics or c.get("topic") in topics]
    if not cases:
        raise CaseError("There are no test cases to export.")
    dest = Path(dest)
    clean = [{k: v for k, v in c.items() if k != "_file"} for c in cases]
    if fmt == "tree":
        out_root = validate_dir(dest)
        for c in clean:
            f = file_for(c["topic"], c["category"], out_root)
            doc = load_file(f) if f.is_file() else {"cases": []}
            save_file(f, c["topic"], c["category"], doc["cases"] + [c])
        return {"files": len(list(iter_files(out_root))), "cases": len(clean), "path": str(out_root)}
    dest.parent.mkdir(parents=True, exist_ok=True)
    if fmt == "csv":
        with open(dest, "w", encoding="utf-8-sig", newline="") as fh:
            w = csv.writer(fh)
            w.writerow(CASE_FIELDS + ("topic", "status"))
            for c in clean:
                w.writerow([c.get("id"), c.get("title"), c.get("description"), "\n".join(c.get("preconditions", [])),
                            json.dumps(c.get("test_data", {}), ensure_ascii=False), "\n".join(c.get("steps", [])),
                            "\n".join(c.get("expected_results", [])), c.get("priority"), c.get("category"),
                            c.get("topic"), c.get("status")])
    elif fmt == "json":
        _write_json(dest, {"schema": SCHEMA, "cases": clean})
    else:
        raise CaseError("Export format must be json, csv or tree.")
    return {"files": 1, "cases": len(clean), "path": str(dest)}


def import_cases(src, base: Path | None = None, on_duplicate: str = "skip") -> dict:
    """Import a JSON export (or a folder of case files). Duplicate ids are skipped or get a fresh id."""
    base = base or root()
    src = Path(src)
    files = [src] if src.is_file() else sorted(src.rglob("*.json")) if src.is_dir() else []
    if not files:
        raise CaseError(f"Nothing to import at '{src}'.")
    added, skipped = 0, 0
    for f in files:
        try:
            doc = json.loads(f.read_text(encoding="utf-8-sig"))
        except (OSError, ValueError) as exc:
            raise CaseError(f"'{f.name}' is not valid JSON: {exc}") from exc
        cases = doc.get("cases") if isinstance(doc, dict) else doc
        if not isinstance(cases, list):
            raise CaseError(f"'{f.name}' has no list of test cases.")
        for c in cases:
            c = dict(c) if isinstance(c, dict) else {}
            c.pop("_file", None)
            if c.get("id") and find(c["id"], base):
                if on_duplicate == "skip":
                    skipped += 1
                    continue
                c["id"] = ""
            add_case(c, c.get("topic") or (doc.get("topic") if isinstance(doc, dict) else None) or "Imported", base)
            added += 1
    return {"added": added, "skipped": skipped}
