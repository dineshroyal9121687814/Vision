from core.plugins.citrix_plugin import CitrixPlugin
from core.plugins.electron_plugin import ElectronPlugin
from core.plugins.generic_plugin import GenericPlugin
from core.plugins.java_plugin import JavaPlugin
from core.plugins.sap_plugin import SapPlugin
from core.plugins.web_plugin import WebPlugin


class PluginManager:
    def __init__(self):
        # most specific first; GenericPlugin always matches and must stay last
        self.plugins = [SapPlugin(), CitrixPlugin(), ElectronPlugin(), WebPlugin(), JavaPlugin(), GenericPlugin()]

    def get_plugin_for(self, window: dict):
        for p in self.plugins:
            if p.is_applicable(window or {}):
                return p
        return self.plugins[-1]

    def list_plugins(self) -> list[str]:
        return [p.name for p in self.plugins]
