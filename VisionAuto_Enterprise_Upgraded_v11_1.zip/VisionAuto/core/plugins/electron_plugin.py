from core.plugins.base_plugin import Plugin

PROCESSES = {"code.exe", "slack.exe", "discord.exe", "teams.exe", "ms-teams.exe", "figma.exe",
             "postman.exe", "notion.exe", "whatsapp.exe"}


class ElectronPlugin(Plugin):
    """Electron apps: UIA works when the app exposes accessibility; a CDP-based locator
    (launch with --remote-debugging-port) is the planned upgrade."""
    name = "electron"

    def is_applicable(self, window: dict) -> bool:
        return window.get("process", "").lower() in PROCESSES
