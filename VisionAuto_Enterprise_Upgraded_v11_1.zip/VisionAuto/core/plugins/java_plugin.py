from core.plugins.base_plugin import Plugin


class JavaPlugin(Plugin):
    """Java Swing/AWT. Needs the Java Access Bridge for a deep native tier (planned);
    until then UIA (where exposed) and the vision tiers are used."""
    name = "java"

    def is_applicable(self, window: dict) -> bool:
        return window.get("process", "").lower() in {"java.exe", "javaw.exe"}
