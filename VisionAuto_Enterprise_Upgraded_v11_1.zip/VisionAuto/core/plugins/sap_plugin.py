from core.plugins.base_plugin import Plugin


class SapPlugin(Plugin):
    """SAP GUI for Windows. SAP GUI Scripting (COM, findById) is the planned deep tier;
    it needs scripting enabled on a real SAP system to build and test."""
    name = "sap"

    def is_applicable(self, window: dict) -> bool:
        return window.get("process", "").lower() in {"saplogon.exe", "sapgui.exe", "saplgpad.exe"}
