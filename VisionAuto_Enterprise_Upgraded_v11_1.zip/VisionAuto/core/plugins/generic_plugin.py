from core.plugins.base_plugin import Plugin


class GenericPlugin(Plugin):
    """Catch-all (Win32 / WPF / WinForms / UWP all expose UI Automation)."""
    name = "generic"

    def is_applicable(self, window: dict) -> bool:
        return True
