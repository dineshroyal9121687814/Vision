"""
Plugin system (Module 15): one adapter per UI technology.

A plugin decides (1) whether it owns the current window and (2) how to find
controls natively. The native tier is the fastest and most reliable one; when
it returns None the Resolver falls through to the vision tiers (template, ORB,
OCR, AI, self-heal), which work on any pixels at all.

Today every plugin except Citrix uses Windows UI Automation for the native
tier. Dedicated deeper integrations are the extension points:
    SAP       -> SAP GUI Scripting (COM)         findById() locators
    Java      -> Java Access Bridge              Swing/AWT component tree
    Electron  -> Chrome DevTools Protocol        CSS-selector locators
"""
from __future__ import annotations

from core.system import winenv


class Plugin:
    name = "base"
    uses_uia = True

    def is_applicable(self, window: dict) -> bool:
        return False

    def find_element_native(self, target: dict, window: dict) -> dict | None:
        if self.uses_uia and (target.get("xpath") or target.get("rxpath")):
            from core.system import uia_tree
            from core.xpath.locate import locate

            hit = locate(target, window, lambda: uia_tree.snapshot_window(window.get("title", ""), window.get("_hwnd", 0)))
            if hit:
                return hit
            if target.get("_xpath_only"):
                return None
        if self.uses_uia and not (target.get("name") or target.get("automation_id")) and target.get("help"):
            r0 = target.get("rect")
            near0 = ((r0[0] + r0[2]) / 2, (r0[1] + r0[3]) / 2) if isinstance(r0, (list, tuple)) and len(r0) >= 4 else None
            return winenv.find_by_help(window.get("title", ""), target["help"], target.get("role", ""), near0)
        if not self.uses_uia or not (target.get("name") or target.get("automation_id")):
            return None
        r = target.get("rect")
        has_rect = isinstance(r, (list, tuple)) and len(r) >= 4
        near = ((r[0] + r[2]) / 2, (r[1] + r[3]) / 2) if has_rect else (target.get("x", 0), target.get("y", 0))
        return winenv.find_native(
            window.get("title", ""), name=target.get("name", ""), role=target.get("role", ""),
            automation_id=target.get("automation_id", ""), near=near, hwnd=window.get("_hwnd", 0),
        )
