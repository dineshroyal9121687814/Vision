"""
Web application automation plugin for Chrome, Edge, Firefox, Brave, and Opera.
Enables web application detection and native accessibility / DOM support.
"""
from __future__ import annotations

from core.plugins.base_plugin import Plugin

WEB_BROWSERS = {
    "chrome.exe",
    "msedge.exe",
    "firefox.exe",
    "brave.exe",
    "opera.exe",
    "vivaldi.exe",
}


class WebPlugin(Plugin):
    """Web browser adapter.
    
    Provides specialized browser window identification and leverages UI Automation
    accessible DOM element resolution (roles: Hyperlink, Edit, Button, Document, ListItem).
    """
    name = "web"

    def is_applicable(self, window: dict) -> bool:
        process = str(window.get("process") or "").lower()
        title = str(window.get("title") or "").lower()
        return process in WEB_BROWSERS or any(b in title for b in [" - google chrome", " - personal - microsoft edge", " - mozilla firefox"])

