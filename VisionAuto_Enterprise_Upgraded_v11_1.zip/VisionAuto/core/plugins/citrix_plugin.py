from core.plugins.base_plugin import Plugin

PROCESSES = {"wfica32.exe", "cdviewer.exe", "receiver.exe", "mstsc.exe", "vmware-view.exe"}


class CitrixPlugin(Plugin):
    """Citrix / RDP: the client only receives a pixel stream, there is no local UI tree to query.
    Vision-only is the correct design here, not a missing feature."""
    name = "citrix_rdp"
    uses_uia = False

    def is_applicable(self, window: dict) -> bool:
        return (window.get("process", "").lower() in PROCESSES) or "citrix" in window.get("title", "").lower()
