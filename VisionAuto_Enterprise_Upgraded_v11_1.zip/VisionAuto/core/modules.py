"""Reusable modules (Ranorex "modules / recording modules", UFT "reusable actions"): a saved test can be CALLED from
another test with its own arguments.

    {"type": "call_test", "params": {"test": "login", "args": {"user": "${user}", "password": "=upper(${pw})"}}}

Calls are expanded when the test is loaded, into ordinary steps (arguments become ``set_variable`` steps), so the
engine, reports, retries and validation need no special case. Cycles (A calls B calls A) and runaway depth are refused.
"""
from __future__ import annotations

import copy

MAX_DEPTH = 6


class ModuleError(ValueError):
    pass


def called_tests(steps: list) -> list[str]:
    return [str((s.get("params") or {}).get("test") or "") for s in steps or [] if s.get("type") == "call_test"]


def expand(test: dict, loader, _stack: tuple = ()) -> dict:
    """-> a test whose ``call_test`` steps are replaced by the called test's steps. ``loader(name) -> test dict``.
    Returns the same dict when there is nothing to expand."""
    steps = test.get("steps") or []
    if not any(s.get("type") == "call_test" for s in steps):
        return test
    if len(_stack) >= MAX_DEPTH:
        raise ModuleError(f"modules are nested more than {MAX_DEPTH} deep: {' -> '.join(_stack)}")
    out: list[dict] = []
    apps = list(test.get("applications") or [])
    known = {a.get("alias") for a in apps if isinstance(a, dict)}
    for step in steps:
        if step.get("type") != "call_test":
            out.append(step)
            continue
        p = step.get("params") or {}
        name = str(p.get("test") or "").strip()
        if not name:
            raise ModuleError(f"step {step.get('id')}: 'call_test' needs the name of the test to call")
        if name in _stack:
            raise ModuleError(f"modules call each other in a circle: {' -> '.join(_stack + (name,))}")
        try:
            sub = loader(name)
        except (FileNotFoundError, OSError) as e:
            raise ModuleError(f"step {step.get('id')}: module '{name}' was not found") from e
        sub = expand(sub, loader, _stack + (name,))
        args = p.get("args") or {}
        if not isinstance(args, dict):
            raise ModuleError(f"step {step.get('id')}: arguments of '{name}' must be name = value pairs")
        for var, val in args.items():
            out.append({"type": "set_variable", "params": {"name": str(var), "value": val},
                        "description": f"[{name}] argument {var}", "module": name})
        for sst in copy.deepcopy(sub.get("steps") or []):
            sst["module"] = name
            sst["description"] = f"[{name}] {sst.get('description') or sst.get('type')}"
            out.append(sst)
        for a in sub.get("applications") or []:
            if isinstance(a, dict) and a.get("alias") not in known:
                apps.append(a)
                known.add(a.get("alias"))
    for i, s in enumerate(out, 1):
        s["id"] = i
    new = {**test, "steps": out}
    if apps:
        new["applications"] = apps
    return new
