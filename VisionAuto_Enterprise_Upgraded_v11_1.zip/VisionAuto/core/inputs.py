"""
The tester's questionnaire: which values does this test TYPE, and how reliably can each CLICK be found again?

``collect(test)``   -> {"inputs": [...every typed value...], "clicks": [...how each click is located...], "weak": [...]}
``write(dir, test)`` -> <test>/inputs.json  (edit the values you want to change; steps you leave alone keep the recording)
``load(dir)``       -> {step_id: text} overrides, applied automatically at playback (``apply``)
``ask(test, input)`` -> console prompts, Enter keeps the recorded value

Secrets (redacted while recording) are never written to the file: they are asked for at run time or supplied by the
secret provider.
"""
from __future__ import annotations

import json
from pathlib import Path

FILE = "inputs.json"
CLICKS = ("click", "double_click", "right_click", "middle_click")


def _how(tg: dict) -> str:
    """The strongest way this click can be found again."""
    if tg.get("automation_id") or tg.get("name"):
        return "name"
    if tg.get("visual_neighbors") or tg.get("neighbors"):
        return "neighbours"
    if tg.get("templates"):
        return "picture"
    return "position only"


def collect(test: dict) -> dict:
    inputs, clicks, weak = [], [], []
    for st in test.get("steps") or []:
        t, p, tg = st.get("type"), st.get("params") or {}, st.get("target") or {}
        if t == "type":
            inputs.append({"step": st.get("id"), "label": st.get("description") or "Type text",
                           "value": "" if p.get("redacted") else p.get("text", ""), "secret": bool(p.get("redacted")),
                           "into": tg.get("name") or tg.get("automation_id") or ""})
        elif t == "fill_table":
            inputs.append({"step": st.get("id"), "label": st.get("description") or "Fill table", "value": "", "secret": False,
                           "into": "table (use a data file)"})
        elif t in CLICKS or t == "drag_drop":
            how = _how(tg)
            clicks.append({"step": st.get("id"), "label": st.get("description") or t, "found_by": how,
                           "has_picture": bool(tg.get("templates")), "neighbours": len(tg.get("visual_neighbors") or []) +
                           len(tg.get("neighbors") or [])})
            if how == "position only":
                weak.append(st.get("id"))
    return {"inputs": inputs, "clicks": clicks, "weak": weak}


def write(directory, test: dict) -> Path:
    plan = collect(test)
    path = Path(directory) / FILE
    existing = {}
    if path.is_file():
        try:
            existing = json.loads(path.read_text(encoding="utf-8")).get("values", {})
        except (ValueError, OSError):
            existing = {}
    values = {str(i["step"]): existing.get(str(i["step"]), i["value"]) for i in plan["inputs"] if not i["secret"]}
    doc = {"help": "Change the text of any step; delete a line to keep the recorded value. Secrets are never stored here.",
           "steps": {str(i["step"]): i["label"] for i in plan["inputs"]}, "values": values}
    path.write_text(json.dumps(doc, indent=2, ensure_ascii=False), encoding="utf-8")
    return path


def load(directory) -> dict[int, str]:
    path = Path(directory) / FILE
    if not path.is_file():
        return {}
    try:
        vals = json.loads(path.read_text(encoding="utf-8")).get("values", {})
        return {int(k): str(v) for k, v in vals.items()}
    except (ValueError, OSError, AttributeError):
        return {}


def apply(test: dict, overrides: dict[int, str]) -> int:
    """Put the chosen values into the typed steps (in place). Returns how many steps changed."""
    n = 0
    for st in test.get("steps") or []:
        if st.get("type") == "type" and st.get("id") in overrides and not (st.get("params") or {}).get("redacted"):
            if st["params"].get("text") != overrides[st["id"]]:
                st["params"]["text"] = overrides[st["id"]]
                st["description"] = f"Type '{overrides[st['id']]}'" + (f" into '{(st.get('target') or {}).get('name')}'"
                                                                       if (st.get("target") or {}).get("name") else "")
                n += 1
    return n


def ask(plan: dict, input_fn=input) -> dict[int, str]:
    """Console questionnaire. Enter = keep the recorded value."""
    out = {}
    for i in plan["inputs"]:
        if i["secret"]:
            continue
        ans = input_fn(f"[step {i['step']}] {i['label']}\n   value [{i['value']}]: ").strip()
        if ans:
            out[int(i["step"])] = ans
    return out
