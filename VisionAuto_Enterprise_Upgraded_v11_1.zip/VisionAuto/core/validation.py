"""
Pre-run validation of a (possibly multi-application) test.

Run BEFORE any application is launched or any input is sent, so a typo in an
application alias can never make a step act on the wrong window.

    issues = validate_test(test)            # list of Issue dicts
    errors = [i for i in issues if i["level"] == "error"]
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import Any

from core import applications

KNOWN_STEP_TYPES = {
    "click", "double_click", "right_click", "middle_click", "drag_drop", "scroll", "type", "key",
    "hotkey", "hover", "wait", "launch_app", "open_app", "validate",
    "loop_start", "loop_end", "if_start", "else", "if_end", "break_loop",
    "wait_until", "scroll_until", "window_action", "set_clipboard", "fill_table",
    "set_value", "append_value", "clear_value", "read_value", "select_option", "set_state", "upload_file",
    "wait_for_window", "excel_save", "excel_close", "custom",
    "call_test", "set_variable", "run_command", "http_request", "sql_query", "screenshot",
}
CONTROL_TYPES = {"loop_start", "loop_end", "if_start", "else", "if_end", "break_loop"}
CONDITION_TYPES = {"exists", "not_exists", "variable", "text_contains", "text_equals"}
VARIABLE_OPS = {"equals", "not_equals", "contains", "not_contains", "empty", "not_empty", "gt", "lt", "ge", "le"}
MAX_LOOP_TIMES, MAX_BLOCK_DEPTH = 1000, 8
BUILTIN_VARS = {"_row", "_iteration", "_loop"}
APP_MODES = {"launch", "attach", "attach_or_launch"}
STARTUP = {"lazy", "start"}
FAILURE_POLICIES = {"stop", "continue", "skip_app"}
CLEANUP_POLICIES = {"close_test_launched", "close_all", "leave_open"}
VAR_REF = re.compile(r"\$\{([a-zA-Z0-9_\-]+)\}")
MAX_RETRIES = 5


def issue(level: str, code: str, message: str, step: Any = None, alias: str | None = None) -> dict:
    return {"level": level, "code": code, "message": message, "step": step, "alias": alias}


def variable_refs(obj: Any) -> set[str]:
    if isinstance(obj, str):
        return set(VAR_REF.findall(obj))
    if isinstance(obj, list):
        return set().union(*(variable_refs(x) for x in obj)) if obj else set()
    if isinstance(obj, dict):
        return set().union(*(variable_refs(v) for v in obj.values())) if obj else set()
    return set()


def startup_order(apps: list[dict]) -> list[str]:
    """Aliases ordered so every application comes after the ones it depends on. Raises ValueError on a cycle."""
    deps = {a["alias"]: [d for d in (a.get("depends_on") or []) if isinstance(d, str)] for a in apps if a.get("alias")}
    order: list[str] = []
    state: dict[str, int] = {}

    def visit(alias: str, trail: tuple) -> None:
        if state.get(alias) == 2:
            return
        if state.get(alias) == 1:
            raise ValueError("Application startup dependencies form a cycle: " + " -> ".join(trail + (alias,)))
        state[alias] = 1
        for d in deps.get(alias, []):
            if d in deps:
                visit(d, trail + (alias,))
        state[alias] = 2
        order.append(alias)

    for alias in deps:
        visit(alias, ())
    return order


def validate_test(test: dict, registry: dict | None = None) -> list[dict]:
    """Return every problem found; never raises for bad test content."""
    issues: list[dict] = []
    if not isinstance(test, dict):
        return [issue("error", "schema", "Test must be a JSON object.")]
    steps = test.get("steps")
    if not isinstance(steps, list):
        return [issue("error", "schema", "Test 'steps' must be a list.")]
    if registry is None:
        try:
            registry = applications.load_registry()
        except Exception:
            registry = {}

    # ---- application collection
    apps = test.get("applications") or []
    if not isinstance(apps, list):
        issues.append(issue("error", "schema", "'applications' must be a list."))
        apps = []
    aliases: dict[str, dict] = {}
    for a in apps:
        if not isinstance(a, dict):
            issues.append(issue("error", "schema", "Each application entry must be an object."))
            continue
        alias = str(a.get("alias") or "").strip()
        if not alias:
            issues.append(issue("error", "app_alias_missing", "An application entry has no alias."))
            continue
        if not re.match(r"^[a-zA-Z0-9_\-]+$", alias):
            issues.append(issue("error", "app_alias_invalid", f"Alias '{alias}' may only use letters, digits, '-' and '_'.", alias=alias))
        if alias in aliases:
            issues.append(issue("error", "app_alias_duplicate", f"Alias '{alias}' is used by more than one application.", alias=alias))
            continue
        aliases[alias] = a
        ref = a.get("app_id")
        merged = dict(a)
        if ref:
            reg = registry.get(ref) or next((r for r in registry.values() if r.get("alias") == ref), None)
            if reg is None:
                issues.append(issue("error", "app_missing", f"Application '{alias}' references '{ref}', which is not registered on this machine.", alias=alias))
                continue
            merged = {**reg, **a}
        mode = merged.get("mode", "attach_or_launch")
        if mode not in APP_MODES:
            issues.append(issue("error", "app_mode", f"Application '{alias}' has unknown mode '{mode}'.", alias=alias))
        if merged.get("startup", "lazy") not in STARTUP:
            issues.append(issue("error", "app_startup", f"Application '{alias}' has unknown startup '{merged.get('startup')}'.", alias=alias))
        atype = merged.get("type", "desktop")
        can_launch = mode in ("launch", "attach_or_launch")
        if atype == "desktop" and mode == "launch" and not str(merged.get("exe_path") or "").strip():
            issues.append(issue("error", "app_exe_missing", f"Application '{alias}' must launch but has no executable path configured.", alias=alias))
        elif atype == "desktop" and can_launch and merged.get("exe_path"):
            if not Path(str(merged["exe_path"])).exists() and not _on_path(str(merged["exe_path"])):
                issues.append(issue("warning", "app_exe_not_found", f"Executable for '{alias}' was not found on this machine: {merged['exe_path']}", alias=alias))
        if atype == "web" and not str(merged.get("url") or merged.get("base_url") or "").strip():
            issues.append(issue("error", "app_url_missing", f"Web application '{alias}' has no URL.", alias=alias))
        if atype == "running" and mode == "launch":
            issues.append(issue("error", "app_mode", f"Application '{alias}' is an existing-window target and cannot be launched.", alias=alias))
        if applications.DANGEROUS_BINARIES & {Path(str(merged.get("exe_path") or "x")).name.lower()}:
            issues.append(issue("error", "app_unsafe", f"Application '{alias}' points at a shell or script host, which is not allowed.", alias=alias))
    for alias, a in aliases.items():
        for d in a.get("depends_on") or []:
            if d not in aliases:
                issues.append(issue("error", "app_dependency_missing", f"Application '{alias}' depends on unknown application '{d}'.", alias=alias))
    try:
        startup_order([a for a in aliases.values()])
    except ValueError as e:
        issues.append(issue("error", "app_dependency_cycle", str(e)))

    # ---- policies
    policy = test.get("failure_policy")
    if policy is not None and policy not in FAILURE_POLICIES:
        issues.append(issue("error", "failure_policy", f"failure_policy must be one of {sorted(FAILURE_POLICIES)}."))
    cleanup = (test.get("options") or {}).get("app_cleanup_policy") if isinstance(test.get("options"), dict) else None
    if cleanup is not None and cleanup not in CLEANUP_POLICIES:
        issues.append(issue("error", "cleanup_policy", f"app_cleanup_policy must be one of {sorted(CLEANUP_POLICIES)}."))

    # ---- steps
    defined = set((test.get("variables") or {}).keys()) if isinstance(test.get("variables"), dict) else set()
    defined |= BUILTIN_VARS
    data_cfg = test.get("data") if isinstance(test.get("data"), dict) else {}
    defined |= {str(c) for c in (data_cfg.get("columns") or [])}
    seen_ids: set = set()
    multi = len(aliases) > 1
    for pos, step in enumerate(steps, 1):
        if not isinstance(step, dict):
            issues.append(issue("error", "schema", f"Step {pos} is not an object.", pos))
            continue
        sid = step.get("id", pos)
        if sid in seen_ids:
            issues.append(issue("error", "step_id_duplicate", f"Step id {sid} appears more than once.", sid))
        seen_ids.add(sid)
        stype = step.get("type")
        if stype not in KNOWN_STEP_TYPES:
            issues.append(issue("error", "step_type", f"Step {sid} has unknown type '{stype}'.", sid))
        target = step.get("app")
        if target:
            if target not in aliases:
                known = ", ".join(sorted(aliases)) or "none"
                issues.append(issue("error", "step_app_unknown", f"Step {sid} targets application '{target}', which this test does not define (defined: {known}).", sid, target))
        elif multi and stype not in ("wait", "launch_app", "open_app"):
            issues.append(issue("warning", "step_app_unassigned", f"Step {sid} has no application assigned; it will act on whichever application was last active.", sid))
        retries = step.get("retries", 0)
        if not isinstance(retries, int) or isinstance(retries, bool) or not 0 <= retries <= MAX_RETRIES:
            issues.append(issue("error", "step_retries", f"Step {sid} 'retries' must be an integer from 0 to {MAX_RETRIES}.", sid))
        for name in sorted(variable_refs([step.get("params"), step.get("check"), step.get("validations"), step.get("target"), step.get("condition")])):
            if name not in defined:
                issues.append(issue("error", "variable_undefined", f"Step {sid} uses ${{{name}}}, which is not defined before this step.", sid))
        prm = step.get("params") or {}
        if stype == "set_variable" and prm.get("name"):
            defined.add(str(prm["name"]).strip())
        if stype in ("run_command", "http_request", "sql_query", "read_value") and prm.get("save_as"):
            defined.add(str(prm["save_as"]).strip())
        if stype == "call_test" and isinstance(prm.get("args"), dict):
            defined.update(str(k) for k in prm["args"])
        saved = str(step.get("save_as") or "").strip()
        if saved:
            if not re.match(r"^[a-zA-Z0-9_\-]+$", saved):
                issues.append(issue("error", "variable_name", f"Step {sid} saves to invalid variable name '{saved}'.", sid))
            defined.add(saved)
    issues.extend(_validate_blocks(steps))
    issues.extend(_validate_scenarios(steps, test))
    return issues


_CONTAINER_ROLES = {"pane", "window", "group", "custom", "document"}


def _is_blind_container_click(step: dict) -> bool:
    """A click whose recorded element is a big container (a whole pane): nothing semantic identifies what was hit."""
    tg = step.get("target") or {}
    r = tg.get("rect")
    if str(tg.get("role") or "").casefold() not in _CONTAINER_ROLES or tg.get("automation_id") or tg.get("xpath"):
        return False
    if not (isinstance(r, (list, tuple)) and len(r) == 4):
        return False
    return (r[2] - r[0]) * (r[3] - r[1]) > 250_000


WINDOW_ACTIONS = {"maximize", "minimize", "restore", "close", "focus", "set_rect", "restore_recorded"}
RECOVERY_ACTIONS = {"click_text", "press_key", "hotkey", "close"}


def _validate_scenarios(steps: list, test: dict) -> list[dict]:
    """Checks for wait_until / scroll_until / window_action / modifiers / drag params / duration limits / recovery rules."""
    out: list[dict] = []
    for pos, st in enumerate(steps, 1):
        if not isinstance(st, dict):
            continue
        sid, t, p = st.get("id", pos), st.get("type"), st.get("params") or {}
        if t == "wait_until":
            out.extend(_validate_condition(st.get("condition"), sid))
            tm = p.get("timeout_s", 10)
            if isinstance(tm, bool) or not isinstance(tm, (int, float)) or not 0 < tm <= 3600:
                out.append(issue("error", "wait", f"Step {sid}: wait_until timeout_s must be between 0 and 3600.", sid))
        elif t == "scroll_until":
            out.extend(_validate_condition(st.get("until"), sid))
            mx = p.get("max_scrolls", 20)
            if isinstance(mx, bool) or not isinstance(mx, int) or not 1 <= mx <= 200:
                out.append(issue("error", "scroll", f"Step {sid}: max_scrolls must be 1-200 so scrolling always ends.", sid))
        elif t == "window_action":
            if p.get("action") not in WINDOW_ACTIONS:
                out.append(issue("error", "window_action", f"Step {sid}: action must be one of {', '.join(sorted(WINDOW_ACTIONS))}.", sid))
            if not (st.get("window") or {}).get("title"):
                out.append(issue("error", "window_action", f"Step {sid}: window_action needs window.title.", sid))
        elif t == "open_app":
            if not (str(p.get("name") or "").strip() or str(p.get("exe") or "").strip() or str(p.get("aumid") or "").strip()):
                out.append(issue("error", "open_app", f"Step {sid}: open_app needs params.name (or exe / aumid).", sid))
        elif t in ("click", "double_click", "right_click", "middle_click") and _is_blind_container_click(st):
            tg = st.get("target") or {}
            out.append(issue("warning", "blind_container_click",
                             f"Step {sid} clicks inside the container '{tg.get('name') or tg.get('role')}' ({tg.get('role')}) at a "
                             "fixed spot - the exact item was not captured, so this only works if the screen is identical. "
                             "Use an open_app step for Start-menu launches, or edit the locator (XPath) in the Inspector.", sid))
        elif t == "fill_table":
            rows_p, file_p = p.get("rows"), str(p.get("file") or "").strip()
            if not (isinstance(rows_p, list) and rows_p and all(isinstance(r, list) for r in rows_p)) and not file_p:
                out.append(issue("error", "fill_table", f"Step {sid}: fill_table needs params.rows (a list of lists) or params.file.", sid))
            if p.get("max_rows") is not None and (isinstance(p["max_rows"], bool) or not isinstance(p["max_rows"], int) or p["max_rows"] < 1):
                out.append(issue("error", "fill_table", f"Step {sid}: max_rows must be a positive whole number.", sid))
        elif t == "set_clipboard" and not isinstance(p.get("text", ""), str):
            out.append(issue("error", "clipboard", f"Step {sid}: clipboard text must be a string.", sid))
        mods = p.get("modifiers")
        if mods is not None and (not isinstance(mods, (list, str)) or
                                 any(m not in ("ctrl", "shift", "alt", "cmd", "win") for m in (mods if isinstance(mods, list) else str(mods).replace(" ", "").split("+")))):
            out.append(issue("error", "modifiers", f"Step {sid}: modifiers must be a list of ctrl, shift, alt, cmd, win.", sid))
        lim = st.get("max_duration_ms")
        if lim is not None and (isinstance(lim, bool) or not isinstance(lim, int) or not 1 <= lim <= 3_600_000):
            out.append(issue("error", "duration", f"Step {sid}: max_duration_ms must be 1-3600000.", sid))
        if t == "drag_drop" and st.get("to_window") is not None and not (isinstance(st["to_window"], dict) and st["to_window"].get("title")):
            out.append(issue("error", "drag", f"Step {sid}: to_window must be an object with a window title.", sid))
    rules = test.get("recovery")
    if rules is not None:
        if not isinstance(rules, list) or len(rules) > 20:
            out.append(issue("error", "recovery", "recovery must be a list of at most 20 rules.", None))
        else:
            for i, r in enumerate(rules, 1):
                if not (isinstance(r, dict) and str(r.get("window") or "").strip() and r.get("action") in RECOVERY_ACTIONS):
                    out.append(issue("error", "recovery", f"Recovery rule {i} needs window and action ({', '.join(sorted(RECOVERY_ACTIONS))}).", None))
                elif r["action"] != "close" and not str(r.get("value") or "").strip():
                    out.append(issue("error", "recovery", f"Recovery rule {i}: action '{r['action']}' needs a value.", None))
    return out


def _validate_condition(cond, sid) -> list[dict]:
    if not isinstance(cond, dict) or cond.get("type") not in CONDITION_TYPES:
        return [issue("error", "condition", f"Step {sid} needs a condition of type: {', '.join(sorted(CONDITION_TYPES))}.", sid)]
    out = []
    t = cond["type"]
    if t in ("exists", "not_exists", "text_contains", "text_equals") and not isinstance(cond.get("target"), dict):
        out.append(issue("error", "condition", f"Step {sid}: a '{t}' condition needs a 'target' element.", sid))
    if t in ("text_contains", "text_equals") and not str(cond.get("expected", "")):
        out.append(issue("error", "condition", f"Step {sid}: a '{t}' condition needs 'expected' text.", sid))
    if t == "variable":
        if not re.match(r"^[a-zA-Z0-9_\-]+$", str(cond.get("name", ""))):
            out.append(issue("error", "condition", f"Step {sid}: a variable condition needs a valid variable 'name'.", sid))
        if cond.get("op") not in VARIABLE_OPS:
            out.append(issue("error", "condition", f"Step {sid}: variable condition 'op' must be one of {', '.join(sorted(VARIABLE_OPS))}.", sid))
    return out


def _validate_blocks(steps: list) -> list[dict]:
    """loop/if blocks must nest properly, break_loop must be inside a loop, loops must be bounded."""
    issues: list[dict] = []
    stack: list[tuple[str, Any]] = []
    for pos, step in enumerate(steps, 1):
        if not isinstance(step, dict):
            continue
        sid, t = step.get("id", pos), step.get("type")
        if t not in CONTROL_TYPES:
            continue
        if t == "loop_start":
            p = step.get("params") or {}
            if "times" in p:
                n = p["times"]
                if isinstance(n, str) and VAR_REF.fullmatch(n.strip()):
                    pass
                elif not isinstance(n, int) or isinstance(n, bool) or not 1 <= n <= MAX_LOOP_TIMES:
                    issues.append(issue("error", "loop", f"Step {sid}: loop 'times' must be 1-{MAX_LOOP_TIMES} (or a ${{variable}}).", sid))
            elif "while" in p:
                issues.extend(_validate_condition(p["while"], sid))
                mx = p.get("max", 100)
                if not isinstance(mx, int) or isinstance(mx, bool) or not 1 <= mx <= MAX_LOOP_TIMES:
                    issues.append(issue("error", "loop", f"Step {sid}: a 'while' loop needs 'max' of 1-{MAX_LOOP_TIMES} so it can never run forever.", sid))
            else:
                issues.append(issue("error", "loop", f"Step {sid}: a loop needs params.times or params.while.", sid))
            stack.append(("loop", sid))
        elif t == "if_start":
            issues.extend(_validate_condition(step.get("condition"), sid))
            stack.append(("if", sid))
        elif t == "else":
            if not stack or stack[-1][0] != "if":
                issues.append(issue("error", "block", f"Step {sid}: 'else' without a matching if.", sid))
            else:
                stack[-1] = ("else", stack[-1][1])
        elif t == "loop_end":
            if not stack or stack[-1][0] != "loop":
                issues.append(issue("error", "block", f"Step {sid}: loop_end without a matching loop_start.", sid))
            else:
                stack.pop()
        elif t == "if_end":
            if not stack or stack[-1][0] not in ("if", "else"):
                issues.append(issue("error", "block", f"Step {sid}: if_end without a matching if_start.", sid))
            else:
                stack.pop()
        elif t == "break_loop" and not any(k == "loop" for k, _ in stack):
            issues.append(issue("error", "block", f"Step {sid}: break_loop must be inside a loop.", sid))
        if len(stack) > MAX_BLOCK_DEPTH:
            issues.append(issue("error", "block", f"Step {sid}: blocks are nested deeper than {MAX_BLOCK_DEPTH}.", sid))
            break
    for kind, sid in stack:
        issues.append(issue("error", "block", f"The {kind} opened at step {sid} is never closed.", sid))
    return issues


def _on_path(exe: str) -> bool:
    import shutil

    return bool(shutil.which(exe))


def errors_only(issues: list[dict]) -> list[dict]:
    return [i for i in issues if i["level"] == "error"]


def format_issues(issues: list[dict]) -> str:
    return "\n".join(f"[{i['level'].upper()}] {i['message']}" for i in issues)
