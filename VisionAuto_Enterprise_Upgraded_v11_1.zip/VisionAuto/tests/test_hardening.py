"""
Tests for the multi-application hardening work: pre-run validation, strict application targeting,
failure policies, retries, cleanup guarantees, secret redaction, JUnit output, locator scoping,
project export/import, schema migration and the Ranorex/UFT process killer.

Everything here uses mocks or temp folders. None of it proves behaviour against real Windows
applications; see docs/TESTING_AND_VERIFICATION.md for what was and was not verified live.
"""
from __future__ import annotations

import json
import os
import tempfile
import unittest
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from core import applications, locators, project_io, redaction, testfile, validation
from core.playback import app_context as ac
from core.playback.player import Player
from core.reports.junit import build_junit
from core.tools import process_killer as pk


def _ws():
    d = tempfile.mkdtemp(prefix="va_hard_")
    os.environ["VISIONAUTO_HOME"] = d
    return Path(d)


def _test(steps, apps=None, **extra):
    t = {"schema": "visionauto.test/2", "name": "t", "title": "T", "steps": steps,
         "applications": apps if apps is not None else [
             {"alias": "a", "type": "desktop", "exe_path": "a.exe", "mode": "attach_or_launch"},
             {"alias": "b", "type": "desktop", "exe_path": "b.exe", "mode": "attach_or_launch"}],
         "variables": {}}
    t.update(extra)
    return t


WAIT = lambda i, app=None, **k: {"id": i, "type": "wait", "params": {"ms": 1}, "description": f"s{i}", **({"app": app} if app else {}), **k}  # noqa: E731
BAD = lambda i, app=None, **k: {"id": i, "type": "type", "params": {"text": "x", "redacted": True}, "description": f"bad{i}", **({"app": app} if app else {}), **k}  # noqa: E731


class ValidationTests(unittest.TestCase):
    def setUp(self):
        _ws()

    def codes(self, test):
        return {i["code"] for i in validation.validate_test(test, {})}

    def test_valid_two_app_test_has_no_errors(self):
        t = _test([WAIT(1, "a"), WAIT(2, "b")])
        self.assertEqual(validation.errors_only(validation.validate_test(t, {})), [])

    def test_unknown_alias_is_an_error(self):
        self.assertIn("step_app_unknown", self.codes(_test([WAIT(1, "zzz")])))

    def test_duplicate_alias(self):
        apps = [{"alias": "a", "type": "desktop", "exe_path": "x.exe"}, {"alias": "a", "type": "desktop", "exe_path": "y.exe"}]
        self.assertIn("app_alias_duplicate", self.codes(_test([], apps)))

    def test_missing_registry_reference(self):
        apps = [{"alias": "a", "app_id": "not-registered"}]
        self.assertIn("app_missing", self.codes(_test([], apps)))

    def test_cycle_in_dependencies(self):
        apps = [{"alias": "a", "type": "desktop", "exe_path": "x", "depends_on": ["b"]},
                {"alias": "b", "type": "desktop", "exe_path": "y", "depends_on": ["a"]}]
        self.assertIn("app_dependency_cycle", self.codes(_test([], apps)))

    def test_dependency_order(self):
        apps = [{"alias": "ui", "depends_on": ["db"]}, {"alias": "db", "depends_on": ["svc"]}, {"alias": "svc"}]
        self.assertEqual(validation.startup_order(apps), ["svc", "db", "ui"])

    def test_undefined_and_ordered_variables(self):
        steps = [{"id": 1, "app": "a", "type": "type", "params": {"text": "${later}"}},
                 {"id": 2, "app": "a", "type": "wait", "params": {"ms": 1}, "save_as": "later"}]
        self.assertIn("variable_undefined", self.codes(_test(steps)))   # used before it is produced
        steps.reverse()
        steps[0]["id"], steps[1]["id"] = 1, 2
        self.assertNotIn("variable_undefined", self.codes(_test(steps)))

    def test_bad_retries_and_policy_and_unknown_type(self):
        t = _test([WAIT(1, "a", retries=99), {"id": 2, "type": "explode", "app": "a"}], failure_policy="yolo")
        c = self.codes(t)
        self.assertTrue({"step_retries", "step_type", "failure_policy"} <= c)

    def test_shell_host_application_rejected(self):
        apps = [{"alias": "a", "type": "desktop", "exe_path": "C:/Windows/System32/cmd.exe", "mode": "launch"}]
        self.assertIn("app_unsafe", self.codes(_test([], apps)))

    def test_web_app_needs_url_and_running_cannot_launch(self):
        apps = [{"alias": "w", "type": "web", "mode": "launch"}, {"alias": "r", "type": "running", "mode": "launch", "process_name": "p"}]
        c = self.codes(_test([], apps))
        self.assertTrue({"app_url_missing", "app_mode"} <= c)

    def test_malformed_input_never_raises(self):
        self.assertEqual(validation.validate_test([], {})[0]["code"], "schema")
        self.assertEqual(validation.validate_test({"steps": "x"}, {})[0]["code"], "schema")


class StrictTargetingTests(unittest.TestCase):
    def setUp(self):
        _ws()

    def test_unknown_alias_never_launches_or_attaches(self):
        ctx = ac.AppContextManager([{"alias": "a", "type": "desktop", "exe_path": "a.exe"}], dry_run=False)
        with patch.object(ctx, "_attach_application") as att, patch.object(ctx, "_launch_application") as lau:
            with self.assertRaises(ac.UnknownApplication):
                ctx.ensure_app("wrong_alias")
        att.assert_not_called()
        lau.assert_not_called()

    def test_wrong_alias_step_fails_and_does_not_reach_other_app(self):
        ws = _ws()
        t = _test([WAIT(1, "a"), WAIT(2, "ghost")])
        run = Player(t, dry_run=True, base_dir=ws).run()
        self.assertEqual(run["status"], "invalid")          # blocked before anything ran
        self.assertEqual(run["steps"], [])
        self.assertIn("ghost", run["error"])

    def test_ambiguous_window_title_is_refused(self):
        defn = {"alias": "a", "type": "desktop", "window_title": "Notepad", "mode": "attach"}
        ctx = ac.AppContextManager([defn])
        infos = {1: {"pid": 10, "title": "a - Notepad"}, 2: {"pid": 11, "title": "b - Notepad"}}
        with patch.object(ac.winenv, "find_windows", return_value=[1, 2]), \
                patch.object(ac.winenv, "window_info", side_effect=lambda h: infos[h]):
            with self.assertRaises(ac.AmbiguousTarget) as cm:
                ctx.ensure_app("a")
        self.assertIn("2 windows", str(cm.exception))
        self.assertEqual(ctx.instances["a"].status, "failed")     # failure is visible in telemetry

    def test_allow_ambiguous_accepts_first(self):
        defn = {"alias": "a", "type": "desktop", "window_title": "Notepad", "mode": "attach", "allow_ambiguous": True}
        ctx = ac.AppContextManager([defn])
        with patch.object(ac.winenv, "find_windows", return_value=[5, 6]), \
                patch.object(ac.winenv, "window_info", return_value={"pid": 1, "title": "Notepad"}):
            self.assertEqual(ctx.ensure_app("a").hwnd, 5)

    def test_process_attach_is_exact_not_substring_or_empty(self):
        defn = {"alias": "a", "type": "running", "process_name": "calc.exe", "mode": "attach"}
        ctx = ac.AppContextManager([defn])
        running = [{"process": "", "pid": 1, "title": "x", "hwnd": 1},
                   {"process": "calculator_helper.exe", "pid": 2, "title": "y", "hwnd": 2}]
        with patch.object(ac.applications, "discover_running_apps", return_value=running), \
                patch.object(ac.winenv, "find_windows", return_value=[]):
            with self.assertRaises(Exception) as cm:
                ctx.ensure_app("a")
        self.assertIn("Could not attach", str(cm.exception))      # neither the blank nor the look-alike matched

    def test_two_instances_of_same_process_are_ambiguous(self):
        defn = {"alias": "a", "type": "running", "process_name": "calc.exe", "mode": "attach"}
        ctx = ac.AppContextManager([defn])
        running = [{"process": "calc.exe", "pid": 1, "title": "1", "hwnd": 1}, {"process": "CALC.EXE", "pid": 2, "title": "2", "hwnd": 2}]
        with patch.object(ac.applications, "discover_running_apps", return_value=running), \
                patch.object(ac.winenv, "find_windows", return_value=[]):
            with self.assertRaises(ac.AmbiguousTarget):
                ctx.ensure_app("a")

    def test_launch_timeout_fails_and_stops_owned_process(self):
        defn = {"alias": "a", "type": "desktop", "exe_path": "app.exe", "window_title": "Never", "timeout_s": 0.3, "mode": "launch"}
        ctx = ac.AppContextManager([defn])
        proc = SimpleNamespace(pid=42, terminate=lambda: setattr(proc, "stopped", True), wait=lambda timeout=None: 0,
                               kill=lambda: None, poll=lambda: None, stopped=False)
        with patch.object(ac.subprocess, "Popen", return_value=proc), patch.object(ac.winenv, "window_exists", return_value=False):
            with self.assertRaises(TimeoutError):
                ctx.ensure_app("a")
        self.assertTrue(proc.stopped)
        self.assertEqual(ctx.instances["a"].status, "failed")
        self.assertIn("did not show a window", ctx.instances["a"].error)

    def test_application_lost_mid_test(self):
        defn = {"alias": "a", "type": "desktop", "exe_path": "app.exe", "window_title": "App", "mode": "launch", "timeout_s": 2}
        ctx = ac.AppContextManager([defn])
        proc = SimpleNamespace(pid=7, returncode=1, poll=lambda: 1, terminate=lambda: None, wait=lambda timeout=None: 1, kill=lambda: None)
        with patch.object(ac.subprocess, "Popen", return_value=proc), patch.object(ac.winenv, "window_exists", return_value=True), \
                patch.object(ac.winenv, "activate_window", return_value=True):
            ctx.ensure_app("a")
        with patch.object(ac.winenv, "window_exists", return_value=False):
            with self.assertRaises(ac.ApplicationLost):
                ctx.switch_to("a")
        with self.assertRaises(ac.ApplicationLost):         # stays failed: no silent restart
            ctx.ensure_app("a")

    def test_window_reactivated_on_every_step_and_missing_window_fails(self):
        defn = {"alias": "a", "type": "desktop", "window_title": "App", "mode": "attach"}
        ctx = ac.AppContextManager([defn])
        with patch.object(ac.winenv, "find_windows", return_value=[3]), patch.object(ac.winenv, "window_info", return_value={"pid": 1, "title": "App"}), \
                patch.object(ac.winenv, "window_exists", return_value=True), patch.object(ac.winenv, "activate_window", return_value=True) as act:
            ctx.switch_to("a")
            ctx.switch_to("a")
            self.assertEqual(act.call_count, 2)
        with patch.object(ac.winenv, "window_exists", return_value=True), patch.object(ac.winenv, "activate_window", return_value=False):
            with self.assertRaises(ac.ApplicationLost):
                ctx.switch_to("a")

    def test_cleanup_never_closes_attached_or_unowned(self):
        ctx = ac.AppContextManager([], dry_run=False)
        closed = []
        proc = lambda n: SimpleNamespace(terminate=lambda: closed.append(n), wait=lambda timeout=None: 0, kill=lambda: None)  # noqa: E731
        owned = ac.ApplicationInstance("owned", {"alias": "owned"}); owned.process, owned.launched_by_test, owned.status = proc("owned"), True, "running"
        pre = ac.ApplicationInstance("pre", {"alias": "pre"}); pre.process, pre.launched_by_test, pre.status = proc("pre"), False, "attached"
        ctx.instances = {"owned": owned, "pre": pre}
        out = ctx.cleanup("close_test_launched")
        self.assertEqual(closed, ["owned"])
        self.assertEqual([r["alias"] for r in out], ["owned"])
        self.assertEqual(ctx.cleanup("leave_open"), [])

    def test_strict_substitution(self):
        ctx = ac.AppContextManager([], variables={"x": "1"})
        self.assertEqual(ctx.substitute_variables("${x}", strict=True), "1")
        with self.assertRaises(ac.UndefinedVariable):
            ctx.substitute_variables("a ${nope}", strict=True)


class PlayerPolicyTests(unittest.TestCase):
    def setUp(self):
        self.ws = _ws()

    def run_t(self, t, **opts):
        return Player(t, options=opts or None, dry_run=True, base_dir=self.ws).run()

    def statuses(self, run):
        return [(s["id"], s["status"]) for s in run["steps"]]

    def test_stop_policy_halts_after_first_failure(self):
        run = self.run_t(_test([WAIT(1, "a"), BAD(2, "a"), WAIT(3, "b")]))
        self.assertEqual(run["status"], "failed")
        self.assertEqual([i for i, _ in self.statuses(run)], [1, 2])
        self.assertEqual(run["summary"]["not_run"], 1)

    def test_continue_policy_runs_everything_but_fails_overall(self):
        run = self.run_t(_test([BAD(1, "a"), WAIT(2, "b")], failure_policy="continue"))
        self.assertEqual(run["status"], "failed")
        self.assertEqual(len(run["steps"]), 2)

    def test_skip_app_policy_skips_only_the_failed_application(self):
        run = self.run_t(_test([BAD(1, "a"), WAIT(2, "a"), WAIT(3, "b")], failure_policy="skip_app"))
        by = {s["id"]: s for s in run["steps"]}
        self.assertEqual(by[2]["status"], "skipped")
        self.assertIn("already failed", by[2]["detail"])
        self.assertNotIn("already failed", by[3].get("detail", ""))   # app b still ran
        self.assertEqual(run["status"], "failed")

    def test_cleanup_steps_run_after_failure(self):
        run = self.run_t(_test([BAD(1, "a"), WAIT(2, "a"), WAIT(9, "a", cleanup=True)]))
        ids = [s["id"] for s in run["steps"]]
        self.assertEqual(ids, [1, 9])
        self.assertTrue(run["steps"][-1]["cleanup"])

    def test_cleanup_runs_after_cancellation(self):
        called = []
        p = Player(_test([WAIT(1, "a"), WAIT(2, "a")]), dry_run=True, base_dir=self.ws, should_stop=lambda: True)
        with patch.object(p.app_context, "cleanup", side_effect=lambda **k: called.append(1) or []):
            run = p.run()
        self.assertEqual(run["status"], "aborted")
        self.assertEqual(called, [1])

    def test_cleanup_runs_even_if_engine_crashes(self):
        called = []
        p = Player(_test([WAIT(1, "a")]), dry_run=True, base_dir=self.ws)
        with patch.object(p, "_run_with_retries", side_effect=RuntimeError("boom")), \
                patch.object(p.app_context, "cleanup", side_effect=lambda **k: called.append(1) or []):
            with self.assertRaises(RuntimeError):
                p.run()
        self.assertEqual(called, [1])

    def test_undefined_variable_fails_step_instead_of_typing_placeholder(self):
        t = _test([{"id": 1, "app": "a", "type": "type", "params": {"text": "${missing}"}}])
        t["variables"] = {"missing": "ok"}
        p = Player(t, dry_run=True, base_dir=self.ws)
        p.app_context.variables.clear()            # simulate it vanishing at runtime
        res = p.run_step(t["steps"][0])
        self.assertEqual(res["status"], "failed")
        self.assertIn("not defined", res["error"])

    def test_retries_only_for_retryable_failures(self):
        p = Player(_test([WAIT(1, "a")]), dry_run=True, base_dir=self.ws)
        calls = []
        def fake(step):
            calls.append(1)
            return {"id": 1, "status": "failed", "retryable": step.get("flag", True), "error": "x"}
        with patch.object(p, "_run_step", side_effect=fake), patch.object(p, "_sleep"):
            r = p._run_with_retries({"id": 1, "type": "validate", "retries": 2})
            self.assertEqual((len(calls), r["attempts"]), (3, 3))
            self.assertNotIn("retryable", r)
            calls.clear()
            r = p._run_with_retries({"id": 1, "type": "click", "retries": 2, "flag": False})   # e.g. input already sent
            self.assertEqual(len(calls), 1)
        calls.clear()
        with patch.object(p, "_run_step", side_effect=fake), patch.object(p, "_sleep"):
            p._run_with_retries({"id": 1, "type": "validate", "retries": 500})
        self.assertEqual(len(calls), 1 + validation.MAX_RETRIES)

    def test_secret_variable_never_written_to_disk(self):
        t = _test([{"id": 1, "app": "a", "type": "wait", "params": {"ms": 1}, "save_as": "api_token", "mock_value": "s3cr3t-VALUE"},
                   {"id": 2, "app": "a", "type": "type", "params": {"text": "pw=${api_token}", "redacted": True}}])
        t["variables"] = {"db_password": "hunter22"}
        run = self.run_t(t)
        for f in Path(run["_dir"]).iterdir():
            if f.suffix in (".json", ".html", ".xml"):
                text = f.read_text(encoding="utf-8")
                self.assertNotIn("s3cr3t-VALUE", text, f.name)
                self.assertNotIn("hunter22", text, f.name)
        self.assertEqual(run["variables"]["db_password"], redaction.REDACTED)

    def test_consolidated_outputs_written(self):
        run = self.run_t(_test([WAIT(1, "a"), WAIT(2, "b"), WAIT(3, "a")]))
        d = Path(run["_dir"])
        self.assertTrue((d / "report.html").exists() and (d / "junit.xml").exists() and (d / "run.json").exists())
        self.assertEqual(run["applications"]["total_switches"], 3)
        self.assertIn("a", (d / "report.html").read_text(encoding="utf-8"))

    def test_dry_run_never_reports_pass(self):
        run = self.run_t(_test([WAIT(1, "a")]))
        self.assertEqual(run["status"], "inconclusive")


class RedactionJunitTests(unittest.TestCase):
    def test_name_heuristics_and_declared(self):
        self.assertTrue(redaction.is_secret_name("Admin_Password"))
        self.assertTrue(redaction.is_secret_name("custom", declared=["custom"]))
        self.assertFalse(redaction.is_secret_name("customer_id"))

    def test_short_secret_values_do_not_scrub_innocent_text(self):
        run = {"steps": [{"error": "step 1 ok"}], "variables": {"pin": "1"}}
        self.assertEqual(redaction.redact_run(run, {"pin": "1"})["steps"][0]["error"], "step 1 ok")

    def test_junit_status_mapping_and_validity(self):
        run = {"test": "t", "status": "failed", "started_at": "now", "summary": {"duration_ms": 1500, "not_run": 1},
               "steps": [{"id": 1, "status": "passed", "app": "web", "description": "ok", "duration_ms": 10},
                         {"id": 2, "status": "failed", "app": "desktop", "description": "bad \x00 <&>", "error": "boom \x07", "duration_ms": 20},
                         {"id": 3, "status": "skipped", "detail": "dry", "app": "web"}]}
        root = ET.fromstring(build_junit(run))
        self.assertEqual((root.get("tests"), root.get("failures"), root.get("skipped")), ("4", "1", "2"))
        cases = root.findall("testcase")
        self.assertEqual(cases[1].get("classname"), "desktop")
        self.assertIsNotNone(cases[1].find("failure"))
        self.assertIsNotNone(cases[2].find("skipped"))

    def test_junit_invalid_run_is_a_failure_not_a_pass(self):
        root = ET.fromstring(build_junit({"test": "t", "status": "invalid", "error": "bad alias", "steps": [], "summary": {}}))
        self.assertEqual(root.get("errors"), "1")
        self.assertIsNotNone(root.find("testcase/failure"))


class LocatorTests(unittest.TestCase):
    def setUp(self):
        self.repo = locators.LocatorRepository(_ws() / "locators.json")
        self.repo.add(locators.Locator("Save", "desktop", "automation_id", "btnSave", control_type="Button"))
        self.repo.add(locators.Locator("Save", "browser", "css", "button#save"))

    def test_scoped_resolution_never_crosses_applications(self):
        self.assertEqual(self.repo.resolve("save", "desktop").value, "btnSave")
        self.assertEqual(self.repo.resolve("Save", "browser").value, "button#save")
        with self.assertRaises(locators.LocatorError) as cm:
            self.repo.resolve("Save", "excel")
        self.assertIn("desktop", str(cm.exception))                # tells you where it does exist
        with self.assertRaises(locators.LocatorError):
            self.repo.resolve("Save", "")                          # no scope = refuse, not "search everything"

    def test_duplicate_in_scope_rejected_and_validation(self):
        with self.assertRaises(locators.LocatorError):
            self.repo.add(locators.Locator("save", "desktop", "name", "Save"))
        with self.assertRaises(locators.LocatorError):
            self.repo.add(locators.Locator("X", "desktop", "bogus", "v"))

    def test_recovery_is_stored_beside_original_and_gated_on_confidence(self):
        loc = self.repo.resolve("Save", "desktop")
        self.assertFalse(self.repo.record_recovery(loc.id, "name", "Save As", 0.4, {}))
        self.assertTrue(self.repo.record_recovery(loc.id, "name", "Save As", 0.95, {"method": "ocr"}))
        again = self.repo.resolve("Save", "desktop")
        self.assertEqual(again.value, "btnSave")                    # original preserved
        self.assertEqual(again.recovered[0]["value"], "Save As")

    def test_best_strategy_prefers_strongest(self):
        self.assertEqual(locators.best_strategy({"xpath": "//a", "automation_id": "id1", "text": "t"}), ("automation_id", "id1"))
        self.assertIsNone(locators.best_strategy({}))

    def test_corrupt_repository_is_an_error_not_silent_empty(self):
        self.repo.path.write_text("{not json", encoding="utf-8")
        with self.assertRaises(locators.LocatorError):
            self.repo.list()


class PersistenceTests(unittest.TestCase):
    def setUp(self):
        self.ws = _ws()
        (self.ws / "tests").mkdir(parents=True, exist_ok=True)

    def write(self, name, data):
        d = self.ws / "tests" / name
        d.mkdir(parents=True, exist_ok=True)
        (d / "test.json").write_text(json.dumps(data), encoding="utf-8")
        return d

    def test_old_v2_loads_migrates_in_memory_and_original_preserved_on_save(self):
        d = self.write("old", {"schema": "visionauto.test/2", "name": "old", "app": {"process": "x.exe", "title": "X"}, "steps": []})
        before = (d / "test.json").read_bytes()
        t, _ = testfile.load_test(d)
        self.assertEqual((d / "test.json").read_bytes(), before)    # load never rewrites
        self.assertEqual(t["schema_version"], testfile.SCHEMA_VERSION)
        self.assertEqual(t["applications"][0]["alias"], "default")
        testfile.save_test(t, d)
        self.assertEqual((d / "test.pre-v3.json").read_bytes(), before)
        self.assertNotIn("migrated_from", json.loads((d / "test.json").read_text()))

    def test_multi_app_roundtrip(self):
        t = testfile.new_test("multi")
        t["applications"] = [{"alias": "a", "mode": "launch", "depends_on": ["b"]}, {"alias": "b"}]
        t["steps"] = [WAIT(1, "a")]
        p = testfile.save_test(t)
        back, _ = testfile.load_test(p)
        self.assertEqual(back["applications"][0]["depends_on"], ["b"])
        self.assertEqual(back["steps"][0]["app"], "a")

    def test_invalid_schema_rejected(self):
        for bad in ({"schema": "something/else", "steps": []}, {"schema": "visionauto.test/2", "steps": "no"},
                    {"schema": "visionauto.test/2", "schema_version": 99, "steps": []}, {"schema_version": True, "steps": []}):
            d = self.write("bad", bad)
            with self.assertRaises(testfile.TestFormatError, msg=bad):
                testfile.load_test(d)

    def test_non_object_test_is_rejected(self):
        d = self.write("lst", [])
        with self.assertRaises(testfile.TestFormatError):
            testfile.load_test(d)


class ProjectIOTests(unittest.TestCase):
    def setUp(self):
        self.ws = _ws()
        self.reg = self.ws / "applications.json"
        applications.register_app({"id": "crm", "name": "CRM", "alias": "crm", "type": "desktop", "exe_path": r"C:\Users\bob\CRM\crm.exe",
                                   "working_dir": r"C:\Users\bob\CRM", "password": "hunter2", "url": ""}, self.reg)
        t = testfile.new_test("flow")
        t["applications"] = [{"alias": "desktop", "app_id": "crm", "mode": "launch"}]
        t["steps"] = [WAIT(1, "desktop")]
        testfile.save_test(t)
        a = testfile.test_dir("flow") / "assets"
        a.mkdir()
        (a / "shot.png").write_bytes(b"png")

    def test_export_strips_machine_paths_and_secrets(self):
        out = project_io.export_project(["flow"], self.ws / "out.zip", self.reg)
        with zipfile.ZipFile(out) as z:
            blob = "".join(z.read(n).decode("utf-8", "ignore") for n in z.namelist() if n.endswith(".json"))
            self.assertNotIn("bob", blob)
            self.assertNotIn("hunter2", blob)
            self.assertIn("crm.exe", blob)                    # only as a hint
            self.assertIn("tests/flow/assets/shot.png", z.namelist())

    def test_import_on_other_machine_reports_missing_path_and_never_overwrites(self):
        out = project_io.export_project(["flow"], self.ws / "out.zip", self.reg)
        ws2 = _ws()
        reg2 = ws2 / "applications.json"
        r = project_io.import_project(out, registry_path=reg2)
        self.assertEqual(r["tests"], ["flow"])
        self.assertEqual(r["needs_path"][0]["exe_hint"], "crm.exe")        # not silently "working"
        self.assertTrue((ws2 / "tests" / "flow" / "assets" / "shot.png").exists())
        r2 = project_io.import_project(out, registry_path=reg2)             # second import keeps user's copy
        self.assertEqual(r2["tests"], [])
        self.assertTrue(any("already exists" in s for s in r2["skipped"]))
        r3 = project_io.import_project(out, overwrite=True, registry_path=reg2)
        self.assertEqual(r3["tests"], ["flow"])
        self.assertTrue((ws2 / "tests" / "flow" / "test.json.bak").exists())  # data preserved

    def test_path_override_resolves_executable(self):
        out = project_io.export_project(["flow"], self.ws / "out.zip", self.reg)
        ws2 = _ws()
        reg2 = ws2 / "applications.json"
        r = project_io.import_project(out, path_overrides={"crm": r"D:\apps\crm.exe"}, registry_path=reg2)
        self.assertEqual(r["needs_path"], [])
        self.assertEqual(applications.load_registry(reg2)["crm"]["exe_path"], r"D:\apps\crm.exe")

    def test_malicious_archive_rejected(self):
        evil = self.ws / "evil.zip"
        with zipfile.ZipFile(evil, "w") as z:
            z.writestr("../../escape.txt", "x")
            z.writestr("manifest.json", json.dumps({"format": project_io.FORMAT, "tests": []}))
        with self.assertRaises(ValueError):
            project_io.import_project(evil, registry_path=self.ws / "r.json")
        notproj = self.ws / "np.zip"
        with zipfile.ZipFile(notproj, "w") as z:
            z.writestr("readme.txt", "hi")
        with self.assertRaises(ValueError):
            project_io.import_project(notproj, registry_path=self.ws / "r.json")


class FakeProc:
    def __init__(self, pid, name, exe=""):
        self.pid, self.info = pid, {"pid": pid, "name": name, "exe": exe, "create_time": 1.0}


class ProcessKillerTests(unittest.TestCase):
    # pids are far from 1 (init), which is an ancestor of this process in containers and therefore correctly protected
    PROCS = [FakeProc(4001, "Ranorex Studio.exe"), FakeProc(4002, "RanorexSpy.exe"), FakeProc(4003, "UFT.exe"),
             FakeProc(4004, "QtpAutomationAgent.exe"), FakeProc(4005, "chrome.exe"), FakeProc(4006, "notepad.exe"),
             FakeProc(4007, "ranorex_notes_editor.exe"), FakeProc(4008, "")]

    def find(self, **k):
        return pk.find_processes(process_iter=lambda attrs: iter(self.PROCS), **k)

    def test_finds_only_vendor_processes(self):
        names = {f.name for f in self.find()}
        self.assertEqual(names, {"Ranorex Studio.exe", "RanorexSpy.exe", "UFT.exe", "QtpAutomationAgent.exe", "ranorex_notes_editor.exe"})
        self.assertNotIn("chrome.exe", names)

    def test_product_filter(self):
        self.assertEqual({f.product for f in self.find(products=("uft",))}, {"uft"})

    def test_extra_name_is_exact(self):
        got = {f.name for f in self.find(products=(), extra_names=["Notepad.exe"])}
        self.assertEqual(got, {"notepad.exe"})

    def test_never_targets_own_process_or_ancestors(self):
        procs = [FakeProc(os.getpid(), "ranorex_self.exe")]
        self.assertEqual(pk.find_processes(process_iter=lambda a: iter(procs)), [])

    def test_kill_graceful_then_force_and_error_reporting(self):
        class P:
            def __init__(self, pid, behaviour): self.pid, self.b, self.alive = pid, behaviour, True
            def terminate(self):
                if self.b == "denied": raise PermissionError("nope")
                if self.b == "gone": raise ProcessLookupError()
                if self.b == "polite": self.alive = False
            def is_running(self): return self.alive
            def kill(self): self.alive = False
        table = {10: P(10, "polite"), 11: P(11, "stubborn"), 12: P(12, "denied"), 13: P(13, "gone")}
        found = [pk.Found(pid, f"ranorex{pid}.exe", "ranorex") for pid in table]
        res = {r["pid"]: r["result"] for r in pk.kill_processes(found, grace_s=0.2, process_factory=lambda pid: table[pid])}
        self.assertEqual(res, {10: "terminated", 11: "killed", 12: "denied", 13: "already_gone"})

    def test_list_mode_never_kills(self):
        with patch.object(pk, "find_processes", return_value=[pk.Found(99, "UFT.exe", "uft")]), patch.object(pk, "kill_processes") as k:
            self.assertEqual(pk.main([]), 0)
            k.assert_not_called()

    def test_kill_requires_confirmation_unless_yes(self):
        found = [pk.Found(99, "UFT.exe", "uft")]
        with patch.object(pk, "find_processes", return_value=found), patch.object(pk, "kill_processes", return_value=[{"pid": 99, "name": "UFT.exe", "result": "terminated"}]) as k:
            with patch("builtins.input", return_value="n"):
                self.assertEqual(pk.main(["--kill"]), 1)
            k.assert_not_called()
            with patch("builtins.input", return_value="y"):
                self.assertEqual(pk.main(["--kill"]), 0)
            self.assertEqual(k.call_count, 1)
            self.assertEqual(pk.main(["--kill", "--yes"]), 0)

    def test_kill_with_failures_returns_nonzero(self):
        found = [pk.Found(99, "UFT.exe", "uft")]
        with patch.object(pk, "find_processes", return_value=found), patch.object(pk, "kill_processes", return_value=[{"pid": 99, "name": "UFT.exe", "result": "denied"}]):
            self.assertEqual(pk.main(["--kill", "--yes"]), 3)

    def test_real_psutil_listing_does_not_crash(self):
        try:
            import psutil  # noqa: F401
        except ImportError:
            self.skipTest("psutil not installed")
        self.assertIsInstance(pk.find_processes(), list)

    def test_own_children_are_protected(self):
        """A child of this process is never killed, even if it is named like a Ranorex binary."""
        try:
            import psutil
        except ImportError:
            self.skipTest("psutil not installed")
        import subprocess
        import sys
        d = Path(tempfile.mkdtemp())
        exe = d / "RanorexAgent.exe"
        if os.name == "nt":
            self.skipTest("symlinked interpreter is POSIX-only")
        exe.symlink_to(sys.executable)
        child = subprocess.Popen([str(exe), "-c", "import time; time.sleep(30)"])
        try:
            self.assertNotIn(child.pid, [f.pid for f in pk.find_processes()])
        finally:
            child.kill()
            child.wait()

    def test_real_kill_of_a_detached_lookalike_process(self):
        """End-to-end with a REAL process: an unrelated (reparented) process named like a Ranorex binary is found and stopped."""
        try:
            import psutil
        except ImportError:
            self.skipTest("psutil not installed")
        import subprocess
        import sys
        import time
        if os.name == "nt":
            self.skipTest("POSIX detach trick; Windows run is covered by docs/TESTING_AND_VERIFICATION.md")
        d = Path(tempfile.mkdtemp())
        exe = d / "UFT.exe"
        exe.symlink_to(sys.executable)
        marker = f"va_marker_{os.getpid()}"
        subprocess.run(["sh", "-c", f"setsid '{exe}' -c 'import time; time.sleep(60)  # {marker}' >/dev/null 2>&1 &"], check=True)
        found = []
        for _ in range(40):
            found = [f for f in pk.find_processes(products=("uft",)) if f.exe.startswith(str(d)) or "UFT" in f.name]
            if found:
                break
            time.sleep(0.1)
        try:
            self.assertTrue(found, "detached UFT.exe lookalike was not found")
            out = pk.kill_processes(found, grace_s=3)
            self.assertIn(out[0]["result"], ("terminated", "killed"))
            time.sleep(0.2)
            self.assertFalse(any(psutil.pid_exists(f.pid) and psutil.Process(f.pid).status() != psutil.STATUS_ZOMBIE for f in found))
        finally:
            for f in found:
                try:
                    psutil.Process(f.pid).kill()
                except Exception:
                    pass

if __name__ == "__main__":
    unittest.main()
