import tempfile
import unittest
from pathlib import Path

from core.reports.report import _shot, build_html


class ReportSafetyTests(unittest.TestCase):
    def test_report_escapes_user_values_and_embeds_only_local_screenshots(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            report = build_html({
                "title": "<script>alert(1)</script>", "test": "unsafe", "status": "failed",
                "started_at": "now", "run_id": "1", "environment": {"os": "Windows <host>", "python": "3"},
                "summary": {"total": 1, "passed": 0, "failed": 1, "duration_ms": 3},
                "steps": [{"id": 1, "description": "<img src=x onerror=alert(2)>", "status": "failed",
                           "method": "ocr", "locator_confidence": 0.8,
                           "locator_evidence": {"matched_text": "<unsafe>"},
                           "error": "failure", "screenshot": "../../secret.png",
                           "validations": [{"status": "failed", "description": "value check",
                                            "expected": "<wanted>", "actual": "<actual>"}]}]}, root)
            self.assertIn("&lt;script&gt;alert(1)&lt;/script&gt;", report)
            self.assertIn("confidence 0.800", report)
            self.assertIn("expected: &quot;&lt;wanted&gt;&quot;", report)
            self.assertIn("actual: &quot;&lt;actual&gt;&quot;", report)
            self.assertNotIn("data:image", report)
            self.assertEqual(_shot(root, "../../secret.png"), "")


if __name__ == "__main__":
    unittest.main()
