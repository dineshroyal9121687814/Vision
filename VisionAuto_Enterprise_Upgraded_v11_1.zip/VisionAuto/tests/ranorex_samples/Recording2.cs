using System;
using Ranorex;

namespace Demo
{
    public partial class Recording2 : ITestModule
    {
        void ITestModule.Run()
        {
            Mouse.DefaultMoveTime = 300;
            Init();
            Host.Local.RunApplication("calc.exe", "", "", false);
            Delay.Milliseconds(500);
            repo.Calculator.Buttons.Five.Click();
            repo.Calculator.Buttons.Plus.Click(Location.Center);
            repo.Calculator.Buttons.Five.Click();
            repo.Calculator.Buttons.Equals.Click();
            repo.Calculator.Buttons.Five.MoveTo();
            Keyboard.Press("{LControlKey down}c{LControlKey up}");
            repo.Calculator.Display.PressKeys("Hello{Tab}World{Return}");
            Report.Log(ReportLevel.Info, "Mouse", "done");
            Validate.Exists(repo.Calculator.DisplayInfo);
            Validate.NotExists(repo.Calculator.Buttons.PlusInfo);
            Validate.AttributeEqual(repo.Calculator.DisplayInfo, "Text", "Display is 10");
            repo.Calculator.Buttons.Equals.DoubleClick();
            SomeCustomHelper.Do();
        }
    }
}
