using System;
using Ranorex;

namespace Demo
{
    public partial class Recording1 : ITestModule
    {
        void ITestModule.Run()
        {
            Mouse.DefaultMoveTime = 300;
            Keyboard.DefaultKeyPressTime = 100;
            Delay.SpeedFactor = 1.0;
            Init();

            Host.Local.RunApplication("calc.exe", "", "", false);
            Report.Log(ReportLevel.Info, "Mouse", "Click Five");
            repo.Calculator.Buttons.Five.Click();
            repo.Calculator.Buttons.Plus.Click(Location.Center);
            repo.Calculator.Buttons.Five.Click();
            Delay.Milliseconds(200);
            repo.Calculator.Buttons.Equals.Click();
            Validate.Exists(repo.Calculator.DisplayInfo);
            Validate.AttributeEqual(repo.Calculator.DisplayInfo, "Text", "10");
            Keyboard.Press("{LControlKey down}c{LControlKey up}");
            string total = repo.Calculator.Display.Text;
            int retries = 3;
            if (retries > 1)
            {
                repo.Calculator.Buttons.Equals.DoubleClick();
            }
            Report.Screenshot();
            SomeWeirdCustomHelper.DoThing(total);
        }
    }
}
