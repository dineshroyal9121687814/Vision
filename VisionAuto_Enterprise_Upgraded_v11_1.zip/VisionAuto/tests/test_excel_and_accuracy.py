"""Regression tests for: Calculator 'windows match explorer.exe' failure, Excel launch, no silent skipping, dropdown scrolling.
Logic tests with fakes - they do NOT prove Excel works on a real Windows machine (docs/WINDOWS_E2E_TEST_RESULTS.md)."""
import os
import tempfile
import unittest
from unittest import mock

from tests.helpers import use_temp_workspace

use_temp_workspace()

from core.automation.errors import AmbiguousTarget                                    # noqa: E402
from core.playback.backend import DryRunBackend                                       # noqa: E402
from core.playback.player import Player                                               # noqa: E402
from core.playback.resolver import ElementNotFound, Resolution                         # noqa: E402
from core.system import excel_launch, launcher                                         # noqa: E402

EXPLORER_WINDOWS = [{"hwnd": i, "title": t, "process": "explorer.exe"} for i, t in enumerate(
    ["", "Program Manager", "Taskbar"] + [f"Folder {n}" for n in range(10)], 1)]       # the 13 windows from the screenshot


class OpenAppRegression(unittest.TestCase):
    """Screenshot bug: 'Open Calculator' -> '13 windows match process explorer.exe'."""

    def player(self):
        p = Player({"name": "x", "steps": []}, {"timeout_s": 1, "settle_wait": False}, backend=DryRunBackend())
        p.dry_run = False
        return p

    def test_open_app_never_demands_the_recorded_launcher_window(self):
        p = self.player()
        step = {"id": 1, "type": "open_app", "params": {"name": "Calculator"}, "window": {"title": "", "process": "explorer.exe"}}
        with mock.patch.object(p, "_enumerate_windows", return_value=EXPLORER_WINDOWS), \
             mock.patch("core.playback.player.launcher.open_application", return_value={"method": "known:calc.exe", "tried": []}), \
             mock.patch("core.playback.player.launcher.plan"):
            r = p.run_step(step)
        self.assertEqual(r["status"], "passed", r.get("error"))

    def test_process_only_legacy_window_is_not_enforced_for_normal_steps_either(self):
        p = self.player()
        p._resolve = lambda tg, st, tag, timeout=None: Resolution(5, 5, "native", 1.0)
        step = {"id": 1, "type": "click", "target": {"name": "OK"}, "params": {}, "window": {"title": "", "process": "explorer.exe"}}
        with mock.patch.object(p, "_enumerate_windows", return_value=EXPLORER_WINDOWS):
            r = p.run_step(step)
        self.assertEqual(r["status"], "passed", r.get("error"))      # same as before the strict-window work

    def test_an_explicit_process_choice_is_still_strict(self):
        p = self.player()
        step = {"id": 1, "type": "click", "target": {"name": "OK"}, "params": {},
                "window": {"title": "", "process": "explorer.exe", "match": "contains"}}
        with mock.patch.object(p, "_enumerate_windows", return_value=EXPLORER_WINDOWS), \
             mock.patch("core.playback.player.winenv.foreground_window", return_value={"hwnd": 0}):
            r = p.run_step(step)
        self.assertEqual(r["failure_kind"], "AmbiguousTarget")


class LauncherFixes(unittest.TestCase):
    def test_exe_path_with_spaces_stays_one_argument(self):
        exe = r"C:\Program Files\Microsoft Office\root\Office16\EXCEL.EXE"
        self.assertEqual(launcher.split_command(exe), [exe])
        self.assertEqual(launcher.split_command(f'"{exe}" /safe'), [exe, "/safe"])
        self.assertEqual(launcher.split_command(exe + " /safe"), [exe, "/safe"])
        self.assertEqual(launcher.split_command("calc.exe"), ["calc.exe"])
        self.assertEqual(launcher.split_command("ms-settings:"), ["ms-settings:"])

    def test_policy_check_sees_the_real_program_not_the_first_word(self):
        with self.assertRaises(ValueError):
            launcher.plan(exe=r"C:\Windows\System32\cmd.exe /c calc")
        self.assertTrue(launcher.plan(exe=r"C:\Program Files\App One\app.exe"))

    def test_bare_exe_not_on_path_falls_back_to_shell_execute(self):
        m = launcher.Method("exe", "excel.exe", "known:excel.exe")
        with mock.patch("core.system.launcher.subprocess.Popen", side_effect=FileNotFoundError), \
             mock.patch.object(os, "startfile", create=True) as sf:
            launcher.start_method(m)
        sf.assert_called_once_with("excel.exe")

    def test_excel_is_a_known_app(self):
        self.assertEqual(launcher.plan("Excel")[0].value, "excel.exe")
        self.assertEqual(launcher.plan("Microsoft Excel")[0].value, "excel.exe")


class FakeExcel:
    """Minimal COM stand-in: Ready flips after N polls, workbooks by FullName."""

    def __init__(self, ready_after=0, books=(), pv=None):
        self.polls, self.ready_after, self.pv = 0, ready_after, pv
        self.books = [self._wb(b) for b in books]
        self.Visible, self.Hwnd = False, 900
        self.opened = []
        self.Workbooks = mock.Mock(Count=len(self.books))
        self.Workbooks.Item = lambda i: self.books[i - 1]
        self.Workbooks.Open = self._open
        self.ProtectedViewWindows = mock.Mock(Count=1 if pv else 0)
        self.ProtectedViewWindows.Item = lambda i: self.pv

    @staticmethod
    def _wb(path):
        wb = mock.Mock(FullName=path, Name=os.path.basename(path), Saved=True)
        wb.Windows = lambda i: mock.Mock(Hwnd=777)
        return wb

    @property
    def Ready(self):
        self.polls += 1
        return self.polls > self.ready_after

    def _open(self, path):
        self.opened.append(path)
        self.books.append(self._wb(path))
        self.Workbooks.Count = len(self.books)


class ExcelLaunch(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.book = os.path.join(self.tmp.name, "Budget 2026.xlsx")           # note the space
        open(self.book, "w").close()

    def run_open(self, app_seq, path="", **kw):
        seq = iter(app_seq)
        last = {"v": None}

        def attach():
            try:
                last["v"] = next(seq)
            except StopIteration:
                pass
            return last["v"]
        fg = {"v": 0}
        popen, startfile = mock.Mock(), mock.Mock()
        exe = kw.pop("exe", r"C:\Program Files\Microsoft Office\root\Office16\EXCEL.EXE")
        base = dict(attach=attach, find_exe=lambda: exe,
                    popen=popen, startfile=startfile, sleep=lambda s: None, clock=iter(range(0, 10000)).__next__,
                    focus=lambda h: fg.update(v=h), foreground=lambda: fg["v"], is_window=lambda h: True, timeout_s=50)
        base.update(kw)
        out = excel_launch.open_excel(path, **base)
        return out, popen, startfile

    def test_launches_with_spaced_exe_and_file_then_waits_for_ready_and_workbook(self):
        app = FakeExcel(ready_after=3, books=[self.book])
        out, popen, _ = self.run_open([None, None, app], self.book)
        popen.assert_called_once_with([r"C:\Program Files\Microsoft Office\root\Office16\EXCEL.EXE", self.book])
        self.assertTrue(out["launched"])
        self.assertEqual((out["hwnd"], out["workbook"]), (777, "Budget 2026.xlsx"))
        self.assertGreaterEqual(app.polls, 4)                                   # not reported until Application.Ready

    def test_existing_instance_is_reused_and_workbook_opened_in_it(self):
        app = FakeExcel(books=[os.path.join(self.tmp.name, "other.xlsx")])
        out, popen, _ = self.run_open([app], self.book)
        popen.assert_not_called()
        self.assertEqual(app.opened, [self.book])
        self.assertFalse(out["launched"])

    def test_already_open_workbook_is_selected_not_reopened(self):
        app = FakeExcel(books=[os.path.join(self.tmp.name, "other.xlsx"), self.book])
        out, _, _ = self.run_open([app], self.book)
        self.assertEqual(app.opened, [])
        self.assertEqual(out["workbook"], "Budget 2026.xlsx")

    def test_no_exe_found_uses_shell_execute(self):
        app = FakeExcel(books=[])
        _, popen, startfile = self.run_open([None, app], "", exe="")
        popen.assert_not_called()
        startfile.assert_called_once_with("excel.exe")

    def test_missing_file_and_wrong_type_fail_before_anything_starts(self):
        with self.assertRaises(ValueError):
            self.run_open([None], os.path.join(self.tmp.name, "nope.xlsx"))
        txt = os.path.join(self.tmp.name, "a.txt")
        open(txt, "w").close()
        with self.assertRaises(ValueError):
            self.run_open([None], txt)

    def test_never_ready_is_a_failure_not_a_success(self):
        with self.assertRaises(ValueError) as cm:
            self.run_open([FakeExcel(ready_after=10**6)], "", timeout_s=5)
        self.assertIn("never became ready", str(cm.exception))

    def test_cannot_bring_to_front_is_a_failure(self):
        app = FakeExcel(books=[self.book])
        with self.assertRaises(ValueError) as cm:
            self.run_open([app], self.book, foreground=lambda: 1)
        self.assertIn("front", str(cm.exception))

    def test_protected_view_is_reported_not_bypassed(self):
        pv = mock.Mock()
        pv.Workbook.FullName = self.book
        with self.assertRaises(ValueError) as cm:
            self.run_open([FakeExcel(pv=pv)], self.book)
        self.assertIn("Protected View", str(cm.exception))
        pv.Edit.assert_not_called()

    def test_save_and_close_are_verified(self):
        app = FakeExcel(books=[self.book])
        wb = app.books[0]
        out = excel_launch.save_workbook(self.book, attach=lambda: app)
        wb.Save.assert_called_once()
        self.assertTrue(out["verified"])
        wb.Saved = False
        with self.assertRaises(ValueError):
            excel_launch.save_workbook(self.book, attach=lambda: app)
        wb.Close.side_effect = lambda SaveChanges: app.books.remove(wb) or setattr(app.Workbooks, "Count", 0)
        self.assertTrue(excel_launch.close_workbook(self.book, save=True, attach=lambda: app)["verified"])
        wb.Close.assert_called_with(SaveChanges=True)

    def test_player_open_app_routes_excel_and_reports_verified(self):
        p = Player({"name": "x", "steps": []}, {"timeout_s": 5, "settle_wait": False}, backend=DryRunBackend())
        p.dry_run = False
        step = {"id": 1, "type": "open_app", "params": {"name": "Excel", "path": self.book}, "window": {}}
        with mock.patch("core.playback.player.launcher.plan"), \
             mock.patch("core.playback.player.excel_launch.open_excel",
                        return_value={"method": "launch", "hwnd": 5, "workbook": "Budget 2026.xlsx", "tried": ["exe"]}) as oe:
            r = p.run_step(step)
        self.assertEqual((r["status"], r["method"]), ("passed", "excel:launch"))
        self.assertEqual(r["outcome" if "outcome" in r else "method"], r.get("outcome", "excel:launch"))
        oe.assert_called_once()


class NothingIsSilentlySkipped(unittest.TestCase):
    def test_default_mode_replays_every_recorded_scroll_and_repeated_click(self):
        from core.settings import validate
        self.assertEqual(validate({})["scroll_mode"], "exact")
        tg = {"x": 11, "y": 20, "name": "n"}
        steps = [{"id": i, "type": t, "target": dict(tg), "params": pr, "window": {}} for i, (t, pr) in enumerate(
            [("click", {}), ("click", {}), ("click", {}), ("scroll", {"dx": 0, "dy": -3}), ("double_click", {})], 1)]
        p = Player({"name": "x", "steps": steps}, {"timeout_s": 1, "settle_wait": False, "scroll_mode": "exact"},
                   backend=DryRunBackend(), dry_run=True)
        run = p.run()
        self.assertEqual(len(run["steps"]), 5)                           # (dry run reports 'skipped' = not verified, by design)
        self.assertTrue(all("dry run" in r["detail"] for r in run["steps"]))
        kinds = [a[0] for a in p.backend.actions if a[0] in ("click", "scroll", "double_click")]
        self.assertEqual(kinds[:3], ["click"] * 3)                      # the intentional repeated clicks all happen
        self.assertEqual(len(kinds), 5)
        self.assertFalse([r for r in run["steps"] if r.get("skipped_by_policy")])

    def test_adaptive_skip_is_labelled_when_the_user_opted_in(self):
        p = Player({"name": "x", "steps": []}, {"timeout_s": 1, "settle_wait": False, "scroll_mode": "adaptive"}, backend=DryRunBackend())
        p.dry_run = False
        p._skip_scroll = lambda step, pr: True
        p._ensure_window = lambda s: None
        r = p.run_step({"id": 1, "type": "scroll", "target": {"x": 1, "y": 1}, "params": {"dx": 0, "dy": -3}, "window": {}})
        self.assertEqual(r["outcome"], "skipped_by_policy")
        self.assertIn("scroll_mode=adaptive", r["skipped_by_policy"])


class DropdownScrolling(unittest.TestCase):
    def player(self, appear_after):
        p = Player({"name": "x", "steps": []}, {"timeout_s": 1, "settle_wait": False}, backend=DryRunBackend())
        p.dry_run = False
        p._ensure_window = lambda s: None
        state = {"scrolls": 0}
        p.uia = mock.Mock(select_option=mock.Mock(return_value=False), read_value=mock.Mock(side_effect=lambda x, y: "Zimbabwe"))
        calls = []

        def resolve(tg, st, tag, timeout=None):
            if tag != "option":
                return Resolution(50, 60, "native", 1.0)
            calls.append(1)
            if appear_after is None or state["scrolls"] < appear_after:
                raise ElementNotFound("not visible")
            return Resolution(55, 300, "native", 1.0)
        p._resolve = resolve
        p._scroll_notches = lambda x, y, dx, dy: state.update(scrolls=state["scrolls"] + 1)
        return p, state

    STEP = {"id": 1, "type": "select_option", "target": {"name": "Country", "role": "ComboBox"}, "params": {"text": "Zimbabwe"}, "window": {}}

    def test_scrolls_until_the_option_is_visible_then_clicks_it_and_verifies(self):
        p, state = self.player(appear_after=3)
        r = p.run_step(dict(self.STEP))
        self.assertEqual(r["status"], "passed", r.get("error"))
        self.assertEqual(state["scrolls"], 3)
        self.assertEqual(r["outcome"], "verified")
        self.assertIn(("click", 55, 300, "left", 1), p.backend.actions)       # clicked where the option IS NOW
        self.assertEqual(r["scrolled"], 3)

    def test_falls_back_to_type_ahead_when_the_option_never_shows(self):
        p, state = self.player(appear_after=None)
        r = p.run_step({**self.STEP, "params": {"text": "Zimbabwe", "max_scrolls": 2}})
        self.assertEqual(r["status"], "passed", r.get("error"))
        self.assertIn("type-ahead", r["input_method"])
        self.assertTrue([a for a in p.backend.actions if a[0] == "type"])

    def test_duplicate_option_names_stop_safely(self):
        p, _ = self.player(appear_after=0)
        orig = p._resolve
        p._resolve = lambda tg, st, tag, timeout=None: (_ for _ in ()).throw(AmbiguousTarget("2 options named Zimbabwe")) if tag == "option" else orig(tg, st, tag, timeout)
        r = p.run_step(dict(self.STEP))
        self.assertEqual(r["failure_kind"], "AmbiguousTarget")

    def test_wrong_value_after_selection_fails(self):
        p, _ = self.player(appear_after=0)
        p.uia.read_value = lambda x, y: "Zambia"
        r = p.run_step(dict(self.STEP))
        self.assertEqual(r["failure_kind"], "PostconditionFailed")


if __name__ == "__main__":
    unittest.main()
