"""Step palette, suggestions, AI custom-step store, custom step execution, one test x many data rows."""
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from tests import helpers                                                          # noqa: E402
from core import validation                                                        # noqa: E402
from core.playback.backend import DryRunBackend                                    # noqa: E402
from core.playback.player import Player                                            # noqa: E402
from core.steplib import catalog, custom                                           # noqa: E402

GOOD = '''
import time
def run(ctx, who="x", n="1"):
    ctx.type("hello " + who)
    ctx.set("greeted", who)
    ctx.expect(len(who) > 0, "a name was given")
    return who
'''


class Catalog(unittest.TestCase):
    def test_every_catalog_type_is_known_to_validation(self):
        missing = [t for t in catalog.action_types() if t not in validation.KNOWN_STEP_TYPES]
        self.assertEqual(missing, [])

    def test_build_drag_drop_between_windows(self):
        s = catalog.build_step("drag_drop", {"target": {"name": "a.txt"}, "window": {"title": "Src"},
                                             "to": {"name": "Folder"}, "to_window": {"title": "Dst"}}, 4)
        self.assertEqual((s["to"]["name"], s["to_window"]["title"], s["window"]["title"]), ("Folder", "Dst", "Src"))

    def test_required_field_is_named(self):
        with self.assertRaisesRegex(ValueError, "Option text"):
            catalog.build_step("select_option", {"target": {"name": "Country"}})

    def test_number_is_validated_and_params_filled(self):
        s = catalog.build_step("wait", {"seconds": "2"})
        self.assertEqual(s["params"]["seconds"], 2)
        with self.assertRaises(ValueError):
            catalog.build_step("wait", {"seconds": "soon"})

    def test_suggestions_follow_last_step_and_data(self):
        out = catalog.suggest("type", ["username"])
        self.assertTrue(any(o["preset"].get("text") == "${username}" for o in out))
        self.assertEqual(out[0]["type"], "key")

    def test_grouped_has_dropdown_choices(self):
        self.assertIn("Forms & lists", catalog.grouped())


class CustomSteps(unittest.TestCase):
    def setUp(self):
        helpers.use_temp_workspace()

    def test_unsafe_code_is_rejected(self):
        for bad in ("import os\ndef run(ctx): pass", "def run(ctx):\n    open('x')", "def run(ctx):\n    ().__class__",
                    "def run(ctx):\n    eval('1')", "def other(): pass", "def run(a): pass"):
            self.assertTrue(custom.check_source(bad), bad)
        with self.assertRaises(custom.CustomStepError):
            custom.save("evil", "import subprocess\ndef run(ctx): pass")

    def test_draft_does_not_run_until_approved(self):
        custom.save("greet", GOOD, "greets")
        ctx = custom.Context(DryRunBackend(), {})
        with self.assertRaisesRegex(custom.CustomStepError, "draft"):
            custom.run("greet", {"who": "Ann"}, ctx)
        custom.approve("greet")
        out = custom.run("greet", {"who": "Ann"}, ctx)
        self.assertEqual(out["returned"], "Ann")
        self.assertEqual(ctx.vars["greeted"], "Ann")

    def test_failed_expectation_fails_the_step(self):
        custom.save("greet", GOOD)
        custom.approve("greet")
        with self.assertRaisesRegex(custom.CustomStepError, "a name was given"):
            custom.run("greet", {"who": ""}, custom.Context(DryRunBackend(), {}))

    def test_generate_uses_llm_and_saves_draft(self):
        class FakeLLM:
            def generate(self, prompt):
                return "```python\n" + GOOD + "\n```"
        meta = custom.generate("say hello", "say_hello", llm=FakeLLM())
        self.assertEqual((meta["status"], meta["author"]), ("draft", "ai"))
        self.assertIn("say_hello", custom.names())
        self.assertNotIn("say_hello", custom.names(approved_only=True))

    def test_generate_without_ai_gives_guidance(self):
        class Off:
            def generate(self, prompt):
                return None
        with self.assertRaisesRegex(custom.CustomStepError, "not available"):
            custom.generate("x", "nothing", llm=Off())

    def test_player_runs_approved_custom_step_with_variables(self):
        custom.save("greet", GOOD)
        custom.approve("greet")
        step = {"id": 1, "type": "custom", "t_ms": 0, "window": {}, "validations": [], "description": "greet",
                "params": {"method": "greet", "args": {"who": "${name}"}}}
        backend = DryRunBackend()
        test = {"name": "c", "steps": [step], "applications": [], "variables": {"name": "Zed"}}
        out = Player(test, {"timeout_s": 1.0, "settle_wait": False}, backend=backend, dry_run=False).run()
        self.assertEqual(out["status"], "passed", out)
        self.assertIn(("type", "hello Zed"), backend.actions)

    def test_player_refuses_unknown_method_cleanly(self):
        step = {"id": 1, "type": "custom", "t_ms": 0, "window": {}, "validations": [], "description": "x",
                "params": {"method": "nope"}}
        test = {"name": "c", "steps": [step], "applications": [], "variables": {}}
        out = Player(test, {"timeout_s": 1.0, "settle_wait": False}, backend=DryRunBackend(), dry_run=False).run()
        self.assertEqual(out["status"], "failed")
        self.assertIn("does not exist", out["steps"][0]["error"])


class OneTestManyRows(unittest.TestCase):
    def test_runs_once_per_data_row_with_values_substituted(self):
        helpers.use_temp_workspace()
        s = {"id": 1, "type": "type", "t_ms": 0, "window": {}, "validations": [], "description": "t", "params": {"text": "${user}"}}
        backend = DryRunBackend()
        rows = [{"user": "ann"}, {"user": "bob"}, {"user": "cy"}]
        out = Player({"name": "d", "steps": [s], "applications": [], "variables": {}}, {"timeout_s": 1.0},
                     backend=backend, dry_run=True, data=rows).run()
        self.assertEqual([a[1] for a in backend.actions if a[0] == "type"], ["ann", "bob", "cy"])
        self.assertEqual(out["data"]["rows_run"], 3)


if __name__ == "__main__":
    unittest.main()
