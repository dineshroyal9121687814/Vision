import tempfile
import unittest
from pathlib import Path

from tests import helpers  # noqa: F401
from core import testfile
from core.importers.uft.importer import import_script
from core.importers.uft.runner import run_script, static_check
from core.importers.uft.vbinterp import BudgetExceeded, Interpreter, StopRun
from core.importers.uft.vbparse import parse
from core.importers.uft.vbruntime import VbError
from core.playback.backend import DryRunBackend


def run(src: str, **kw) -> Interpreter:
    it = Interpreter(**kw)
    it.run_program(parse(src))
    return it


def val(src: str, name: str):
    return run(src).globals.vars[name.casefold()]


class VbLanguageTests(unittest.TestCase):
    def test_loops_functions_and_coercion(self):
        src = """
Function Fact(n)
  If n <= 1 Then
    Fact = 1
  Else
    Fact = n * Fact(n - 1)
  End If
End Function
t = 0
For i = 10 To 1 Step -3: t = t + i: Next
s = "a" & 1 + 2 & "b"
r = Fact(6)
"""
        it = run(src)
        self.assertEqual(it.globals.vars["r"], 720)
        self.assertEqual(it.globals.vars["t"], 10 + 7 + 4 + 1)
        self.assertEqual(it.globals.vars["s"], "a3b")

    def test_select_do_exit_and_with_dictionary(self):
        src = """
Set d = CreateObject("Scripting.Dictionary")
d.Add "k", 5
d("j") = 7
n = 0
Do Until n >= 100
  n = n + 1
  If n = 3 Then Exit Do
Loop
Select Case d("j")
  Case 1 To 5: z = "low"
  Case Is >= 7: z = "high"
End Select
For Each k In d.Keys: ks = ks & k: Next
"""
        it = run(src)
        g = it.globals.vars
        self.assertEqual((g["n"], g["z"], g["ks"]), (3, "high", "kj"))

    def test_on_error_resume_next_and_err_object(self):
        it = run("On Error Resume Next\nx = 1 / 0\ne = Err.Number\nd = Err.Description\nOn Error Goto 0\nf = Err.Number")
        g = it.globals.vars
        self.assertEqual((g["e"], g["f"]), (11, 0))
        self.assertIn("zero", g["d"].lower())
        with self.assertRaises(VbError):
            run("x = 1 / 0")

    def test_arrays_byref_and_split_join(self):
        it = run("Dim a(2)\na(1) = 5\nSub Inc(ByRef v)\nv = v + 1\nEnd Sub\nInc a(1)\nn = 1\nInc n\n"
                 "p = Split(\"a,b,c\", \",\")\nj = Join(p, \"-\") & UBound(p)")
        self.assertEqual(it.globals.vars["n"], 2)
        self.assertEqual(it.globals.vars["j"], "a-b-c2")

    def test_budget_stops_runaway_loops_and_dangerous_objects_are_blocked(self):
        with self.assertRaises(BudgetExceeded):
            run("Do\nx = x + 1\nLoop", max_statements=5000)
        with self.assertRaises(VbError):
            run('Set s = CreateObject("WScript.Shell")')
        with self.assertRaises(VbError):
            run("Function F(n)\nF = F(n + 1)\nEnd Function\nx = F(1)")

    def test_unsupported_statements_fail_loudly_not_silently(self):
        prog = parse("x = Eval(\"1+1\")\nExecute \"y=2\"")
        self.assertEqual(len(prog["unsupported"]), 2)
        with self.assertRaises(VbError):
            Interpreter().run_program(prog)
        self.assertTrue(static_check(prog)["unsupported_constructs"])

    def test_execute_file_is_sandboxed_and_cannot_escape(self):
        from core.importers.uft.uftobjects import UftHost
        host = UftHost.__new__(UftHost)
        host.base_dir = Path(tempfile.mkdtemp()).resolve()
        (host.base_dir / "lib.vbs").write_text("Function Two()\nTwo = 2\nEnd Function", encoding="utf-8")
        self.assertIsNotNone(host.load_library("lib.vbs"))
        self.assertIsNone(host.load_library("../../etc/passwd"))
        self.assertIsNone(host.load_library("C:\\Windows\\win.ini"))


SCRIPT = '''
Dim names, n
names = Array("alice", "bob")
Function Greet(who)
  Greet = "Hello " & who
End Function
For Each n In names
  Window("Notepad").WinEdit("Text Editor").Set Greet(n)
  If Window("Notepad").WinEdit("Text Editor").Exist(1) Then
    Reporter.ReportEvent micPass, "typed", n
  End If
Next
For i = 1 To DataTable.GetRowCount
  Window("Notepad").WinButton("Save").Click
Next
'''


class UftScriptModeTests(unittest.TestCase):
    def setUp(self):
        helpers.use_temp_workspace()
        self.tmp = Path(tempfile.mkdtemp())

    def test_control_flow_script_imports_in_script_mode_and_runs_on_engine(self):
        (self.tmp / "T.vbs").write_text(SCRIPT, encoding="utf-8")
        (self.tmp / "d.csv").write_text("a\n1\n2\n3\n", encoding="utf-8")
        res = import_script(self.tmp / "T.vbs", name="Flow")
        self.assertEqual(res["mode"], "script")
        self.assertEqual(res["report"]["unsupported_count"], 0)
        self.assertTrue(Path(res["ast"]).is_file())
        backend = DryRunBackend()
        out = run_script(res["script"], dry_run=True, backend=backend, data=self.tmp / "d.csv")
        self.assertEqual(out["status"], "inconclusive")
        kinds = [s["type"] for s in out["steps"]]
        self.assertEqual(kinds.count("report"), 2)
        self.assertEqual(kinds.count("type"), 2)
        self.assertEqual(sum(1 for a in backend.actions if a[0] == "click"), 2 + 3)   # 2 Set + 3 data rows

    def test_straight_line_scripts_still_become_native_tests(self):
        (self.tmp / "S.vbs").write_text('Window("Notepad").WinButton("OK").Click\n', encoding="utf-8")
        res = import_script(self.tmp / "S.vbs", name="Simple")
        self.assertNotEqual(res.get("mode"), "script")
        self.assertEqual(len(res["test"]["steps"]), 1)

    def test_failed_ui_step_can_be_caught_with_on_error(self):
        from core.importers.uft.uftobjects import UFT_STEP_FAILED  # noqa: F401
        (self.tmp / "E.vbs").write_text('On Error Resume Next\nSetSecureTest\nWindow("W").WinEdit("p").SetSecure "abc"\n'
                                        'code = Err.Number\nReporter.ReportEvent micDone, "code", code\n', encoding="utf-8")
        res = import_script(self.tmp / "E.vbs", name="Err", force_script=True)
        out = run_script(res["script"], dry_run=True, backend=DryRunBackend())
        reports = [s for s in out["steps"] if s["type"] == "report"]
        self.assertIn("429", reports[0]["description"])       # SetSecure refused, run continued

    def test_migration_report_lists_unsupported_members(self):
        (self.tmp / "U.vbs").write_text('If x Then\nWindow("W").WinObject("o").Object.Foo\nEnd If\n', encoding="utf-8")
        res = import_script(self.tmp / "U.vbs", name="Uns")
        self.assertTrue(res["report"]["manual_review_required"])
        self.assertTrue(any("Object" in u["construct"] for u in res["report"]["unsupported_constructs"]))

    def test_run_action_executes_other_action(self):
        (self.tmp / "Main.vbs").write_text('RunAction "Login", oneIteration\nReporter.ReportEvent micDone, "m", v\n', encoding="utf-8")
        (self.tmp / "Login.vbs").write_text('v = "from-login"\nReporter.ReportEvent micDone, "a", "login ran"\n', encoding="utf-8")
        res = import_script(self.tmp / "Main.vbs", name="Act", force_script=True, actions={"Login": self.tmp / "Login.vbs"})
        out = run_script(res["script"], dry_run=True, backend=DryRunBackend())
        descs = [s["description"] for s in out["steps"] if s["type"] == "report"]
        self.assertTrue(any("login ran" in d for d in descs))


if __name__ == "__main__":
    unittest.main()
