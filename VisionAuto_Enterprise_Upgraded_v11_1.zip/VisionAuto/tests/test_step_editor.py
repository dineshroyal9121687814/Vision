import tempfile
import unittest
from pathlib import Path

import cv2
import numpy as np

from tests.helpers import use_temp_workspace

use_temp_workspace()

from app.gui.step_editor import make_step
from core import testfile
from core.playback.resolver import Resolver


class StepEditorModelTests(unittest.TestCase):
    def test_ranorex_xpath_maps_to_supported_uia_fields(self):
        with tempfile.TemporaryDirectory() as tmp:
            step = make_step(
                "click", Path(tmp), 1, "Ranorex XPath",
                "/form[@title='Calculator']/button[@automationid='sum'][@text='Add']")
        self.assertEqual(step["window"]["title"], "Calculator")
        self.assertEqual(step["target"]["automation_id"], "sum")
        self.assertEqual(step["target"]["text"], "Add")
        self.assertEqual(step["target"]["role"], "Button")
        self.assertEqual(step["target"]["source_locator"]["kind"], "ranorex")

    def test_text_and_action_values_create_native_test_steps(self):
        with tempfile.TemporaryDirectory() as tmp:
            type_step = make_step("type", Path(tmp), 1, "Text", "Search", value="hello")
            wait_step = make_step("wait", Path(tmp), 2, "None", "", value="250")
            hotkey = make_step("hotkey", Path(tmp), 3, "None", "", value="ctrl+s")
        self.assertEqual(type_step["target"]["name"], "Search")
        self.assertEqual(type_step["params"]["text"], "hello")
        self.assertEqual(wait_step["params"]["ms"], 250)
        self.assertEqual(hotkey["params"]["keys"], "ctrl+s")

    def test_image_locator_is_copied_into_test_assets(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            image = np.full((30, 40, 3), 120, dtype=np.uint8)
            source = root / "button.png"
            self.assertTrue(cv2.imwrite(str(source), image))
            test_dir = root / "workspace" / "tests" / "img"
            step = make_step("click", test_dir, 2, "Image", str(source))
            rel = step["target"]["templates"]["crop300"]["path"]
            self.assertEqual(rel, "assets/s002_manual.png")
            self.assertTrue((test_dir / rel).is_file())

    def test_test_definition_edit_has_a_restorable_backup(self):
        with tempfile.TemporaryDirectory() as tmp:
            test = testfile.new_test("editable")
            directory = Path(tmp)
            testfile.save_test(test, directory)
            testfile.backup_test(directory)
            edited = make_step("click", directory, 1, "Text", "Save")
            test["steps"].append(edited)
            testfile.save_test(test, directory)
            restored = testfile.restore_backup(directory)
            self.assertEqual(restored, directory / "test.json")
            saved, _ = testfile.load_test(directory)
            self.assertEqual(saved["steps"], [])

    def test_explicit_coordinate_locator_resolves_without_visual_guessing(self):
        resolver = Resolver(None, {"use_native": False}, grab=lambda: self.fail("fixed coordinate should not search the screen"))
        result = resolver.resolve_once({"x": 31, "y": 47, "locator_mode": "coordinates"}, {})
        self.assertEqual((result.x, result.y, result.method), (31, 47, "coordinates"))


if __name__ == "__main__":
    unittest.main()
