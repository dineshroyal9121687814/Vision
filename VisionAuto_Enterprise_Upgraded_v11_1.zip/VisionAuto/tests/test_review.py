import unittest

from tests.helpers import use_temp_workspace

use_temp_workspace()

from core import review, testfile  # noqa: E402
from core.ai.analyze import suggest_validations  # noqa: E402
from core.ai.describe import describe_step  # noqa: E402


def make_test():
    steps = [
        {"id": 1, "type": "click", "window": {"title": "Settings"},
         "target": {"x": 10, "y": 10, "name": "Dark mode", "role": "CheckBox", "state": {"toggle": "off"},
                    "templates": {"crop100": {"path": "a.png", "click": [50, 50], "size": [100, 100]}}}},
        {"id": 2, "type": "click", "window": {"title": "Settings"},
         "target": {"x": 20, "y": 20, "name": "Profile", "role": "ListItem"}},
        {"id": 3, "type": "type", "window": {"title": "Settings"}, "params": {"text": "hello"},
         "target": {"x": 30, "y": 30, "name": "Search", "role": "Edit"}},
        {"id": 4, "type": "click", "window": {"title": "Save As"}, "target": {"x": 40, "y": 40, "name": "Save", "role": "Button"}},
        {"id": 5, "type": "key", "window": {"title": "Settings"}, "params": {"key": "esc"}},
    ]
    t = testfile.new_test("review_demo")
    t["steps"] = steps
    for s in steps:
        s["description"] = describe_step(s)
        s["validations"] = []
    return t


class ReviewTests(unittest.TestCase):
    def test_options_are_specific_to_the_step(self):
        t = make_test()
        kinds = [o["validation"]["type"] for o in review.validation_options(t["steps"][0])]
        self.assertEqual(kinds[0], "state")                 # checkbox flipped is the most meaningful check
        self.assertIn("image_visible", kinds)
        sel = review.validation_options(t["steps"][1])[0]["validation"]
        self.assertEqual((sel["type"], sel["expected"]), ("state", "selected"))
        typed = [o["validation"]["type"] for o in review.validation_options(t["steps"][2])]
        self.assertIn("text_contains", typed)
        key_opts = review.validation_options(t["steps"][4])
        self.assertEqual([o["validation"]["type"] for o in key_opts], ["window_title_contains"])
        self.assertEqual(key_opts[0]["label"], "Window title contains 'Settings'")

    def test_use_selected_items_as_validation_points(self):
        t = make_test()
        n = review.use_steps_as_validation(t, [1, 2])
        self.assertEqual(n, 2)
        self.assertEqual(t["steps"][0]["validations"][0]["expected"], "on")
        self.assertEqual(review.use_steps_as_validation(t, [1, 2]), 0)     # no duplicates

    def test_suggestions_then_finalize_saves(self):
        t = make_test()
        suggest_validations(t)
        self.assertTrue(any(s.get("suggestions") for s in t["steps"]))
        self.assertEqual(t["steps"][2]["suggestions"][0]["type"], "text_contains")
        self.assertEqual(t["steps"][3]["suggestions"][0]["type"], "window_title_contains")   # Save As closed -> Settings
        d = testfile.test_dir("review_demo")
        d.mkdir(parents=True, exist_ok=True)
        review.finalize(t, d, accepted={3: [0]}, title="My settings test")
        saved, _ = testfile.load_test("review_demo")
        self.assertEqual(saved["title"], "My settings test")
        self.assertEqual(len(saved["steps"][2]["validations"]), 1)
        self.assertTrue(all("suggestions" not in s for s in saved["steps"]))

    def test_delete_steps_renumbers(self):
        t = make_test()
        review.delete_steps(t, [2, 3])
        self.assertEqual([s["id"] for s in t["steps"]], [1, 2, 3])
        self.assertEqual(len(review.rows(t)), 3)

    def test_validation_step_has_no_options(self):
        self.assertEqual(review.validation_options({"type": "validate", "target": {"name": "x"}}), [])


if __name__ == "__main__":
    unittest.main()
