"""v10: dropdown option search (recorded scroll -> whole list -> keyboard) and cell-check caption bug."""
import sys
import unittest
from pathlib import Path
from unittest import mock

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from tests import helpers                                                          # noqa: E402
from core.playback import validators                                               # noqa: E402
from core.playback.backend import DryRunBackend                                    # noqa: E402
from core.playback.player import Player                                            # noqa: E402
from core.playback.resolver import Resolution, Resolver                            # noqa: E402
from core.playback.scrollfind import ScrollFinder                                  # noqa: E402
from core.playback.resolver import ElementNotFound                                 # noqa: E402


class FakeResolver:
    """The option becomes 'visible' after `visible_after` wheel notches (net, in the recorded direction)."""
    governor = mock.Mock(allowed=mock.Mock(return_value=False))

    def __init__(self, visible_at):
        self.pos, self.visible_at = 0, visible_at

    def resolve_once(self, target, window, attempt=1, only=None):
        return Resolution(10, 10, "uia", 0.9) if self.pos == self.visible_at else None


def finder(visible_at, **o):
    fr = FakeResolver(visible_at)

    def scroll(x, y, dx, dy):
        if dy:
            fr.pos = max(-20, min(60, fr.pos + (1 if dy < 0 else -1)))      # a real list has two ends

    f = ScrollFinder(fr, scroll, lambda t, i=0: None, {"use_native": False, **o}, sleep=lambda s: None)
    f._region = lambda rect: np.full((10, 10), ((fr.pos + 30) * 2) % 256, np.uint8)       # picture changes while the list moves
    return f, fr


TARGET = {"name": "Zebra", "role": "ListItem", "intent": "pick_option", "container": {"rect": [0, 0, 100, 200], "role": "list"}}


class OptionSearch(unittest.TestCase):
    def test_recorded_scroll_amount_is_replayed_first(self):
        f, fr = finder(visible_at=-5)                      # 5 notches in the recorded direction (dy>0 = wheel up = pos-1)
        res = f.find({**TARGET, "scroll_recorded": {"dy": 8}}, {})
        self.assertIsNotNone(res)
        self.assertEqual(res.evidence["strategy"], "recorded-scroll")
        self.assertEqual(res.evidence["scrolled"], 5)

    def test_whole_list_is_scanned_both_ways_one_notch_at_a_time(self):
        f, fr = finder(visible_at=40)                      # far in the OTHER direction than the hint
        res = f.find({**TARGET, "scroll_hint": -1}, {})
        self.assertIsNotNone(res, "item 40 notches away must be found (30 was the old cap)")

    def test_gives_up_when_absent(self):
        f, fr = finder(visible_at=10 ** 6)
        self.assertIsNone(f.find(TARGET, {}))


class Classic(unittest.TestCase):
    def test_scroll_tier_is_in_classic_order_and_guarded(self):
        helpers.use_temp_workspace()
        self.assertIn("scroll", Resolver.CLASSIC_ORDER)
        r = Resolver.__new__(Resolver)
        r.o = {"engine_profile": "classic", "scroll_find": True}
        r.scrollfinder = mock.Mock()
        r._scrolled = False
        st = {"attempt": 1}
        plain = {"name": "Save", "container": {"role": "pane"}}
        self.assertIsNone(r._t_scroll(plain, {}, st))                 # a plain page is never scrolled on its own
        r.scrollfinder.find.assert_not_called()
        r.recording_scrolls = True
        r._t_scroll({**plain, "intent": "pick_option"}, {}, st)
        r.scrollfinder.find.assert_called_once()


class KeyboardFallbackAndNotes(unittest.TestCase):
    def _player(self, steps):
        helpers.use_temp_workspace()
        be = DryRunBackend()
        return Player({"name": "t", "steps": steps, "applications": [], "variables": {}},
                      {"timeout_s": 1.0, "settle_wait": False, "use_vision_ai": False, "use_ocr": False},
                      backend=be, dry_run=False, grab=lambda: (np.zeros((300, 400, 3), np.uint8), (0, 0))), be

    def test_recorded_scrolls_are_noted_on_the_option(self):
        steps = [{"id": 1, "type": "click", "intent": "open_dropdown", "target": {"name": "Font", "x": 1, "y": 1}, "window": {}},
                 {"id": 2, "type": "scroll", "params": {"dy": -3}, "window": {}},
                 {"id": 3, "type": "scroll", "params": {"dy": -4}, "window": {}},
                 {"id": 4, "type": "click", "intent": "pick_option", "target": {"name": "Zebra", "x": 5, "y": 5}, "window": {}}]
        p, _ = self._player(steps)
        p.test["steps"] = steps                          # intents as the recorder annotates them
        p._note_recorded_scrolls()
        self.assertEqual(steps[3]["target"]["scroll_recorded"], {"dy": -7})

    def test_keyboard_select_when_option_never_found(self):
        step = {"id": 4, "type": "click", "intent": "pick_option", "target": {"name": "Zebra", "x": 5, "y": 5}, "window": {}}
        p, be = self._player([step])
        res = {}
        with mock.patch("time.sleep"):
            self.assertTrue(p._keyboard_pick_option(step, res))
        self.assertEqual([a for a in be.actions if a[0] in ("type", "press")], [("type", "Zebra"), ("press", "enter")])
        self.assertEqual(res["method"], "keyboard-select")
        self.assertTrue(res["warnings"])

    def test_execute_falls_back_to_keyboard_only_for_options(self):
        step = {"id": 4, "type": "click", "t_ms": 0, "intent": "pick_option", "target": {"name": "Zebra", "x": 5, "y": 5},
                "window": {}, "validations": []}
        p, be = self._player([step])
        with mock.patch.object(p, "_resolve", side_effect=ElementNotFound("nope")), mock.patch("time.sleep"):
            res = {}
            p._execute(step, res)
        self.assertEqual(res["method"], "keyboard-select")
        plain = {**step, "intent": "click"}
        with mock.patch.object(p, "_resolve", side_effect=ElementNotFound("nope")), mock.patch("time.sleep"):
            with self.assertRaises(ElementNotFound):
                p._execute(plain, {})


class CellCaption(unittest.TestCase):
    def _read(self, wtxt, title="Book1 - Excel"):
        v = validators.Validator.__new__(validators.Validator)
        v.o = {"use_ocr": True}
        v.park_pointer = None
        v._expected = "2"
        tgt = {"name": "H9", "role": "DataItem"}
        res = Resolution(100, 100, "image", 0.9)
        v.resolver = mock.Mock()
        v.resolver.resolve_once.return_value = res
        v.resolver.governor = None
        win = {"title": title, "process": "EXCEL.EXE"}
        with mock.patch.object(validators.excel_com, "read_cell", return_value=None), \
                mock.patch.object(validators.excel_com, "active_cell", return_value=None), \
                mock.patch.object(validators.winenv, "element_at", return_value={}), \
                mock.patch.object(validators.winenv, "win32_text_at", return_value=wtxt), \
                mock.patch.object(validators.winenv, "excel_formula_bar", return_value=None), \
                mock.patch.object(v, "_native", return_value=None), mock.patch.object(v, "_focused", return_value={}), \
                mock.patch.object(v, "_ocr_reads", side_effect=RuntimeError("no ocr")):
            return list(v._text_candidates(tgt, win))

    def test_window_caption_is_never_a_cell_value(self):
        reads = self._read("Book1")
        self.assertFalse(any(t == "Book1" for t, _ in reads), reads)

    def test_caption_filter_keeps_real_control_text(self):
        v = validators
        self.assertTrue("Book1 - Excel".casefold().startswith("book1"))


if __name__ == "__main__":
    unittest.main()
