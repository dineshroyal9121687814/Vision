"""Unit tests for VisionAuto dual AI models (Vision Neural Embedder + Cognitive Reasoning Engine)."""
import unittest
import numpy as np

from core.ai import embedder
from core.ai.ai_engine import AIMatcher
from core.ai.cognitive import CognitiveEngine
from core.system import winenv


class TestAIModels(unittest.TestCase):
    def test_vision_embedder_backend(self):
        backend = embedder.backend_name()
        self.assertIn(backend, {"neural", "onnx", "classical"})

    def test_vision_embedder_output(self):
        img = np.zeros((100, 100, 3), dtype=np.uint8)
        cv2_img = np.ascontiguousarray(img)
        emb = embedder.embed(cv2_img)
        self.assertIsInstance(emb, np.ndarray)
        self.assertEqual(emb.ndim, 1)
        self.assertGreater(len(emb), 0)

        # Check normalization (norm should be ~1.0 for neural/onnx)
        if embedder.backend_name() in ("neural", "onnx"):
            norm = np.linalg.norm(emb)
            self.assertAlmostEqual(norm, 1.0, places=3)

    def test_vision_ai_matcher_similarity(self):
        matcher = AIMatcher()
        btn1 = np.ones((40, 80, 3), dtype=np.uint8) * 200
        btn2 = np.ones((40, 80, 3), dtype=np.uint8) * 190  # slight shade difference
        noise = np.random.randint(0, 255, (40, 80, 3), dtype=np.uint8)

        is_same, score_similar = matcher.is_same_element(btn1, btn2, threshold=0.8)
        _, score_noise = matcher.is_same_element(btn1, noise, threshold=0.8)

        self.assertGreater(score_similar, score_noise)

    def test_cognitive_intent_parsing(self):
        cog = CognitiveEngine()

        # Click
        s_click = cog.parse_intent_to_step("Click the 'Save' button in 'Notepad'")
        self.assertEqual(s_click["type"], "click")
        self.assertEqual(s_click["target"]["name"], "Save")
        self.assertEqual(s_click["window"]["title"], "Notepad")

        # Type
        s_type = cog.parse_intent_to_step("Type 'test@example.com' into 'Email'")
        self.assertEqual(s_type["type"], "type")
        self.assertEqual(s_type["params"]["text"], "test@example.com")
        self.assertEqual(s_type["target"]["name"], "Email")

        # Wait
        s_wait = cog.parse_intent_to_step("Wait 2.5 seconds")
        self.assertEqual(s_wait["type"], "wait")
        self.assertEqual(s_wait["params"]["ms"], 2500)

        # Validate window
        s_val_win = cog.parse_intent_to_step("Verify window title contains 'Dashboard'")
        self.assertEqual(s_val_win["type"], "validate")
        self.assertEqual(s_val_win["check"]["type"], "window_title_contains")
        self.assertEqual(s_val_win["check"]["expected"], "Dashboard")

        # Switch app
        s_switch = cog.parse_intent_to_step("Switch to application 'Chrome'")
        self.assertEqual(s_switch["type"], "switch_app")
        self.assertEqual(s_switch["app"], "Chrome")

    def test_cognitive_failure_diagnostics(self):
        cog = CognitiveEngine()
        step = {"type": "click", "target": {"name": "Submit"}, "window": {"title": "Main Window"}}

        # Window mismatch diagnosis
        diag = cog.diagnose_failure(step, "Could not activate window Main Window", active_window="Security Alert")
        self.assertIn("mismatch", diag["summary"].lower())
        self.assertIn("Security Alert", diag["summary"])
        self.assertGreaterEqual(diag["confidence"], 0.8)

        # Element not found diagnosis
        diag2 = cog.diagnose_failure(step, "Element not found within 10s")
        self.assertIn("Submit", diag2["summary"])
        self.assertTrue("suggestion" in diag2)

    def test_cognitive_self_healing_suggestion(self):
        cog = CognitiveEngine()
        failed = {"name": "Sign In", "role": "button"}
        candidates = [
            {"name": "Sign In with SSO", "role": "button"},
            {"name": "Cancel", "role": "button"},
            {"name": "Help", "role": "link"},
        ]
        suggestion = cog.suggest_healing(failed, candidates)
        self.assertIsNotNone(suggestion)
        self.assertEqual(suggestion["replacement"]["name"], "Sign In with SSO")
        self.assertGreaterEqual(suggestion["confidence"], 0.5)

    def test_winenv_find_windows_is_public(self):
        self.assertTrue(callable(winenv.find_windows))
        self.assertTrue(callable(winenv._find_windows))


if __name__ == "__main__":
    unittest.main()

