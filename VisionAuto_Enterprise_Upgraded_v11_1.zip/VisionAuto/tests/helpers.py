"""Shared test helpers: fake OS probe + synthetic frames (no display needed)."""
from __future__ import annotations

import os
import sys
import tempfile
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


def use_temp_workspace() -> str:
    d = tempfile.mkdtemp(prefix="va_ws_")
    os.environ["VISIONAUTO_HOME"] = d
    (Path(d) / "settings.json").write_text('{"engine_profile": "strict"}', encoding="utf-8")   # these suites test the strict pipeline
    return d


def make_frame(w=800, h=600, seed=1) -> np.ndarray:
    rng = np.random.default_rng(seed)
    return rng.integers(0, 255, (h, w, 3), dtype=np.uint8)


class FakeProbe:
    """Stands in for winenv.SystemProbe."""

    def __init__(self, frame=None, windows=None, elements=None):
        self.frame = frame if frame is not None else make_frame()
        self.windows = windows or {}
        self.elements = elements or {}
        self.default_window = {"title": "Notepad", "process": "notepad.exe", "pid": 100, "hwnd": 1}

    def grab(self):
        return self.frame.copy(), (0, 0)

    def window_at(self, x, y):
        return self.windows.get((x, y), self.default_window)

    def foreground(self):
        return self.default_window

    def element_at(self, x, y):
        return self.elements.get((x, y), {})

    def focused_element(self):
        return {}
