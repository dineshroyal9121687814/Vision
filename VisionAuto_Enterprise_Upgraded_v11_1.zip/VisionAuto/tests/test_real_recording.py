"""Regression on a REAL recording (an Excel session from the field): every recorded click must resolve back to the
recorded point, using only the stored pictures + the stored full-screen frames. Look-alike empty cells used to be
resolved one or two rows off (a plain best-score pick) - the case this guards."""
import json
import os
import sys
import unittest
from pathlib import Path

import cv2

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from core import settings                                                          # noqa: E402
from core.playback.resolver import Resolver                                        # noqa: E402

FIX = Path(__file__).parent / "fixtures" / "real_excel"


class RealExcelRecording(unittest.TestCase):
    def _run(self, **opts):
        test = json.loads((FIX / "test.json").read_text(encoding="utf-8"))
        origin = tuple((test.get("screen") or {}).get("origin", [0, 0]))
        worst, checked = 0.0, 0
        for s in test["steps"]:
            tg = s.get("target")
            if not tg or not tg.get("templates") or not tg.get("full"):
                continue
            frame = cv2.imread(str(FIX / tg["full"]))
            r = Resolver(str(FIX), {**settings.validate({}), "use_native": False, "use_ocr": False, "use_ai": False, **opts},
                         grab=lambda f=frame: (f, origin))
            r.rect_provider = lambda w: (w or {}).get("rect")           # the window is exactly where it was recorded
            tgt = r._prepare(dict(tg), s["window"])
            res = r.resolve_once(tgt, s["window"], 1)
            self.assertIsNotNone(res, f"step {s['id']} not resolved")
            worst = max(worst, ((res.x - tg["x"]) ** 2 + (res.y - tg["y"]) ** 2) ** .5)
            checked += 1
        return checked, worst

    def test_classic_profile_lands_every_click_on_the_recorded_point(self):
        checked, worst = self._run()
        self.assertGreaterEqual(checked, 15)
        self.assertLessEqual(worst, 6, "a click landed on a neighbouring cell")

    def test_strict_profile_too(self):
        checked, worst = self._run(**settings.validate({"engine_profile": "strict"}))
        self.assertLessEqual(worst, 6)


if __name__ == "__main__":
    unittest.main()
