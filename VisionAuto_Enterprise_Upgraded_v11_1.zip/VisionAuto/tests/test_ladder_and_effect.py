"""Resolution ladder, before/after evidence, exact buttons, repeat-previous, AI vision (verified)."""
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from tests import helpers                                                          # noqa: E402
from core.automation import effect                                                 # noqa: E402
from core.ai import vision_advisor                                                 # noqa: E402
from core.playback.backend import DryRunBackend                                    # noqa: E402
from core.playback.player import Player                                            # noqa: E402
from core.playback.resolver import Resolver                                        # noqa: E402

OPTS = {"timeout_s": 0.6, "use_native": False, "use_ocr": True, "use_ai": False, "settle_wait": False,
        "use_vision_ai": False}


class Effect(unittest.TestCase):
    def test_difference_and_change(self):
        a = np.zeros((50, 80, 3), np.uint8)
        b = a.copy()
        b[10:40, 10:60] = 255
        self.assertFalse(effect.changed(a, a.copy()))
        self.assertTrue(effect.changed(a, b))

    def test_text_in_tolerates_ocr_slips(self):
        self.assertTrue(effect.text_in("Name: Jahn Smith  Save", "John Smith"))
        self.assertFalse(effect.text_in("Cancel Help", "John Smith"))
        self.assertTrue(effect.text_in("xx", ""))

    def test_region_is_clipped(self):
        self.assertEqual(effect.region_around((5, 5), (100, 100, 3), (60, 60)), (0, 0, 35, 35))


class Ladder(unittest.TestCase):
    def test_order_is_text_then_coordinates_then_wide(self):
        r = Resolver(None, OPTS)
        o = r.tier_order({})
        self.assertLess(o.index("ocr_local"), o.index("coordtext"))
        self.assertLess(o.index("coordtext"), o.index("ocr_wide"))
        self.assertLess(o.index("ocr_wide"), o.index("vision"))
        self.assertLess(o.index("uia"), o.index("ocr_local"))

    def _resolver(self):
        r = Resolver(None, OPTS, grab=lambda: (np.zeros((400, 600, 3), np.uint8), (0, 0)))
        return r

    def test_coordinates_accepted_only_when_text_is_there(self):
        r = self._resolver()
        t = {"x": 300, "y": 200, "name": "Save"}
        with patch("core.ocr.ocr_engine.read_all_text", return_value="Cancel  Save  Help"):
            res = r._t_coordtext(t, {}, {"attempt": 0, "frame": None, "origin": (0, 0)})
        self.assertEqual((res.x, res.y, res.method), (300, 200, "coordinates(verified)"))
        with patch("core.ocr.ocr_engine.read_all_text", return_value="Delete everything"):
            self.assertIsNone(r._t_coordtext(t, {}, {"attempt": 0, "frame": None, "origin": (0, 0)}))

    def test_unnamed_target_is_never_accepted_by_coordinates(self):
        self.assertIsNone(self._resolver()._t_coordtext({"x": 1, "y": 1}, {}, {"attempt": 0, "frame": None, "origin": (0, 0)}))

    def test_ocr_local_does_not_search_whole_screen(self):
        r = self._resolver()
        seen = []

        def fake_find(img, label, **kw):
            seen.append(img.shape)
            return type("M", (), {"found": False})()
        with patch("core.ocr.ocr_engine.find_text", side_effect=fake_find):
            r._t_ocr_local({"x": 300, "y": 200, "name": "Save"}, {}, {"attempt": 0, "frame": None, "origin": (0, 0)})
        self.assertTrue(seen)
        self.assertTrue(all(s != (400, 600, 3) for s in seen))


class Vision(unittest.TestCase):
    def test_parse_answer(self):
        self.assertEqual(vision_advisor.parse_answer('ok {"found": true, "x": 50, "y": 20, "text": "Save"}', 0.5, (1000, 800)),
                         {"x": 100, "y": 40, "text": "Save"})
        self.assertIsNone(vision_advisor.parse_answer('{"found": false}', 1, (10, 10)))
        self.assertIsNone(vision_advisor.parse_answer("no json", 1, (10, 10)))
        self.assertIsNone(vision_advisor.parse_answer('{"found": true, "x": 99999, "y": 1}', 1, (10, 10)))

    def _r(self, ans):
        r = Resolver(None, {**OPTS, "use_vision_ai": True}, grab=lambda: (np.zeros((400, 600, 3), np.uint8), (0, 0)))
        r.vision_advisor = type("A", (), {"locate": lambda s, f, w, h=None: ans})()
        return r

    def test_ai_point_is_used_only_when_text_is_verified(self):
        t = {"name": "Save", "x": 10, "y": 10}
        with patch("core.ocr.ocr_engine.read_all_text", return_value="Save"):
            res = self._r({"x": 100, "y": 50, "text": "Save"})._t_vision(t, {}, {"attempt": 1, "frame": None, "origin": (0, 0)})
        self.assertEqual((res.x, res.y, res.method), (100, 50, "vision(verified)"))
        with patch("core.ocr.ocr_engine.read_all_text", return_value="Something else"):
            self.assertIsNone(self._r({"x": 100, "y": 50})._t_vision(t, {}, {"attempt": 1, "frame": None, "origin": (0, 0)}))

    def test_unnamed_target_is_not_given_to_ai(self):
        self.assertIsNone(self._r({"x": 1, "y": 1})._t_vision({"x": 5, "y": 5}, {}, {"attempt": 1, "frame": None, "origin": (0, 0)}))


def _click(i, **kw):
    s = {"id": i, "type": "click", "t_ms": 0, "window": {}, "validations": [], "description": "c",
         "target": {"role": "ListItem", "x": 100 + i, "y": 80, "name": f"B{i}", "locator_mode": "coordinates"}}
    s.update(kw)
    return s


class ExactButtons(unittest.TestCase):
    def setUp(self):
        helpers.use_temp_workspace()

    def _run(self, step):
        be = DryRunBackend()
        Player({"name": "b", "steps": [step], "applications": [], "variables": {}},
               {**OPTS, "use_ocr": False, "verify_effect": False}, backend=be, dry_run=False,
               grab=lambda: (np.zeros((300, 400, 3), np.uint8), (0, 0))).run()
        return be.actions

    def test_each_recorded_button_and_modifier_is_replayed_exactly(self):
        cases = [
            (dict(type="click"), ("click", 101, 80, "left", 1)),
            (dict(type="right_click"), ("click", 101, 80, "right", 1)),
            (dict(type="double_click"), ("click", 101, 80, "left", 2)),
            (dict(type="middle_click"), ("click", 101, 80, "middle", 1)),
            (dict(type="click", params={"modifiers": ["ctrl"]}), ("click", 101, 80, "left", 1, ("ctrl",))),
            (dict(type="click", params={"modifiers": ["shift", "ctrl"]}), None),
        ]
        for extra, want in cases:
            acts = [a for a in self._run(_click(1, **extra)) if a[0] == "click"]
            self.assertEqual(len(acts), 1, extra)
            if want:
                self.assertEqual(tuple(acts[0][:len(want)]), want, extra)
            else:
                self.assertEqual(set(acts[0][5]), {"shift", "ctrl"})

    def test_right_button_drag_with_ctrl(self):
        s = {"id": 1, "type": "drag_drop", "t_ms": 0, "window": {}, "validations": [], "description": "d",
             "target": {"x": 50, "y": 50, "name": "a", "locator_mode": "coordinates"}, "to": {"x": 200, "y": 150, "name": "b", "locator_mode": "coordinates"},
             "params": {"button": "right", "modifiers": ["ctrl"]}}
        drags = [a for a in self._run(s) if a[0] == "drag"]
        self.assertEqual(len(drags), 1)
        self.assertEqual(drags[0][5], "right")
        self.assertIn("ctrl", drags[0][6])


class ClickEffect(unittest.TestCase):
    def setUp(self):
        helpers.use_temp_workspace()

    def _player(self, frames, **opts):
        it = iter(frames)
        last = [frames[-1]]

        def grab():
            try:
                last[0] = next(it)
            except StopIteration:
                pass
            return last[0], (0, 0)
        be = DryRunBackend()
        p = Player({"name": "e", "steps": [_click(1)], "applications": [], "variables": {}},
                   {**OPTS, "use_ocr": False, "effect_wait_s": 0.15, **opts}, backend=be, dry_run=False, grab=grab)
        return p, be

    def test_changed_screen_is_verified_and_not_repeated(self):
        a = np.zeros((300, 400, 3), np.uint8)
        b = a.copy()
        b[40:140, 60:200] = 200
        p, be = self._player([a, a, b, b, b, b])
        out = p.run()
        self.assertEqual(len([x for x in be.actions if x[0] == "click"]), 1)
        self.assertTrue(out["steps"][0]["effect"]["changed"])

    def test_no_change_repeats_once_then_reports(self):
        a = np.zeros((300, 400, 3), np.uint8)
        p, be = self._player([a])
        out = p.run()
        self.assertEqual(len([x for x in be.actions if x[0] == "click"]), 2)
        st = out["steps"][0]
        self.assertTrue(st["effect"]["retried"] and not st["effect"]["changed"])
        self.assertIn("nothing visibly changed", " ".join(st.get("warnings", [])))
        self.assertEqual(st["status"], "passed")

    def test_strict_effect_fails_the_step(self):
        a = np.zeros((300, 400, 3), np.uint8)
        p, _ = self._player([a], strict_effect=True)
        self.assertEqual(p.run()["steps"][0]["status"], "failed")


class RepeatPrevious(unittest.TestCase):
    def setUp(self):
        helpers.use_temp_workspace()

    def _player(self, policy="safe"):
        p = Player({"name": "r", "steps": [], "applications": [], "variables": {}},
                   {**OPTS, "repeat_previous_policy": policy}, backend=DryRunBackend(), dry_run=False)
        return p

    def test_rules(self):
        p = self._player()
        tab = {"id": 1, "type": "click", "target": {"role": "TabItem"}}
        add = {"id": 2, "type": "click", "target": {"role": "Button", "name": "Add"}}
        self.assertTrue(p._may_repeat(tab, {}))
        self.assertEqual(p._may_repeat(add, {}), "")
        self.assertTrue(p._may_repeat(add, {"effect": {"changed": False}}))
        self.assertEqual(p._may_repeat({"id": 3, "type": "type"}, {}), "")
        self.assertTrue(p._may_repeat({"id": 4, "type": "hover"}, {}))
        self.assertEqual(self._player("never")._may_repeat(tab, {}), "")
        self.assertTrue(self._player("always")._may_repeat(add, {}))

    def test_missing_element_repeats_previous_then_finds_it(self):
        p = self._player()
        calls = []
        prev = {"id": 1, "type": "click", "target": {"role": "TabItem"}}
        cur = {"id": 2, "type": "click", "target": {}}
        p._prev_step, p._prev_res = prev, {}
        results = iter([{"status": "failed", "retryable": True, "error": "x not found"}, {"status": "passed"},
                        {"status": "passed"}])

        def fake(step):
            calls.append(step["id"])
            return next(results)
        p._run_step = fake
        p._sleep = lambda s: None
        out = p._run_with_retries(cur)
        self.assertEqual(calls, [2, 1, 2])
        self.assertIn("repeated step 1", out["repeated_previous"])

    def test_unsafe_previous_is_not_repeated_and_step_fails(self):
        p = self._player()
        p._prev_step, p._prev_res = {"id": 1, "type": "click", "target": {"role": "Button"}}, {}
        calls = []
        p._run_step = lambda step: (calls.append(step["id"]), {"status": "failed", "retryable": True, "error": "not found"})[1]
        p._sleep = lambda s: None
        out = p._run_with_retries({"id": 2, "type": "click", "target": {}})
        self.assertEqual(out["status"], "failed")
        self.assertNotIn(1, calls)


if __name__ == "__main__":
    unittest.main()


class RetrySafety(unittest.TestCase):
    def setUp(self):
        helpers.use_temp_workspace()

    def test_button_with_no_visible_change_is_reported_not_repeated(self):
        a = np.zeros((300, 400, 3), np.uint8)
        step = _click(1)
        step["target"]["role"] = "Button"
        be = DryRunBackend()
        out = Player({"name": "s", "steps": [step], "applications": [], "variables": {}},
                     {**OPTS, "use_ocr": False, "effect_wait_s": 0.15}, backend=be, dry_run=False,
                     grab=lambda: (a, (0, 0))).run()
        self.assertEqual(len([x for x in be.actions if x[0] == "click"]), 1)
        self.assertIn("nothing visibly changed", " ".join(out["steps"][0]["warnings"]))


class RecordTimeLabel(unittest.TestCase):
    def test_ocr_label_used_by_ladder_when_no_name(self):
        r = Resolver(None, OPTS, grab=lambda: (np.zeros((400, 600, 3), np.uint8), (0, 0)))
        t = {"x": 300, "y": 200, "ocr_label": "Total 42"}
        with patch("core.ocr.ocr_engine.read_all_text", return_value="Row Total 42 EUR"):
            res = r._t_coordtext(t, {}, {"attempt": 0, "frame": None, "origin": (0, 0)})
        self.assertEqual(res.method, "coordinates(verified)")

    def test_recorder_helper_returns_short_label(self):
        from core.recorder.recorder import Recorder
        with patch("core.ocr.ocr_engine.read_all_text", return_value="  Total \n 42  "):
            self.assertEqual(Recorder._ocr_label(np.zeros((300, 400, 3), np.uint8), (0, 0), 100, 100), "Total 42")
        with patch("core.ocr.ocr_engine.read_all_text", side_effect=RuntimeError("no ocr")):
            self.assertEqual(Recorder._ocr_label(np.zeros((300, 400, 3), np.uint8), (0, 0), 100, 100), "")
