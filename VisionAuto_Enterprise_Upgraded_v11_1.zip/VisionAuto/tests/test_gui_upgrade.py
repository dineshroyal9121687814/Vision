"""GUI-layer tests for the upgrade (real PySide6 offscreen when installed, otherwise tests/fake_qt.py).

With the fake Qt these exercise the page *logic* (filters, deletion, worker/control wiring, settings persistence,
close handling) - not rendering. See docs/IMPLEMENTATION_REPORT.md for what still needs a real-Qt / Windows run."""
import json
import os
import tempfile
import unittest
from datetime import datetime
from pathlib import Path
from types import SimpleNamespace

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from tests.helpers import use_temp_workspace

use_temp_workspace()
try:
    import PySide6  # noqa: F401
    from PySide6.QtWidgets import QApplication

    _app = QApplication.instance() or QApplication([])
    REAL_QT = True
    from tests import qt_noblock

    qt_noblock.install()
except ImportError:
    from tests import fake_qt

    fake_qt.install()
    REAL_QT = False

from core import paths, settings, testcases, testfile  # noqa: E402


def fresh():
    d = tempfile.mkdtemp(prefix="va_gui_")
    os.environ["VISIONAUTO_HOME"] = d
    paths.ensure_dirs()
    return Path(d)


def make_run(test, run_id, status="passed", started=None):
    d = paths.runs_dir() / test / run_id
    d.mkdir(parents=True)
    (d / "run.json").write_text(json.dumps({"test": test, "run_id": run_id, "status": status, "steps": [],
                                            "started_at": (started or datetime.now()).isoformat(timespec="seconds"),
                                            "summary": {"total": 1, "passed": 1}}))
    (d / "report.html").write_text("<html/>")
    return d


class ReportsPageTests(unittest.TestCase):
    def test_filter_delete_and_immediate_refresh(self):
        fresh()
        a, b = make_run("Login", "r1"), make_run("Pay", "r2", "failed")
        from app.gui.pages.reports_page import ReportsPage
        page = ReportsPage()
        self.assertEqual(len(page.all_rows), 2)
        page.search.setText("pay")
        page.apply_filter()
        self.assertEqual([r["test"] for r in page.rows], ["Pay"])
        page.search.setText("")
        page._confirm_and_delete([str(a)], "1 report")      # the confirmation box answers "yes" in the fake
        self.assertFalse(a.exists())
        self.assertTrue(b.exists())
        self.assertEqual(len(page.all_rows), 1)             # list refreshed straight away
        self.assertEqual(len(page.rows), 1)

    def test_nothing_deleted_when_user_declines(self):
        fresh()
        a = make_run("Login", "r1")
        from app.gui.pages import reports_page
        page = reports_page.ReportsPage()
        real = reports_page.QMessageBox.question
        reports_page.QMessageBox.question = staticmethod(lambda *a, **k: reports_page.QMessageBox.StandardButton.No)
        try:
            page._confirm_and_delete([str(a)], "1 report")
        finally:
            reports_page.QMessageBox.question = real
        self.assertTrue(a.exists())


class SettingsPageTests(unittest.TestCase):
    def test_retry_theme_and_storage_settings_persist(self):
        ws = fresh()
        from app.gui.pages.settings_page import SettingsPage
        page = SettingsPage()
        page.w["retry_max_attempts"].setValue(5)
        page.w["retry_mode"].setCurrentIndex(page.w["retry_mode"].findData("restart_test"))
        page.w["theme"].setCurrentIndex(page.w["theme"].findData("light"))
        page.w["retry_ask_before"].setChecked(False)
        emitted = []
        page.theme_changed.connect(emitted.append)
        target = ws / "my_cases"
        page.w["testcases_dir"].setText(str(target))
        page.save()
        saved = settings.load()
        self.assertEqual((saved["retry_max_attempts"], saved["retry_mode"], saved["theme"], saved["retry_ask_before"]),
                         (5, "restart_test", "light", False))
        self.assertEqual(saved["testcases_dir"], str(target.resolve()))
        self.assertTrue(target.is_dir())
        self.assertEqual(emitted, ["light"])

    def test_invalid_storage_path_is_rejected_not_saved(self):
        ws = fresh()
        f = ws / "file.txt"
        f.write_text("x")
        from app.gui.pages.settings_page import SettingsPage
        page = SettingsPage()
        page.w["testcases_dir"].setText(str(f))
        page.save()
        self.assertEqual(settings.load()["testcases_dir"], "")


class PlayWorkerTests(unittest.TestCase):
    def worker(self):
        from app.gui.workers import PlayWorker
        return PlayWorker({"kind": "native", "name": "x"})

    def test_controls_follow_the_state_machine_and_signal_state(self):
        fresh()
        w = self.worker()
        states = []
        w.state_changed.connect(states.append)
        self.assertEqual(w.controller.state, "running")
        self.assertTrue(w.pause())
        self.assertFalse(w.pause())
        self.assertTrue(w.resume())
        self.assertTrue(w.stop())
        self.assertFalse(w.pause())
        self.assertTrue(w.cancel())
        self.assertEqual(states, ["paused", "running", "stopping", "cancelling"])

    def test_scripts_cannot_pause(self):
        from app.gui.workers import PlayWorker
        w = PlayWorker({"kind": "uft", "script": "s", "name": "x"})
        self.assertFalse(w.supports_pause)
        self.assertFalse(w.pause())

    def test_retry_question_is_answered_through_the_worker(self):
        fresh()
        w = self.worker()
        w.retry_question.connect(lambda payload: w.answer_retry("retry"))     # the dialog's answer
        self.assertEqual(w._ask({"timeout_s": 5}, 5), "retry")

    def test_retry_question_ends_when_run_is_stopped(self):
        fresh()
        w = self.worker()
        w.retry_question.connect(lambda payload: w.stop())
        self.assertIsNone(w._ask({"timeout_s": 5}, 5))

    def test_worker_runs_a_test_and_finishes_controller(self):
        fresh()
        test = testfile.new_test("wk")
        test["steps"] = [{"id": 1, "type": "wait", "params": {"ms": 1}, "window": {}, "validations": []}]
        testfile.save_test(test)
        from app.gui.workers import PlayWorker
        w = PlayWorker({"kind": "native", "name": "wk"}, dry_run=True)
        got = []
        w.finished_run.connect(got.append)
        w.start()
        if not REAL_QT:
            self.assertEqual(len(got), 1)
        else:
            w.wait(15000)
        self.assertEqual(w.controller.state, "finished")


class CloseHandlingTests(unittest.TestCase):
    def test_active_run_is_cancelled_and_joined_before_close(self):
        fresh()
        from app.gui.main_window import MainWindow
        win = MainWindow()
        calls = []

        class Run:
            def isRunning(self): return True
            def cancel(self): calls.append("cancel")
            def wait(self, ms): calls.append("wait"); return True
        win.library.worker = Run()
        event = SimpleNamespace(accepted=None, accept=lambda: setattr(event, "accepted", True),
                                ignore=lambda: setattr(event, "accepted", False))
        win.closeEvent(event)
        self.assertEqual(calls, ["cancel", "wait"])
        self.assertTrue(event.accepted)

    def test_close_is_refused_if_the_run_does_not_stop(self):
        fresh()
        from app.gui.main_window import MainWindow
        win = MainWindow()

        class Stuck:
            def isRunning(self): return True
            def cancel(self): pass
            def wait(self, ms): return False
        win.library.worker = Stuck()
        event = SimpleNamespace(accepted=None, accept=lambda: setattr(event, "accepted", True),
                                ignore=lambda: setattr(event, "accepted", False))
        win.closeEvent(event)
        self.assertFalse(event.accepted)

    def test_recording_in_progress_blocks_close(self):
        fresh()
        from app.gui.main_window import MainWindow
        win = MainWindow()
        win.recorder.session = object()
        win.recorder._finishing = False
        event = SimpleNamespace(accepted=None, accept=lambda: setattr(event, "accepted", True),
                                ignore=lambda: setattr(event, "accepted", False))
        win.closeEvent(event)
        self.assertFalse(event.accepted)


class TestCasesPageTests(unittest.TestCase):
    __test__ = True

    def test_generate_edit_and_save_into_chosen_folder(self):
        ws = fresh()
        from app.gui.pages.testcases_page import TestCasesPage
        page = TestCasesPage()
        page.gen_text.setPlainText("Login:\nPassword must be minimum 8 characters.\nPayment:\nAmount must be between 1 and 100.")
        if REAL_QT:
            self.skipTest("worker is asynchronous under real Qt")
        page.generate()
        self.assertTrue(page.flat)
        self.assertEqual({t for t, _ in page.flat}, {"Login", "Payment"})
        out = ws / "chosen"
        page.out_dir.setText(str(out))
        page.save_generated()
        self.assertTrue((out / "Login" / "login_positive.json").is_file())
        self.assertTrue((out / "Payment" / "payment_boundary.json").is_file())

    def test_library_crud_through_core_and_refresh(self):
        fresh()
        testcases.add_case({"title": "A", "steps": ["s"]}, "Login")
        from app.gui.pages.testcases_page import TestCasesPage
        page = TestCasesPage()
        self.assertEqual(len(page.cases), 1)
        page.apply_filter()
        self.assertEqual(len(page.shown), 1)


if __name__ == "__main__":
    unittest.main()
