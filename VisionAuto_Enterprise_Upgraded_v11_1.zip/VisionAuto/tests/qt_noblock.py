"""With real PySide6 a modal QMessageBox / QFileDialog would block an unattended test forever. Answer them instantly.
The fake Qt used on machines without PySide6 already does this; this makes the real one behave the same in tests."""


def install() -> None:
    try:
        from PySide6.QtWidgets import QFileDialog, QInputDialog, QMessageBox
    except ImportError:
        return
    yes, ok = QMessageBox.StandardButton.Yes, QMessageBox.StandardButton.Ok
    for name, answer in (("question", yes), ("information", ok), ("warning", ok), ("critical", ok), ("about", ok)):
        setattr(QMessageBox, name, staticmethod(lambda *a, _r=answer, **k: _r))
    QFileDialog.getOpenFileName = staticmethod(lambda *a, **k: ("", ""))
    QFileDialog.getSaveFileName = staticmethod(lambda *a, **k: ("", ""))
    QFileDialog.getExistingDirectory = staticmethod(lambda *a, **k: "")
    QInputDialog.getText = staticmethod(lambda *a, **k: ("", False))
