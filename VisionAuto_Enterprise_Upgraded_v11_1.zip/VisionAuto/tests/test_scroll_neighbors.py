"""Neighbour anchors, scroll-to-find, adaptive scroll, drag with auto-scroll, recorder capture."""
import unittest
from unittest import mock

import numpy as np

from core.playback.backend import DryRunBackend
from core.playback.player import Player
from core.playback.resolver import ElementNotFound, Resolution, Resolver
from core.playback.scrollfind import ScrollFinder
from core.settings import validate as validate_settings
from core.vision import neighbors

BLANK = lambda: (np.zeros((200, 200, 3), np.uint8), (0, 0))  # noqa: E731


def item(name, y, role="ListItem"):
    return {"name": name, "role": role, "rect": [100, y, 300, y + 24], "automation_id": ""}


class Neighbours(unittest.TestCase):
    LIST = {item(n, 100 + 24 * i)["name"]: item(n, 100 + 24 * i) for i, n in enumerate("ABCDEFG")}

    def element_at(self, x, y):
        for it in self.LIST.values():
            r = it["rect"]
            if r[0] <= x <= r[2] and r[1] <= y <= r[3]:
                return it
        return {}

    def test_sample_finds_items_above_and_below_with_offsets(self):
        target = self.LIST["D"]
        out = neighbors.sample(self.element_at, 200, 172 + 12 - 12, target)       # click inside D
        names = {n["name"]: n for n in out}
        self.assertIn("C", names)
        self.assertIn("E", names)
        self.assertEqual(names["C"]["side"], "above")
        self.assertEqual(names["E"]["side"], "below")
        self.assertLess(names["C"]["dy"], 0)
        self.assertNotIn("D", names)                                                # not itself

    def test_budget_stops_sampling(self):
        ticks = iter([0, 0, 10, 10, 10, 10])
        out = neighbors.sample(self.element_at, 200, 172, self.LIST["D"], budget_s=0.1, clock=lambda: next(ticks))
        self.assertLessEqual(len(out), 1)

    def test_container_is_the_nearest_scrollable_ancestor(self):
        anc = [{"name": "row", "role": "Group", "rect": [90, 90, 310, 300]},
               {"name": "Countries", "role": "List", "rect": [80, 80, 320, 320], "automation_id": "lst"},
               {"name": "Page", "role": "Document", "rect": [0, 0, 800, 600]}]
        c = neighbors.container_of((200, 150), anc, [0, 0, 800, 600])
        self.assertEqual((c["role"], c["name"]), ("List", "Countries"))

    def test_whole_window_is_not_a_container(self):
        anc = [{"name": "Page", "role": "Document", "rect": [0, 0, 800, 600]}]
        self.assertIsNone(neighbors.container_of((200, 150), anc, [0, 0, 800, 600]))

    def test_locate_cross_checks_several_anchors(self):
        a = {"name": "C", "dx": 0, "dy": -24, "dist": 24}
        b = {"name": "E", "dx": 0, "dy": 24, "dist": 24}
        liar = {"name": "X", "dx": 5, "dy": 5, "dist": 7}
        x, y, votes, _ = neighbors.locate([(a, (200, 148)), (b, (200, 196)), (liar, (500, 500))])
        self.assertEqual((round(x), round(y), votes), (200, 172, 2))

    def test_locate_nothing(self):
        self.assertIsNone(neighbors.locate([]))


class AnchorTier(unittest.TestCase):
    def resolver(self, found):
        r = Resolver(".", validate_settings({}), grab=BLANK)
        plugin = mock.Mock()
        plugin.find_element_native.side_effect = lambda crit, w: found.get(crit.get("name"))
        r.plugins = mock.Mock(get_plugin_for=lambda w: plugin)
        r.governor = mock.Mock(allowed=lambda *a: True, call=lambda w, fn: fn())
        return r

    TARGET = {"x": 200, "y": 172, "neighbors": [{"name": "C", "role": "ListItem", "dx": 0, "dy": -24, "dist": 24},
                                                {"name": "E", "role": "ListItem", "dx": 0, "dy": 24, "dist": 24}]}

    def test_unnamed_drop_zone_is_found_from_its_neighbours(self):
        r = self.resolver({"C": {"rect": [100, 136, 300, 160]}, "E": {"rect": [100, 184, 300, 208]}})
        res = r._t_anchor(self.TARGET, {}, {"attempt": 1})
        self.assertEqual((res.method, res.x, res.y), ("anchor", 200, 172))
        self.assertEqual(res.evidence["votes"], 2)

    def test_list_scrolled_by_a_different_amount_anchor_follows(self):
        r = self.resolver({"C": {"rect": [100, 36, 300, 60]}, "E": {"rect": [100, 84, 300, 108]}})   # moved up 100 px
        res = r._t_anchor(self.TARGET, {}, {"attempt": 1})
        self.assertEqual((res.x, res.y), (200, 72))

    def test_no_anchor_on_screen(self):
        self.assertIsNone(self.resolver({})._t_anchor(self.TARGET, {}, {"attempt": 1}))

    def test_named_target_rejected_when_one_anchor_and_something_else_is_there(self):
        r = self.resolver({"C": {"rect": [100, 136, 300, 160]}})
        t = {**self.TARGET, "name": "D", "role": "ListItem"}
        with mock.patch("core.system.winenv.element_at", return_value={"name": "Q", "role": "ListItem", "rect": [1, 1, 9, 9]}):
            self.assertIsNone(r._t_anchor(t, {}, {"attempt": 1}))


class ScrollSearch(unittest.TestCase):
    """The element is below the fold: scroll the container until the cheap tiers see it."""

    def finder(self, appears_after, typeahead_hits=False, container_role="List", opts=None):
        r = Resolver(".", validate_settings({}), grab=BLANK)
        r.governor = mock.Mock(allowed=lambda *a: True, call=lambda w, fn: fn())
        state = {"scrolls": 0, "typed": None}
        scrolls, types = [], []

        def scroll(x, y, dx, dy):
            if dy:
                state["scrolls"] += 1
            scrolls.append((x, y, dx, dy))

        def typer(text, interval):
            state["typed"] = text
            types.append(text)

        def resolve_once(target, window, attempt=1, only=None):
            if typeahead_hits and state["typed"]:
                return Resolution(10, 10, "image", 0.9)
            if appears_after is not None and state["scrolls"] >= appears_after:
                return Resolution(10, 10, "image", 0.9)
            return None

        r.resolve_once = resolve_once
        f = ScrollFinder(r, scroll, typer, {**validate_settings({}), **(opts or {})}, sleep=lambda s: None)
        return f, scrolls, types

    def target(self, role="List"):
        return {"name": "Germany", "role": "ListItem", "container": {"role": role, "rect": [100, 100, 300, 300]}}

    def test_wheel_finds_it_after_a_few_steps(self):
        f, scrolls, _ = self.finder(appears_after=4)
        with mock.patch("core.system.winenv.grab_region", side_effect=[(np.full((10, 10, 3), (i * 9) % 250, np.uint8), (0, 0)) for i in range(50)]), \
                mock.patch("core.system.winenv.scroll_into_view", return_value=False):
            res = f.find(self.target(), {})
        self.assertEqual(res.method, "scroll+image")
        self.assertEqual(res.evidence["scrolled"], 4)
        self.assertEqual(res.evidence["strategy"], "wheel")
        self.assertTrue(all((x, y) == (200, 200) for x, y, _, dy in scrolls if dy))     # always over the container

    def test_native_scroll_into_view_is_tried_first(self):
        f, scrolls, types = self.finder(appears_after=0)
        with mock.patch("core.system.winenv.scroll_into_view", return_value=True):
            res = f.find(self.target(), {})
        self.assertEqual(res.evidence["strategy"], "scroll-into-view")
        self.assertEqual((scrolls, types), ([], []))

    def test_type_ahead_in_a_list_before_any_wheel(self):
        f, scrolls, types = self.finder(appears_after=None, typeahead_hits=True)
        with mock.patch("core.system.winenv.scroll_into_view", return_value=False):
            res = f.find(self.target(), {})
        self.assertEqual(res.evidence["strategy"], "type-ahead")
        self.assertEqual(types, ["Germany"])
        self.assertFalse(any(dy for *_, dy in scrolls))

    def test_no_type_ahead_in_a_menu_or_document(self):
        f, _, types = self.finder(appears_after=None, typeahead_hits=True)
        with mock.patch("core.system.winenv.scroll_into_view", return_value=False), \
                mock.patch("core.system.winenv.grab_region", return_value=(np.zeros((10, 10, 3), np.uint8), (0, 0))):
            f.find(self.target("Menu"), {})
        self.assertEqual(types, [])

    def test_gives_up_at_the_end_of_the_content_in_both_directions(self):
        f, scrolls, _ = self.finder(appears_after=None)
        same = (np.zeros((10, 10, 3), np.uint8), (0, 0))                           # picture never changes = end reached
        with mock.patch("core.system.winenv.grab_region", return_value=same), \
                mock.patch("core.system.winenv.scroll_into_view", return_value=False):
            self.assertIsNone(f.find(self.target(), {}))
        dys = [dy for *_, dy in scrolls if dy]
        self.assertTrue(any(d > 0 for d in dys) and any(d < 0 for d in dys))       # tried both directions
        self.assertLessEqual(len(dys), 8)                                          # and stopped quickly

    def test_target_without_container_is_not_scrolled(self):
        f, scrolls, _ = self.finder(appears_after=1)
        self.assertIsNone(f.find({"name": "x"}, {}))
        self.assertEqual(scrolls, [])

    def test_step_cap(self):
        f, scrolls, _ = self.finder(appears_after=None, opts={"scroll_find_steps": 5})
        frames = iter([(np.full((10, 10, 3), i * 7 % 250, np.uint8), (0, 0)) for i in range(500)])
        with mock.patch("core.system.winenv.grab_region", side_effect=lambda r: next(frames)), \
                mock.patch("core.system.winenv.scroll_into_view", return_value=False):
            f.find(self.target(), {})
        self.assertLessEqual(len([1 for *_, dy in scrolls if dy]), 5)

    def test_resolver_runs_the_scroll_tier_last_and_once(self):
        r = Resolver(".", validate_settings({"engine_profile": "strict"}), grab=BLANK)
        r.scrollfinder = mock.Mock(find=mock.Mock(return_value=Resolution(1, 2, "scroll+image", 0.9)))
        t = {"container": {"rect": [0, 0, 9, 9]}}
        st = {"attempt": 1}
        r._scrolled = False
        self.assertEqual(r._t_scroll(t, {}, st).method, "scroll+image")
        self.assertIsNone(r._t_scroll(t, {}, st))                                  # not again in the same resolve()
        r.scrollfinder.find.assert_called_once()
        self.assertEqual(Resolver.DEFAULT_ORDER[-1], "scroll")


class AdaptiveScroll(unittest.TestCase):
    def player(self, found_at, mode="adaptive"):
        p = Player.__new__(Player)
        p.dry_run = False
        p.opts = validate_settings({"scroll_mode": mode})
        p.resolver = mock.Mock()
        p.resolver._prepare = lambda t, w: t
        p.resolver.resolve_once = mock.Mock(return_value=Resolution(*found_at, "image", 0.9) if found_at else None)
        p._next_step = {"type": "click", "window": {}, "target": {"name": "Germany", "container": {"rect": [100, 100, 300, 400]}}}
        return p

    def test_target_already_visible_scroll_is_skipped(self):
        self.assertTrue(self.player((200, 250))._skip_scroll({"window": {}}, {}))

    def test_target_near_the_edge_is_scrolled(self):
        self.assertFalse(self.player((200, 395))._skip_scroll({"window": {}}, {}))

    def test_target_not_visible_is_scrolled(self):
        self.assertFalse(self.player(None)._skip_scroll({"window": {}}, {}))

    def test_exact_mode_and_exact_flag_always_scroll(self):
        self.assertFalse(self.player((200, 250), "exact")._skip_scroll({"window": {}}, {}))
        self.assertFalse(self.player((200, 250))._skip_scroll({"window": {}}, {"exact": True}))

    def test_scroll_not_followed_by_a_list_click_is_never_skipped(self):
        p = self.player((200, 250))
        p._next_step = {"type": "click", "window": {}, "target": {"name": "Zoom in"}}          # no container: not a list
        self.assertFalse(p._skip_scroll({"window": {}}, {}))
        p._next_step = {"type": "key", "params": {"key": "enter"}}
        self.assertFalse(p._skip_scroll({"window": {}}, {}))


class DragWithAutoScroll(unittest.TestCase):
    def setUp(self):
        self.p = Player.__new__(Player)
        self.p.dry_run = False
        self.p.opts = validate_settings({"scroll_find_budget_s": 5.0})
        self.p.backend = DryRunBackend()
        self.p.should_stop = lambda: False
        self.p.resolver = mock.Mock()
        self.p.resolver._prepare = lambda t, w: t
        self.step = {"id": 5, "type": "drag_drop", "window": {}, "target": {"x": 200, "y": 150, "container": {"rect": [100, 100, 300, 400]}}}
        self.to = {"name": "Folder 40", "x": 200, "y": 900, "container": {"rect": [100, 100, 300, 400]}}

    def run_drag(self, appears_after):
        calls = {"n": 0}

        def resolve_once(t, w, attempt=1, only=None):
            calls["n"] += 1
            return Resolution(200, 300, "uia", 0.95) if calls["n"] > appears_after else None
        self.p.resolver.resolve_once = resolve_once
        res = {}
        src = Resolution(200, 150, "uia", 0.9)
        with mock.patch("time.sleep"):
            out = self.p._drag_with_autoscroll(self.step, src, self.to, {}, {}, res)
        return out, res

    def test_button_is_held_while_scrolling_and_released_on_the_target(self):
        out, res = self.run_drag(appears_after=3)
        a = self.p.backend.actions
        self.assertIsNone(out)
        self.assertEqual(a[0][0], "mouse_down")
        self.assertEqual(a[-1], ("mouse_up", "left"))
        self.assertEqual(len([x for x in a if x[0] == "scroll"]), 3)
        self.assertTrue(all(x[4] < 0 for x in a if x[0] == "scroll"))             # destination is below: wheel down
        self.assertIn("scroll+uia", res["method"])

    def test_upward_drag_scrolls_up(self):
        self.to["y"] = 20
        self.step["target"]["y"] = 300
        self.run_drag(appears_after=1)
        self.assertTrue(all(x[4] > 0 for x in self.p.backend.actions if x[0] == "scroll"))

    def test_button_is_released_even_if_the_target_never_appears(self):
        self.p.opts["scroll_find_steps"] = 4
        with self.assertRaises(ElementNotFound):
            self.run_drag(appears_after=999)
        self.assertEqual(self.p.backend.actions[-1], ("mouse_up", "left"))
        self.assertEqual(len([x for x in self.p.backend.actions if x[0] == "scroll"]), 4)

    def test_same_container_uses_autoscroll_other_container_scrolls_destination(self):
        p = self.p
        p._drag_with_autoscroll = mock.Mock(return_value=None)
        self.assertIsNone(p._reach_destination(self.step, None, self.to, None, {}, {}))
        p._drag_with_autoscroll.assert_called_once()
        other = {**self.to, "container": {"rect": [500, 100, 700, 400]}}
        p._resolve = mock.Mock(return_value=Resolution(600, 300, "scroll+uia", 0.9))
        p.resolver.resolve_once = mock.Mock(return_value=Resolution(200, 150, "uia", 0.9))
        res = {}
        dst = p._reach_destination(self.step, None, other, None, {}, res)
        self.assertEqual(dst.x, 600)
        self.assertTrue(res["scrolled_for_destination"])

    def test_source_lost_while_scrolling_destination_is_an_honest_error(self):
        other = {**self.to, "container": {"rect": [500, 100, 700, 400]}}
        self.p._resolve = mock.Mock(return_value=Resolution(600, 300, "scroll+uia", 0.9))
        self.p.resolver.resolve_once = mock.Mock(return_value=None)
        with self.assertRaises(ElementNotFound):
            self.p._reach_destination(self.step, None, other, None, {}, {})


class RecorderCapture(unittest.TestCase):
    def test_neighbours_and_container_are_recorded_with_the_target(self):
        from core.recorder.recorder import Recorder
        rec = Recorder.__new__(Recorder)
        rec._record_neighbors = True
        el = item("D", 172)
        el["ancestors"] = [{"name": "Countries", "role": "List", "rect": [80, 80, 320, 320]}]
        others = {"C": item("C", 148), "E": item("E", 196)}
        probe = mock.Mock()
        probe.element_at = lambda x, y: next((o for o in others.values() if o["rect"][1] <= y <= o["rect"][3]), {})
        rec.probe = probe
        ev = mock.Mock(x=200, y=180, extra={"element": el, "window": {"rect": [0, 0, 800, 600]}})
        rec._context(ev)
        self.assertEqual(ev.extra["container"]["role"], "List")
        self.assertEqual({n["name"] for n in ev.extra["neighbors"]}, {"C", "E"})

    def test_target_carries_neighbors_and_container(self):
        from core.recorder.recorder import Recorder
        rec = Recorder.__new__(Recorder)
        raw = {"neighbors": [{"name": "C"}], "container": {"role": "List", "rect": [1, 2, 3, 4]},
               "to_neighbors": [{"name": "Z"}], "to_container": None}
        src = rec._target(raw, 5, 5, {"name": "D"}, 1, "src", False)
        dst = rec._target(raw, 5, 5, {"name": "D"}, 1, "dst", False)
        self.assertEqual(src["neighbors"][0]["name"], "C")
        self.assertEqual(src["container"]["role"], "List")
        self.assertEqual(dst["neighbors"][0]["name"], "Z")
        self.assertNotIn("container", dst)


class BackendPrimitives(unittest.TestCase):
    def test_dry_run_records_hold_and_release(self):
        b = DryRunBackend()
        b.mouse_down(1, 2)
        b.mouse_move(3, 4)
        b.mouse_up()
        self.assertEqual(b.actions, [("mouse_down", 1, 2, "left"), ("mouse_move", 3, 4), ("mouse_up", "left")])


if __name__ == "__main__":
    unittest.main()
