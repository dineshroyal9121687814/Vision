' Supported UFT migration corpus sample: object actions, a parameter, and checkpoints.
Browser("Demo Browser").Page("Login").WebEdit("Username").Set Parameter("user")
Browser("Demo Browser").Page("Login").WebButton("Submit").Click
Browser("Demo Browser").Page("Login").WebButton("Submit").CheckProperty "text", "Sign in"
Browser("Demo Browser").Page("Login").WebButton("Submit").Exist 5
