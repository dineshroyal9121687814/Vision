"""open_app / Start-menu compaction / Inspect-style paths / type-settle. Runs on any OS (no display, no Windows)."""
import json
import shutil
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from tests.helpers import FakeProbe, ROOT, use_temp_workspace

use_temp_workspace()

from core import cli, inspector, testfile, validation  # noqa: E402
from core.playback.backend import DryRunBackend  # noqa: E402
from core.playback.player import Player  # noqa: E402
from core.recorder.builder import RawEvent  # noqa: E402
from core.recorder.launch_detect import compact_launches  # noqa: E402
from core.recorder.recorder import Recorder  # noqa: E402
from core.system import launcher  # noqa: E402
from core.xpath.pathgen import element_path  # noqa: E402
from core.xpath.tree import UiaNode  # noqa: E402

REC = ROOT / "workspace" / "tests"


def original(name):
    """A Start-menu recording as it was made (before `cli fix`). Self-contained: the user's workspace recording of this
    name changes over time, so the test no longer depends on it."""
    sh = {"title": "Search", "process": "SearchHost.exe"}
    return {"name": name, "applications": [], "variables": {}, "steps": [
        {"id": 1, "type": "click", "t_ms": 0, "window": {"title": "", "process": "explorer.exe"}, "validations": [],
         "target": {"x": 320, "y": 1190, "name": "Start", "role": "Button", "automation_id": "StartButton"}, "params": {"button": "left"}},
        {"id": 2, "type": "type", "t_ms": 100, "window": sh, "validations": [], "params": {"text": "cal"}},
        {"id": 3, "type": "click", "t_ms": 200, "window": sh, "validations": [], "params": {"button": "left"},
         "target": {"x": 661, "y": 459, "name": "CoreInput", "role": "Pane", "rect": [100, 100, 1068, 932]}},
        {"id": 4, "type": "double_click", "t_ms": 300, "window": {"title": "Calculator", "process": "ApplicationFrameHost.exe"},
         "validations": [], "params": {"button": "left"}, "target": {"x": 10, "y": 10, "name": "Nine", "role": "Button"}}]}


START = {"x": 320, "y": 1190, "name": "Start", "role": "Button", "automation_id": "StartButton"}


def st(i, t, proc="x.exe", title="", **kw):
    return {"id": i, "type": t, "t_ms": i * 100, "window": {"title": title, "process": proc}, "validations": [], **kw}


class LauncherPlanTests(unittest.TestCase):
    APPS = [{"Name": "Calculator", "AppID": "Microsoft.WindowsCalculator_8wekyb3d8bbwe!App"},
            {"Name": "Calendar", "AppID": "cal-id"}, {"Name": "Camera", "AppID": "cam-id"},
            {"Name": "Notepad", "AppID": "notepad-id"}]

    def test_match_prefers_exact_then_prefix_and_ignores_unrelated(self):
        m = launcher.match_start_app("calculator", self.APPS)
        self.assertEqual(m[0]["name"], "Calculator")
        self.assertEqual(launcher.match_start_app("zzzzqq", self.APPS), [])
        self.assertEqual(launcher.match_start_app("note", self.APPS)[0]["name"], "Notepad")

    def test_plan_order_cheap_first_keyboard_last_and_no_pixel_clicks(self):
        kinds = [m.kind for m in launcher.plan("Calculator", start_apps=self.APPS)]
        self.assertEqual(kinds[0], "exe")
        self.assertEqual(kinds[-1], "keyboard")
        self.assertNotIn("click", kinds)

    def test_shells_are_refused(self):
        for bad in ("cmd.exe /c calc", "powershell", "calc.exe & calc.exe"):
            with self.assertRaises(ValueError):
                launcher.plan("x", exe=bad)

    def test_tie_between_lookalikes_uses_chooser(self):
        apps = [{"Name": "Cal Tool A", "AppID": "a"}, {"Name": "Cal Tool B", "AppID": "b"}]
        ms = launcher.plan("cal tool", start_apps=apps, allow_keyboard=False, chooser=lambda n, c: "Cal Tool B")
        self.assertEqual(ms[-2].label, "startapp:Cal Tool B")

    def test_open_application_tries_next_strategy_until_window_appears(self):
        started = []
        with mock.patch.object(launcher, "start_method", lambda m, b=None: started.append(m.label)), \
             mock.patch.object(launcher.winenv, "activate_window", lambda t: True), \
             mock.patch.object(launcher, "wait_for_window") as wait:
            wait.side_effect = [0, 0, 77]        # attach check, first launch times out, second works
            out = launcher.open_application("Calculator", timeout_s=9, apps_provider=lambda: self.APPS)
        self.assertEqual(out["hwnd"], 77)
        self.assertEqual(len(started), 2)

    def test_open_application_fails_loudly_with_everything_tried(self):
        with mock.patch.object(launcher, "start_method", lambda m, b=None: None), \
             mock.patch.object(launcher, "wait_for_window", lambda *a, **k: 0):
            with self.assertRaises(ValueError) as cm:
                launcher.open_application("Calculator", timeout_s=2, apps_provider=lambda: self.APPS)
        self.assertIn("tried:", str(cm.exception))
        self.assertIn("keyboard", str(cm.exception))


class CompactTests(unittest.TestCase):
    def test_real_recordings_are_repaired(self):
        for name in ("cal", "Test1", "aaa"):
            test = original(name)
            new, changes = compact_launches(test["steps"])
            if test["steps"][0]["type"] == "open_app":
                # The shipped recording was already repaired (and its .pre_fix.bak is not in this copy of the
                # workspace): repairing again must change nothing.
                self.assertEqual(changes, [], name)
            else:
                self.assertEqual(len(changes), 1, name)
            self.assertEqual(new[0]["type"], "open_app")
            self.assertTrue(new[0]["params"]["name"], name)       # the app the user recorded (Calculator, Excel, ...)
            self.assertEqual(new[0]["params"]["window_title"], new[0]["params"]["name"])
            self.assertEqual([s["id"] for s in new], list(range(1, len(new) + 1)))
            self.assertNotIn("CoreInput", json.dumps(new[0]))

    def test_win_key_variant_and_enter_selection(self):
        steps = [st(1, "hotkey", params={"keys": "win+s"}, proc="explorer.exe"),
                 st(2, "type", "SearchHost.exe", "Search", params={"text": "notepad"}),
                 st(3, "key", "SearchHost.exe", "Search", params={"key": "enter"}),
                 st(4, "type", "notepad.exe", "Untitled - Notepad", params={"text": "hello"})]
        new, ch = compact_launches(steps)
        self.assertEqual([s["type"] for s in new], ["open_app", "type"])
        self.assertEqual(new[0]["params"]["window_title"], "Untitled - Notepad")

    def test_unrelated_steps_and_redacted_typing_untouched(self):
        steps = [st(1, "click", "app.exe", "App", target={"x": 1, "y": 1}),
                 st(2, "type", "SearchHost.exe", "Search", params={"text": "", "redacted": True})]
        new, ch = compact_launches(steps)
        self.assertEqual(ch, [])
        self.assertEqual([s["type"] for s in new], ["click", "type"])

    def test_query_only_when_no_window_followed(self):
        new, _ = compact_launches([st(1, "click", "explorer.exe", target=dict(START)),
                                   st(2, "type", "SearchHost.exe", "Search", params={"text": "paint"})])
        self.assertEqual(new[0]["params"]["name"], "Paint")

    def test_recorder_applies_compaction_on_stop(self):
        import time
        probe = FakeProbe()
        probe.default_window = {"title": "Search", "process": "SearchHost.exe", "pid": 5, "hwnd": 5}
        rec = Recorder("launchrec", probe=probe)
        rec.start(listeners=False, overwrite=True)
        t = 1.0
        for ch in "cal":
            rec.inject(RawEvent("key_down", t, key=ch, is_char=True))
            rec.inject(RawEvent("key_up", t + 0.01, key=ch))
            t += 0.1
        time.sleep(0.5)                                   # the worker has read the foreground window by now
        probe.default_window = {"title": "Calculator", "process": "ApplicationFrameHost.exe", "pid": 9, "hwnd": 9}
        rec.inject(RawEvent("mouse_down", t + 3, 50, 50))
        rec.inject(RawEvent("mouse_up", t + 3.05, 50, 50))
        time.sleep(0.5)
        path = rec.stop()
        test = json.loads(Path(path).read_text(encoding="utf-8"))
        self.assertEqual([s["type"] for s in test["steps"]], ["open_app", "click"])


class PathTests(unittest.TestCase):
    def test_breadcrumb_and_window_scoped_xpath(self):
        p = element_path({"name": "Nine", "role": "Button", "automation_id": "num9Button",
                          "ancestors": [{"name": "", "role": "Group"}, {"name": "Calculator", "role": "Window"},
                                        {"name": "Desktop 1", "role": "Pane"}]})
        self.assertEqual(p["xpath"], "/window[@name='Calculator']//button[@automationid='num9Button']")
        self.assertTrue(p["breadcrumb"].startswith("Calculator [Window] > Group > Nine"))

    def test_nothing_known_gives_none(self):
        self.assertIsNone(element_path({}))


class InspectorTests(unittest.TestCase):
    def tree(self):
        root = UiaNode("Desktop", "Desktop")
        win = UiaNode("Window", "Calculator", rect=(0, 0, 400, 600))
        pane = UiaNode("Pane", "", rect=(0, 0, 400, 600))
        b9 = UiaNode("Button", "Nine", automation_id="num9Button", rect=(10, 10, 60, 60))
        b8 = UiaNode("Button", "Eight", automation_id="num8Button", rect=(70, 10, 120, 60))
        root.add(win)
        win.add(pane)
        pane.add(b9, b8)
        return root, b9

    def test_xpath_find_pick_and_format(self):
        root, b9 = self.tree()
        self.assertIn("num9Button", inspector.xpath_of(b9, root))
        self.assertEqual(inspector.find_nodes(root, "nine"), [b9])
        self.assertIs(inspector.deepest_at(root, 20, 20), b9)
        self.assertEqual(inspector.breadcrumb(b9), "Calculator [Window] > Pane > Nine [Button]")
        text = inspector.format_tree(root, only=inspector.branch_ids(root, [b9]))
        self.assertIn("Button 'Nine' #num9Button", text)
        self.assertNotIn("Eight", text)


class PlayerTests(unittest.TestCase):
    def test_blind_container_click_is_flagged_and_fixed_test_is_clean(self):
        test = original("cal")
        self.assertIn("blind_container_click", [i["code"] for i in validation.validate_test(test)])
        fixed, _ = compact_launches(test["steps"])
        test["steps"] = fixed
        self.assertNotIn("blind_container_click", [i["code"] for i in validation.validate_test(test)])

    def test_open_app_requires_a_name(self):
        t = {"name": "x", "applications": [], "variables": {}, "steps": [
            {"id": 1, "type": "open_app", "window": {}, "params": {}, "validations": []}]}
        self.assertIn("open_app", [i["code"] for i in validation.validate_test(t)])

    def test_apps_matrix_example_validates_and_runs_every_row(self):
        use_temp_workspace()
        d = Path(tempfile.mkdtemp())
        shutil.copytree(REC / "apps_matrix", d / "apps_matrix")
        test = json.loads((d / "apps_matrix" / "test.json").read_text(encoding="utf-8"))
        self.assertEqual([i for i in validation.validate_test({**test, "data": {**test["data"], "columns": ["app", "title"]}})
                          if i["level"] == "error"], [])
        opened = []

        def fake_open(name, **kw):
            opened.append((name, kw["window_title"]))
            return {"method": "fake", "hwnd": 1, "tried": []}

        with mock.patch("core.playback.player.launcher.open_application", fake_open), \
             mock.patch.object(Player, "_settle", lambda *a, **k: None):
            p = Player(test, {"timeout_s": 1.0}, backend=DryRunBackend(), base_dir=d / "apps_matrix")
            p.validator.evaluate = lambda v, w: {"status": "passed", "description": v.get("description", ""), "detail": ""}
            run = p.run()
        self.assertEqual(opened, [("Calculator", "Calculator"), ("Notepad", "Notepad"), ("Paint", "Paint")])
        self.assertEqual(run["status"], "passed")

    def test_typing_waits_for_the_screen_to_settle(self):
        """The old player skipped settling after `type`, so the next click fired before search results existed."""
        t = {"name": "typed", "applications": [], "variables": {},
             "steps": [{"id": 1, "type": "type", "window": {}, "params": {"text": "cal"}, "validations": []}]}
        calls = []
        with mock.patch.object(Player, "_settle", lambda *a, **k: calls.append(1)):
            Player(t, {"timeout_s": 1.0}, backend=DryRunBackend()).run()
        self.assertEqual(calls, [1])

    def test_cli_fix_rewrites_and_keeps_a_backup(self):
        ws = use_temp_workspace()
        d = Path(ws) / "tests" / "cal"
        (d / "assets").mkdir(parents=True)
        (d / "test.json").write_text(json.dumps(original("cal")), encoding="utf-8")      # start from the unrepaired recording
        (d / "test.json.pre_fix.bak").unlink(missing_ok=True)
        self.assertEqual(cli.main(["fix", "cal"]), 0)
        fixed = json.loads((d / "test.json").read_text(encoding="utf-8"))
        self.assertEqual(fixed["steps"][0]["type"], "open_app")
        self.assertTrue((d / "test.json.pre_fix.bak").exists())


if __name__ == "__main__":
    unittest.main()
