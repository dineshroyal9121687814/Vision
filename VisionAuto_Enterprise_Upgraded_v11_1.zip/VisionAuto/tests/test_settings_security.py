"""Settings persistence and privacy regressions."""
from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest import mock

from tests.helpers import use_temp_workspace

use_temp_workspace()

from core import settings  # noqa: E402
from core.system.winenv import _describe  # noqa: E402


class SettingsTests(unittest.TestCase):
    def test_settings_are_validated_and_saved_atomically(self):
        with tempfile.TemporaryDirectory() as tmp, mock.patch("core.paths.workspace", return_value=Path(tmp)):
            settings.save({"timeout_s": 5, "min_recovery_confidence": 0.8})
            path = Path(tmp) / "settings.json"
            before = path.read_bytes()
            loaded = settings.load()
            self.assertEqual(loaded["timeout_s"], 5.0)
            self.assertEqual(loaded["min_recovery_confidence"], 0.8)
            self.assertEqual(list(Path(tmp).glob(".settings-*.tmp")), [])

            with self.assertRaisesRegex(ValueError, "between 0 and 1"):
                settings.save({"min_recovery_confidence": 1.5})
            self.assertEqual(path.read_bytes(), before)

    def test_invalid_or_non_object_settings_fall_back_to_defaults(self):
        with tempfile.TemporaryDirectory() as tmp, mock.patch("core.paths.workspace", return_value=Path(tmp)):
            path = Path(tmp) / "settings.json"
            path.write_text(json.dumps({"use_native": "yes"}), encoding="utf-8")
            self.assertEqual(settings.load(), settings.DEFAULTS)
            path.write_text("[]", encoding="utf-8")
            self.assertEqual(settings.load(), settings.DEFAULTS)

    def test_settings_reject_credentials_in_local_model_url(self):
        with self.assertRaisesRegex(ValueError, "credentials"):
            settings.validate({"llm_base_url": "http://user:token@localhost:11434"})
        with self.assertRaisesRegex(ValueError, "HTTPS"):
            settings.validate({"llm_base_url": "http://model-host:11434"})

    def test_password_uia_description_never_reads_value_or_text(self):
        rect = SimpleNamespace(left=0, top=0, right=200, bottom=40)
        info = SimpleNamespace(name="Password", control_type="Edit", automation_id="password",
                               class_name="Edit", rectangle=rect, is_password=True)
        element = SimpleNamespace(element_info=info, get_value=mock.Mock(return_value="very-secret"),
                                  window_text=mock.Mock(return_value="very-secret"))
        described = _describe(element)
        self.assertTrue(described["is_password"])
        self.assertNotIn("value", described)
        self.assertNotIn("text", described)
        element.get_value.assert_not_called()
        element.window_text.assert_not_called()


if __name__ == "__main__":
    unittest.main()
