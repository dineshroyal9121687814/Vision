"""analytics, object repository, data manager, integrations, AI assistant, security."""
import json
import tempfile
import unittest
from datetime import datetime
from pathlib import Path

from core import ai_assistant, analytics, datamgr, integrations, object_repo, security


def run(name, status, day, **kw):
    return {"test_name": name, "test": name, "status": status, "started_at": f"{day}T10:00:00", "duration_ms": 2000,
            "healed": kw.get("healed", 0), "retries": kw.get("retries", 0), "dry_run": kw.get("dry", False)}


class AnalyticsTests(unittest.TestCase):
    def test_counts_come_only_from_real_runs(self):
        tests = [{"name": "a"}, {"name": "b"}, {"name": "c"}]
        runs = [run("a", "failed", "2026-11-08"), run("a", "passed", "2026-11-01"), run("b", "passed", "2026-11-08", healed=2),
                run("c", "failed", "2026-11-08", dry=True)]
        s = analytics.snapshot(runs, tests, now=datetime(2026, 11, 9))
        self.assertEqual((s["tests"], s["executions"]), (3, 3))          # the dry run is not an execution
        self.assertEqual((s["passed"], s["failed"], s["never_run"]), (1, 1, 1))
        self.assertEqual(s["healed"], 2)
        self.assertEqual(s["success_rate"], 66.7)
        self.assertEqual(len(s["trend"]), 14)
        self.assertEqual(s["trend"][-2]["failed"], 1)

    def test_empty_workspace_has_no_invented_numbers(self):
        s = analytics.snapshot([], [], now=datetime(2026, 11, 9))
        self.assertIsNone(s["success_rate"])
        self.assertEqual((s["executions"], s["avg_duration_ms"]), (0, 0))


class ObjectRepoTests(unittest.TestCase):
    def test_reliability_and_search(self):
        strat = object_repo.strategies_of({"name": "Save", "automation_id": "btn1", "role": "button"})
        self.assertTrue(strat)
        score, basis = object_repo.reliability(strat, [])
        self.assertTrue(0 < score <= 100 and basis)
        weak, _ = object_repo.reliability(object_repo.strategies_of({"x": 1, "y": 2}), [])
        self.assertLess(weak, score)
        measured, why = object_repo.reliability(strat, [("t", "failed", ""), ("t", "passed", "uia")])
        self.assertIn("measured", why)
        self.assertLess(measured, score)
        objs = [{"name": "Save", "application": "notepad.exe", "reliability": 90, "group": "", "locator": "x", "value": "", "test": "t"},
                {"name": "Zed", "application": "calc.exe", "reliability": 20, "group": "", "locator": "x", "value": "", "test": "t"}]
        self.assertEqual([o["name"] for o in object_repo.search(objs, "sav")], ["Save"])
        self.assertEqual([o["name"] for o in object_repo.search(objs, min_reliability=50)], ["Save"])
        self.assertEqual([o["name"] for o in object_repo.search(objs, application="calc")], ["Zed"])

    def test_locator_fix_advice_lists_weak_objects_first(self):
        objs = [{"name": "A", "test": "t", "step": 1, "reliability": 80, "locator": "Name"},
                {"name": "B", "test": "t", "step": 2, "reliability": 30, "locator": "Coordinates"},
                {"name": "C", "test": "t", "step": 3, "reliability": 45, "locator": "Image"}]
        fx = ai_assistant.locator_fixes(objs)
        self.assertEqual([f["object"] for f in fx], ["B", "C"])


class DataManagerTests(unittest.TestCase):
    def test_csv_roundtrip_check_and_bulk_edit(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / "in.csv"
            p.write_text("name,qty\nA,1\nB,x\nA,\n", encoding="utf-8")
            pv = datamgr.preview(p)
            self.assertEqual((pv["columns"], pv["total"]), (["name", "qty"], 3))
            probs = datamgr.check(pv["columns"], pv["rows"], required=["qty"], numeric=["qty"], unique=["name"])
            kinds = {(x["row"], x["column"]) for x in probs}
            self.assertIn((2, "qty"), kinds)                           # 'x' is not a number
            self.assertIn((3, "qty"), kinds)                           # empty required
            self.assertIn((3, "name"), kinds)                          # duplicate A
            self.assertTrue(datamgr.check(["a"], [], required=["zz"]))  # unknown column is reported
            n = datamgr.bulk_edit(pv["rows"], "name", "A", "Z")
            self.assertEqual(n, 2)
            for ext in (".json", ".csv", ".xlsx"):
                out = datamgr.export(pv["columns"], pv["rows"], Path(d) / ("out" + ext))
                self.assertTrue(out.exists() and out.stat().st_size > 0)
                self.assertEqual(datamgr.preview(out)["total"], 3)

    def test_mapping_reports_missing_variables(self):
        test = {"steps": [{"id": 1, "action": "type", "text": "${user}"}, {"id": 2, "action": "type", "text": "${pwd}"}]}
        m = datamgr.mapping(test, ["user", "extra"])
        self.assertEqual(m["mapped"], {"user": "user"})
        self.assertEqual(m["missing"], ["pwd"])
        self.assertEqual(m["unused_columns"], ["extra"])


class IntegrationTests(unittest.TestCase):
    def test_components_report_real_availability(self):
        comps = integrations.components()
        self.assertTrue(comps)
        for c in comps:
            self.assertIn(c["installed"], (True, False))
        self.assertIsInstance(integrations.plugins(), list)


class AssistantTests(unittest.TestCase):
    def test_sentences_become_validated_steps_and_unparsed_lines_are_reported(self):
        r = ai_assistant.nl_to_steps("Open notepad\nType 'hello' into Editor\npress ctrl+s\nwait 2 seconds\ndo something magical")
        acts = [s["type"] for s in r["steps"]]
        self.assertIn("type", acts)
        self.assertIn("open_app", acts)
        self.assertIn("wait", acts)
        self.assertEqual(len(r["unparsed"]), 1)
        self.assertIn("magical", r["unparsed"][0])

    def test_failure_explanation_has_a_category_and_never_blames_a_passing_run(self):
        ok = ai_assistant.explain_failure({"steps": [{"id": 1, "status": "passed"}]})
        self.assertIsNone(ok["failed_step"])
        bad = ai_assistant.explain_failure({"steps": [{"id": 3, "status": "failed", "description": "Click Save",
                                                       "error": "Could not find element 'Save'"}]})
        self.assertEqual(bad["failed_step"], 3)
        self.assertTrue(bad["cause"] and bad["category"])

    def test_regression_suggestions_priority(self):
        rows = [{"test_name": "a", "status": "failed"}, {"test_name": "b", "status": "passed", "healed": 1},
                {"test_name": "c", "status": "passed", "retries": 2}, {"test_name": "d", "status": "passed"}]
        self.assertEqual([x["test"] for x in ai_assistant.regression_suggestions(rows)], ["a", "b", "c"])

    def test_works_without_any_ai(self):
        out = ai_assistant.requirements_to_cases("User can log in with a valid password", llm=None)
        self.assertFalse(out["ai_used"])


class SecurityTests(unittest.TestCase):
    def test_secrets_are_masked(self):
        self.assertNotIn("hunter2secret", security.mask("password=hunter2secret"))
        self.assertNotIn("abcdefghijklmnop1234", security.mask("Authorization: Bearer abcdefghijklmnop1234"))
        self.assertNotIn("p4ss", security.mask("http://bob:p4ss@host/x"))
        self.assertEqual(security.mask("plain text"), "plain text")

    def test_safe_join_blocks_traversal(self):
        with tempfile.TemporaryDirectory() as d:
            self.assertTrue(str(security.safe_join(d, "a", "b.txt")).startswith(str(Path(d).resolve())))
            with self.assertRaises(ValueError):
                security.safe_join(d, "..", "x")

    def test_command_ok_rejects_metacharacters(self):
        self.assertFalse(security.command_ok("calc.exe & del *")[0])
        self.assertFalse(security.command_ok("/nonexistent/prog")[0])


if __name__ == "__main__":
    unittest.main()
