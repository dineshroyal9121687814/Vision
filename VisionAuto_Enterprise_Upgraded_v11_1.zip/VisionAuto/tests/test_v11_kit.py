"""v11: expressions, comparisons, reusable modules, command / HTTP / SQL / screenshot steps, soft checks, patterns."""
import http.server
import json
import sqlite3
import sys
import tempfile
import threading
import unittest
from pathlib import Path
from unittest import mock

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from tests import helpers                                                          # noqa: E402
from core import modules, validation                                               # noqa: E402
from core.playback import compare, expr                                            # noqa: E402
from core.playback.backend import DryRunBackend                                    # noqa: E402
from core.playback.player import Player                                            # noqa: E402
from core.recorder import patterns                                                 # noqa: E402
from core.steplib import catalog                                                   # noqa: E402


class Expr(unittest.TestCase):
    def test_functions_and_arithmetic(self):
        self.assertEqual(expr.evaluate('=upper("ab") + "-" + str(int("4") * 2)'), "AB-8")
        self.assertEqual(expr.evaluate('=add_days("2026-11-17", 14)'), "2026-12-01")
        self.assertEqual(expr.evaluate('=regex("ID-(\\\\d+)", "ID-4521", 1)'), "4521")
        self.assertEqual(expr.evaluate("plain text"), "plain text")
        self.assertEqual(expr.evaluate('=item("[\\"a\\",\\"b\\"]", 2)'), "b")

    def test_nothing_dangerous_runs(self):
        for bad in ('=__import__("os").system("x")', '=open("f")', "=(1).__class__", '=[x for x in ()]', "=lambda: 1"):
            with self.assertRaises(expr.ExpressionError):
                expr.evaluate(bad)

    def test_bind_quotes_values(self):
        out = expr.bind('=upper(${a})', {"a": 'x") + __import__("os") + ("'})
        self.assertEqual(expr.evaluate(out), 'X") + __IMPORT__("OS") + ("')


class Compare(unittest.TestCase):
    def test_numbers_dates_text(self):
        self.assertTrue(compare.check("1,250.50", "equals", "1250.5", tolerance=0.01)[0])
        self.assertTrue(compare.check("$15", "between", "10", "20")[0])
        self.assertFalse(compare.check("abc", "gt", "1")[0])
        self.assertTrue(compare.check("2026-01-01", "date_before", "2026-02-01")[0])
        self.assertTrue(compare.check("Order 42 placed", "regex", r"Order \d+")[0])
        self.assertTrue(compare.check("Red", "in_list", "red;green", ignore_case=True)[0])
        self.assertFalse(compare.check("x", "nonsense")[0])


class Modules(unittest.TestCase):
    LIB = {"login": {"steps": [{"id": 1, "type": "type", "params": {"text": "${user}"}}], "applications": []},
           "a": {"steps": [{"id": 1, "type": "call_test", "params": {"test": "b"}}]},
           "b": {"steps": [{"id": 1, "type": "call_test", "params": {"test": "a"}}]}}

    def _load(self, n):
        if n not in self.LIB:
            raise FileNotFoundError(n)
        return self.LIB[n]

    def test_expand_turns_arguments_into_variables(self):
        t = {"steps": [{"id": 1, "type": "call_test", "params": {"test": "login", "args": {"user": "ann"}}},
                       {"id": 2, "type": "key", "params": {"key": "enter"}}]}
        out = modules.expand(t, self._load)
        self.assertEqual([s["type"] for s in out["steps"]], ["set_variable", "type", "key"])
        self.assertEqual([s["id"] for s in out["steps"]], [1, 2, 3])
        self.assertTrue(out["steps"][1]["description"].startswith("[login]"))

    def test_cycle_and_missing_are_refused(self):
        with self.assertRaises(modules.ModuleError):
            modules.expand({"steps": [{"id": 1, "type": "call_test", "params": {"test": "a"}}]}, self._load)
        with self.assertRaises(modules.ModuleError):
            modules.expand({"steps": [{"id": 1, "type": "call_test", "params": {"test": "nope"}}]}, self._load)


def player(steps, **opts):
    helpers.use_temp_workspace()
    return Player({"name": "t", "steps": steps, "applications": [], "variables": {}},
                  {"timeout_s": 1.0, "settle_wait": False, "use_vision_ai": False, "use_ocr": False, **opts},
                  backend=DryRunBackend(), dry_run=False, grab=lambda: (np.zeros((60, 80, 3), np.uint8), (0, 0)))


def run(p, step):
    return p.run_step({"id": 1, **step})


class Kit(unittest.TestCase):
    def test_set_variable_expression_uses_variables_safely(self):
        p = player([])
        p.app_context.set_variable("first", "ann smith")
        r = run(p, {"type": "set_variable", "params": {"name": "who", "value": '=upper(${first}) + "-" + str(len(${first}))'}})
        self.assertEqual(r["status"], "passed", r)
        self.assertEqual(p.app_context.variables["who"], "ANN SMITH-9")
        bad = run(p, {"type": "set_variable", "params": {"name": "x", "value": "=nosuch(1)"}})
        self.assertEqual(bad["status"], "failed")

    def test_run_command_exit_code_output_and_variable(self):
        p = player([])
        ok = run(p, {"type": "run_command", "params": {"command": f'"{sys.executable}" -c "print(6*7)"', "save_as": "out",
                                                         "expect_output": "42"}})
        self.assertEqual(ok["status"], "passed", ok)
        self.assertEqual(p.app_context.variables["out"], "42")
        bad = run(p, {"type": "run_command", "params": {"command": f'"{sys.executable}" -c "import sys; sys.exit(3)"'}})
        self.assertEqual(bad["status"], "failed")
        self.assertIn("exit code 3", bad["error"])
        self.assertEqual(run(p, {"type": "run_command", "params": {"command": "definitely-not-a-program-xyz"}})["status"], "failed")

    def test_commands_can_be_switched_off(self):
        r = run(player([], allow_commands=False), {"type": "run_command", "params": {"command": "echo hi"}})
        self.assertEqual(r["status"], "failed")

    def test_http_request(self):
        class H(http.server.BaseHTTPRequestHandler):
            def do_GET(self):
                code = 404 if self.path == "/missing" else 200
                body = json.dumps({"user": {"id": 7, "tags": ["a", "b"]}}).encode()
                self.send_response(code)
                self.end_headers()
                self.wfile.write(body)

            def log_message(self, *a):
                pass
        srv = http.server.HTTPServer(("127.0.0.1", 0), H)
        threading.Thread(target=srv.serve_forever, daemon=True).start()
        self.addCleanup(srv.shutdown)
        base = f"http://127.0.0.1:{srv.server_port}"
        p = player([])
        ok = run(p, {"type": "http_request", "params": {"url": base + "/u", "json_path": "user.tags.1", "save_as": "tag",
                                                          "expect_status": "200"}})
        self.assertEqual(ok["status"], "passed", ok)
        self.assertEqual(p.app_context.variables["tag"], "b")
        self.assertEqual(run(p, {"type": "http_request", "params": {"url": base + "/missing"}})["status"], "failed")
        self.assertEqual(run(p, {"type": "http_request", "params": {"url": base + "/missing", "expect_status": "404"}})["status"], "passed")
        self.assertEqual(run(p, {"type": "http_request", "params": {"url": "ftp://x"}})["status"], "failed")

    def test_sql_query_read_only_by_default(self):
        d = Path(tempfile.mkdtemp())
        db = d / "t.db"
        con = sqlite3.connect(db)
        con.execute("create table u(id integer, name text)")
        con.execute("insert into u values (1,'ann'),(2,'bob')")
        con.commit()
        con.close()
        p = player([])
        ok = run(p, {"type": "sql_query", "params": {"database": str(db), "sql": "select name from u order by id",
                                                       "expect_rows": 2, "expect_value": "ann", "save_as": "n"}})
        self.assertEqual(ok["status"], "passed", ok)
        self.assertEqual(p.app_context.variables["n"], "ann")
        self.assertEqual(run(p, {"type": "sql_query", "params": {"database": str(db), "sql": "delete from u"}})["status"], "failed")
        self.assertEqual(run(p, {"type": "sql_query", "params": {"database": str(db), "sql": "select 1", "expect_rows": 5}})["status"], "failed")

    def test_screenshot_is_saved_in_the_run_folder(self):
        p = player([])
        p.run_dir = Path(tempfile.mkdtemp())
        r = run(p, {"type": "screenshot", "params": {"name": "after login"}})
        self.assertEqual(r["status"], "passed", r)
        self.assertTrue((p.run_dir / r["screenshot"]).exists())

    def test_external_steps_do_nothing_in_a_dry_run(self):
        helpers.use_temp_workspace()
        p = Player({"name": "t", "steps": [], "applications": [], "variables": {}}, {"timeout_s": 1.0}, backend=DryRunBackend(),
                   dry_run=True, grab=lambda: (np.zeros((60, 80, 3), np.uint8), (0, 0)))
        with mock.patch("subprocess.run") as sp, mock.patch("urllib.request.urlopen") as uo:
            run(p, {"type": "run_command", "params": {"command": "rm -rf /"}})
            run(p, {"type": "http_request", "params": {"url": "http://example.com"}})
        sp.assert_not_called()
        uo.assert_not_called()


class SoftChecks(unittest.TestCase):
    def test_soft_failure_continues_but_test_fails(self):
        steps = [{"id": 1, "type": "run_command", "on_fail": "continue", "params": {"command": f'"{sys.executable}" -c "import sys; sys.exit(1)"'}},
                 {"id": 2, "type": "set_variable", "params": {"name": "after", "value": "reached"}}]
        p = player(steps)
        out = p.run()
        statuses = [r["status"] for r in out["steps"]]
        self.assertEqual(statuses, ["failed", "passed"], out["steps"])
        self.assertEqual(out["status"], "failed")
        self.assertTrue(out["steps"][0].get("soft_failure"))

    def test_hard_failure_stops(self):
        steps = [{"id": 1, "type": "run_command", "params": {"command": f'"{sys.executable}" -c "import sys; sys.exit(1)"'}},
                 {"id": 2, "type": "set_variable", "params": {"name": "after", "value": "reached"}}]
        out = player(steps, retries=0).run()
        self.assertEqual(len(out["steps"]), 1)


class Catalog(unittest.TestCase):
    def test_new_steps_are_in_the_palette_and_valid(self):
        for t in ("set_variable", "call_test", "run_command", "http_request", "sql_query", "screenshot"):
            self.assertIn(t, catalog.BY_TYPE)
            self.assertIn(t, validation.KNOWN_STEP_TYPES)

    def test_value_check_step_builds_with_engine_key(self):
        s = catalog.build_step("validate", {"validation_type": "value_check", "op": "between", "expected": "1", "expected2": "5",
                                            "target": {"name": "Total"}}, 3)
        self.assertEqual(s["check"]["type"], "value_check")
        self.assertEqual(s["check"]["op"], "between")

    def test_variables_defined_by_new_steps_are_known(self):
        test = {"name": "t", "version": 1, "applications": [], "steps": [
            {"id": 1, "type": "run_command", "params": {"command": "x", "save_as": "o"}},
            {"id": 2, "type": "type", "target": {"name": "f", "x": 1, "y": 1}, "params": {"text": "${o}"}}]}
        codes = [i.get("code") for i in validation.validate_test(test)]
        self.assertNotIn("variable_undefined", codes)


class PaletteInsert(unittest.TestCase):
    SAMPLE = {"set_variable": {"name": "v", "value": "=today()"}, "call_test": {"test": "login", "args": "user=ann"},
              "run_command": {"command": "echo hi"}, "http_request": {"url": "https://example.com"},
              "sql_query": {"database": "a.db", "sql": "select 1"}, "screenshot": {"name": "x"}}

    def test_every_new_step_can_be_added_from_the_palette(self):
        from core import editing
        for t, vals in self.SAMPLE.items():
            test = {"name": "t", "version": 1, "applications": [], "steps": [
                {"id": 1, "type": "wait", "params": {"seconds": 1}, "window": {}, "validations": []}]}
            step = catalog.build_step(t, vals)
            editing.add_step_after(test, 1, step)
            self.assertEqual(test["steps"][1]["type"], t)
            self.assertTrue(test["steps"][1]["description"])

    def test_text_typed_for_an_element_becomes_a_locator(self):
        s = catalog.build_step("click", {"target": "Save", "window": "Book1 - Excel"})
        self.assertEqual(s["target"]["name"], "Save")
        self.assertEqual(s["window"], {"title": "Book1 - Excel"})

    def test_required_field_is_named_when_missing(self):
        with self.assertRaises(ValueError) as cm:
            catalog.build_step("http_request", {"method": "GET"})
        self.assertIn("Address", str(cm.exception))


class Patterns(unittest.TestCase):
    @staticmethod
    def t(n, v):
        return {"type": "type", "target": {"name": n}, "params": {"text": v}}

    @staticmethod
    def c(n):
        return {"type": "click", "target": {"name": n}}

    def test_repeated_block_found_and_turned_into_loop(self):
        t, c = self.t, self.c
        steps = [t("User", "a"), t("Password", "x"), c("Login"),
                 t("Name", "Ann"), t("Qty", "1"), c("Add"), t("Name", "Bob"), t("Qty", "2"), c("Add"), t("Name", "Cy"), t("Qty", "3"), c("Add")]
        found = patterns.analyze(steps)
        kinds = [f["kind"] for f in found]
        self.assertIn("login", kinds)
        rep = next(f for f in found if f["kind"] == "repeated_block")
        self.assertEqual((rep["start"], rep["length"], rep["repeats"]), (3, 3, 3))
        new = patterns.apply_data_loop({"name": "x", "steps": steps}, rep)
        self.assertEqual([s["type"] for s in new["steps"]].count("type"), 4)      # login 2 + ONE block of 2
        self.assertIn("loop_start", [s["type"] for s in new["steps"]])
        p = player(new["steps"])
        typed = []
        orig = p._execute

        def spy(step, res):
            if step["type"] == "type":
                typed.append(step["params"]["text"])
                return
            if step["type"] == "click":
                return
            return orig(step, res)
        p._execute = spy
        p.run()
        self.assertEqual(typed[2:], ["Ann", "1", "Bob", "2", "Cy", "3"])           # replays exactly what was recorded

    def test_plain_sequence_has_no_findings(self):
        self.assertEqual(patterns.analyze([self.c("A"), self.c("B"), self.c("C")]), [])


class Validator(unittest.TestCase):
    def test_value_check_reads_and_compares(self):
        from core.playback.validators import Validator as V
        v = V.__new__(V)
        v.o = {}
        v._text_candidates = lambda t, w: iter([("$1,250.50", "UI Automation")])
        st, detail, actual = V._once(v, {"type": "value_check", "op": "between", "expected": "1000", "expected2": "2000",
                                         "target": {"name": "Total"}}, {})
        self.assertEqual(st, "passed", detail)
        st, detail, _ = V._once(v, {"type": "value_check", "op": "lt", "expected": "100", "target": {"name": "Total"}}, {})
        self.assertEqual(st, "failed")


if __name__ == "__main__":
    unittest.main()


class CellReadWrongPoint(unittest.TestCase):
    """'F8 row contains 1 (found Name Box)': the located point was the Name Box, not the cell."""

    def _candidates(self, at_located, at_recorded, same_layout=True):
        from core.playback.resolver import Resolution
        from core.playback.validators import Validator as V
        v = V.__new__(V)
        v.o = {"use_ocr": True}
        v.park_pointer = None
        v._expected = "1"
        v._ocr_reads = mock.Mock(side_effect=RuntimeError("no ocr"))
        v._native = lambda t, w: None
        v._focused = lambda w: {}
        r = mock.Mock()
        r.resolve_once.return_value = Resolution(50, 10, "image", 0.8)
        r._layout_same = same_layout
        r._recorded_point = lambda t: (300, 200)
        r.governor.call.side_effect = lambda w, fn: fn()
        v.resolver = r
        win = {"title": "Book1 - Excel", "process": "EXCEL.EXE"}

        def element_at(x, y):
            return at_located if (x, y) == (50, 10) else at_recorded
        with mock.patch("core.playback.validators.excel_com.read_cell", return_value=None), \
                mock.patch("core.playback.validators.winenv.element_at", side_effect=element_at), \
                mock.patch("core.playback.validators.winenv.excel_formula_bar", return_value=None), \
                mock.patch("core.playback.validators.winenv.win32_text_at", return_value="Book1"), \
                mock.patch("core.ocr.ocr_engine", create=True):
            return list(v._text_candidates({"name": "F8", "role": "DataItem"}, win))

    def test_name_box_is_not_a_cell_value_and_the_recorded_cell_answers(self):
        got = self._candidates({"name": "Name Box", "text": "Name Box", "role": "Edit"},
                               {"name": "F8", "value": "1", "role": "DataItem", "class_name": "EXCEL7"})
        self.assertEqual(got, [("1", "UI Automation at point")])

    def test_nothing_readable_is_not_a_wrong_value(self):
        got = self._candidates({"name": "Name Box", "text": "Name Box", "role": "Edit"}, {"name": "Ribbon", "role": "Button"})
        self.assertFalse(any(t in ("Name Box", "Book1") for t, _ in got if t), got)
