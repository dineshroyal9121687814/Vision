"""Hybrid reading: native value -> Excel COM -> OCR (last resort), pointer parking, short-value OCR."""
import unittest
from unittest import mock

import cv2
import numpy as np

from core.ocr import ocr_engine
from core.playback.validators import Validator
from core.system import excel_com
from core.vision import pointer


def cell_image(text: str) -> np.ndarray:
    img = np.full((40, 104, 3), 255, np.uint8)
    cv2.rectangle(img, (12, 8), (92, 32), (70, 115, 33), 2)           # Excel's green selection frame
    cv2.putText(img, text, (88 - 11 * len(text), 27), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (0, 0, 0), 1, cv2.LINE_AA)
    return img


class _Plugins:
    def __init__(self, el):
        self.el = el

    def get_plugin_for(self, w):
        return self

    def find_element_native(self, t, w):
        return self.el


class _Resolver:
    def __init__(self, el, frame=None):
        self.plugins = _Plugins(el)
        self.frame = frame if frame is not None else np.full((300, 400, 3), 255, np.uint8)
        self.dir = None
        self.abort_check = lambda: False

    def resolve_once(self, t, w, attempt=1):
        return mock.Mock(x=200, y=150, method="template")

    def grab(self):
        return self.frame, (0, 0)


TARGET = {"name": "G8", "role": "DataItem", "automation_id": "G8", "class_name": "XLSpreadsheetCell",
          "rect": [150, 138, 250, 162], "rel": [0.5, 0.5]}
WIN = {"title": "Book1 - Excel", "process": "EXCEL.EXE"}


class CellAddressIsNotTheValue(unittest.TestCase):
    """The reported failure: validation compared '1' with UIA's name for the cell, 'G8'."""

    def test_address_name_is_a_label(self):
        self.assertTrue(Validator._label_only(TARGET))
        self.assertFalse(Validator._label_only({"name": "Display is 9,801", "role": "Text"}))
        self.assertFalse(Validator._label_only({"name": "OK", "automation_id": "OK", "role": "Button"}))

    def test_uia_value_wins_over_the_label(self):
        v = Validator(_Resolver({**TARGET, "value": "1"}), {})
        self.assertEqual(next(v._text_candidates(TARGET, WIN)), ("1", "UI Automation"))

    def test_excel_com_is_used_when_uia_only_knows_the_address(self):
        v = Validator(_Resolver(dict(TARGET)), {})
        with mock.patch.object(excel_com, "read_cell", return_value="1"):
            self.assertEqual(next(v._text_candidates(TARGET, WIN)), ("1", "Excel"))

    def test_ocr_off_in_settings_is_reported_not_passed(self):
        v = Validator(_Resolver(None), {"use_ocr": False})
        text, why = next(v._text_candidates({"rect": [150, 138, 250, 162]}, {}))
        self.assertIsNone(text)
        self.assertIn("OCR", why)

    def test_full_validation_passes_through_excel_com(self):
        v = Validator(_Resolver(dict(TARGET)), {})
        with mock.patch.object(excel_com, "read_cell", return_value="1"):
            r = v.evaluate({"type": "text_contains", "expected": "1", "target": TARGET, "timeout_s": 0}, WIN)
        self.assertEqual(r["status"], "passed", r)


@unittest.skipUnless(ocr_engine.available(), "no OCR engine installed")
class ShortValueOcr(unittest.TestCase):
    def test_lone_digits_are_readable(self):
        for text in ("1", "2", "7", "15", "9,801"):
            self.assertIn(text, ocr_engine.read_small(cell_image(text), expected=text), text)

    def test_cell_border_is_not_text(self):
        crop = ocr_engine.ink_crop(cell_image("1"))
        self.assertLess(crop.shape[1], 40)                    # the 80 px frame was stripped, only the glyph is left

    def test_validator_reads_a_cell_by_ocr_when_nothing_else_can(self):
        frame = np.full((300, 400, 3), 255, np.uint8)
        frame[130:170, 148:252] = cell_image("1")
        v = Validator(_Resolver(None, frame), {})
        r = v.evaluate({"type": "text_equals", "expected": "1", "target": {"rect": [150, 138, 250, 162],
                                                                          "rel": [0.5, 0.5]}, "timeout_s": 0}, {})
        self.assertEqual(r["status"], "passed", r)


class OcrEngineChain(unittest.TestCase):
    def test_allowlist_only_for_numeric_expectations(self):
        self.assertIsNotNone(ocr_engine.allowlist_for("9,801"))
        self.assertIsNone(ocr_engine.allowlist_for("Total"))
        self.assertIsNone(ocr_engine.allowlist_for(""))

    def test_a_failing_engine_falls_through_to_the_next(self):
        runners = {"rapidocr": mock.Mock(side_effect=RuntimeError("model missing")),
                   "tesseract": mock.Mock(return_value=[([(0, 0)] * 4, "ok", 0.9)])}
        with mock.patch.object(ocr_engine, "engines", return_value=["rapidocr", "tesseract"]), \
                mock.patch.dict(ocr_engine._RUNNERS, runners):
            self.assertEqual(ocr_engine._results(np.zeros((10, 10, 3), np.uint8))[0][1], "ok")

    def test_no_engine_at_all_is_an_error_not_silence(self):
        with mock.patch.object(ocr_engine, "engines", return_value=[]):
            with self.assertRaises(RuntimeError):
                ocr_engine._results(np.zeros((10, 10, 3), np.uint8))


class PointerParking(unittest.TestCase):
    def test_pointer_over_the_region_is_moved_to_the_title_bar(self):
        moves = []
        rect = [150, 138, 250, 162]
        with mock.patch.object(pointer, "position", return_value=(200, 150)):
            moved = pointer.park_if_over(lambda x, y: moves.append((x, y)), rect, {"rect": [0, 0, 1000, 700]})
        self.assertTrue(moved)
        self.assertEqual(moves, [(500, 12)])

    def test_pointer_elsewhere_is_left_alone(self):
        with mock.patch.object(pointer, "position", return_value=(900, 600)):
            self.assertFalse(pointer.park_if_over(lambda x, y: self.fail("moved"), [150, 138, 250, 162], {}))

    def test_no_pointer_info_means_no_move(self):
        with mock.patch.object(pointer, "position", return_value=None):
            self.assertFalse(pointer.park_if_over(lambda x, y: self.fail("moved"), [0, 0, 10, 10], {}))


if __name__ == "__main__":
    unittest.main()


class RapidOutputShapes(unittest.TestCase):
    """Regression: recognition-only output is (text, score); the score '0.6358...' was read as the cell text."""

    def test_text_score_pair_gives_the_text(self):
        self.assertEqual(ocr_engine._rapid_unpack(([["1", 0.6358076333999634]], 0.1))[0][1], "1")

    def test_box_text_score_triple(self):
        self.assertEqual(ocr_engine._rapid_unpack(([[[[0, 0]] * 4, "15", "0.66"]], 0.1))[0][1], "15")

    def test_result_object(self):
        obj = mock.Mock(txts=("9,801",), scores=(0.9,), boxes=None)
        self.assertEqual(ocr_engine._rapid_unpack(obj)[0][1], "9,801")

    def test_none_is_empty(self):
        self.assertEqual(ocr_engine._rapid_unpack((None, 0.1)), [])


class EditModeCell(unittest.TestCase):
    def test_in_cell_editor_is_read_when_com_is_busy(self):
        v = Validator(_Resolver(dict(TARGET)), {})
        with mock.patch.object(excel_com, "read_cell", return_value=None), \
                mock.patch("core.playback.validators.winenv.focused_element", return_value={"value": "1", "role": "Edit"}):
            self.assertEqual(next(v._text_candidates(TARGET, WIN)), ("1", "Excel cell editor"))


# ----------------------------------------------------------------------------- speed / Excel entry
from tests.helpers import make_frame  # noqa: E402


class GovernedNative(unittest.TestCase):
    def test_slow_app_skips_uia_in_validations(self):
        res = _Resolver({"name": "x", "value": "v"})
        gov = mock.Mock()
        gov.allowed.return_value = False
        res.governor = gov
        v = Validator(res, {"use_ocr": False})
        self.assertIsNone(v._native({"name": "x"}, {}))
        gov.call.assert_not_called()

    def test_uia_goes_through_the_time_box(self):
        res = _Resolver({"name": "x"})
        gov = mock.Mock()
        gov.allowed.return_value = True
        gov.call.return_value = {"name": "x", "value": "5"}
        res.governor = gov
        v = Validator(res, {})
        self.assertEqual(v._native({"name": "x"}, {})["value"], "5")
        gov.call.assert_called_once()

    def test_excel_com_is_asked_before_uia(self):
        res = _Resolver(dict(TARGET))
        res.plugins.find_element_native = mock.Mock(side_effect=AssertionError("UIA must not run"))
        v = Validator(res, {})
        with mock.patch.object(excel_com, "read_cell", return_value="7"):
            self.assertEqual(next(v._text_candidates(TARGET, WIN)), ("7", "Excel"))


class ExcelTypedEntry(unittest.TestCase):
    """Typed value is verified after the commit key, in the cell that was ACTIVE when typing (not the clicked one)."""

    def player(self):
        from core.playback.player import Player
        p = Player.__new__(Player)
        p.dry_run = False
        p._pending_cells = []
        return p

    def typed_step(self):
        return {"id": 4, "type": "type", "params": {"text": "2"}, "window": WIN,
                "validations": [{"type": "text_contains", "expected": "2", "target": TARGET}]}

    def test_check_moves_to_the_active_cell_and_runs_after_commit(self):
        p = self.player()
        res = {"id": 4, "status": "passed", "validations": []}
        with mock.patch.object(excel_com, "active_cell", return_value="G9"):
            eff = p._defer_cell_checks(self.typed_step(), res)
        self.assertEqual(eff["validations"], [])
        self.assertEqual(p._pending_cells[0]["addr"], "G9")
        p._flush_cell_checks(res, upto=4)                      # same step: not committed yet
        self.assertEqual(len(p._pending_cells), 1)
        key_res = {"id": 5, "status": "passed", "validations": []}
        with mock.patch.object(excel_com, "read_cell", return_value="2"):
            p._flush_cell_checks(key_res, upto=5)
        self.assertEqual(res["validations"][0]["status"], "passed")
        self.assertEqual(p._pending_cells, [])

    def test_wrong_value_fails_the_typed_step_and_the_current_step(self):
        p = self.player()
        res = {"id": 4, "status": "passed", "validations": []}
        with mock.patch.object(excel_com, "active_cell", return_value="G9"):
            p._defer_cell_checks(self.typed_step(), res)
        key_res = {"id": 5, "status": "passed", "validations": []}
        with mock.patch.object(excel_com, "read_cell", return_value="3"):
            p._flush_cell_checks(key_res, upto=5)
        self.assertEqual(res["status"], "failed")
        self.assertEqual(key_res["status"], "failed")
        self.assertIn("G9", res["error"])

    def test_still_editing_waits_for_the_next_step(self):
        p = self.player()
        res = {"id": 4, "status": "passed", "validations": []}
        with mock.patch.object(excel_com, "active_cell", return_value="G9"):
            p._defer_cell_checks(self.typed_step(), res)
        with mock.patch.object(excel_com, "read_cell", return_value=None):
            p._flush_cell_checks({"id": 5, "status": "passed"}, upto=5)
        self.assertEqual(len(p._pending_cells), 1)

    def test_without_com_the_immediate_check_is_kept(self):
        p = self.player()
        with mock.patch.object(excel_com, "active_cell", return_value=None):
            eff = p._defer_cell_checks(self.typed_step(), {"id": 4, "status": "passed"})
        self.assertEqual(len(eff["validations"]), 1)
        self.assertEqual(p._pending_cells, [])


class TemplateSearchOrder(unittest.TestCase):
    def test_small_picture_is_tried_in_the_near_area_before_the_big_one_scans_the_screen(self):
        from core.playback.resolver import Resolver
        r = Resolver(None, {})
        calls = []

        def fake(area, img, **k):
            calls.append((area.shape[:2], img.shape[0]))
            return mock.Mock(found=img.shape[0] == 100, x=50, y=50, confidence=0.95, scale=1.0,
                             second_confidence=0.1, ambiguous=False)

        r.locator.find_by_template = fake
        frame = make_frame(1920, 1200, seed=1)
        st = {"frame": frame, "origin": (0, 0), "attempt": 1, "template_ambiguous": False,
              "c300": (np.zeros((300, 300, 3), np.uint8), (150, 150)), "c100": (np.zeros((100, 100, 3), np.uint8), (50, 50))}
        res = r._t_image({"x": 500, "y": 500}, {}, st)
        self.assertIsNotNone(res)
        self.assertEqual(len(calls), 2)                        # 300 then 100, both in the first (near) area
        self.assertEqual(calls[0][0], calls[1][0])
        self.assertLess(calls[0][0][0], 1200)
