"""
End-to-end GUI-layer flow without a display:
record (synthetic input) -> Stop -> AI analysis -> review dialog -> save -> playback -> report.
Uses real PySide6 (offscreen) when installed, otherwise tests/fake_qt.py.
"""
import json
import os
import time
import unittest
from unittest import mock
from pathlib import Path
from types import SimpleNamespace
import gc

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from tests.helpers import FakeProbe, use_temp_workspace

use_temp_workspace()

try:
    import PySide6  # noqa: F401
    from PySide6.QtWidgets import QApplication

    _app = QApplication.instance() or QApplication([])
    REAL_QT = True
except ImportError:
    from tests import fake_qt

    fake_qt.install()
    REAL_QT = False

from core import testfile  # noqa: E402
from core.recorder.builder import RawEvent  # noqa: E402
from core.recorder.recorder import Recorder  # noqa: E402

CHECKBOX = {"name": "Dark mode", "role": "CheckBox", "automation_id": "darkMode", "rect": [90, 90, 110, 110],
            "state": {"toggle": "off"}}
SEARCH = {"name": "Search", "role": "Edit", "rect": [180, 190, 300, 210]}


def tearDownModule():
    # Explicitly drain Qt-owned widget cycles while QApplication is alive.
    # Without this, Windows can fast-fail during interpreter shutdown after
    # the offscreen GUI-flow tests have passed.
    if REAL_QT:
        _app.processEvents()
        gc.collect()
        _app.quit()
        _app.processEvents()


def record_session():
    probe = FakeProbe(elements={(100, 100): CHECKBOX, (200, 200): SEARCH})
    probe.default_window = {"title": "Settings", "process": "app.exe", "pid": 7, "hwnd": 1}
    rec = Recorder("gui flow", probe=probe)
    rec.start(listeners=False, overwrite=True)
    t = time.monotonic()
    ev = [RawEvent("mouse_down", t, 100, 100), RawEvent("mouse_up", t + 0.05, 100, 100),
          RawEvent("mouse_down", t + 3, 200, 200), RawEvent("mouse_up", t + 3.05, 200, 200)]
    for i, ch in enumerate("hello"):
        ev += [RawEvent("key_down", t + 4 + i * 0.1, key=ch, is_char=True), RawEvent("key_up", t + 4.01 + i * 0.1, key=ch)]
    for e in ev:
        rec.inject(e)
    return rec


class GuiFlowTests(unittest.TestCase):
    def test_full_flow(self):
        from app.gui.pages.library_page import LibraryPage
        from app.gui.review_dialog import ReviewDialog
        from app.gui.workers import FinishRecordingWorker, PlayWorker

        rec = record_session()
        shown = []
        w = FinishRecordingWorker(SimpleNamespace(rec=rec))
        done = []
        w.progress.connect(lambda m, f: shown.append(m))
        w.done.connect(lambda test, d: done.append((test, d)))
        w.failed.connect(lambda m: self.fail(m))
        w.run()
        self.assertEqual(len(done), 1)
        test, directory = done[0]
        self.assertEqual([s["type"] for s in test["steps"]], ["click", "click", "type"])
        self.assertTrue(shown and shown[-1] == "Done")
        self.assertIn("Dark mode", test["steps"][0]["description"])
        self.assertTrue(test["steps"][0].get("suggestions"))                    # AI suggested a checkbox state check

        dlg = ReviewDialog(test, directory)
        ticked = [c for c in test["steps"][0]["_cands"] if c["checked"]]
        self.assertEqual([c["v"]["type"] for c in ticked], ["state"])           # confident suggestion pre-ticked
        dlg._selected_ids = lambda: [2]                                          # user also selects the Search box
        dlg._use_selected()
        dlg._save(False)

        saved, _ = testfile.load_test(test["name"])
        self.assertEqual(saved["steps"][0]["validations"][0]["expected"], "on")
        self.assertTrue(saved["steps"][1]["validations"])
        self.assertTrue(all("_cands" not in s and "suggestions" not in s for s in saved["steps"]))

        lib = LibraryPage()
        lib.select_by_name(test["name"])
        steps = []
        pw = PlayWorker({"kind": "native", "name": test["name"]}, dry_run=True)
        pw.step.connect(lib._on_step)
        pw.step.connect(steps.append)
        finished = []
        pw.finished_run.connect(finished.append)
        pw.failed.connect(lambda m: self.fail(m))
        pw.run()
        run = finished[0]
        self.assertEqual(run["status"], "inconclusive")
        # checkbox state (AI, pre-ticked) + Search box (user selected) + typed text (AI, confident)
        self.assertEqual(run["summary"]["validations"], 3)
        self.assertEqual(sorted(v["type"] for r in run["steps"] for v in r["validations"]),
                         ["state", "text_contains", "text_equals"])
        self.assertTrue(all(r["status"] == "skipped" for r in run["steps"]))
        self.assertTrue((Path(run["_dir"]) / "report.html").exists())
        report_html = (Path(run["_dir"]) / "report.html").read_text(encoding="utf-8")
        self.assertIn("Environment", report_html)
        self.assertIn("confidence", report_html)

    def test_pages_construct_and_refresh(self):
        from app.gui.main_window import MainWindow

        win = MainWindow()
        for page in (win.dashboard, win.library, win.reports):
            page.refresh()
        win.settings.save()
        saved = json.loads((Path(os.environ["VISIONAUTO_HOME"]) / "settings.json").read_text())
        self.assertIn("timeout_s", saved)

    def test_closing_review_keeps_recording_and_explicit_discard_removes_it(self):
        from app.gui.pages.recorder_page import RecorderPage
        from core import testfile

        class ClosedReview:
            discarded = False
            run_after = False

            def __init__(self, test, directory, parent):
                self.title = type("Title", (), {"text": lambda self: test["title"]})()

            def exec(self):
                return 0

        test = {"schema": "visionauto.test/2", "name": "closed_review", "title": "Closed review",
                "steps": [{"id": 1, "type": "click", "description": "Click Save", "validations": []}]}
        directory = testfile.test_dir(test["name"])
        testfile.save_test(test, directory)
        page = RecorderPage()
        page._cleanup = lambda: None
        saved = []
        page.test_saved.connect(lambda name, run: saved.append((name, run)))
        with mock.patch("app.gui.pages.recorder_page.ReviewDialog", ClosedReview):
            page._on_done(test, str(directory))
        persisted, _ = testfile.load_test(test["name"])
        self.assertEqual(len(persisted["steps"]), 1)
        self.assertEqual(saved, [(test["name"], False)])
        self.assertIn(test["name"], [item["name"] for item in testfile.list_tests()])

        class DiscardedReview(ClosedReview):
            discarded = True

        test["name"] = "explicit_discard"
        directory = testfile.test_dir(test["name"])
        testfile.save_test(test, directory)
        with mock.patch("app.gui.pages.recorder_page.ReviewDialog", DiscardedReview):
            page._on_done(test, str(directory))
        self.assertFalse(directory.exists())

    def test_step_editor_saves_added_step_and_backup(self):
        from app.gui.step_editor import StepEditorDialog, make_step
        from core import testfile

        test = testfile.new_test("step_editor_flow")
        directory = testfile.test_dir(test["name"])
        directory.mkdir(parents=True, exist_ok=True)
        testfile.save_test(test, directory)
        editor = StepEditorDialog(test, directory)
        editor.test["steps"].append(make_step("click", directory, 1, "Text", "Save"))
        editor._renumber()
        editor.save_steps()
        saved, _ = testfile.load_test(test["name"])
        self.assertEqual(len(saved["steps"]), 1)
        self.assertEqual(saved["steps"][0]["target"]["name"], "Save")
        self.assertTrue((directory / "test.json.bak").is_file())


if __name__ == "__main__":
    unittest.main()
