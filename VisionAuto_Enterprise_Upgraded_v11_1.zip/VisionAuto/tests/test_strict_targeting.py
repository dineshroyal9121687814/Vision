"""Strict targeting: the wrong-action defect class.  Pure/mocked unit tests - they prove the DECISION logic, not real
desktop automation (see docs/WINDOWS_E2E_TEST_RESULTS.md for what still needs a real Windows run)."""
import unittest
from unittest import mock

import cv2
import numpy as np

from tests.helpers import make_frame, use_temp_workspace

use_temp_workspace()

from core.automation import guard, locator_test, position, quadrants, textloc          # noqa: E402
from core.automation import window_target as wt                                         # noqa: E402
from core.automation.errors import (AmbiguousTarget, LowConfidenceTarget, PostconditionFailed,   # noqa: E402
                                    WrongTarget)
from core.playback.backend import DryRunBackend                                         # noqa: E402
from core.playback.player import Player                                                 # noqa: E402
from core.playback.resolver import Resolution, Resolver                                 # noqa: E402
from core.xpath.locate import locate                                                    # noqa: E402
from core.xpath.tree import UiaNode                                                     # noqa: E402

N1 = {"hwnd": 1, "title": "Untitled - Notepad", "process": "notepad.exe", "pid": 10, "rect": [0, 0, 800, 600]}
N2 = {"hwnd": 2, "title": "Untitled - Notepad", "process": "notepad.exe", "pid": 11, "rect": [0, 0, 400, 300]}
CALC = {"hwnd": 3, "title": "Calculator", "process": "calc.exe", "pid": 12, "rect": [0, 0, 300, 400]}
DD = {"hwnd": 4, "title": "", "process": "notepad.exe", "pid": 10, "popup": True, "owner": 1, "owner_title": "Untitled - Notepad"}
WINS = [N1, N2, CALC, DD]


class WindowTargetTests(unittest.TestCase):
    def r(self, d, fg=0, wins=WINS):
        return wt.resolve_window(wt.WindowSpec.from_dict(d), wins, fg)

    def test_exact_contains_regex(self):
        self.assertEqual(self.r({"title": "Calculator", "match": "exact"}).window["hwnd"], 3)
        self.assertEqual(self.r({"title": "calc", "match": "contains"}).window["hwnd"], 3)
        self.assertEqual(self.r({"title": r"^Calc\w+$", "match": "regex"}).window["hwnd"], 3)
        self.assertEqual(self.r({"title": "Calc", "match": "exact"}).status, "none")

    def test_bad_regex_and_mode_rejected(self):
        with self.assertRaises(ValueError):
            wt.WindowSpec.from_dict({"title": "(", "match": "regex"})
        with self.assertRaises(ValueError):
            wt.WindowSpec.from_dict({"title": "x", "match": "fuzzy"})

    def test_two_identical_windows_are_ambiguous_not_first(self):
        m = self.r({"title": "Untitled - Notepad", "match": "exact", "process": "notepad.exe"})
        self.assertEqual(m.status, "ambiguous")
        self.assertEqual({w["hwnd"] for w in m.windows}, {1, 2})

    def test_hwnd_and_pid_hints_break_ties_only_when_criteria_hold(self):
        spec = {"title": "Untitled - Notepad", "match": "exact", "hwnd": 2}
        self.assertEqual(self.r(spec).window["hwnd"], 2)
        self.assertEqual(self.r({**spec, "hwnd": 3}).status, "ambiguous")      # stale hint (belongs to Calculator): ignored
        self.assertEqual(self.r({"title": "Untitled", "pid": 11}).window["hwnd"], 2)

    def test_legacy_title_only_prefers_the_active_window_else_ambiguous(self):
        self.assertEqual(self.r({"title": "Untitled - Notepad"}, fg=2).window["hwnd"], 2)
        self.assertEqual(self.r({"title": "Untitled - Notepad"}, fg=3).status, "ambiguous")
        # an EXPLICIT choice is never decided by what happens to be in front
        self.assertEqual(self.r({"title": "Untitled - Notepad", "match": "exact"}, fg=2).status, "ambiguous")

    def test_main_window_picks_the_applications_primary_window(self):
        m = self.r({"main_window": True, "process": "calc.exe"})
        self.assertEqual(m.window["hwnd"], 3)
        m = self.r({"main_window": True, "process": "notepad.exe"})        # pop-up ignored, larger window clearly the main one
        self.assertEqual(m.window["hwnd"], 1)
        same = [N1, {**N2, "rect": [0, 0, 780, 590]}]
        self.assertEqual(self.r({"main_window": True, "process": "notepad.exe"}, wins=same).status, "ambiguous")
        self.assertEqual(self.r({"main_window": True, "process": "notepad.exe"}, fg=2, wins=same).window["hwnd"], 2)
        self.assertEqual(self.r({"main_window": True, "process": "word.exe"}).status, "none")

    def test_validate_spec(self):
        self.assertTrue(wt.validate_spec(wt.WindowSpec.from_dict({"main_window": True})))
        self.assertFalse(wt.validate_spec(wt.WindowSpec.from_dict({"main_window": True, "process": "calc.exe"})))
        self.assertTrue(wt.validate_spec(wt.WindowSpec.from_dict({})))

    def test_popup_is_attributed_to_its_owner(self):
        m = self.r({"owner_title": "Untitled - Notepad", "popup": True, "title": ""}, wins=[DD, N1])
        self.assertEqual(m.window["hwnd"], 4)


class PositionTests(unittest.TestCase):
    def test_window_relative_survives_move_and_normalized_survives_resize(self):
        rec = [100, 100, 500, 400]
        spec = position.from_screen_point(300, 200, "window", rec)
        self.assertEqual(position.compute(spec, [700, 50, 1100, 350]), (900, 150))     # moved
        spec = position.from_screen_point(300, 250, "normalized", rec)
        self.assertEqual(position.compute(spec, [0, 0, 800, 600]), (400, 300))         # resized
        spec = position.from_screen_point(120, 130, "anchor", anchor_rect=[100, 100, 140, 120])
        self.assertEqual(position.compute(spec, anchor_rect=[500, 500, 540, 520]), (520, 530))
        c = position.from_screen_point(150, 150, "container", container_rect=[100, 100, 200, 200])
        self.assertEqual(position.compute(c, container_rect=[0, 0, 400, 400]), (200, 200))

    def test_missing_geometry_is_an_error_not_a_stale_point(self):
        with self.assertRaises(ValueError):
            position.compute({"mode": "window", "dx": 5, "dy": 5}, None)


def cluttered(w=800, h=600, seed=5):
    return make_frame(w, h, seed=seed)


class QuadrantTests(unittest.TestCase):
    def finder_for(self, frame, tpl):
        def f(rect):
            reg = frame[rect[1]:rect[3], rect[0]:rect[2]]
            if reg.shape[0] < tpl.shape[0] or reg.shape[1] < tpl.shape[1]:
                return []
            res = cv2.matchTemplate(reg, tpl, cv2.TM_CCOEFF_NORMED)
            ys, xs = np.where(res >= 0.9)
            out = []
            for y, x in zip(ys, xs):
                out.append(quadrants.Candidate(rect[0] + x + tpl.shape[1] // 2, rect[1] + y + tpl.shape[0] // 2, float(res[y, x])))
            return out
        return f

    def test_finds_target_in_the_right_quadrant_and_never_returns_a_region_centre(self):
        frame = cluttered()
        tpl = frame[420:470, 560:640].copy()                                  # bottom-right
        res = quadrants.search([0, 0, 800, 600], self.finder_for(frame, tpl), "all")
        self.assertEqual(res.status, "found")
        self.assertTrue(res.chosen.quadrant.startswith("br"))
        self.assertAlmostEqual(res.chosen.x, 600, delta=3)
        self.assertAlmostEqual(res.chosen.y, 445, delta=3)                      # the thing's own centre,
        self.assertNotEqual((res.chosen.x, res.chosen.y), (600, 450))           # ... not the br quadrant centre (600, 450)
        only_tl = quadrants.search([0, 0, 800, 600], self.finder_for(frame, tpl), "tl")
        self.assertEqual(only_tl.status, "none")                               # user restricted the search: not found there

    def test_two_lookalikes_in_different_quadrants_are_ambiguous(self):
        frame = cluttered()
        tpl = frame[420:470, 560:640].copy()
        frame[60:110, 100:180] = tpl
        res = quadrants.search([0, 0, 800, 600], self.finder_for(frame, tpl), "all")
        self.assertEqual(res.status, "ambiguous")
        self.assertEqual(len(res.candidates), 2)
        self.assertIsNone(res.chosen)

    def test_order_and_validation(self):
        self.assertEqual(quadrants.parse_order("br, tl"), ["br", "tl"])
        self.assertEqual(quadrants.parse_order("bottom-left"), ["bl"])
        with self.assertRaises(ValueError):
            quadrants.parse_order("middle")

    def test_recursive_subdivision_finds_small_target_the_quadrant_pass_missed(self):
        calls = []

        def finder(rect):
            calls.append(tuple(rect))
            small = (rect[2] - rect[0]) <= 200
            return [quadrants.Candidate(150, 120, 0.95)] if small and rect[0] <= 150 < rect[2] and rect[1] <= 120 < rect[3] else []
        res = quadrants.search([0, 0, 800, 600], finder, "tl", max_depth=2)
        self.assertEqual(res.status, "found")
        self.assertIn("tl/", res.chosen.quadrant)


class GuardTests(unittest.TestCase):
    OPTS = {"strict_targeting": True, "min_action_confidence": 0.85}

    def test_fuzzy_low_confidence_refused_high_accepted(self):
        with self.assertRaises(LowConfidenceTarget):
            guard.vet(Resolution(5, 5, "ocr(contains)", 0.6), {}, self.OPTS)
        with self.assertRaises(LowConfidenceTarget):
            guard.vet(Resolution(5, 5, "xpath-heal", 0.82), {}, self.OPTS)
        self.assertIsNotNone(guard.vet(Resolution(5, 5, "ocr(contains)", 0.93), {}, self.OPTS))
        self.assertIsNotNone(guard.vet(Resolution(5, 5, "native", 1.0), {}, self.OPTS))

    def test_blind_coordinates_refused_unless_explicit(self):
        with self.assertRaises(LowConfidenceTarget):
            guard.vet(Resolution(5, 5, "coordinates(fallback)", 0.3), {}, self.OPTS)
        guard.vet(Resolution(5, 5, "coordinates", 1.0), {"locator_mode": "coordinates"}, self.OPTS)

    def test_identity_mismatch(self):
        r = Resolution(5, 5, "native", 1.0, evidence={"automation_id": "cancelBtn", "role": "Button"})
        with self.assertRaises(WrongTarget):
            guard.vet(r, {"automation_id": "saveBtn", "name": "Save"}, self.OPTS)
        guard.vet(r, {"xpath": "//button[@name='x']", "automation_id": "saveBtn"}, self.OPTS)   # explicit XPath = user's identity

    def test_outside_window_refused(self):
        with self.assertRaises(WrongTarget):
            guard.vet(Resolution(900, 900, "native", 1.0), {}, self.OPTS, [0, 0, 500, 500])

    def test_strict_off_changes_nothing(self):
        guard.vet(Resolution(5, 5, "ocr", 0.1), {}, {"strict_targeting": False})


def two_save_buttons():
    win = UiaNode("Window", "App", rect=(0, 0, 800, 600))
    a = UiaNode("Pane", "Left", automation_id="left", rect=(0, 0, 400, 600))
    b = UiaNode("Pane", "Right", automation_id="right", rect=(400, 0, 800, 600))
    a.add(UiaNode("Button", "Save", automation_id="s1", rect=(10, 10, 90, 40)))
    b.add(UiaNode("Button", "Save", automation_id="s2", rect=(410, 10, 490, 40)))
    return win.add(a, b)


class XPathAmbiguityTests(unittest.TestCase):
    def test_locate_refuses_to_pick_between_two_matches(self):
        tree = two_save_buttons()
        with self.assertRaises(AmbiguousTarget) as cm:
            locate({"xpath": "//button[@name='Save']", "x": 12, "y": 12}, {}, lambda: tree)     # even right next to one
        self.assertEqual(len(cm.exception.candidates), 2)

    def test_container_scoped_xpath_is_unique_and_resolves(self):
        tree = two_save_buttons()
        hit = locate({"xpath": "//pane[@automationid='right']//button[@name='Save']"}, {}, lambda: tree)
        self.assertEqual(hit["automation_id"], "s2")

    def test_preview_reports_count_warning_and_candidates(self):
        tree = two_save_buttons()
        out = locator_test.test_xpath(tree, "//button[@name='Save']")
        self.assertEqual((out["count"], out["verdict"], out["unique"]), (2, "ambiguous", False))
        self.assertIn("NOT click", out["warning"])
        out = locator_test.test_xpath(tree, "//button[@name='Save']", container_xpath="//pane[@automationid='left']")
        self.assertEqual((out["count"], out["verdict"]), (1, "ok"))
        self.assertEqual(locator_test.test_xpath(tree, "//button[")["verdict"], "invalid")
        self.assertEqual(locator_test.test_xpath(tree, "//button[@name='Nope']")["verdict"], "not-found")

    def test_native_ambiguity_does_not_fall_through_to_ocr(self):
        resolver = Resolver(None, {"use_native": True, "use_ocr": True, "use_ai": False}, grab=lambda: (make_frame(200, 200), (0, 0)))
        with mock.patch.object(resolver.plugins, "get_plugin_for") as gp, \
             mock.patch.object(resolver, "_t_ocr", side_effect=AssertionError("must not reach OCR")):
            gp.return_value.find_element_native.side_effect = AmbiguousTarget("2 controls")
            with self.assertRaises(AmbiguousTarget):
                resolver.resolve_once({"name": "Save", "role": "Button", "x": 10, "y": 10}, {"title": "App"}, 1)


class TextLocTests(unittest.TestCase):
    def boxes(self):
        b = lambda x: [(x, 0), (x + 40, 0), (x + 40, 20), (x + 0, 20)]
        return lambda frame: [(b(10), "Save", 0.95), (b(300), "Save as...", 0.9), (b(500), "Savve", 0.8)]

    def test_modes(self):
        f = lambda mode, w="Save": [h.text for h in textloc.find_all(None, w, mode, results_fn=self.boxes())]
        self.assertEqual(f("exact"), ["Save"])
        self.assertEqual(sorted(f("contains")), ["Save", "Save as..."])
        self.assertEqual(sorted(f("startswith")), ["Save", "Save as..."])
        self.assertEqual(sorted(f("regex", r"^Sa\w+$")), ["Save", "Savve"])
        self.assertEqual(sorted(f("fuzzy")), ["Save", "Savve"])
        self.assertEqual(f("exact", "save"), ["Save"])                    # case-insensitive by default
        self.assertEqual(textloc.find_all(None, "save", "exact", case_sensitive=True, results_fn=self.boxes()), [])

    def test_identical_text_is_separated_by_container(self):
        b = lambda x: [(x, 0), (x + 40, 0), (x + 40, 20), (x, 20)]
        hits = textloc.find_all(None, "OK", "exact", results_fn=lambda f: [(b(10), "OK", .9), (b(500), "OK", .9)])
        one, cands = textloc.unique_candidate(hits)
        self.assertIsNone(one)
        self.assertEqual(len(cands), 2)
        one, _ = textloc.unique_candidate(hits, container_rect=(400, 0, 700, 50))
        self.assertEqual(one.x, 520)


class FakeUia:
    """Stands in for core.system.uia_actions (Windows UIA patterns)."""

    def __init__(self, value="", writable=True, shows=None, options=("Red", "Green")):
        self.value, self.writable, self.shows, self.options = value, writable, shows, list(options)
        self.state = "off"

    def read_value(self, x, y):
        return self.value

    def set_value(self, x, y, text, append=False):
        if not self.writable:
            return False
        self.value = self.value + text if append else text
        return True

    def select_option(self, x, y, text="", index=None):
        name = text if index is None else self.options[index]
        if name not in self.options:
            return False
        self.value = self.shows if self.shows is not None else name
        return True

    def set_toggle(self, x, y, want):
        self.state = want
        return True

    def select_item(self, x, y):
        return True

    def submit_file_dialog(self, hwnd, paths):
        return True


class ActionTests(unittest.TestCase):
    def player(self, uia=None):
        p = Player({"name": "x", "steps": []}, {"timeout_s": 0.6, "use_native": False, "use_ocr": False, "settle_wait": False},
                   backend=DryRunBackend())
        p.dry_run = False
        p.uia = uia or FakeUia()
        p._resolve = lambda tg, st, tag, timeout=None: Resolution(50, 60, "native", 1.0, evidence=tg.get("_ev", {}))
        p._ensure_window = lambda step: None
        return p

    def step(self, t, params=None, **kw):
        return {"id": 1, "type": t, "target": {"name": "Field", "role": "Edit", **kw.pop("target", {})},
                "params": params or {}, "window": {}, **kw}

    def test_set_value_replaces_and_is_verified(self):
        p = self.player(FakeUia(value="old"))
        r = p.run_step(self.step("set_value", {"text": "hello"}))
        self.assertEqual(r["status"], "passed")
        self.assertEqual(r["outcome"], "verified")
        self.assertEqual(p.uia.value, "hello")
        self.assertEqual(r["input_method"], "ValuePattern")

    def test_append_and_clear(self):
        p = self.player(FakeUia(value="ab"))
        self.assertEqual(p.run_step(self.step("append_value", {"text": "cd"}))["status"], "passed")
        self.assertEqual(p.uia.value, "abcd")
        self.assertEqual(p.run_step(self.step("clear_value"))["status"], "passed")
        self.assertEqual(p.uia.value, "")

    def test_value_that_does_not_read_back_fails(self):
        class Liar(FakeUia):
            def set_value(self, *a, **k):
                return True                              # pretends success, value unchanged
        p = self.player(Liar(value="old"))
        r = p.run_step(self.step("set_value", {"text": "new"}))
        self.assertEqual((r["status"], r["failure_kind"]), ("failed", "PostconditionFailed"))

    def test_keyboard_fallback_refuses_when_focus_is_not_on_the_field(self):
        p = self.player(FakeUia(writable=False))
        with mock.patch("core.playback.actions_ext.winenv.focused_element", return_value={"name": "Other", "role": "Edit"}):
            r = p.run_step(self.step("set_value", {"text": "secret"}))
        self.assertEqual(r["failure_kind"], "WrongTarget")
        self.assertFalse([a for a in p.backend.actions if a[0] in ("type", "hotkey")])

    def test_disabled_target_is_not_acted_on(self):
        p = self.player()
        r = p.run_step(self.step("set_value", {"text": "x"}, target={"_ev": {"disabled": True}}))
        self.assertEqual(r["failure_kind"], "WrongTarget")
        r = p.run_step({"id": 2, "type": "click", "target": {"name": "Go", "_ev": {"disabled": True}}, "params": {}, "window": {}})
        self.assertEqual(r["status"], "failed")
        self.assertFalse([a for a in p.backend.actions if a[0] == "click"])

    def test_select_option_verifies_the_exact_option(self):
        p = self.player(FakeUia())
        self.assertEqual(p.run_step(self.step("select_option", {"text": "Green"}))["outcome"], "verified")
        p = self.player(FakeUia(shows="Red"))                              # control ends on a different option
        r = p.run_step(self.step("select_option", {"text": "Green"}))
        self.assertEqual(r["failure_kind"], "PostconditionFailed")

    def test_checkbox_is_state_based(self):
        p = self.player(FakeUia())
        states = iter(["on", "on"])
        p._read_state = lambda x, y: next(states)
        r = p.run_step(self.step("set_state", {"state": "check"}))
        self.assertEqual(r["status"], "passed")
        self.assertIn("already on", r["state_check"])                      # already checked: NOT toggled off
        self.assertFalse([a for a in p.backend.actions if a[0] == "click"])
        states = iter(["on", "on"])
        p._read_state = lambda x, y: next(states)
        r = p.run_step(self.step("set_state", {"state": "uncheck"}))      # on -> off requested, reads back 'on': fails
        self.assertEqual(r["failure_kind"], "PostconditionFailed")

    def test_upload_validates_file_before_anything_happens(self):
        p = self.player()
        r = p.run_step(self.step("upload_file", {"path": "/definitely/missing.pdf"}))
        self.assertEqual(r["status"], "failed")
        self.assertIn("does not exist", r["error"])
        self.assertEqual(p.backend.actions, [])
        import tempfile
        with tempfile.NamedTemporaryFile(suffix=".exe") as f:
            r = p.run_step(self.step("upload_file", {"path": f.name, "extensions": [".pdf"]}))
        self.assertIn("Unsupported", r["error"])

    def test_upload_drives_the_dialog_and_proves_it_closed(self):
        import tempfile
        p = self.player()
        dlg = {"hwnd": 77, "title": "Open", "class": "#32770", "pid": 5, "process": "app.exe"}
        alive = {"v": True}
        p.uia.submit_file_dialog = lambda h, paths: alive.update(v=False) or True
        with tempfile.NamedTemporaryFile(suffix=".pdf") as f, \
             mock.patch.object(p, "_enumerate_windows", return_value=[dlg]), \
             mock.patch("core.playback.actions_ext.winenv.window_info", return_value={"pid": 5}), \
             mock.patch("core.playback.actions_ext.winenv.is_window", side_effect=lambda h: alive["v"]):
            r = p.run_step(self.step("upload_file", {"path": f.name}, window={"_hwnd": 9}))
        self.assertEqual((r["status"], r["outcome"]), ("passed", "verified"))
        self.assertEqual([a for a in p.backend.actions if a[0] == "click"], [("click", 50, 60, "left", 1)])

    def test_upload_dialog_left_open_is_a_failure(self):
        import tempfile
        p = self.player()
        dlg = {"hwnd": 77, "title": "Open", "class": "#32770", "pid": 5}
        with tempfile.NamedTemporaryFile(suffix=".pdf") as f, \
             mock.patch.object(p, "_enumerate_windows", return_value=[dlg]), \
             mock.patch("core.playback.actions_ext.winenv.window_info", return_value={"pid": 5}), \
             mock.patch("core.playback.actions_ext.winenv.is_window", return_value=True):
            r = p.run_step(self.step("upload_file", {"path": f.name, "close_timeout_s": 0.2}, window={"_hwnd": 9}))
        self.assertEqual(r["failure_kind"], "PostconditionFailed")

    def test_unverified_actions_are_labelled_and_can_be_made_failures(self):
        p = self.player()
        st = {"id": 1, "type": "click", "target": {"name": "Go"}, "params": {}, "window": {}}
        self.assertEqual(p.run_step(st)["outcome"], "unverified")
        p.opts["require_postcondition"] = True
        r = p.run_step(st)
        self.assertEqual((r["status"], r["failure_kind"]), ("failed", "PostconditionMissing"))

    def test_input_is_released_after_a_crash(self):
        p = self.player()
        p._resolve = mock.Mock(side_effect=RuntimeError("boom"))
        r = p.run_step({"id": 1, "type": "click", "target": {"name": "Go"}, "params": {}, "window": {}})
        self.assertEqual(r["status"], "failed")
        self.assertIn(("release_all",), p.backend.actions)

    def test_wait_for_window_ambiguity_and_success(self):
        p = self.player()
        with mock.patch.object(p, "_enumerate_windows", return_value=[N1, CALC]), \
             mock.patch("core.playback.player.winenv.foreground_window", return_value={"hwnd": 0}):
            ok = p.run_step({"id": 1, "type": "wait_for_window", "params": {"window": {"title": "Calculator", "match": "exact"}}, "window": {}})
        self.assertEqual((ok["status"], ok["outcome" if "outcome" in ok else "status"]), ("passed", "passed"))
        with mock.patch.object(p, "_enumerate_windows", return_value=[N1, N2]), \
             mock.patch("core.playback.player.winenv.foreground_window", return_value={"hwnd": 0}):
            bad = p.run_step({"id": 2, "type": "wait_for_window", "params": {"window": {"title": "Notepad"}}, "window": {}})
        self.assertEqual(bad["failure_kind"], "AmbiguousTarget")


class ResolverIntegrationTests(unittest.TestCase):
    """The real Resolver on synthetic screenshots (no desktop needed)."""

    def setUp(self):
        import tempfile
        from pathlib import Path
        from core.system.imageio import imwrite
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.screen = make_frame(1000, 700, seed=3)
        self.tpl = self.screen[400:460, 700:800].copy()                       # target lives bottom-right
        (Path(self.tmp.name) / "assets").mkdir()
        imwrite(Path(self.tmp.name) / "assets" / "t.png", self.tpl)
        self.target = {"x": 10, "y": 10, "name": "thing", "templates": {"crop300": {"path": "assets/t.png", "click": [50, 30]}}}

    def resolver(self, win=(0, 0, 1000, 700)):
        r = Resolver(self.tmp.name, {"use_native": False, "use_ocr": False, "use_ai": False, "strict_targeting": True},
                     grab=lambda: (self.screen, (0, 0)))
        r._win_rect = list(win)
        return r

    def test_quadrant_search_finds_the_real_target_not_a_region_centre(self):
        t = dict(self.target, search_quadrant="all", search_scope="screen_only")
        res = self.resolver().resolve_once(t, {}, attempt=1)
        self.assertTrue(res.method.startswith(("template", "quadrant")), res.method)
        self.assertAlmostEqual(res.x, 750, delta=4)
        self.assertAlmostEqual(res.y, 430, delta=4)

    def test_quadrant_restriction_disambiguates_lookalikes(self):
        self.screen[100:160, 100:200] = self.tpl                              # identical picture top-left too
        t = dict(self.target, search_scope="screen_only")
        with self.assertRaises(AmbiguousTarget):                              # no quadrant: refuse
            self.resolver().resolve_once(t, {}, attempt=1)
        res = self.resolver().resolve_once(dict(t, search_quadrant="br"), {}, attempt=1)   # user says: bottom-right
        self.assertAlmostEqual(res.x, 750, delta=4)
        with self.assertRaises(AmbiguousTarget):                              # both quadrants: still refuse
            self.resolver().resolve_once(dict(t, search_quadrant="tl,br"), {}, attempt=1)

    def test_position_locator_follows_the_window(self):
        spec = position.from_screen_point(300, 250, "window", [100, 100, 500, 400])
        t = {"locator_mode": "position", "position": spec, "name": "p"}
        a = self.resolver(win=(100, 100, 500, 400)).resolve_once(t, {}, attempt=1)
        b = self.resolver(win=(600, 200, 1000, 500)).resolve_once(t, {}, attempt=1)     # window moved
        self.assertEqual((a.x, a.y), (300, 250))
        self.assertEqual((b.x, b.y), (800, 350))
        self.assertEqual(a.method, "position")

    def test_position_outside_the_window_is_refused(self):
        spec = {"mode": "window", "dx": 5000, "dy": 5}
        with self.assertRaises(LowConfidenceTarget):
            self.resolver().resolve_once({"locator_mode": "position", "position": spec}, {}, attempt=1)


class TargetConfigTests(unittest.TestCase):
    def test_round_trip_and_validation(self):
        from core.automation import target_config as tc
        step = {"window": {"title": "Notepad", "process": "notepad.exe"}, "target": {"name": "Save"}}
        tc.apply_config(step, {"window_match": "exact", "search_quadrant": "br", "text_match": "exact",
                               "container": {"automation_id": "toolbar"}})
        cfg = tc.extract_config(step)
        self.assertEqual((cfg["window_match"], cfg["search_quadrant"], cfg["container"]), ("exact", "br", {"automation_id": "toolbar"}))
        self.assertEqual(step["window"]["window_target"], "specific")
        for bad in ({"main_window": True}, {"window_match": "fuzzy"}, {"search_quadrant": "centre"}, {"text_match": "soundex"},
                    {"position": {"mode": "container"}}):
            with self.assertRaises(ValueError, msg=str(bad)):
                tc.apply_config({"window": {"title": "x"}, "target": {"name": "y"}}, bad)

    def test_main_window_mode_is_stored(self):
        from core.automation import target_config as tc
        step = tc.apply_config({"window": {"process": "calc.exe"}, "target": {"name": "1"}}, {"main_window": True})
        self.assertEqual(step["window"]["window_target"], "main")


if __name__ == "__main__":
    unittest.main()
