"""Tests for the upgrade: bulk table I/O, run controller, retry policy, reports, test cases, generator, settings."""
import json
import os
import tempfile
import threading
import time
import unittest
from datetime import datetime, timedelta
from pathlib import Path
from unittest import mock

from tests.helpers import make_frame, use_temp_workspace

use_temp_workspace()

from core import excel_io, execution, paths, retry, settings, testcases, testgen  # noqa: E402
from core.playback.backend import DryRunBackend  # noqa: E402
from core.playback.player import Player  # noqa: E402
from core.playback.resolver import ElementNotFound  # noqa: E402
from core.reports import manage  # noqa: E402

FRAME = make_frame(400, 300)
OPTS = {"timeout_s": 0.5, "use_native": False, "use_ocr": False, "use_ai": False, "settle_wait": False,
        "retry_delay_s": 0.0, "use_llm": False}


def fresh_ws():
    d = tempfile.mkdtemp(prefix="va_up_")
    os.environ["VISIONAUTO_HOME"] = d
    paths.ensure_dirs()
    return Path(d)


def steps(*types):
    return [{"id": i, "type": t, "params": {"ms": 1} if t == "wait" else {"text": "x"} if t == "type" else {"key": "tab"},
             "window": {}, "validations": []} for i, t in enumerate(types, 1)]


def player(test_steps, opts=None, **kw):
    be = DryRunBackend()
    p = Player({"name": "up", "steps": test_steps}, {**OPTS, **(opts or {})}, backend=be, grab=lambda: (FRAME, (0, 0)), **kw)
    return p, be


class ExcelIoTests(unittest.TestCase):
    def setUp(self):
        self.d = Path(tempfile.mkdtemp(prefix="va_xl_"))

    def test_xlsx_roundtrip_keeps_types_and_blank_cells(self):
        rows = [["id", "name", "amount", "when"], [1, "Ann", 2.5, datetime(2026, 1, 2)], [2, None, 0, None]]
        out = excel_io.write_table(self.d / "a.xlsx", rows)
        self.assertEqual(out["rows"], 3)
        back = excel_io.read_table(self.d / "a.xlsx")
        self.assertEqual(back[1][:3], [1, "Ann", 2.5])
        self.assertIsNone(back[2][1])

    def test_formula_text_is_not_executed_and_control_chars_removed(self):
        out = excel_io.write_table(self.d / "f.xlsx", [["=1+1", "a\x07b"]])
        self.assertEqual(out["sanitized"], 1)
        back = excel_io.read_table(self.d / "f.xlsx")
        self.assertEqual(back[0], ["=1+1", "ab"])

    def test_existing_workbook_formatting_and_other_sheets_survive_and_backup_is_made(self):
        from openpyxl import Workbook, load_workbook
        wb = Workbook()
        ws = wb.active
        ws["A1"] = "keep"
        ws["A1"].font = ws["A1"].font.copy(bold=True)
        ws.column_dimensions["A"].width = 33
        wb.create_sheet("Other")["B2"] = "other"
        wb.save(self.d / "e.xlsx")
        out = excel_io.write_table(self.d / "e.xlsx", [["new", "row"]], start="A3")
        self.assertTrue(Path(out["backup"]).is_file())
        wb2 = load_workbook(self.d / "e.xlsx")
        self.assertTrue(wb2.active["A1"].font.bold)
        self.assertEqual(wb2.active.column_dimensions["A"].width, 33)
        self.assertEqual(wb2["Other"]["B2"].value, "other")
        self.assertEqual(wb2.active["A3"].value, "new")

    def test_csv_tsv_json_roundtrip(self):
        rows = [["a", "b"], ["x,1", 'q"t'], ["multi\nline", "ü"]]
        for ext in (".csv", ".tsv"):
            excel_io.write_table(self.d / f"t{ext}", rows)
            self.assertEqual(excel_io.read_table(self.d / f"t{ext}"), rows)
        excel_io.write_table(self.d / "t.json", rows)
        self.assertEqual(excel_io.read_table(self.d / "t.json")[1], ["x,1", 'q"t'])

    def test_meaningful_errors(self):
        with self.assertRaisesRegex(excel_io.TableError, "not found"):
            excel_io.read_table(self.d / "nope.xlsx")
        (self.d / "bad.xlsx").write_text("not a zip")
        with self.assertRaisesRegex(excel_io.TableError, "not a valid Excel"):
            excel_io.read_table(self.d / "bad.xlsx")
        with self.assertRaisesRegex(excel_io.TableError, "Unsupported"):
            excel_io.read_table(self.d / "x.docx")
        excel_io.write_table(self.d / "c.csv", [["id", "name"], [1, "a"]])
        with self.assertRaisesRegex(excel_io.TableError, "missing required column"):
            excel_io.read_table(self.d / "c.csv", required_columns=["email"])
        excel_io.write_table(self.d / "s.xlsx", [["a"]])
        with self.assertRaisesRegex(excel_io.TableError, "Sheet 'Nope' not found"):
            excel_io.read_table(self.d / "s.xlsx", sheet="Nope")
        with self.assertRaisesRegex(excel_io.TableError, "Invalid start cell"):
            excel_io.write_table(self.d / "s.xlsx", [["a"]], start="??")

    def test_progress_and_cancel_leave_no_half_written_file(self):
        rows = [[i, "v"] for i in range(5000)]
        seen = []
        excel_io.write_table(self.d / "p.xlsx", rows, progress=lambda d, t: seen.append(d))
        self.assertTrue(seen and seen[-1] == 5000)
        with self.assertRaises(excel_io.Cancelled):
            excel_io.write_table(self.d / "c.xlsx", rows, cancel=lambda: True)
        self.assertFalse((self.d / "c.xlsx").exists())
        self.assertEqual([p.name for p in self.d.iterdir() if p.name.startswith(".va-")], [])

    def test_large_dataset_is_fast_and_complete(self):
        rows = [[i, f"user {i}", i * 1.5] for i in range(20000)]
        t = time.perf_counter()
        excel_io.write_table(self.d / "big.xlsx", rows)
        self.assertLess(time.perf_counter() - t, 20)
        self.assertEqual(len(excel_io.read_table(self.d / "big.xlsx")), 20000)

    def test_clipboard_text_quotes_special_cells(self):
        text = excel_io.to_clipboard_text([["a\tb", 'say "hi"', None, "line1\nline2"], [1, 2, 3, 4]])
        self.assertEqual(text, '"a\tb"\t"say ""hi"""\t\t"line1\nline2"\r\n1\t2\t3\t4')


class ControllerTests(unittest.TestCase):
    def test_legal_and_illegal_transitions(self):
        c = execution.RunController()
        self.assertFalse(c.pause())                      # not started
        self.assertTrue(c.start())
        self.assertTrue(c.pause())
        self.assertFalse(c.pause())                      # already paused
        self.assertTrue(c.resume())
        self.assertFalse(c.resume())
        self.assertTrue(c.stop())
        self.assertTrue(c.should_stop())
        self.assertFalse(c.pause())                      # cannot pause a stopping run
        self.assertTrue(c.cancel())                      # stop can be escalated to cancel
        self.assertEqual(c.finish(), execution.CANCELLED)
        self.assertFalse(c.stop())
        self.assertTrue(c.start())                       # reusable after a terminal state

    def test_wait_if_paused_blocks_until_resume_and_ends_on_stop(self):
        c = execution.RunController()
        c.start()
        c.pause()
        out = []
        t = threading.Thread(target=lambda: out.append(c.wait_if_paused()))
        t.start()
        time.sleep(0.2)
        self.assertTrue(t.is_alive())
        c.resume()
        t.join(2)
        self.assertEqual(out, [True])
        c.pause()
        t2 = threading.Thread(target=lambda: out.append(c.wait_if_paused()))
        t2.start()
        c.stop()
        t2.join(2)
        self.assertEqual(out[-1], False)


class PlayerControlTests(unittest.TestCase):
    def setUp(self):
        fresh_ws()

    def run_in_thread(self, p):
        box = {}
        t = threading.Thread(target=lambda: box.update(run=p.run()))
        t.start()
        return t, box

    def test_pause_stops_after_current_step_and_resume_continues_with_next_step(self):
        c = execution.RunController()
        c.start()
        gate = threading.Event()
        seen = []

        def on_step(r):
            if r.get("status") != "running":
                seen.append(r["id"])
                if r["id"] == 2:
                    c.pause()
                    gate.set()

        p, be = player(steps("type", "type", "type", "type"), controller=c, on_step=on_step)
        t, box = self.run_in_thread(p)
        gate.wait(3)
        time.sleep(0.4)
        self.assertEqual(seen, [1, 2])                   # nothing ran while paused
        self.assertEqual(len(be.actions), 2)
        c.resume()
        t.join(5)
        self.assertEqual(seen, [1, 2, 3, 4])             # continued from step 3: nothing repeated or skipped
        self.assertEqual(len(be.actions), 4)
        self.assertEqual(box["run"]["status"], "passed")

    def test_stop_while_paused_ends_run_with_partial_report(self):
        c = execution.RunController()
        c.start()
        gate = threading.Event()

        def on_step(r):
            if r.get("status") != "running" and r["id"] == 1:
                c.pause()
                gate.set()

        p, be = player(steps("type", "type", "type"), controller=c, on_step=on_step)
        t, box = self.run_in_thread(p)
        gate.wait(3)
        c.stop()
        t.join(5)
        self.assertFalse(t.is_alive())                   # no orphan worker
        run = box["run"]
        self.assertEqual(run["status"], "aborted")
        self.assertEqual(run["summary"]["passed"], 1)
        self.assertTrue((Path(run["_dir"]) / "run.json").is_file())

    def test_cancel_marks_report_cancelled_and_thread_ends(self):
        c = execution.RunController()
        c.start()
        gate = threading.Event()

        def on_step(r):
            if r.get("status") != "running" and r["id"] == 1:
                c.cancel()
                gate.set()

        p, _ = player(steps("type", "type", "type"), controller=c, on_step=on_step)
        t, box = self.run_in_thread(p)
        t.join(5)
        self.assertFalse(t.is_alive())
        self.assertEqual(box["run"]["status"], "cancelled")


class FastEntryTests(unittest.TestCase):
    def test_consecutive_typing_steps_skip_settle_but_last_one_settles(self):
        fresh_ws()
        calls = []
        p, _ = player(steps("type", "key", "type", "key", "wait"), {"settle_wait": True, "fast_entry": True})
        with mock.patch.object(Player, "_settle", lambda self, *a, **k: calls.append(1)):
            p.run()
        # every typing step except the last one before a non-typing step skips the settle
        self.assertEqual(len(calls), 1)
        calls.clear()
        p, _ = player(steps("type", "key", "type", "key", "wait"), {"settle_wait": True, "fast_entry": False})
        with mock.patch.object(Player, "_settle", lambda self, *a, **k: calls.append(1)):
            p.run()
        self.assertEqual(len(calls), 4)

    def test_fill_table_pastes_once_with_special_characters_and_restores_clipboard(self):
        fresh_ws()
        store = {"t": "before"}

        class Clip:
            def get(self): return store["t"]
            def set(self, t): store["t"] = t

        from core.system import clipboard
        pasted = []
        step = [{"id": 1, "type": "fill_table", "window": {}, "validations": [],
                 "params": {"rows": [["a", "b\tc"], ["1", 'q"x']]}}]
        p, be = player(step)
        orig_hotkey = be.hotkey
        be.hotkey = lambda k: (pasted.append((k, store["t"])), orig_hotkey(k))
        with mock.patch.object(clipboard, "_backend", Clip()):
            run = p.run()
        self.assertEqual(run["status"], "passed", run)
        self.assertEqual(len(pasted), 1)                 # one paste for the whole block
        self.assertEqual(pasted[0][0], "ctrl+v")
        self.assertEqual(pasted[0][1], 'a\t"b\tc"\r\n1\t"q""x"')
        self.assertEqual(store["t"], "before")
        self.assertEqual(run["steps"][0]["cells"], 4)

    def test_fill_table_file_must_be_inside_test_folder_and_missing_file_fails_clearly(self):
        ws = fresh_ws()
        step = [{"id": 1, "type": "fill_table", "window": {}, "validations": [], "params": {"file": "../../etc/passwd"}}]
        p, _ = player(step)
        run = p.run()
        self.assertEqual(run["status"], "failed")
        self.assertIn("inside the test", run["steps"][0]["error"])


class RetryPolicyTests(unittest.TestCase):
    def setUp(self):
        fresh_ws()

    def flaky(self, fails, error=ElementNotFound):
        n = {"calls": 0}
        orig = Player._execute

        def execute(self, step, res):
            n["calls"] += 1
            if n["calls"] <= fails:
                raise error("target not found" if error is ElementNotFound else "boom")
            return orig(self, step, res)
        return n, mock.patch.object(Player, "_execute", execute)

    def test_classification(self):
        self.assertFalse(retry.classify({"status": "failed", "error": "Sensitive input was redacted"})["recoverable"])
        c = retry.classify({"status": "failed", "error": "Element not found", "retryable": True})
        self.assertTrue(c["recoverable"] and not c["input_sent"])
        c = retry.classify({"status": "failed", "error": "Validation failed: x"})
        self.assertTrue(c["recoverable"] and c["input_sent"])

    def test_not_found_is_retried_after_user_says_retry_and_history_is_recorded(self):
        n, patch = self.flaky(1)
        questions = []
        p, _ = player(steps("type"), {"retry_max_attempts": 2}, ask_user=lambda pl, t: questions.append(pl) or "retry")
        with patch:
            run = p.run()
        self.assertEqual(run["status"], "passed")
        step = run["steps"][0]
        self.assertTrue(step["recovered_by_retry"])
        self.assertEqual(len(questions), 1)
        self.assertEqual(questions[0]["classification"]["category"], "not_found")
        h = step["retry_history"][0]
        self.assertEqual((h["decision"], h["via"], h["result"]), ("retry", "user", "passed"))
        self.assertTrue(h["diagnosis"]["summary"])

    def test_no_answer_follows_timeout_action(self):
        n, patch = self.flaky(1)
        p, _ = player(steps("type"), {"retry_timeout_action": "retry"}, ask_user=lambda pl, t: None)
        with patch:
            run = p.run()
        self.assertEqual(run["steps"][0]["retry_history"][0]["via"], "timeout")
        self.assertEqual(run["status"], "passed")
        n, patch = self.flaky(1)
        p, _ = player(steps("type"), {"retry_timeout_action": "skip"}, ask_user=lambda pl, t: None)
        with patch:
            run = p.run()
        self.assertEqual(run["status"], "failed")        # never retried, never marked passed
        self.assertEqual(n["calls"], 1)

    def test_attempts_are_bounded_and_failure_is_not_hidden(self):
        n, patch = self.flaky(99)
        p, _ = player(steps("type"), {"retry_max_attempts": 3, "retry_ask_before": False, "retry_auto": True})
        with patch:
            run = p.run()
        self.assertEqual(run["status"], "failed")
        self.assertEqual(n["calls"], 4)                  # 1 + 3 retries, not endless
        self.assertEqual(len(run["steps"][0]["retry_history"]), 3)

    def test_permanent_failure_is_never_retried(self):
        step = [{"id": 1, "type": "type", "window": {}, "validations": [], "params": {"text": "x", "redacted": True}}]
        p, _ = player(step, {"retry_ask_before": False, "retry_auto": True})
        run = p.run()
        self.assertEqual(run["status"], "failed")
        self.assertEqual(run["steps"][0]["retry_history"][0]["decision"], "give_up")
        self.assertEqual(len(run["steps"][0]["retry_history"]), 1)

    def test_input_already_sent_is_not_blindly_retried(self):
        n, patch = self.flaky(1, error=RuntimeError)
        p, _ = player(steps("type"), {"retry_ask_before": False, "retry_auto": True})
        with patch:
            run = p.run()
        self.assertEqual(run["status"], "failed")
        self.assertEqual(n["calls"], 1)
        self.assertEqual(run["steps"][0]["retry_history"][0]["via"], "auto-retry-unsafe")
        n, patch = self.flaky(1, error=RuntimeError)
        p, _ = player(steps("type"), {"retry_ask_before": False, "retry_auto": True, "retry_allow_after_input": True})
        with patch:
            self.assertEqual(p.run()["status"], "passed")

    def test_user_stop_answer_ends_the_run(self):
        n, patch = self.flaky(99)
        p, _ = player(steps("type", "type"), {"retry_continue": 1, "continue_on_failure": True}, ask_user=lambda pl, t: "stop")
        with patch:
            run = p.run()
        self.assertEqual(len(run["steps"]), 1)           # second step never ran

    def test_restart_mode_reruns_whole_test_and_keeps_abandoned_attempt(self):
        n, patch = self.flaky(1)
        p, be = player(steps("type", "type"), {"retry_mode": "restart_test", "retry_ask_before": False, "retry_auto": True})
        with patch:
            run = p.run()
        self.assertEqual(run["status"], "passed")
        self.assertEqual(len(run["restarts"]), 1)
        self.assertEqual(len(run["steps"]), 2)

    def test_stop_after_repeated_failures(self):
        n, patch = self.flaky(99)
        p, _ = player(steps("type", "type", "type", "type"), {"retry_enabled": False, "continue_on_failure": True,
                                                              "retry_stop_after_failures": 2})
        with patch:
            run = p.run()
        self.assertEqual(len(run["steps"]), 2)

    def test_dry_run_never_retries(self):
        n, patch = self.flaky(99)
        p = Player({"name": "d", "steps": steps("type")}, OPTS, dry_run=True)
        with patch:
            run = p.run()
        self.assertEqual(n["calls"], 1)

    def test_report_shows_retry_history(self):
        n, patch = self.flaky(1)
        p, _ = player(steps("type"), ask_user=lambda pl, t: "retry")
        with patch:
            run = p.run()
        html = (Path(run["_dir"]) / "report.html").read_text(encoding="utf-8")
        self.assertIn("Retry attempt 1", html)
        self.assertIn("retry attempts", html)


class ReportManagementTests(unittest.TestCase):
    def make_run(self, test, run_id, status="passed", started=None):
        d = paths.runs_dir() / test / run_id
        d.mkdir(parents=True)
        (d / "run.json").write_text(json.dumps({"test": test, "run_id": run_id, "status": status,
                                                "started_at": (started or datetime.now()).isoformat(timespec="seconds"),
                                                "summary": {"total": 2, "passed": 1, "failed": 1, "duration_ms": 5}, "steps": []}))
        (d / "report.html").write_text("<html></html>")
        (d / "shot.jpg").write_bytes(b"x" * 10)
        return d

    def setUp(self):
        fresh_ws()

    def test_list_filter_sort(self):
        self.make_run("Login", "r1", "passed")
        self.make_run("Pay", "r2", "failed")
        rows = manage.list_reports()
        self.assertEqual(len(rows), 2)
        self.assertEqual([r["test"] for r in manage.filter_sort(rows, status="failed")], ["Pay"])
        self.assertEqual(manage.filter_sort(rows, text="login")[0]["test"], "Login")
        self.assertEqual(manage.filter_sort(rows, sort_by="status", descending=False)[0]["status"], "failed")

    def test_delete_only_the_selected_run_and_nothing_else(self):
        a, b = self.make_run("Login", "r1"), self.make_run("Login", "r2")
        tests_dir = paths.tests_dir() / "Login"
        tests_dir.mkdir(parents=True)
        (tests_dir / "test.json").write_text("{}")
        out = manage.delete_run(a)
        self.assertTrue(out["deleted"])
        self.assertFalse(a.exists())
        self.assertTrue(b.exists())
        self.assertTrue((tests_dir / "test.json").exists())
        self.assertEqual(len(manage.list_reports()), 1)

    def test_empty_test_history_folder_is_removed_but_not_when_other_runs_exist(self):
        a = self.make_run("Solo", "r1")
        manage.delete_run(a)
        self.assertFalse((paths.runs_dir() / "Solo").exists())

    def test_refuses_dangerous_paths(self):
        keep = paths.tests_dir()
        keep.mkdir(parents=True, exist_ok=True)
        (keep / "x.txt").write_text("x")
        self.make_run("T", "r1")
        for bad in (paths.runs_dir(), paths.runs_dir() / "T", keep, paths.workspace(), Path("/tmp")):
            res = manage.delete_run(bad)
            self.assertFalse(res["deleted"], bad)
            self.assertTrue(res["error"])
        self.assertTrue((keep / "x.txt").exists())
        self.assertTrue((paths.runs_dir() / "T" / "r1").exists())
        (paths.runs_dir() / "T" / "nojson").mkdir()
        self.assertFalse(manage.delete_run(paths.runs_dir() / "T" / "nojson")["deleted"])      # unfinished / unrelated

    def test_missing_folder_is_handled(self):
        res = manage.delete_run(paths.runs_dir() / "Ghost" / "r1")
        self.assertFalse(res["deleted"])
        self.assertEqual(res["error"], "already deleted")

    def test_delete_selected_and_old(self):
        old = self.make_run("T", "old", started=datetime.now() - timedelta(days=40))
        new = self.make_run("T", "new")
        res = manage.delete_old(30)
        self.assertEqual(res["deleted"], 1)
        self.assertFalse(old.exists())
        self.assertTrue(new.exists())
        self.assertEqual(manage.delete_runs([new, new])["deleted"], 1)       # duplicates are ignored

    def test_undeletable_file_is_reported_not_raised(self):
        d = self.make_run("T", "r1")
        real_unlink = Path.unlink

        def unlink(self, *a, **k):
            if self.name == "shot.jpg":
                raise PermissionError(13, "Permission denied")
            return real_unlink(self, *a, **k)
        with mock.patch.object(Path, "unlink", unlink), mock.patch("os.chmod"):
            res = manage.delete_run(d)
        self.assertFalse(res["deleted"])
        self.assertIn("could not be deleted", res["error"])


class TestCaseTests(unittest.TestCase):
    def setUp(self):
        self.ws = fresh_ws()

    def case(self, title="Login ok", **kw):
        return {"title": title, "steps": ["a", "b"], "expected_results": ["ok"], "category": "positive", **kw}

    def test_crud_clone_and_search(self):
        c = testcases.add_case(self.case(), "Login")
        self.assertEqual(c["id"], "LOG-POS-001")
        self.assertEqual(c["status"], "not_run")
        clone = testcases.clone_case(c["id"])
        self.assertEqual(clone["id"], "LOG-POS-002")
        self.assertEqual(len(testcases.list_cases()), 2)
        testcases.update_case(c["id"], {"title": "Renamed", "priority": "high"})
        self.assertEqual(testcases.find(c["id"])["priority"], "High")
        self.assertEqual([x["title"] for x in testcases.search(testcases.list_cases(), "renamed")], ["Renamed"])
        self.assertTrue(testcases.delete_case(clone["id"]))
        self.assertEqual(len(testcases.list_cases()), 1)
        self.assertFalse(testcases.delete_case("NOPE"))

    def test_moving_category_moves_case_between_files_and_empty_file_is_removed(self):
        c = testcases.add_case(self.case(), "Login")
        testcases.update_case(c["id"], {"category": "negative"})
        self.assertFalse((testcases.root() / "Login" / "login_positive.json").exists())
        self.assertTrue((testcases.root() / "Login" / "login_negative.json").exists())

    def test_result_cannot_be_faked(self):
        c = testcases.add_case(self.case(status="passed", result="passed"), "Login")
        self.assertEqual(c["status"], "not_run")
        self.assertNotIn("result", c)

    def test_custom_storage_path_validation_and_migration_preserves_cases(self):
        testcases.add_case(self.case(), "Login")
        new = self.ws / "elsewhere" / "cases"
        out = testcases.change_root(new)
        self.assertEqual(out["copied"], 1)
        self.assertEqual(settings.load()["testcases_dir"], str(new.resolve()))
        self.assertEqual(len(testcases.list_cases()), 1)                         # found in the new place
        self.assertTrue((paths.testcases_dir() / "Login" / "login_positive.json").exists())   # old copy kept
        with self.assertRaises(testcases.CaseError):
            testcases.validate_dir("")
        f = self.ws / "afile"
        f.write_text("x")
        with self.assertRaisesRegex(testcases.CaseError, "is a file"):
            testcases.validate_dir(f)

    def test_import_export_roundtrip_and_duplicate_handling(self):
        testcases.add_case(self.case("A"), "Login")
        testcases.add_case(self.case("B", category="negative"), "Payment")
        dest = self.ws / "export.json"
        self.assertEqual(testcases.export_cases(dest)["cases"], 2)
        out = testcases.import_cases(dest)
        self.assertEqual((out["added"], out["skipped"]), (0, 2))
        out = testcases.import_cases(dest, on_duplicate="renumber")
        self.assertEqual(out["added"], 2)
        testcases.export_cases(self.ws / "e.csv", fmt="csv")
        self.assertIn("Login ok" if False else "A", (self.ws / "e.csv").read_text(encoding="utf-8-sig"))
        tree = testcases.export_cases(self.ws / "tree", fmt="tree")
        self.assertGreaterEqual(tree["files"], 2)
        (self.ws / "bad.json").write_text("{nope")
        with self.assertRaises(testcases.CaseError):
            testcases.import_cases(self.ws / "bad.json")

    def test_reusable_steps_and_variables(self):
        testcases.save_shared_step("login", ["Open app", "Log in as ${user}"])
        c = {"title": "t", "steps": [{"use": "login"}, "Check ${user}"], "test_data": {"user": "ann"}, "expected_results": ["${user} sees home"]}
        out = testcases.expand(c)
        self.assertEqual(out["steps"], ["Open app", "Log in as ann", "Check ann"])
        self.assertEqual(out["expected_results"], ["ann sees home"])
        with self.assertRaises(testcases.CaseError):
            testcases.expand({"title": "t", "steps": [{"use": "missing"}]})

    def test_topic_delete_stays_inside_root(self):
        testcases.add_case(self.case(), "Login")
        testcases.add_case(self.case("P"), "Payment")
        self.assertEqual(testcases.delete_topic("Login"), 1)
        self.assertEqual(testcases.list_topics(), ["Payment"])
        self.assertEqual(testcases.delete_topic("../.."), 0)


class GeneratorTests(unittest.TestCase):
    def setUp(self):
        fresh_ws()

    REQ = ("Login:\nUsername and password are required. The password must be minimum 8 characters.\n"
           "Payment:\nAmount must be between 1 and 5000. The user pays by credit card and gets a receipt.\n"
           "Registration:\nThe user can register with an email address.")

    def test_topics_are_split_and_all_categories_and_fields_present(self):
        r = testgen.generate(self.REQ)
        self.assertEqual(list(r["topics"]), ["Login", "Payment", "Registration"])
        cases = r["topics"]["Login"]
        self.assertEqual({c["category"] for c in cases}, set(testcases.CATEGORIES))
        for c in cases:
            for f in testcases.CASE_FIELDS:
                self.assertIn(f, c)
            self.assertTrue(c["steps"] and c["expected_results"] and c["id"])
            self.assertEqual(c["status"], "not_run")
        self.assertEqual(len({c["id"] for c in cases}), len(cases))

    def test_boundary_values_for_numeric_range(self):
        titles = [c["title"] for c in testgen.generate(self.REQ)["topics"]["Payment"] if c["category"] == "boundary"]
        for v in ("0)", "1)", "5000)", "5001)"):
            self.assertTrue(any(f"({v}" in t or t.endswith(v) for t in titles), (v, titles))

    def test_length_boundaries(self):
        cases = [c for c in testgen.generate(self.REQ)["topics"]["Login"] if c["category"] == "boundary"]
        self.assertTrue(any("7 characters" in c["title"] for c in cases))
        self.assertTrue(any("8 characters" in c["title"] for c in cases))

    def test_files_are_separate_per_topic_and_category(self):
        r = testgen.generate(self.REQ)
        out = testgen.save_generated(r["topics"])
        root = Path(out["root"])
        for rel in ("Login/login_positive.json", "Login/login_negative.json", "Login/login_boundary.json",
                    "Payment/payment_positive.json", "Payment/payment_negative.json", "Registration/registration_validation.json"):
            self.assertTrue((root / rel).is_file(), rel)
        self.assertGreaterEqual(len(out["files"]), 20)
        # a second save never overwrites: ids stay unique
        testgen.save_generated(r["topics"])
        ids = [c["id"] for c in testcases.list_cases()]
        self.assertEqual(len(ids), len(set(ids)))

    def test_custom_output_folder(self):
        out = Path(tempfile.mkdtemp(prefix="va_out_")) / "my cases"
        r = testgen.generate("Search box accepts text", topic="Search", categories=("positive", "negative"))
        res = testgen.save_generated(r["topics"], out)
        self.assertTrue((out / "Search" / "search_positive.json").is_file())
        self.assertEqual(res["root"], str(out.resolve()))

    def test_duplicates_removed_against_saved_and_coverage_reported(self):
        r1 = testgen.generate("Search box accepts text", topic="Search")
        testgen.save_generated(r1["topics"])
        r2 = testgen.generate("Search box accepts text", topic="Search", existing=testcases.list_cases())
        self.assertEqual(r2["topics"]["Search"], [])
        self.assertGreater(len(r2["duplicates"]["Search"]), 0)
        cov = testgen.generate("Users can log in with a valid password. Admins can export every report to PDF.", topic="Login")["coverage"]["Login"]
        self.assertTrue(cov["items"])
        self.assertTrue(any(not i["covered"] for i in cov["items"]) or cov["percent"] == 100.0)

    def test_empty_requirement_is_rejected(self):
        with self.assertRaises(testcases.CaseError):
            testgen.generate("   ")

    def test_llm_cases_are_merged_but_marked_ai_and_bad_answers_ignored(self):
        class LLM:
            def available(self): return True
            def generate(self, p): return json.dumps({"cases": [{"title": "Odd one", "steps": ["s"], "expected_results": ["e"], "category": "negative"}, {"nope": 1}]})
        r = testgen.generate("Login with password", topic="Login", llm=LLM())
        ai = [c for c in r["topics"]["Login"] if c["source"] == "ai"]
        self.assertEqual([c["title"] for c in ai], ["Odd one"])

        class Bad:
            def available(self): return True
            def generate(self, p): return "not json"
        self.assertTrue(testgen.generate("Login with password", topic="Login", llm=Bad())["topics"]["Login"])


class SettingsTests(unittest.TestCase):
    def setUp(self):
        fresh_ws()

    def test_new_settings_persist_and_validate(self):
        opts = settings.load()
        opts.update(retry_max_attempts=4, retry_mode="restart_test", theme="light", testcases_dir="", retry_timeout_s=12.5)
        settings.save(opts)
        back = settings.load()
        self.assertEqual((back["retry_max_attempts"], back["retry_mode"], back["theme"], back["retry_timeout_s"]), (4, "restart_test", "light", 12.5))
        for bad in ({"retry_mode": "x"}, {"retry_max_attempts": 99}, {"theme": "pink"}, {"retry_timeout_action": "explode"}):
            with self.assertRaises(ValueError):
                settings.validate(bad)

    def test_one_bad_setting_keeps_the_others(self):
        (paths.workspace() / "settings.json").write_text(json.dumps({"timeout_s": 7.0, "retry_mode": "garbage"}))
        got = settings.load()
        self.assertEqual(got["timeout_s"], 7.0)
        self.assertEqual(got["retry_mode"], "retry_step")


if __name__ == "__main__":
    unittest.main()


class ExcelComTests(unittest.TestCase):
    """Fake COM object model: proves one block assignment and that Excel's settings are always restored."""

    class Rng:
        def __init__(self, ws, a, b): self.ws, self.a, self.b = ws, a, b
        @property
        def Value2(self): return None
        @Value2.setter
        def Value2(self, v): self.ws.assigned.append((self.a, self.b, v))

    class WS:
        def __init__(self): self.assigned = []
        def Cells(self, r, c): return (r, c)
        def Range(self, a, b): return ExcelComTests.Rng(self, a, b)

    class App:
        def __init__(self, fail=False):
            self.ScreenUpdating, self.EnableEvents, self.Calculation = True, True, -4105
            self.ws, self.fail = ExcelComTests.WS(), fail
            ws = self.ws
            self.ActiveWorkbook = type("WB", (), {"ActiveSheet": ws, "Worksheets": lambda s, n: ws})()
            self.log = []

        def __setattr__(self, k, v):
            if k in ("ScreenUpdating", "EnableEvents", "Calculation") and hasattr(self, "log"):
                self.log.append((k, v))
            object.__setattr__(self, k, v)

    def test_single_block_write_and_settings_restored(self):
        from core import excel_com
        app = self.App()
        out = excel_com.write_block([["a", 1], ["=SUM(1)", None]], start="B2", app=app)
        self.assertEqual(len(app.ws.assigned), 1)                       # one COM assignment for the whole block
        a, b, grid = app.ws.assigned[0]
        self.assertEqual((a, b), ((2, 2), (3, 3)))
        self.assertEqual(grid[1][0], "'=SUM(1)")                        # formula text stays text
        self.assertEqual((app.ScreenUpdating, app.EnableEvents, app.Calculation), (True, True, -4105))
        self.assertEqual(out["cells"], 4)

    def test_settings_restored_even_when_write_fails(self):
        from core import excel_com
        app = self.App()

        class Boom(self.WS):
            def Range(self, a, b): raise RuntimeError("COM error")
        app.ActiveWorkbook.ActiveSheet = Boom()
        with self.assertRaises(RuntimeError):
            excel_com.write_block([["x"]], app=app)
        self.assertEqual((app.ScreenUpdating, app.EnableEvents, app.Calculation), (True, True, -4105))

    def test_bad_input_and_non_windows_messages(self):
        from core import excel_com
        with self.assertRaisesRegex(excel_io.TableError, "Invalid start cell"):
            excel_com.write_block([["x"]], start="1A", app=self.App())
        with mock.patch.object(excel_com.sys, "platform", "linux"):
            with self.assertRaisesRegex(excel_io.TableError, "needs Windows"):
                excel_com.write_block([["x"]])
