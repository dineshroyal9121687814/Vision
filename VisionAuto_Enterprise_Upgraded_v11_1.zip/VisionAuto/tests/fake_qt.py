"""
Minimal PySide6 stand-in so the GUI *logic* (workers, pages, review dialog) can be exercised on machines
without Qt / a display (CI, this sandbox). It does not simulate Qt rendering or layout.

  * unknown widgets/methods are permissive no-ops
  * Signal is synchronous (emit calls the connected slots immediately)
  * QThread.start() runs run() inline
  * a few widgets keep real state (QLineEdit, QCheckBox, spin boxes, list/table items)
When real PySide6 is installed the tests use it instead (QT_QPA_PLATFORM=offscreen).
"""
from __future__ import annotations

import sys
import types


class _Meta(type):
    def __getattr__(cls, name):
        if name.startswith("__"):
            raise AttributeError(name)
        return _Any()


class _Any(metaclass=_Meta):
    def __init__(self, *a, **k):
        pass

    def __call__(self, *a, **k):
        return _Any()

    def __getattr__(self, name):
        if name.startswith("__"):
            raise AttributeError(name)
        return _Any()

    def _op(self, *a):
        return _Any()

    __or__ = __ror__ = __add__ = __radd__ = __sub__ = __rsub__ = __mul__ = __rmul__ = _op
    __floordiv__ = __truediv__ = __rfloordiv__ = __rtruediv__ = __and__ = _op

    def __iter__(self):
        return iter(())

    def __bool__(self):
        return True

    def __int__(self):
        return 0

    __index__ = __int__

    def __lt__(self, o):
        return False

    __gt__ = __le__ = __ge__ = __lt__


class _Bound:
    def __init__(self):
        self.slots = []

    def connect(self, fn):
        self.slots.append(fn)

    def disconnect(self, *a):
        self.slots.clear()

    def emit(self, *a):
        for fn in list(self.slots):
            fn(*a)


class Signal:
    def __init__(self, *types):
        self.name = None

    def __set_name__(self, owner, name):
        self.name = name

    def __get__(self, obj, owner=None):
        if obj is None:
            return self
        return obj.__dict__.setdefault("_sigs", {}).setdefault(self.name, _Bound())


Widget = _Meta("Widget", (_Any,), {})


class QObject(Widget):
    pass


class QThread(QObject):
    def start(self, *a):
        self.run()

    def isRunning(self):
        return False

    def run(self):
        pass


class QLineEdit(Widget):
    def __init__(self, text="", *a):
        self._t = text

    def text(self):
        return self._t

    def setText(self, t):
        self._t = t


class QCheckBox(Widget):
    def __init__(self, *a):
        self._c = False

    def isChecked(self):
        return self._c

    def setChecked(self, v):
        self._c = bool(v)


class QPlainTextEdit(Widget):
    def __init__(self, text="", *a):
        self._t = text if isinstance(text, str) else ""

    def toPlainText(self):
        return self._t

    def setPlainText(self, t):
        self._t = t


class QComboBox(Widget):
    """Stateful combo box: (label, data) items and a current index."""

    def __init__(self, *a):
        self._items, self._i = [], -1

    def addItem(self, label, data=None):
        self._items.append((label, label if data is None else data))
        if self._i < 0:
            self._i = 0

    def addItems(self, labels):
        for x in labels:
            self.addItem(x)

    def clear(self):
        self._items, self._i = [], -1

    def findData(self, data):
        return next((i for i, (_, d) in enumerate(self._items) if d == data), -1)

    def setCurrentIndex(self, i):
        self._i = i

    def setCurrentText(self, t):
        self._i = next((i for i, (l, _) in enumerate(self._items) if l == t), self._i)

    def currentIndex(self):
        return self._i

    def currentData(self):
        return self._items[self._i][1] if 0 <= self._i < len(self._items) else None

    def currentText(self):
        return self._items[self._i][0] if 0 <= self._i < len(self._items) else ""


class _Spin(Widget):
    def __init__(self, *a):
        self._v = 0

    def value(self):
        return self._v

    def setValue(self, v):
        self._v = v


class QListWidgetItem(Widget):
    def __init__(self, text="", *a):
        self._t = text
        self._state = None

    def text(self):
        return self._t

    def setText(self, t):
        self._t = t

    def setCheckState(self, s):
        self._state = s

    def checkState(self):
        return self._state


class QMessageBox(Widget):
    class StandardButton:
        Yes = "yes"
        No = "no"

    @staticmethod
    def question(*a, **k):
        return "yes"

    information = critical = warning = question


class QFileDialog(Widget):
    @staticmethod
    def getOpenFileName(*a, **k):
        return "", ""

    @staticmethod
    def getOpenFileNames(*a, **k):
        return [], ""


class _Layout(Widget):
    def count(self):
        return 0


_SPECIAL = {"QHBoxLayout": type("QHBoxLayout", (_Layout,), {}), "QVBoxLayout": type("QVBoxLayout", (_Layout,), {}),
            "QFormLayout": type("QFormLayout", (_Layout,), {}), "QGridLayout": type("QGridLayout", (_Layout,), {}),
            "Signal": Signal, "QObject": QObject, "QThread": QThread, "QLineEdit": QLineEdit, "QCheckBox": QCheckBox, "QComboBox": QComboBox, "QPlainTextEdit": QPlainTextEdit,
            "QSpinBox": type("QSpinBox", (_Spin,), {}), "QDoubleSpinBox": type("QDoubleSpinBox", (_Spin,), {}),
            "QListWidgetItem": QListWidgetItem, "QMessageBox": QMessageBox, "QFileDialog": QFileDialog}


class _Module(types.ModuleType):
    def __getattr__(self, name):
        if name.startswith("__"):
            raise AttributeError(name)
        cls = _SPECIAL.get(name) or type(name, (Widget,), {})
        setattr(self, name, cls)
        return cls


def install() -> None:
    root = _Module("PySide6")
    root.__path__ = []
    sys.modules["PySide6"] = root
    for sub in ("QtCore", "QtGui", "QtWidgets"):
        m = _Module("PySide6." + sub)
        sys.modules["PySide6." + sub] = m
        setattr(root, sub, m)
