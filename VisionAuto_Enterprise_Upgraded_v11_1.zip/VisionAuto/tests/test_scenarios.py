import tempfile
import time
import unittest
from pathlib import Path
from unittest import mock

import numpy as np

from tests import helpers
from tests.helpers import make_frame
from core import settings, validation
from core.playback.backend import DryRunBackend
from core.playback.player import Player
from core.playback.resolver import NativeGovernor, Resolver
from core.system import geometry, winenv
from core.system.imageio import imwrite
from core.vision import zones


def step(i, t, **kw):
    return {"id": i, "type": t, "t_ms": 0, "window": {}, "validations": [], "description": f"s{i}", **kw}


def player(steps, dry_run=True, **kw):
    helpers.use_temp_workspace()
    test = {"name": "sc", "steps": steps, "applications": [], "variables": {}, **kw.pop("test_extra", {})}
    backend = kw.pop("backend", DryRunBackend())
    return Player(test, kw.pop("options", {"timeout_s": 1.0}), backend=backend, dry_run=dry_run, **kw), backend


class GeometryTests(unittest.TestCase):
    SCREEN = [0, 0, 1920, 1080]

    def test_plan_restores_size_state_and_clamps_to_screen(self):
        rec = [100, 100, 900, 700]
        self.assertEqual(geometry.plan(rec, "normal", [100, 100, 905, 703], "normal", self.SCREEN)["action"], "none")
        self.assertEqual(geometry.plan(rec, "normal", [0, 0, 400, 300], "normal", self.SCREEN),
                         {"action": "rect", "rect": rec})
        self.assertEqual(geometry.plan(rec, "normal", [0, 0, 1920, 1040], "maximized", self.SCREEN)["rect"], rec)
        self.assertEqual(geometry.plan(rec, "maximized", [0, 0, 1, 1], "normal", self.SCREEN),
                         {"action": "state", "state": "maximized"})
        self.assertEqual(geometry.plan([1800, 100, 2600, 700], "normal", [0, 0, 5, 5], "normal", self.SCREEN)["rect"],
                         [1120, 100, 1920, 700])
        self.assertEqual(geometry.plan(None, "normal", [0, 0, 5, 5], "normal", self.SCREEN)["action"], "none")

    def test_maps_points_and_rebases_every_recorded_position(self):
        self.assertEqual(geometry.map_point((500, 400), [100, 100, 900, 700], [200, 150, 1000, 750]), (600, 450))
        t = {"x": 500, "y": 400, "ocr_region": [100, 100, 200, 100], "zone": {"rect": [100, 100, 300, 300]}}
        out = geometry.rebase_target(t, [100, 100, 900, 700], [200, 150, 1000, 750])
        self.assertEqual((out["x"], out["y"], out["ocr_region"], out["zone"]["rect"]),
                         (600, 450, [200, 150, 200, 100], [200, 150, 400, 350]))
        self.assertEqual(t["x"], 500)                                    # input untouched
        self.assertEqual(geometry.map_point((900, 700), [100, 100, 900, 700], [100, 100, 500, 400]), (500, 400))


class ZoneTests(unittest.TestCase):
    def frame(self):
        f = np.full((800, 1200, 3), 30, np.uint8)
        f[:, 50:300] = (60, 60, 60)
        f[:, 299] = (90, 90, 90)
        f[559, 300:] = (90, 90, 90)
        f[780:800, :] = (200, 120, 0)
        rng = np.random.default_rng(1)
        for _ in range(100):
            y, x = int(rng.integers(20, 540)), int(rng.integers(320, 1100))
            f[y:y + 2, x:x + int(rng.integers(20, 200))] = (200, 200, 200)
        return f

    def test_layout_finds_the_editor_terminal_sidebar_and_status_bar(self):
        f, win = self.frame(), [0, 0, 1200, 800]
        got = {name: zones.detect_zone(f, (0, 0), win, pt) for name, pt in
               {"editor": (600, 300), "terminal": (600, 650), "sidebar": (150, 300), "status": (600, 790)}.items()}
        self.assertEqual(got["editor"]["rect"][1:4:2], [0, 558])
        self.assertEqual(got["terminal"]["rect"][1:4:2], [558, 780])
        self.assertEqual(got["sidebar"]["rect"][0::2], [50, 298])
        self.assertEqual(got["status"]["rect"][1], 780)
        self.assertTrue(all(z["source"] == "layout" for z in got.values()))

    def test_uia_container_beats_layout_and_blank_screens_fall_back_to_a_grid(self):
        anc = [{"name": "Terminal", "role": "Pane", "rect": [300, 560, 1200, 780]}, {"name": "", "role": "Window", "rect": [0, 0, 1200, 800]}]
        z = zones.detect_zone(None, (0, 0), [0, 0, 1200, 800], (600, 650), anc)
        self.assertEqual((z["source"], z["name"]), ("uia", "Terminal"))
        blank = np.full((800, 1200, 3), 50, np.uint8)
        g = zones.detect_zone(blank, (0, 0), [0, 0, 1200, 800], (1100, 700))
        self.assertEqual((g["source"], g["name"]), ("grid", "area bottom-right"))
        self.assertIsNone(zones.detect_zone(blank, (0, 0), [0, 0, 100, 100], (500, 500)))


class ResolverGeometryTests(unittest.TestCase):
    def setUp(self):
        helpers.use_temp_workspace()
        self.tmp = Path(tempfile.mkdtemp())

    def resolver(self, frame, **opts):
        base = {"use_native": False, "use_ocr": False, "use_ai": False, **opts}
        return Resolver(self.tmp, settings.validate(base), grab=lambda: (frame, (0, 0)))

    def test_window_moved_since_recording_still_finds_the_element_in_the_zone_first(self):
        screen = make_frame(1200, 800, seed=7)
        tpl = screen[300:420, 300:420].copy()
        (self.tmp / "assets").mkdir()
        imwrite(self.tmp / "assets" / "b.png", tpl)
        moved = np.roll(screen, (60, 40), axis=(0, 1))           # the whole window content moved by (+40, +60)
        target = {"x": 360, "y": 360, "name": "b", "zone": {"rect": [250, 250, 500, 500]},
                  "templates": {"crop300": {"path": "assets/b.png", "click": [60, 60]}}}
        r = self.resolver(moved)
        r.rect_provider = lambda w: [40, 60, 1240, 860]
        found = r.resolve(target, {"title": "App", "rect": [0, 0, 1200, 800]}, timeout=1)
        self.assertEqual((found.x, found.y), (400, 420))
        self.assertIn(found.evidence["stage"], ("near", "zone"))      # not the whole-screen scan

    def test_stages_are_smallest_first_and_scope_can_forbid_a_screen_scan(self):
        frame = np.zeros((2000, 3000, 3), np.uint8)
        r = self.resolver(frame)
        r._win_rect = [200, 100, 2200, 1500]
        t = {"x": 1000, "y": 800, "zone": {"rect": [700, 500, 1500, 1100]}}
        names = [n for n, _ in r.search_stages(t, frame, (0, 0))]
        self.assertEqual(names, ["near", "zone", "window", "screen"])
        self.assertEqual([n for n, _ in r.search_stages({**t, "search_scope": "local_only"}, frame, (0, 0))], ["near", "zone", "window"])
        self.assertEqual([n for n, _ in r.search_stages({**t, "search_scope": "screen_only"}, frame, (0, 0))], ["screen"])

    def test_native_lookup_that_is_too_slow_is_dropped_for_that_app_only(self):
        slow = mock.Mock()
        slow.find_element_native.side_effect = lambda t, w: time.sleep(0.6)
        plugins = mock.Mock()
        plugins.get_plugin_for.return_value = slow
        r = Resolver(self.tmp, settings.validate({"use_ocr": False, "use_ai": False, "native_budget_s": 0.2}),
                     grab=lambda: (np.zeros((100, 100, 3), np.uint8), (0, 0)))
        r.plugins = plugins
        win = {"title": "Big", "process": "big.exe"}
        t0 = time.monotonic()
        self.assertIsNone(r._t_uia({"name": "x"}, win, {"attempt": 0, "split_xpath": False}))
        self.assertLess(time.monotonic() - t0, 0.5)
        self.assertIn("big.exe", r.governor.slow)
        self.assertIsNone(r._t_uia({"name": "x"}, win, {"attempt": 0, "split_xpath": False}))
        self.assertEqual(slow.find_element_native.call_count, 1)             # never asked again
        self.assertTrue(r.governor.allowed({"process": "other.exe"}, {"name": "x"}))

    def test_electron_apps_start_with_visual_tiers_unless_the_user_asks_for_uia(self):
        g = NativeGovernor({"native_policy": "auto"})
        vs = {"process": "Code.exe", "title": "x - Visual Studio Code"}
        self.assertFalse(g.allowed(vs, {"name": "Save"}))
        self.assertTrue(g.allowed(vs, {"name": "Save", "locator_order": ["uia", "ocr"]}))
        self.assertTrue(g.allowed(vs, {"xpath": "//button"}))
        self.assertFalse(NativeGovernor({"native_policy": "never"}).allowed({"process": "x.exe"}, {}))
        self.assertTrue(NativeGovernor({"native_policy": "always"}).allowed(vs, {}))

    def test_native_retries_back_off_instead_of_running_on_every_poll(self):
        r = self.resolver(np.zeros((10, 10, 3), np.uint8), use_native=True)
        turns = [a for a in range(10) if r._native_turn({"attempt": a}, {"process": "x.exe"}, {})]
        self.assertEqual(turns, [0, 1, 4, 8])


class WindowGeometryPlaybackTests(unittest.TestCase):
    def test_a_resized_window_is_put_back_to_its_recorded_size(self):
        p, _ = player([step(1, "wait", params={"ms": 1})], dry_run=False)
        state = {"rect": [0, 0, 500, 400], "state": "normal"}

        def set_rect(hwnd, rect):
            state["rect"] = list(rect)
            return True

        window = {"title": "App", "rect": [100, 100, 900, 700], "state": "normal"}
        with mock.patch.object(winenv, "window_rect", lambda h: state["rect"]), \
             mock.patch.object(winenv, "window_state", lambda h: state["state"]), \
             mock.patch.object(winenv, "virtual_screen", lambda: [0, 0, 1920, 1080]), \
             mock.patch.object(winenv, "set_window_rect", side_effect=set_rect) as setter:
            self.assertTrue(p._restore_geometry(window, hwnd=42))
            setter.assert_called_once_with(42, [100, 100, 900, 700])
            setter.reset_mock()
            self.assertTrue(p._restore_geometry(window, hwnd=42))            # already right: nothing to do
            setter.assert_not_called()
        self.assertEqual(p._geometry_log[0]["restored"], True)

    def test_fixed_size_dialog_that_refuses_to_resize_reports_failure_not_a_crash(self):
        p, _ = player([step(1, "wait", params={"ms": 1})], dry_run=False)
        win = {"title": "Dlg", "rect": [100, 100, 500, 400], "state": "normal"}
        with mock.patch.object(winenv, "window_rect", lambda h: [0, 0, 300, 200]), \
             mock.patch.object(winenv, "window_state", lambda h: "normal"), \
             mock.patch.object(winenv, "virtual_screen", lambda: [0, 0, 1920, 1080]), \
             mock.patch.object(winenv, "set_window_rect", return_value=True):
            t0 = time.monotonic()
            self.assertFalse(p._restore_geometry(win, hwnd=1))
        self.assertLess(time.monotonic() - t0, 2.0)

    def test_disabled_by_setting_and_ignored_in_dry_run(self):
        p, _ = player([step(1, "wait", params={"ms": 1})], dry_run=False, options={"restore_window_geometry": False})
        with mock.patch.object(winenv, "set_window_rect") as setter:
            self.assertTrue(p._restore_geometry({"title": "A", "rect": [1, 1, 500, 500]}, hwnd=1))
            setter.assert_not_called()


class DragDropTests(unittest.TestCase):
    def drag_step(self, **kw):
        return step(1, "drag_drop", target={"x": 100, "y": 100}, to={"x": 900, "y": 500},
                    window={"title": "Source", "rect": [0, 0, 600, 600]}, **kw)

    def test_cross_window_drag_restores_destination_window_and_uses_hold_and_hover(self):
        s = self.drag_step(to_window={"title": "Target", "rect": [650, 0, 1250, 600], "state": "normal"},
                           params={"hold_ms": 300, "hover_ms": 500, "steps": 30})
        p, backend = player([s])
        out = p.run()
        self.assertEqual(out["steps"][0]["cross_window"], {"from": "Source", "to": "Target"})
        self.assertEqual([a for a in backend.actions if a[0] == "drag"], [("drag", 100, 100, 900, 500, "left")])
        self.assertEqual(backend.drag_params, {"steps": 30, "hold_ms": 300, "hover_ms": 500, "step_delay_ms": 12})

    def test_drop_position_maps_to_the_same_place_in_a_moved_destination_window(self):
        p, _ = player([self.drag_step()], dry_run=False)
        p._current_rect = lambda w: [1000, 200, 1600, 800]                   # destination window now sits elsewhere
        to_win = {"title": "Target", "rect": [650, 0, 1250, 600]}
        res = p._drop_point(self.drag_step(), mock.Mock(x=100, y=100), {"x": 950, "y": 300}, to_win, "position")
        self.assertEqual((res.x, res.y), (1300, 500))
        rel = p._drop_point(self.drag_step(), mock.Mock(x=130, y=120), {"x": 900, "y": 500}, None, "relative")
        self.assertEqual((rel.x, rel.y), (130 + 800, 120 + 400))

    def test_bad_drag_parameters_fail_the_step_instead_of_being_clamped_silently(self):
        for params in ({"steps": 0}, {"hold_ms": -5}, {"hover_ms": 99999}):
            out = player([self.drag_step(params=params)])[0].run()
            self.assertEqual(out["steps"][0]["status"], "failed", params)
        out = player([self.drag_step(params={"modifiers": ["hyper"]})])[0].run()      # caught before anything is sent
        self.assertEqual(out["status"], "invalid")

    def test_modifier_click_is_passed_to_the_input_backend(self):
        p, backend = player([step(1, "click", target={"x": 5, "y": 6}, params={"modifiers": ["ctrl", "shift"]})])
        p.run()
        self.assertEqual(backend.actions[-1], ("click", 5, 6, "left", 1, ("ctrl", "shift")))


class ScenarioStepTests(unittest.TestCase):
    COND = {"type": "exists", "target": {"x": 1, "y": 1, "name": "Done"}}

    def test_wait_until_polls_until_true_or_times_out_with_a_clear_message(self):
        p, _ = player([step(1, "wait", params={"ms": 1})], dry_run=False)
        calls = iter([False, False, True])
        p._poll_condition = lambda s, c: next(calls)
        p._wait_until(step(1, "wait_until", condition=self.COND), {"timeout_s": 5, "poll_ms": 50})
        p._poll_condition = lambda s, c: False
        with self.assertRaises(ValueError) as cm:
            p._wait_until(step(1, "wait_until", condition=self.COND, description="spinner gone"), {"timeout_s": 0.2, "poll_ms": 50})
        self.assertIn("not met within 0.2s", str(cm.exception))

    def test_scroll_until_scrolls_a_bounded_number_of_times(self):
        p, backend = player([step(1, "wait", params={"ms": 1})], dry_run=False)
        seen = iter([False, False, True])
        p._poll_condition = lambda s, c: next(seen)
        res = {}
        p._scroll_until(step(1, "scroll_until", target={"x": 50, "y": 60}, until=self.COND), {"dy": -5, "max_scrolls": 10, "pause_ms": 0}, res)
        self.assertEqual((res["scrolls"], backend.actions.count(("scroll", 50, 60, 0, -5))), (2, 2))
        p._poll_condition = lambda s, c: False
        with self.assertRaises(ValueError):
            p._scroll_until(step(1, "scroll_until", target={"x": 1, "y": 2}, until=self.COND), {"max_scrolls": 3, "pause_ms": 0}, {})

    def test_new_step_types_run_in_dry_run_and_pass_validation(self):
        steps = [step(1, "wait_until", condition=self.COND, params={"timeout_s": 5}),
                 step(2, "scroll_until", target={"x": 5, "y": 5}, until=self.COND, params={"max_scrolls": 5}),
                 step(3, "window_action", window={"title": "Notepad"}, params={"action": "maximize"}),
                 step(4, "set_clipboard", params={"text": "hi"})]
        out = player(steps)[0].run()
        self.assertEqual(out["status"], "inconclusive")
        self.assertEqual(validation.errors_only(validation.validate_test({"name": "x", "steps": steps, "applications": []})), [])

    def test_step_over_its_time_limit_fails_with_the_measured_time(self):
        slow = step(1, "wait", params={"ms": 60}, max_duration_ms=5)
        fast = step(2, "wait", params={"ms": 1}, max_duration_ms=5000)
        out = player([slow, fast], dry_run=False, test_extra={"failure_policy": "continue"})[0].run()
        a, b = out["steps"]
        self.assertEqual(a["status"], "failed")
        self.assertIn("Too slow", a["error"])
        self.assertEqual(b["status"], "passed")

    def test_scenario_steps_are_validated(self):
        bad = [step(1, "wait_until", condition={"type": "nope"}),
               step(2, "scroll_until", target={"x": 1, "y": 1}, until=self.COND, params={"max_scrolls": 9999}),
               step(3, "window_action", window={"title": ""}, params={"action": "explode"}),
               step(4, "click", target={"x": 1, "y": 1}, params={"modifiers": ["hyper"]}, max_duration_ms=0)]
        codes = {i["code"] for i in validation.validate_test({"name": "x", "steps": bad, "applications": []})}
        self.assertTrue({"condition", "scroll", "window_action", "modifiers", "duration"} <= codes)


class RecoveryTests(unittest.TestCase):
    RULES = [{"window": "Update available", "action": "click_text", "value": "Later"}]

    def test_unexpected_popup_is_dismissed_and_the_failed_step_is_retried_once(self):
        p, backend = player([step(1, "click", target={"x": 5, "y": 5})], dry_run=False, test_extra={"recovery": self.RULES})
        p.resolver.resolve = mock.Mock(return_value=mock.Mock(x=300, y=200))
        results = iter([{"status": "failed", "retryable": True, "id": 1, "type": "click", "error": "blocked"},
                        {"status": "passed", "id": 1, "type": "click"}])
        with mock.patch.object(winenv, "find_windows", lambda t: [7] if t == "Update available" else []), \
             mock.patch.object(winenv, "activate_window", return_value=True), \
             mock.patch.object(p, "_run_step", side_effect=lambda s: next(results)):
            res = p._run_with_retries(p.test["steps"][0])
        self.assertEqual((res["status"], res["recovered"]), ("passed", True))
        self.assertIn(("click", 300, 200, "left", 1), backend.actions)
        self.assertEqual(p._recoveries[0]["window"], "Update available")

    def test_no_matching_popup_means_no_recovery_and_rules_are_validated(self):
        p, _ = player([step(1, "click", target={"x": 5, "y": 5})], dry_run=False, test_extra={"recovery": self.RULES})
        with mock.patch.object(winenv, "find_windows", lambda t: []):
            self.assertFalse(p._try_recovery(p.test["steps"][0]))
        for rules in ([{"window": "", "action": "close"}], [{"window": "A", "action": "explode"}], [{"window": "A", "action": "press_key"}], "no"):
            issues = validation.validate_test({"name": "x", "steps": [step(1, "wait", params={"ms": 1})], "applications": [], "recovery": rules})
            self.assertTrue([i for i in issues if i["code"] == "recovery"], rules)

    def test_recovery_attempts_are_capped(self):
        p, _ = player([step(1, "click", target={"x": 5, "y": 5})], dry_run=False,
                      test_extra={"recovery": [{"window": "X", "action": "close"}]})
        with mock.patch.object(winenv, "find_windows", lambda t: [1]), mock.patch.object(winenv, "close_window", return_value=True), \
             mock.patch("time.sleep"):
            ok = [p._try_recovery(p.test["steps"][0]) for _ in range(40)]
        self.assertEqual(sum(ok), p.MAX_RECOVERIES)


class ExtraValidationTests(unittest.TestCase):
    def setUp(self):
        helpers.use_temp_workspace()
        self.tmp = Path(tempfile.mkdtemp())

    def validator(self, frame=None):
        p, _ = player([step(1, "wait", params={"ms": 1})], dry_run=False,
                      grab=(lambda: (frame, (0, 0))) if frame is not None else None)
        return p.validator

    def test_clipboard_checks_use_the_clipboard_backend(self):
        from core.system import clipboard

        class Fake:
            text = "copied: ABC"
            get = lambda self: self.text                       # noqa: E731
            set = lambda self, t: setattr(self, "text", t)     # noqa: E731

        clipboard._backend = Fake()
        try:
            v = self.validator()
            self.assertEqual(v._once({"type": "clipboard_contains", "expected": "abc"}, {})[0], "passed")
            self.assertEqual(v._once({"type": "clipboard_equals", "expected": "nope"}, {})[0], "failed")
        finally:
            clipboard._backend = None

    def test_file_checks_work_in_allowed_folders_never_echo_content_and_block_the_rest(self):
        f = self.tmp / "export.csv"
        f.write_text("id,total\n1,99\n", encoding="utf-8")
        v = self.validator()
        self.assertEqual(v._once({"type": "file_exists", "path": str(f), "min_bytes": 5}, {})[0], "passed")
        self.assertEqual(v._once({"type": "file_exists", "path": str(f), "min_bytes": 5000}, {})[0], "failed")
        status, detail, _ = v._once({"type": "file_contains", "path": str(f), "expected": "total"}, {})
        self.assertEqual(status, "passed")
        self.assertNotIn("99", detail)
        self.assertEqual(v._once({"type": "file_exists", "path": str(self.tmp / "missing.csv")}, {})[0], "failed")
        self.assertEqual(v._once({"type": "file_exists", "path": "/etc/passwd"}, {})[0], "failed")

    def test_text_in_a_region_or_zone_reads_only_that_part_of_the_screen(self):
        frame = make_frame(1000, 700, seed=2)
        seen = []

        def fake_read(crop):
            seen.append(crop.shape[:2])
            return "Build succeeded in 3.2s"

        v = self.validator(frame)
        with mock.patch("core.ocr.ocr_engine.read_all_text", side_effect=fake_read):
            ok = v._once({"type": "text_in_region", "expected": "build SUCCEEDED", "region": [100, 400, 500, 200]}, {})
            zone = v._once({"type": "text_in_region", "expected": "succeeded", "target": {"zone": {"rect": [0, 500, 1000, 700]}}}, {})
            rx = v._once({"type": "text_in_region", "expected": r"\d\.\ds", "match": "regex", "region": [0, 0, 300, 300]}, {})
            bad = v._once({"type": "text_in_region", "expected": "failed", "region": [100, 400, 500, 200]}, {})
            nothing = v._once({"type": "text_in_region", "expected": "x"}, {})
        self.assertEqual([ok[0], zone[0], rx[0], bad[0], nothing[0]], ["passed", "passed", "passed", "failed", "skipped"])
        self.assertEqual(seen[:2], [(200, 500), (200, 1000)])

    def test_region_baseline_detects_visual_change(self):
        frame = make_frame(800, 600, seed=4)
        base = frame[100:300, 100:400].copy()
        (self.tmp / "assets").mkdir()
        imwrite(self.tmp / "assets" / "base.png", base)
        p, _ = player([step(1, "wait", params={"ms": 1})], dry_run=False, grab=lambda: (frame, (0, 0)))
        p.resolver.dir = self.tmp
        spec = {"type": "region_matches_baseline", "baseline": "assets/base.png", "region": [100, 100, 300, 200]}
        self.assertEqual(p.validator._once(spec, {})[0], "passed")
        frame[150:250, 150:350] = 255
        self.assertEqual(p.validator._once(spec, {})[0], "failed")
        self.assertEqual(p.validator._once({**spec, "baseline": "../x.png"}, {})[0], "failed")


class RecordedGeometryTests(unittest.TestCase):
    def test_recorder_stores_window_rect_state_and_cross_window_destination(self):
        from core.recorder.recorder import _window_record
        rec = _window_record({"title": "Calc", "process": "calc.exe", "rect": [10, 20, 410, 520], "state": "normal", "hwnd": 5})
        self.assertEqual(rec, {"title": "Calc", "process": "calc.exe", "rect": [10, 20, 410, 520], "state": "normal"})
        self.assertEqual(_window_record({"title": "x"}), {"title": "x", "process": ""})


if __name__ == "__main__":
    unittest.main()


class EditingScenarioTests(unittest.TestCase):
    def make(self):
        helpers.use_temp_workspace()
        return {"name": "e", "applications": [], "variables": {}, "steps": [
            step(1, "drag_drop", target={"x": 10, "y": 10}, to={"x": 90, "y": 90}, window={"title": "A", "rect": [0, 0, 500, 500]}),
            step(2, "click", target={"x": 5, "y": 5})]}

    def test_zone_drag_modifiers_limit_and_recovery_edits(self):
        from core import editing
        t = self.make()
        z = editing.set_zone(t, 2, [10, 20, 300, 400], "terminal")
        self.assertEqual((z["source"], z["rect"]), ("user", [10, 20, 300, 400]))
        editing.set_drag_options(t, 1, hold_ms=400, hover_ms=600, drop_mode="position", modifiers=["shift"])
        self.assertEqual(t["steps"][0]["params"], {"hold_ms": 400, "hover_ms": 600, "drop_mode": "position", "modifiers": ["shift"]})
        editing.set_click_modifiers(t, 2, ["ctrl"])
        editing.set_max_duration(t, 2, 1500)
        self.assertEqual((t["steps"][1]["params"]["modifiers"], t["steps"][1]["max_duration_ms"]), (["ctrl"], 1500))
        editing.set_recovery(t, [{"window": "Update", "action": "click_text", "value": "Later"}])
        self.assertEqual([i for i in editing.validate(t) if i["level"] == "error"], [])
        for bad in (lambda: editing.set_zone(t, 2, [5, 5, 1, 1]), lambda: editing.set_drag_options(t, 2, hold_ms=1),
                    lambda: editing.set_drag_options(t, 1, hold_ms=99999), lambda: editing.set_drag_options(t, 1, drop_mode="x"),
                    lambda: editing.set_click_modifiers(t, 2, ["hyper"]), lambda: editing.set_max_duration(t, 2, 0),
                    lambda: editing.set_recovery(t, [{"window": "A", "action": "explode"}])):
            with self.assertRaises(ValueError):
                bad()
        self.assertEqual(len(t["recovery"]), 1)

    def test_add_wait_until_step_and_reject_invalid_ones(self):
        from core import editing
        t = self.make()
        cond = {"type": "not_exists", "target": {"x": 1, "y": 1, "name": "Loading"}}
        editing.add_step_after(t, 1, {"type": "wait_until", "condition": cond, "params": {"timeout_s": 30}})
        self.assertEqual([s["type"] for s in t["steps"]], ["drag_drop", "wait_until", "click"])
        self.assertIn("does not exist", t["steps"][1]["description"])
        with self.assertRaises(ValueError):
            editing.add_step_after(t, 1, {"type": "wait_until", "condition": {"type": "nope"}})
        with self.assertRaises(ValueError):
            editing.add_step_after(t, 1, {"type": "teleport"})
        self.assertEqual(len(t["steps"]), 3)
