import unittest

from tests import helpers  # noqa: F401
from core.xpath import XPathError, find_best, generate_xpath, query, rank_nodes, rxpath_to_xpath
from core.xpath.engine import evaluate
from core.xpath.locate import locate
from core.xpath.tree import UiaNode


def calc():
    win = UiaNode("Window", "Calculator", rect=(0, 0, 400, 600), process="calc.exe")
    pad = UiaNode("Pane", "", automation_id="NumberPad", rect=(0, 100, 400, 600))
    for i in range(10):
        pad.add(UiaNode("Button", str(i), automation_id=f"num{i}Button", rect=(i * 40, 200, i * 40 + 38, 240)))
    pad.add(UiaNode("Button", "Plus", automation_id="plusButton", rect=(0, 300, 40, 340)))
    pad.add(UiaNode("Button", "Hidden", automation_id="ghost", rect=(0, 0, 0, 0), visible=False))
    win.add(pad, UiaNode("Edit", "Display", automation_id="CalculatorResults", value="0", rect=(0, 0, 400, 90)))
    return win


class XPathTests(unittest.TestCase):
    def test_standard_xpath_and_case_insensitive_names(self):
        self.assertEqual([n.name for n in query(calc(), "//Button[@Name='5']")], ["5"])
        self.assertEqual(len(query(calc(), "//button[starts-with(@automationid,'num')]")), 10)
        self.assertEqual(evaluate(calc(), "count(//button)"), 12)

    def test_ranorex_dialect_regex_and_absolute_path(self):
        hits = query(calc(), "/form[@title='Calculator']//button[@text~'^[1-3]$']", "ranorex")
        self.assertEqual([n.name for n in hits], ["1", "2", "3"])
        self.assertEqual(query(calc(), "/form//text[@enabled='True']", "ranorex")[0].name, "Display")

    def test_quote_escapes_and_bad_expressions(self):
        self.assertIn("\"it's\"", rxpath_to_xpath("/form[@title='it\\'s']"))
        with self.assertRaises(XPathError):
            query(calc(), "//button[")
        with self.assertRaises(XPathError):
            rxpath_to_xpath("")
        with self.assertRaises(XPathError):
            rxpath_to_xpath("//a[@x~5]")

    def test_find_best_ignores_hidden_and_refuses_to_guess(self):
        tree = calc()
        self.assertIsNone(find_best(tree, "//button[@name='Hidden']").node)
        m = find_best(tree, "//button[starts-with(@automationid,'num')]")
        self.assertTrue(m.ambiguous and m.node is None)
        near = find_best(tree, "//button[starts-with(@automationid,'num')]", near=(3 * 40 + 19, 220))
        self.assertEqual(near.node.name, "3")

    def test_generated_xpath_is_unique_and_stable(self):
        tree = calc()
        for node in tree.walk():
            if node.width == 0:
                continue
            xp = generate_xpath(node, tree)
            self.assertEqual(query(tree, xp), [node], xp)
        self.assertEqual(generate_xpath(tree.children[0].children[4], tree), "//button[@automationid='num4Button']")

    def test_ranking_heals_a_renamed_control_only_when_clear(self):
        tree = calc()
        sig = {"automation_id": "plusButton", "name": "Add", "role": "Button", "rect": (0, 300, 40, 340)}
        self.assertEqual(rank_nodes(tree, sig)[0][1].automation_id, "plusButton")
        hit = locate({"xpath": "//button[@name='Add']", **sig}, {}, lambda: tree)
        self.assertEqual(hit["via"], "xpath-heal")
        self.assertEqual(hit["automation_id"], "plusButton")
        self.assertIn("suggested_xpath", hit)
        vague = locate({"xpath": "//button[@name='Nope']", "role": "Button"}, {}, lambda: tree)
        self.assertIsNone(vague)

    def test_password_values_are_never_exposed(self):
        win = UiaNode("Window", "Login", rect=(0, 0, 100, 100))
        win.add(UiaNode("Edit", "pw", value="hunter2", password=True, rect=(0, 0, 50, 20)))
        self.assertEqual(query(win, "//edit[@value='hunter2']"), [])
        self.assertNotIn("value", win.children[0].describe())


if __name__ == "__main__":
    unittest.main()
