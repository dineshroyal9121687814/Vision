import unittest
import ast
import io
import json
from unittest import mock

from tests.helpers import use_temp_workspace

use_temp_workspace()

from core.ai.analyze import analyze, apply_suggestions, suggest_validations  # noqa: E402
from core.ai.describe import describe_step  # noqa: E402
from core.ai.llm import OllamaClient  # noqa: E402
from core.importers.ranorex.llm_fallback import LlmTranslator, _safe_generated_tree  # noqa: E402


def step(i, t, title="Notepad", **kw):
    s = {"id": i, "type": t, "window": {"title": title, "process": "notepad.exe"}, "validations": []}
    s.update(kw)
    s["description"] = describe_step(s)
    return s


class DescribeTests(unittest.TestCase):
    def test_descriptions(self):
        cases = [
            (step(1, "click", target={"name": "Save", "role": "Button", "x": 1, "y": 2}),
             "Click 'Save' button in 'Notepad'"),
            (step(1, "click", target={"x": 523, "y": 410}), "Click element at (523, 410) in 'Notepad'"),
            (step(1, "drag_drop", target={"name": "a.txt", "role": "ListItem"}, to={"name": "Trash", "role": "Pane"}),
             "Drag 'a.txt' list item and drop on 'Trash' area in 'Notepad'"),
            (step(1, "type", params={"text": "hello"}, target={"name": "Search", "role": "Edit"}),
             "Type 'hello' into 'Search' text box in 'Notepad'"),
            (step(1, "hotkey", params={"keys": "ctrl+shift+s"}), "Press Ctrl+Shift+S in 'Notepad'"),
            (step(1, "scroll", params={"dx": 0, "dy": -3}), "Scroll down 3 notch(es) in 'Notepad'"),
        ]
        for s, expected in cases:
            self.assertEqual(s["description"], expected)


class SuggestTests(unittest.TestCase):
    def test_window_change_text_and_checkbox(self):
        test = {"steps": [
            step(1, "click", target={"name": "Save As", "role": "MenuItem"}),
            step(2, "type", title="Save As", params={"text": "report.txt"}, target={"name": "File name", "role": "Edit"}),
            step(3, "click", title="Save As", target={"name": "Read only", "role": "CheckBox", "state": {"toggle": "off"}}),
            step(4, "click", title="Notepad", target={"name": "x", "role": "Button"}),
        ]}
        n = suggest_validations(test)
        s = test["steps"]
        self.assertEqual(s[0]["suggestions"][0]["type"], "window_title_contains")
        self.assertEqual(s[0]["suggestions"][0]["expected"], "Save As")
        self.assertEqual(s[1]["suggestions"][0]["type"], "text_contains")
        by_type = {v["type"]: v for v in s[2]["suggestions"]}
        self.assertEqual(by_type["state"]["expected"], "on")
        self.assertEqual(by_type["window_title_contains"]["expected"], "Notepad")  # dialog closed
        self.assertGreaterEqual(n, 4)

    def test_modified_flag_in_title_is_not_a_window_change(self):
        test = {"steps": [step(1, "key", params={"key": "enter"}, title="Untitled - Notepad"),
                          step(2, "click", title="*Untitled - Notepad", target={"x": 1, "y": 1})]}
        suggest_validations(test)
        self.assertEqual(test["steps"][0]["suggestions"], [])

    def test_analyze_and_apply(self):
        test = {"name": "t", "title": "t", "steps": [
            step(1, "click", target={"name": "OK", "role": "Button"}),
            step(2, "type", title="Dialog", params={"text": "abc"}, target={"name": "Box", "role": "Edit"}),
        ]}
        analyze(test, ".", use_ocr=False)
        self.assertTrue(test["summary"])
        apply_suggestions(test, {1: [0], 2: [0]})
        self.assertEqual(test["steps"][0]["validations"][0]["type"], "window_title_contains")
        self.assertNotIn("suggestions", test["steps"][0])
        self.assertNotIn("confidence", test["steps"][0]["validations"][0])


class LocalModelSafetyTests(unittest.TestCase):
    def test_ollama_endpoint_is_configurable_and_validated(self):
        client = OllamaClient(base_url="http://127.0.0.1:11435/")
        response = mock.MagicMock()
        response.__enter__.return_value.status = 200
        with mock.patch("core.ai.llm.urllib.request.urlopen", return_value=response) as urlopen:
            self.assertTrue(client.available())
        self.assertEqual(urlopen.call_args.args[0], "http://127.0.0.1:11435/api/tags")
        with self.assertRaises(ValueError):
            OllamaClient(base_url="file:///tmp/model")
        with self.assertRaisesRegex(ValueError, "credentials"):
            OllamaClient(base_url="http://user:token@localhost:11434")

    def test_generated_python_must_be_a_direct_allowlisted_context_call(self):
        self.assertTrue(_safe_generated_tree(ast.parse('ctx.click("Calculator.Button")')))
        self.assertFalse(_safe_generated_tree(ast.parse('__import__("os").system("whoami")')))
        self.assertFalse(_safe_generated_tree(ast.parse('ctx.click(open("secret.txt").read())')))

    def test_ranorex_llm_refuses_untrusted_expression_output(self):
        response = io.BytesIO(json.dumps({"response": "__import__('os').system('whoami')"}).encode())
        translator = LlmTranslator(base_url="http://127.0.0.1:11435")
        with mock.patch("core.importers.ranorex.llm_fallback.urllib.request.urlopen", return_value=response):
            self.assertIsNone(translator.translate_line("unknownCall();"))


if __name__ == "__main__":
    unittest.main()
