"""Ollama auto-setup flow (all OS calls mocked) and the training-data store."""
import json
import tempfile
import unittest
import zipfile
from pathlib import Path
from unittest import mock

from tests.helpers import use_temp_workspace

use_temp_workspace()

from core import dataset, settings  # noqa: E402
from core.ai import ollama_manager as om  # noqa: E402
from core.playback.backend import DryRunBackend  # noqa: E402
from core.playback.player import Player  # noqa: E402

URL, MODEL = "http://localhost:11434", "qwen2.5-coder:1.5b"


class ManagerTests(unittest.TestCase):
    def test_model_name_matching(self):
        self.assertTrue(om.has_model(["qwen2.5-coder:1.5b"], MODEL))
        self.assertTrue(om.has_model(["llama3:latest"], "llama3"))
        self.assertFalse(om.has_model(["other:1b"], MODEL))

    def test_not_installed_without_consent_installs_nothing(self):
        with mock.patch.object(om, "find_ollama", lambda: None), mock.patch.object(om, "_tags", lambda *a, **k: None), \
             mock.patch.object(om, "install") as inst:
            with self.assertRaises(RuntimeError):
                om.ensure_ready(MODEL, URL, allow_install=False)
        inst.assert_not_called()

    def test_full_flow_installs_starts_pulls(self):
        state = {"up": False, "models": []}
        with mock.patch.object(om, "find_ollama", lambda: None), \
             mock.patch.object(om, "_tags", lambda *a, **k: state["models"] if state["up"] else None), \
             mock.patch.object(om, "install", lambda p=None: "C:/o/ollama.exe") as inst, \
             mock.patch.object(om, "start_server", lambda *a, **k: state.update(up=True) or True), \
             mock.patch.object(om, "pull_model", lambda b, m, p=None: state["models"].append(m)) as pull:
            st = om.ensure_ready(MODEL, URL, allow_install=True)
        self.assertTrue(st["model_ready"])

    def test_untrusted_installer_is_never_run(self):
        ran = []
        with mock.patch.object(om, "IS_WINDOWS", True):
            with self.assertRaises(RuntimeError) as cm:
                om.install(downloader=lambda p: "x.exe", verifier=lambda p: (False, "NotSigned / "),
                           runner=lambda *a, **k: ran.append(a))
        self.assertIn("NOT run", str(cm.exception))
        self.assertEqual(ran, [])

    def test_only_official_url_and_never_starts_remote_server(self):
        with self.assertRaises(ValueError):
            om.download_installer(url="https://evil.example/OllamaSetup.exe")
        with mock.patch.object(om, "_tags", lambda *a, **k: None):
            self.assertFalse(om.start_server("http://some-other-host:11434"))


class DatasetTests(unittest.TestCase):
    def setUp(self):
        use_temp_workspace()

    def _run(self):
        test = {"name": "t", "steps": [
            {"id": 1, "type": "type", "description": "Type", "window": {"title": "App", "process": "a.exe"},
             "params": {"text": "hunter2-secret"}, "target": {"name": "Pass", "role": "Edit", "path": "A > B", "x": 5, "y": 6}},
            {"id": 2, "type": "open_app", "description": "Open", "window": {}, "params": {"name": "${app}", "window_title": "${title}"}}]}
        run = {"test": "t", "run_id": "r1", "status": "passed", "dry_run": False, "summary": {"total": 2},
               "steps": [{"id": 1, "type": "type", "status": "passed", "duration_ms": 10, "method": "native", "locator_confidence": 1.0,
                          "validations": [{"type": "text_equals", "status": "passed"}]},
                         {"id": 2, "type": "open_app", "status": "failed", "error": "boom", "duration_ms": 5}]}
        return run, test

    def test_step_rows_have_features_but_no_typed_text_by_default(self):
        run, test = self._run()
        self.assertEqual(dataset.record_run(run, test), 2)
        rows = [json.loads(l) for l in (dataset.root() / "steps.jsonl").read_text(encoding="utf-8").splitlines()]
        blob = json.dumps(rows)
        self.assertNotIn("hunter2", blob)
        self.assertEqual(rows[0]["params"]["text_len"], 14)
        self.assertEqual(rows[0]["target"]["path"], "A > B")
        self.assertEqual(rows[1]["params"]["name"], "${app}")                 # template, not a data-row value
        self.assertEqual(rows[1]["status"], "failed")

    def test_text_only_when_opted_in_and_never_when_redacted(self):
        run, test = self._run()
        settings.save({"dataset_include_text": True})
        dataset.record_run(run, test)
        self.assertIn("hunter2", (dataset.root() / "steps.jsonl").read_text(encoding="utf-8"))
        test["steps"][0]["params"]["redacted"] = True
        (dataset.root() / "steps.jsonl").unlink()
        dataset.record_run(run, test)
        self.assertNotIn("hunter2", (dataset.root() / "steps.jsonl").read_text(encoding="utf-8"))

    def test_off_switch_dry_runs_and_size_cap(self):
        run, test = self._run()
        settings.save({"collect_training_data": False})
        self.assertEqual(dataset.record_run(run, test), 0)
        settings.save({"collect_training_data": True})
        self.assertEqual(dataset.record_run({**run, "dry_run": True}, test), 0)
        settings.save({"dataset_max_mb": 0})
        self.assertEqual(dataset.record_run(run, test), 0)

    def test_recording_row_and_export(self):
        _, test = self._run()
        n = dataset.record_recording(test, [{"replaced_steps": [1, 2], "name": "Calculator", "reason": "x"}])
        self.assertEqual(n, 1)
        st = dataset.stats()
        self.assertEqual(st["recordings"], 1)
        z = dataset.export(Path(tempfile.mkdtemp()) / "d.zip")
        self.assertIn("recordings.jsonl", zipfile.ZipFile(z).namelist())

    def test_real_player_run_writes_dataset(self):
        t = {"name": "ds", "applications": [], "variables": {},
             "steps": [{"id": 1, "type": "wait", "window": {}, "params": {"ms": 1}, "validations": [], "description": "w"}]}
        with mock.patch.object(Player, "_settle", lambda *a, **k: None):
            Player(t, {"timeout_s": 1.0}, backend=DryRunBackend()).run()      # real (non-dry) run
        self.assertEqual(dataset.stats()["steps"], 1)


if __name__ == "__main__":
    unittest.main()
