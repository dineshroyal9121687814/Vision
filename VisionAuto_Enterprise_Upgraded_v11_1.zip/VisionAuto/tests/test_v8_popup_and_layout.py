"""Right-click mini toolbar / context menu in front (empty title) and the layout+picture last-resort tier."""
import sys
import unittest
from pathlib import Path
from unittest import mock

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from tests import helpers                                                          # noqa: E402
from core.playback import validators                                               # noqa: E402
from core.playback.resolver import Resolver                                        # noqa: E402
from core.system import winenv                                                     # noqa: E402


class Transient(unittest.TestCase):
    def test_empty_title_window_of_same_process_is_transient(self):
        fg = {"title": "", "pid": 42, "popup": False, "owner_title": ""}
        with mock.patch.object(winenv, "_find_windows", return_value=[7]), \
                mock.patch.object(winenv, "window_info", return_value={"pid": 42, "title": "Book1 - Excel"}):
            self.assertTrue(winenv.is_transient_of(fg, "Book1 - Excel"))

    def test_other_process_or_titled_window_is_not(self):
        with mock.patch.object(winenv, "_find_windows", return_value=[7]), \
                mock.patch.object(winenv, "window_info", return_value={"pid": 1, "title": "Book1 - Excel"}):
            self.assertFalse(winenv.is_transient_of({"title": "", "pid": 42}, "Book1 - Excel"))
        self.assertFalse(winenv.is_transient_of({"title": "Notepad", "pid": 42}, "Book1 - Excel"))

    def test_popup_owned_by_recorded_window(self):
        self.assertTrue(winenv.is_transient_of({"title": "", "popup": True, "owner_title": "Book1 - Excel"}, "book1"))

    def test_title_validation_passes_with_mini_toolbar_in_front(self):
        fg = {"title": "", "pid": 42}
        with mock.patch.object(validators.winenv, "foreground_window", return_value=fg), \
                mock.patch.object(validators.winenv, "is_transient_of", return_value=True):
            v = validators.Validator.__new__(validators.Validator)
            status, _, _ = validators.Validator._once(v, {"type": "window_title_contains", "expected": "Book1 - Excel"}, {})
        self.assertEqual(status, "passed")


class LayoutLocal(unittest.TestCase):
    def _resolver(self):
        helpers.use_temp_workspace()
        r = Resolver.__new__(Resolver)
        from core.vision.locator import Locator
        r.locator = Locator()
        r.o = {"layout_coordinates": True}
        r._layout_same = True
        r.grab = None
        return r

    def test_picture_at_recorded_point_is_accepted(self):
        r = self._resolver()
        rng = np.random.default_rng(1)
        frame = rng.integers(0, 255, (300, 400, 3), dtype=np.uint8)
        tpl = frame[100:140, 150:230].copy()
        r._frame = lambda st: (frame, (0, 0))
        target = {"x": 190, "y": 120}
        st = {"attempt": 1, "c100": (tpl, (0, 0)), "c300": None}
        res = r._t_layout_local(target, {}, st)
        self.assertIsNotNone(res)
        self.assertEqual((res.x, res.y), (190, 120))

    def test_nothing_like_it_there_is_refused(self):
        r = self._resolver()
        rng = np.random.default_rng(2)
        frame = rng.integers(0, 255, (300, 400, 3), dtype=np.uint8)
        tpl = rng.integers(0, 255, (40, 80, 3), dtype=np.uint8)
        r._frame = lambda st: (frame, (0, 0))
        st = {"attempt": 1, "c100": (tpl, (0, 0)), "c300": None}
        self.assertIsNone(r._t_layout_local({"x": 190, "y": 120}, {}, st))

    def test_not_when_layout_changed_or_first_attempt(self):
        r = self._resolver()
        r._layout_same = False
        st = {"attempt": 1, "c100": (np.zeros((10, 10, 3), np.uint8), (0, 0)), "c300": None}
        self.assertIsNone(r._t_layout_local({"x": 1, "y": 1}, {}, st))


class V81(unittest.TestCase):
    def _r(self):
        helpers.use_temp_workspace()
        r = Resolver.__new__(Resolver)
        r.o = {"layout_coordinates": True, "use_native": True}
        r._layout_same = False
        r.governor = mock.Mock()
        r.governor.allowed.return_value = True
        r.governor.call.side_effect = lambda w, fn: fn()
        r._frame = lambda st: (np.zeros((300, 400, 3), np.uint8), (0, 0))
        return r

    def test_merged_cell_found_even_if_window_size_differs(self):
        r = self._r()
        with mock.patch("core.playback.resolver.winenv.element_at", return_value={"name": "I9:M9", "role": "DataItem"}):
            res = r._t_layout_local({"name": "M9", "x": 120, "y": 80}, {}, {"attempt": 3, "c100": None, "c300": None})
        self.assertEqual(res.method, "coordinates(layout+cell)")
        with mock.patch("core.playback.resolver.winenv.element_at", return_value={"name": "I9:M9", "role": "DataItem"}):
            self.assertIsNone(r._t_layout_local({"name": "M9", "x": 120, "y": 80}, {}, {"attempt": 1, "c100": None, "c300": None}),
                              "a cell that is merely slow to appear must get ~1s before a coordinate click")

    def test_button_under_point_is_refused(self):
        r = self._r()
        with mock.patch("core.playback.resolver.winenv.element_at", return_value={"name": "Close", "role": "Button"}):
            self.assertIsNone(r._t_layout_local({"name": "M9", "x": 1, "y": 1}, {}, {"attempt": 1, "c100": None, "c300": None}))

    def _check(self, tgt, found, how):
        v = validators.Validator.__new__(validators.Validator)
        v.o = {}
        v._text_candidates = lambda t, w: iter([(found, how)])
        return validators.Validator._once(v, {"type": "text_contains", "expected": "22"}, {}) if False else \
            validators.Validator._once(v, {"type": "text_contains", "expected": "22", "target": tgt}, {})

    def test_typed_box_replaced_by_other_control_is_not_verified(self):
        st, *_ = self._check({"name": "11", "role": "Edit"}, "Name Box", "UI Automation at point")
        self.assertEqual(st, "skipped")

    def test_cell_row_mismatch_still_fails(self):
        st, *_ = self._check({"name": "H9", "role": "DataItem"}, "Book1", "Windows control text")
        self.assertEqual(st, "failed")

    def test_cell_target_named_like_row_still_fails(self):
        st, *_ = self._check({"name": "H9", "role": ""}, "Book1", "UI Automation at point")
        self.assertEqual(st, "failed")


if __name__ == "__main__":
    unittest.main()
