"""Look-alike targets (Excel cells, list rows): decided by recorded position + text, never by a coin toss."""
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from core.automation import evidence                                              # noqa: E402
from core.automation.errors import AmbiguousTarget                                # noqa: E402
from core.playback.resolver import Resolver                                       # noqa: E402
from core.system.imageio import imwrite                                           # noqa: E402
from tests.test_automation_fallbacks import make_frame                            # noqa: E402


class EvidenceChoose(unittest.TestCase):
    def test_nearest_clearly_wins(self):
        self.assertEqual(evidence.choose([(100, 100), (400, 100)], (110, 105), 80).index, 0)

    def test_equidistant_is_not_decided(self):
        self.assertIsNone(evidence.choose([(100, 100), (300, 100)], (200, 100), 150))

    def test_too_far_is_not_decided(self):
        self.assertIsNone(evidence.choose([(100, 100)], (900, 900), 80))

    def test_text_contradiction_removes_candidate(self):
        pick = evidence.choose([(100, 100), (160, 100)], (105, 100), 120, [False, True])
        self.assertEqual(pick.index, 1)

    def test_all_contradicted_is_none(self):
        self.assertIsNone(evidence.choose([(1, 1), (2, 2)], (1, 1), 50, [False, False]))

    def test_ring_is_nearest_first(self):
        pts = evidence.ring((100, 100), 40, 20, 2)
        self.assertEqual(len(pts), 24)
        self.assertEqual(evidence.distance(pts[0], (100, 100)), 20)


class ExcelLikeCells(unittest.TestCase):
    def _setup(self, tmp):
        screen = make_frame(1000, 700, seed=3)
        tpl = screen[200:260, 350:470].copy()
        for k in range(1, 4):                                   # a column of identical cells
            screen[200 + 70 * k:260 + 70 * k, 350:470] = tpl
        assets = Path(tmp) / "assets"
        assets.mkdir()
        imwrite(assets / "t.png", tpl)
        # recorded click: the cell two below the first (centre y = 230 + 140)
        target = {"x": 410, "y": 370, "name": "O7", "templates": {"crop300": {"path": "assets/t.png", "click": [60, 30]}}}
        return screen, target

    def test_identical_cells_resolved_by_recorded_position(self):
        with tempfile.TemporaryDirectory() as tmp:
            screen, target = self._setup(tmp)
            r = Resolver(tmp, {"use_native": False, "use_ocr": False, "use_ai": False}, grab=lambda: (screen, (0, 0)))
            res = r.resolve_once(target, {}, 1)
            self.assertEqual((res.x, res.y), (410, 370))
            self.assertIn("recorded position", res.evidence["disambiguated_by"])

    def test_still_correct_after_window_moved(self):
        with tempfile.TemporaryDirectory() as tmp:
            screen, target = self._setup(tmp)
            r = Resolver(tmp, {"use_native": False, "use_ocr": False, "use_ai": False}, grab=lambda: (screen, (0, 0)))
            res = r.resolve_once(dict(target, y=372), {}, 1)              # a couple of px of drift
            self.assertEqual(res.y, 370)

    def test_text_contradiction_refuses_wrong_neighbour(self):
        with tempfile.TemporaryDirectory() as tmp:
            screen, target = self._setup(tmp)
            r = Resolver(tmp, {"use_native": True, "use_ocr": False, "use_ai": False}, grab=lambda: (screen, (0, 0)))
            r.governor.allowed = lambda *a, **k: True
            r.governor.call = lambda w, fn: fn()
            names = {370: "O7", 300: "O6", 440: "O8", 230: "O4"}
            with patch("core.playback.resolver.winenv.element_at",
                       side_effect=lambda x, y: {"name": names.get(min(names, key=lambda k: abs(k - y)), "")}):
                res = r.resolve_once(dict(target, y=300), {}, 1)           # recorded drift points at O6; O7 is the target
            self.assertEqual(res.y, 370)

    def test_disabled_setting_restores_refusal(self):
        with tempfile.TemporaryDirectory() as tmp:
            screen, target = self._setup(tmp)
            r = Resolver(tmp, {"use_native": False, "use_ocr": False, "use_ai": False, "disambiguate_by_position": False},
                         grab=lambda: (screen, (0, 0)))
            with self.assertRaises(AmbiguousTarget):
                r.resolve_once(target, {}, 1)


class NeighbourProbe(unittest.TestCase):
    def test_unique_neighbour_with_recorded_name_is_found(self):
        r = Resolver(None, {"use_native": True})
        r.governor.allowed = lambda *a, **k: True
        r.governor.call = lambda w, fn: fn()
        grid = {(100, 100): "N6", (140, 100): "O6", (100, 124): "N7", (140, 124): "O7"}

        def at(x, y):
            for (cx, cy), n in grid.items():
                if abs(x - cx) <= 20 and abs(y - cy) <= 12:
                    return {"name": n, "role": "DataItem", "rect": [cx - 20, cy - 12, cx + 20, cy + 12]}
            return {}
        target = {"name": "O7", "role": "DataItem", "rect": [120, 112, 160, 136], "x": 100, "y": 100}
        with patch("core.playback.resolver.winenv.element_at", side_effect=at):
            res = r._t_point(target, {}, {"attempt": 1})
        self.assertEqual((res.x, res.y), (140, 124))
        self.assertTrue(res.evidence["neighbour_probe"])

    def test_two_neighbours_with_same_name_is_refused(self):
        r = Resolver(None, {"use_native": True})
        r.governor.allowed = lambda *a, **k: True
        r.governor.call = lambda w, fn: fn()
        el = lambda cx: {"name": "O7", "role": "DataItem", "rect": [cx - 20, 88, cx + 20, 112]}
        with patch("core.playback.resolver.winenv.element_at",
                   side_effect=lambda x, y: el(60 if x < 100 else 140) if abs(x - 100) > 5 else {"name": "x"}):
            res = r._t_point({"name": "O7", "role": "DataItem", "rect": [80, 88, 120, 112], "x": 100, "y": 100}, {}, {"attempt": 1})
        self.assertIsNone(res)


if __name__ == "__main__":
    unittest.main()
