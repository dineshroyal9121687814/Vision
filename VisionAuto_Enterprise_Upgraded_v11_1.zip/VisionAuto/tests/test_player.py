import json
import math
import time
import unittest
from pathlib import Path
from unittest import mock

import numpy as np

from tests.helpers import FakeProbe, make_frame, use_temp_workspace

use_temp_workspace()

from core import testfile  # noqa: E402
from core.playback.backend import DryRunBackend  # noqa: E402
from core.playback.player import Player  # noqa: E402
from core.playback.resolver import ElementNotFound, Resolution  # noqa: E402
from core.playback.validators import Validator  # noqa: E402
from core.recorder.builder import RawEvent  # noqa: E402
from core.recorder.recorder import Recorder  # noqa: E402

OPTS = {"timeout_s": 0.6, "use_native": False, "use_ocr": False, "use_ai": True, "settle_wait": False, "verify_effect": False, "use_vision_ai": False}
FRAME = make_frame(1000, 700, seed=3)


def shifted(frame, dx, dy, noise=0, seed=9):
    out = np.zeros_like(frame)
    h, w = frame.shape[:2]
    out[dy:, dx:] = frame[:h - dy, :w - dx]
    if noise:
        rng = np.random.default_rng(seed)
        out = np.clip(out.astype(int) + rng.integers(-noise, noise + 1, out.shape), 0, 255).astype(np.uint8)
    return out


def record(name, with_validation=None):
    rec = Recorder(name, probe=FakeProbe(frame=FRAME))
    rec.start(listeners=False, overwrite=True)
    t = time.monotonic()
    rec.inject(RawEvent("mouse_down", t, 500, 350)); rec.inject(RawEvent("mouse_up", t + 0.05, 500, 350))   # click
    rec.inject(RawEvent("mouse_down", t + 1, 200, 200)); rec.inject(RawEvent("mouse_up", t + 1.4, 420, 260))  # drag
    for i, ch in enumerate("ok"):
        rec.inject(RawEvent("key_down", t + 2 + i * 0.1, key=ch, is_char=True))
    rec.inject(RawEvent("key_down", t + 3, key="enter"))
    path = rec.stop()
    if with_validation:
        test, d = testfile.load_test(path)
        test["steps"][0]["validations"] = with_validation
        testfile.save_test(test, d)
    return rec.name


def play(name, frame, opts=None, **kw):
    backend = DryRunBackend()
    player = Player(name, {**OPTS, **(opts or {})}, backend=backend, grab=lambda: (frame, (0, 0)), **kw)
    # These tests exercise synthetic screenshots and locators, not the host's
    # active desktop window. Window synchronization has dedicated mocked tests.
    for step in player.test.get("steps", []):
        step["window"] = {}
    run = player.run()
    return run, backend


class PlayerTests(unittest.TestCase):
    def test_invalid_global_locator_timeouts_are_rejected(self):
        for timeout in (float("nan"), float("inf"), -1, 121):
            with self.subTest(timeout=timeout), self.assertRaisesRegex(ValueError, "timeout_s"):
                Player({"name": "invalid timeout", "steps": []}, {**OPTS, "timeout_s": timeout},
                       backend=DryRunBackend())

    def test_non_finite_locator_and_validation_timeouts_fail_without_waiting(self):
        player = Player({"name": "timeout", "steps": []}, OPTS, backend=DryRunBackend())
        with self.assertRaisesRegex(ValueError, "Locator timeout"):
            player.resolver.resolve({"name": "missing"}, {}, timeout=math.nan)
        result = player.validator.evaluate(
            {"type": "window_title_contains", "expected": "Notepad", "timeout_s": math.inf}, {})
        self.assertEqual(result["status"], "failed")
        self.assertIn("invalid validation timeout", result["detail"])

    def test_locator_waits_until_the_element_becomes_visible(self):
        player = Player({"name": "dynamic visibility", "steps": []}, OPTS, backend=DryRunBackend())
        visible = Resolution(321, 654, "native")
        attempts = []

        def resolve_once(_target, _window, _attempt):
            attempts.append(True)
            return visible if len(attempts) == 3 else None

        with mock.patch.object(player.resolver, "resolve_once", side_effect=resolve_once), \
             mock.patch("core.playback.resolver.time.sleep"):
            result = player.resolver.resolve({"name": "Save"}, {"title": "Notepad"}, timeout=0.5)
        self.assertIs(result, visible)
        self.assertEqual(len(attempts), 3)

    def test_window_activation_is_polled_and_verified_before_playback(self):
        player = Player({"name": "window wait", "steps": []}, OPTS, backend=DryRunBackend())
        player.dry_run = False
        wins = [{"hwnd": 1, "title": "Calculator", "process": "calc.exe"},
                {"hwnd": 2, "title": "Untitled - Notepad", "process": "notepad.exe"}]
        foreground = [{"hwnd": 1}, {"hwnd": 1}, {"hwnd": 1}, {"hwnd": 2}]   # resolve, check, (focus), re-resolve, check
        step = {"window": {"title": "Untitled - Notepad", "process": "notepad.exe"}}
        with mock.patch.object(player, "_enumerate_windows", return_value=wins), \
             mock.patch("core.playback.player.winenv.foreground_window", side_effect=foreground), \
             mock.patch("core.playback.player.winenv.focus_hwnd", return_value=True) as focus, \
             mock.patch.object(player, "_restore_geometry"), \
             mock.patch("core.playback.player.time.sleep"):
            player._ensure_window(step)
        focus.assert_called_once_with(2)                       # activated BY HANDLE, not by title
        self.assertEqual(step["window"]["_hwnd"], 2)

    def test_missing_recorded_window_fails_before_input(self):
        player = Player({"name": "missing window", "steps": []}, OPTS, backend=DryRunBackend())
        # The same process can own multiple windows; a different document of the same app must not be used.
        wins = [{"hwnd": 5, "title": "Other document - Notepad", "process": "notepad.exe", "visible": True}]
        step = {"id": 1, "type": "click", "target": {"x": 20, "y": 30},
                "window": {"title": "Target document - Notepad", "process": "notepad.exe"}, "params": {}}
        player.dry_run = False
        player.opts["timeout_s"] = 0.2
        with mock.patch.object(player, "_enumerate_windows", return_value=wins), \
             mock.patch("core.playback.player.winenv.foreground_window", return_value={"hwnd": 5}):
            result = player.run_step(step)
        self.assertEqual(result["status"], "failed")
        self.assertIn("no input was sent", result["error"])
        self.assertEqual(player.backend.actions, [])

    def test_two_windows_match_is_ambiguous_and_nothing_is_clicked(self):
        player = Player({"name": "two", "steps": []}, OPTS, backend=DryRunBackend())
        wins = [{"hwnd": 5, "title": "Untitled - Notepad", "process": "notepad.exe"},
                {"hwnd": 6, "title": "Untitled - Notepad", "process": "notepad.exe"}]
        step = {"id": 1, "type": "click", "target": {"x": 20, "y": 30}, "params": {},
                "window": {"title": "Untitled - Notepad", "match": "exact", "process": "notepad.exe"}}
        player.dry_run = False
        with mock.patch.object(player, "_enumerate_windows", return_value=wins), \
             mock.patch("core.playback.player.winenv.foreground_window", return_value={"hwnd": 5}):
            result = player.run_step(step)
        self.assertEqual(result["status"], "failed")
        self.assertEqual(result["failure_kind"], "AmbiguousTarget")
        self.assertEqual(len(result["failure_detail"]["candidates"]), 2)
        self.assertEqual(player.backend.actions, [])

    def test_explicit_wait_duration_is_finite_and_bounded(self):
        player = Player({"name": "wait", "steps": []}, OPTS, backend=DryRunBackend(), dry_run=True)
        for value in (float("nan"), float("inf"), -1, 3_600_001):
            with self.subTest(value=value):
                step = {"id": 1, "type": "wait", "params": {"ms": value}, "window": {}}
                result = player._run_step(step)
                self.assertEqual(result["status"], "failed")
                self.assertIn("Wait duration", result["error"])

    def test_replay_on_unchanged_screen(self):
        name = record("same screen")
        run, be = play(name, FRAME)
        self.assertEqual(run["status"], "passed")
        self.assertEqual(run["summary"]["passed"], 4)
        kinds = [a[0] for a in be.actions]
        self.assertEqual(kinds, ["click", "drag", "type", "press"])
        self.assertEqual(be.actions[0][1:3], (500, 350))
        self.assertEqual(be.actions[1][1:5], (200, 200, 420, 260))
        self.assertEqual(be.actions[2][1], "ok")

    def test_element_moved_is_found_by_template(self):
        name = record("moved")
        run, be = play(name, shifted(FRAME, 37, 23))
        self.assertEqual(run["status"], "passed")
        self.assertEqual(be.actions[0][1:3], (537, 373))
        self.assertTrue(run["steps"][0]["method"].startswith("template"))
        # drag: both ends re-located
        self.assertEqual(be.actions[1][1:5], (237, 223, 457, 283))

    def test_heavily_changed_ui_self_heals_and_updates_test(self):
        name = record("healing")
        # 0.82-confidence healing is below the strict default (0.85); this test opts in to the looser threshold.
        run, be = play(name, shifted(FRAME, 37, 23, noise=90), {"min_action_confidence": 0.7})
        self.assertEqual(run["status"], "passed")
        self.assertEqual(be.actions[0][1:3], (537, 373))
        self.assertTrue(run["steps"][0]["method"].startswith("heal"))
        self.assertGreaterEqual(run["summary"]["healed"], 1)
        test, d = testfile.load_test(name)
        self.assertEqual((test["steps"][0]["target"]["x"], test["steps"][0]["target"]["y"]), (537, 373))
        self.assertTrue((d / "test.json.bak").exists())
        self.assertTrue((d / test["steps"][0]["target"]["templates"]["crop300"]["path"]).exists())
        previous = json.loads((d / "test.json.bak").read_text(encoding="utf-8"))
        self.assertEqual((previous["steps"][0]["target"]["x"], previous["steps"][0]["target"]["y"]), (500, 350))
        heal = run["heals"][0]
        self.assertEqual((heal["old_locator"]["x"], heal["new_locator"]["x"]), (500, 537))
        self.assertIn("Locator before / after", (Path(run["_dir"]) / "report.html").read_text(encoding="utf-8"))
        testfile.restore_backup(name)
        restored, _ = testfile.load_test(name)
        self.assertEqual((restored["steps"][0]["target"]["x"], restored["steps"][0]["target"]["y"]), (500, 350))

    def test_failed_run_does_not_commit_recovered_locators(self):
        player = Player({"name": "failed healing", "steps": []}, OPTS, backend=DryRunBackend())
        player._heals.append({"step": 1, "tag": "src", "x": 20, "y": 30, "method": "ocr",
                              "confidence": 0.9, "evidence": {}, "crops": {}})
        with mock.patch.object(player, "_apply_heals") as apply_heals:
            player.finish([], "failed", player.begin())
        apply_heals.assert_not_called()

    def test_unfindable_element_fails_safely_without_clicking_elsewhere(self):
        name = record("gone")
        run, be = play(name, make_frame(1000, 700, seed=77))
        self.assertEqual(run["status"], "failed")
        self.assertEqual(be.actions, [])
        err = run["steps"][0]["error"]
        self.assertIn("Could not find", err)
        self.assertIn("tried:", err)
        self.assertTrue(run["steps"][0]["screenshot"].endswith(".jpg"))
        self.assertEqual(run["summary"]["not_run"], 3)

    def test_drag_does_not_use_stale_coordinates_when_named_destination_is_missing(self):
        player = Player({"name": "safe drag", "steps": []}, OPTS, backend=DryRunBackend(),
                        grab=lambda: (FRAME, (0, 0)))
        step = {"id": 1, "type": "drag_drop", "target": {"x": 100, "y": 100, "name": "File"},
                "to": {"x": 400, "y": 400, "name": "Trash"}, "params": {}, "window": {}}
        with mock.patch.object(player, "_resolve", side_effect=[Resolution(100, 100, "native"),
                                                                  ElementNotFound("Trash not found")]):
            result = player._run_step(step)
        self.assertEqual(result["status"], "failed")
        self.assertIn("Trash not found", result["error"])
        self.assertEqual(player.backend.actions, [])

    def test_scroll_does_not_fall_back_to_stale_coordinates_for_named_target(self):
        player = Player({"name": "safe scroll", "steps": []}, OPTS, backend=DryRunBackend(),
                        grab=lambda: (FRAME, (0, 0)))
        step = {"id": 1, "type": "scroll", "target": {"x": 100, "y": 100, "name": "Results"},
                "params": {"dx": 0, "dy": -3}, "window": {}}
        with mock.patch.object(player, "_resolve", side_effect=ElementNotFound("Results not found")):
            result = player._run_step(step)
        self.assertEqual(result["status"], "failed")
        self.assertEqual(player.backend.actions, [])

    def test_redacted_sensitive_input_is_blocked_without_backend_action_or_screenshot(self):
        player = Player({"name": "secret", "steps": []}, OPTS, backend=DryRunBackend(),
                        grab=lambda: (FRAME, (0, 0)))
        step = {"id": 1, "type": "type", "params": {"text": "", "redacted": True},
                "window": {}, "validations": []}
        result = player._run_step(step)
        self.assertEqual(result["status"], "failed")
        self.assertIn("secure secret input provider", result["error"])
        self.assertEqual(player.backend.actions, [])
        self.assertNotIn("screenshot", result)

    def test_validations_pass_fail_and_are_polled(self):
        ok = [{"type": "window_title_contains", "expected": "Notepad"}]
        bad = [{"type": "window_title_contains", "expected": "Save As", "timeout_s": 0.5}]
        fg = {"title": "Untitled - Notepad", "process": "notepad.exe", "pid": 1, "hwnd": 1}
        with mock.patch("core.playback.validators.winenv.foreground_window", return_value=fg), \
             mock.patch("core.playback.validators.winenv.window_exists", return_value=False):
            run, _ = play(record("val ok", ok), FRAME)
            self.assertEqual(run["status"], "passed")
            self.assertEqual(run["steps"][0]["validations"][0]["status"], "passed")
            self.assertEqual(run["steps"][0]["validations"][0]["expected"], "Notepad")
            self.assertEqual(run["steps"][0]["validations"][0]["actual"], "Untitled - Notepad")
            self.assertIn("environment", run)
            run, _ = play(record("val bad", bad), FRAME)
        self.assertEqual(run["status"], "failed")
        self.assertIn("Validation failed", run["steps"][0]["error"])
        self.assertIn("Untitled - Notepad", run["steps"][0]["validations"][0]["detail"])

    def test_background_window_cannot_satisfy_foreground_title_validation(self):
        validator = Validator(None, {})
        with mock.patch("core.playback.validators.winenv.foreground_window",
                        return_value={"title": "Calculator", "hwnd": 1}), \
             mock.patch("core.playback.validators.winenv.window_exists", return_value=True) as exists:
            status, detail, actual = validator._once(
                {"type": "window_title_contains", "expected": "Notepad"}, {})
        self.assertEqual(status, "failed")
        self.assertIn("Calculator", detail)
        self.assertEqual(actual, "Calculator")
        exists.assert_not_called()

    def test_dry_run_and_abort(self):
        name = record("dry")
        run = Player(name, OPTS, dry_run=True).run()
        self.assertTrue(run["dry_run"])
        self.assertEqual(run["status"], "inconclusive")
        self.assertEqual(run["summary"]["passed"], 0)
        self.assertEqual(run["summary"]["skipped"], run["summary"]["total"])
        stop = {"v": False}

        def on_step(r):
            if r.get("status") == "skipped":
                stop["v"] = True

        run = Player(name, OPTS, dry_run=True, on_step=on_step, should_stop=lambda: stop["v"]).run()
        self.assertEqual(run["status"], "aborted")
        self.assertEqual(run["summary"]["skipped"], 1)

    def test_validate_step_from_hotkey_marker(self):
        rec = Recorder("marker", probe=FakeProbe(frame=FRAME))
        rec.start(listeners=False, overwrite=True)
        rec.inject(RawEvent("marker", time.monotonic(), 500, 350))
        rec.stop()
        run, _ = play(rec.name, FRAME)
        self.assertEqual(run["status"], "passed")
        self.assertEqual(run["steps"][0]["validations"][0]["type"], "element_exists")
        run, _ = play(rec.name, make_frame(1000, 700, seed=5))
        self.assertEqual(run["status"], "failed")


if __name__ == "__main__":
    unittest.main()
