"""pytest hooks.

With real PySide6 (offscreen) the interpreter can crash while tearing Qt down after ALL tests passed (QApplication is destroyed
while Qt objects still exist). The exit status of the test run is what matters, so end the process directly with that status
once the results are reported - only when Qt was actually imported."""
import os
import sys


def pytest_sessionfinish(session, exitstatus):
    if "PySide6.QtWidgets" in sys.modules and os.environ.get("VISIONAUTO_QT_HARD_EXIT", "1") == "1":
        sys.stdout.flush()
        sys.stderr.flush()
        os._exit(int(exitstatus))
