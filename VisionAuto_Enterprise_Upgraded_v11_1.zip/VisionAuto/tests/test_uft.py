import tempfile
import unittest
from pathlib import Path

from tests.helpers import use_temp_workspace

use_temp_workspace()

from core import testfile  # noqa: E402
from core.importers.uft.importer import import_script  # noqa: E402
from core.importers.uft.object_repository import parse_xml_repository  # noqa: E402
from core.importers.uft.vbscript import convert_script  # noqa: E402
from core.playback.backend import DryRunBackend  # noqa: E402
from core.playback.player import Player  # noqa: E402


FIXTURES = Path(__file__).parent / "uft_samples"
REPOSITORY_XML = (FIXTURES / "ObjectRepository.xml").read_text(encoding="utf-8")
SCRIPT = (FIXTURES / "Login.vbs").read_text(encoding="utf-8")


class UFTObjectRepositoryTests(unittest.TestCase):
    def test_reads_xml_export_and_resolves_full_path(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "objects.xml"
            path.write_text(REPOSITORY_XML, encoding="utf-8")
            objects, notes = parse_xml_repository(path)
        self.assertIn("demo browser.login.username", objects)
        self.assertEqual(objects["demo browser.login.username"]["properties"]["htmlid"], "user-name")
        self.assertTrue(any("binary UFT .tsr" in item for item in notes))

    def test_duplicate_leaf_names_require_a_full_object_path(self):
        xml = """<Repository><Page name="One"><Object name="Save"><Property name="micclass">WebButton</Property></Object></Page>
        <Page name="Two"><Object name="Save"><Property name="micclass">WebButton</Property></Object></Page></Repository>"""
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "duplicate.xml"
            path.write_text(xml, encoding="utf-8")
            objects, _ = parse_xml_repository(path)
        from core.importers.uft.object_repository import find_object

        self.assertIsNone(find_object(objects, ["Save"]))
        self.assertEqual(find_object(objects, ["One", "Save"])["path"], "One.Save")


class UFTConversionTests(unittest.TestCase):
    def setUp(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "objects.xml"
            path.write_text(REPOSITORY_XML, encoding="utf-8")
            self.repo, _ = parse_xml_repository(path)

    def test_converts_actions_checkpoints_and_parameters_with_traceability(self):
        converted = convert_script(SCRIPT, "Login.vbs", self.repo, {"user": "alice"})
        self.assertEqual([step["type"] for step in converted.steps],
                         ["click", "hotkey", "type", "click", "validate", "validate"])
        self.assertEqual(converted.steps[2]["params"]["text"], "alice")
        self.assertEqual(converted.steps[0]["target"]["automation_id"], "user-name")
        self.assertEqual(converted.steps[0]["window"]["title"], "Demo Browser")
        self.assertEqual(converted.steps[4]["check"], {"type": "text_equals", "expected": "Sign in"})
        self.assertEqual(converted.steps[0]["source"], {"file": "Login.vbs", "line": 2})
        report = converted.report("Login.vbs")
        self.assertEqual(report["converted_count"], 6)
        self.assertEqual(report["parameters_used"], ["user"])
        self.assertFalse(report["manual_review_required"])

    def test_unresolved_parameters_and_unsupported_lines_are_reported(self):
        script = '''
Browser("Demo Browser").Page("Login").WebEdit("Username").Set Parameter("missing")
If Browser("Demo Browser").Exist Then
  Browser("Demo Browser").Page("Login").WebButton("Submit").Click
End If
Browser("Demo Browser").Page("Login").WebButton("Submit").SetSecure "secret"
'''
        converted = convert_script(script, "Unsafe.vbs", self.repo)
        self.assertEqual(converted.steps, [])
        self.assertGreaterEqual(len(converted.unsupported), 5)
        self.assertTrue(converted.report("Unsafe.vbs")["manual_review_required"])
        self.assertTrue(any("Unresolved input parameter" in row["reason"] for row in converted.unsupported))
        self.assertFalse(any(step["type"] == "click" for step in converted.steps))

    def test_datatable_values_and_boolean_waitproperty(self):
        script = '''
Browser("Demo Browser").Page("Login").WebEdit("Username").Set DataTable.Value("user", dtGlobalSheet)
Browser("Demo Browser").Page("Login").WebButton("Submit").WaitProperty "visible", True, 10
'''
        converted = convert_script(script, "Parameters.vbs", self.repo, {"user": "bob"})
        self.assertEqual([step["type"] for step in converted.steps], ["click", "hotkey", "type", "validate"])
        self.assertEqual(converted.steps[2]["params"]["text"], "bob")
        self.assertEqual(converted.steps[3]["check"]["type"], "element_exists")
        self.assertTrue(any("WaitProperty timeout" in note for note in converted.assumptions))

    def test_import_writes_shared_test_schema_and_migration_report(self):
        with tempfile.TemporaryDirectory() as tmp:
            source = Path(tmp) / "Login.vbs"
            repository = Path(tmp) / "objects.xml"
            source.write_text(SCRIPT, encoding="utf-8")
            repository.write_text(REPOSITORY_XML, encoding="utf-8")
            result = import_script(source, repository, name="UFT Login", parameters={"user": "alice"})
        test, directory = testfile.load_test(result["test_path"])
        self.assertEqual(test["schema"], testfile.SCHEMA)
        self.assertEqual(test["source"]["type"], "uft")
        self.assertEqual(len(test["steps"]), 6)
        self.assertTrue((directory / "migration_report.json").is_file())
        self.assertEqual(result["report"]["unsupported_count"], 0)
        backend = DryRunBackend()
        run = Player(result["test_path"], dry_run=True, backend=backend).run()
        self.assertEqual(run["status"], "inconclusive")
        self.assertEqual([action[0] for action in backend.actions], ["click", "hotkey", "type", "click"])


if __name__ == "__main__":
    unittest.main()
