"""Excel Start-screen launch, drag distance, dropdown opener / hover."""
import sys
import unittest
from pathlib import Path
from unittest import mock

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from tests import helpers                                                          # noqa: E402
from core.playback.backend import DryRunBackend                                    # noqa: E402
from core.playback.player import Player                                            # noqa: E402
from core.playback.resolver import Resolution                                      # noqa: E402

OPTS = {"timeout_s": 1.0, "settle_wait": False, "use_vision_ai": False, "use_ocr": False}


def player(steps, **opts):
    helpers.use_temp_workspace()
    be = DryRunBackend()
    return Player({"name": "t", "steps": steps, "applications": [], "variables": {}}, {**OPTS, **opts}, backend=be,
                  dry_run=False, grab=lambda: (np.zeros((300, 400, 3), np.uint8), (0, 0))), be


class ExcelStartScreen(unittest.TestCase):
    def test_excel_without_a_workbook_path_uses_the_normal_launcher_not_com(self):
        helpers.use_temp_workspace()
        step = {"id": 1, "type": "open_app", "t_ms": 0, "window": {}, "validations": [], "params": {"name": "Excel", "window_title": "Excel"}}
        p, _ = player([step])
        with mock.patch("core.playback.player.excel_launch.open_excel") as com, \
                mock.patch("core.playback.player.launcher.open_application",
                           return_value={"method": "startapp:Excel", "tried": []}) as launch:
            out = p.run()
        com.assert_not_called()
        launch.assert_called_once()
        self.assertEqual(out["status"], "passed", out)

    def test_excel_with_a_workbook_path_still_uses_com(self):
        step = {"id": 1, "type": "open_app", "t_ms": 0, "window": {}, "validations": [],
                "params": {"name": "Excel", "path": "C:\\data\\book.xlsx"}}
        p, _ = player([step])
        with mock.patch("core.playback.player.excel_launch.open_excel",
                        return_value={"method": "attach", "workbook": "book.xlsx", "tried": [], "hwnd": 5}) as com:
            p.run()
        com.assert_called_once()


class DragDistance(unittest.TestCase):
    def _p(self, layout_same=False):
        p, be = player([])
        p.resolver._layout_same = layout_same
        return p

    STEP = {"id": 1, "target": {"x": 100, "y": 100}, "to": {"x": 100, "y": 220}}

    def test_correct_distance_is_untouched(self):
        p = self._p()
        s, d = p._reconcile_drag(self.STEP, Resolution(100, 100, "template(300)"), Resolution(100, 220, "template(300)"), {})
        self.assertEqual((s.y, d.y), (100, 220))

    def test_too_short_drag_destination_is_moved_when_source_is_strong(self):
        p, res = self._p(), {}
        s, d = p._reconcile_drag(self.STEP, Resolution(100, 100, "native"), Resolution(100, 172, "template(300)"), res)
        self.assertEqual((d.x, d.y), (100, 220))
        self.assertIn("destination moved", res["drag_vector_corrected"]["action"])

    def test_weak_source_is_moved_when_destination_is_strong(self):
        p = self._p()
        s, d = p._reconcile_drag(self.STEP, Resolution(100, 124, "template(300)"), Resolution(100, 220, "native"), {})
        self.assertEqual((s.x, s.y), (100, 100))

    def test_both_weak_and_window_unchanged_uses_recorded_coordinates(self):
        p = self._p(layout_same=True)
        s, d = p._reconcile_drag(self.STEP, Resolution(100, 124, "template(300)"), Resolution(100, 172, "template(300)"), {})
        self.assertEqual(((s.x, s.y), (d.x, d.y)), ((100, 100), (100, 220)))

    def test_cross_window_drag_is_not_reconciled(self):
        p = self._p()
        step = {**self.STEP, "to_window": {"title": "Other"}}
        s, d = p._reconcile_drag(step, Resolution(1, 1, "template"), Resolution(900, 900, "template"), {})
        self.assertEqual((d.x, d.y), (900, 900))


class Dropdown(unittest.TestCase):
    def _click(self, intent, role):
        return {"id": 1, "type": "click", "t_ms": 0, "window": {}, "validations": [], "intent": intent,
                "target": {"x": 50, "y": 50, "name": "Combo", "role": role, "locator_mode": "coordinates"}}

    def test_opener_that_opened_nothing_is_clicked_again_even_in_classic_profile(self):
        p, be = player([self._click("open_dropdown", "ComboBox")], effect_wait_s=0.15)
        p.run()
        self.assertEqual(len([a for a in be.actions if a[0] == "click"]), 2)

    def test_ordinary_combobox_click_is_not_repeated_in_classic_profile(self):
        p, be = player([self._click("click", "ComboBox")], effect_wait_s=0.15)
        p.run()
        self.assertEqual(len([a for a in be.actions if a[0] == "click"]), 1)

    def test_option_click_hovers_first(self):
        p, be = player([self._click("pick_option", "ListItem")])
        p.run()
        kinds = [a[0] for a in be.actions]
        self.assertLess(kinds.index("move"), kinds.index("click"))


if __name__ == "__main__":
    unittest.main()
