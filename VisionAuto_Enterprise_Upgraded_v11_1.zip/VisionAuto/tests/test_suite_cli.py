import json
import tempfile
import unittest
from pathlib import Path

from tests import helpers
from core import cli, suite, testfile


def make_test(name, text="hi", bad=False):
    t = testfile.new_test(name)
    t["steps"] = [{"id": 1, "type": "frobnicate" if bad else "type", "t_ms": 0, "window": {}, "validations": [],
                   "params": {"text": text}, "description": "s"}]
    testfile.save_test(t)
    return name


def write_suite(**kw):
    d = Path(tempfile.mkdtemp())
    p = d / "suite.json"
    p.write_text(json.dumps({"name": "S", **kw}), encoding="utf-8")
    return p


class SuiteTests(unittest.TestCase):
    def setUp(self):
        helpers.use_temp_workspace()

    def test_runs_tests_filters_by_tag_and_writes_junit(self):
        for n in ("A", "B", "C"):
            make_test(n)
        p = write_suite(tests=[{"test": "A", "tags": ["smoke"]}, {"test": "B", "tags": ["slow"]}, {"test": "C", "enabled": False}])
        res = suite.run_suite(p, dry_run=True)
        self.assertEqual([r["test"] for r in res["results"]], ["A", "B"])
        res = suite.run_suite(p, include=["smoke"], dry_run=True)
        self.assertEqual([r["test"] for r in res["results"]], ["A"])
        self.assertEqual(res["status"], "inconclusive")
        junit = (Path(res["_dir"]) / "suite_junit.xml").read_text(encoding="utf-8")
        self.assertIn('tests="1"', junit)

    def test_failed_setup_skips_tests_but_teardown_still_runs(self):
        make_test("Setup", bad=True)
        make_test("Main")
        make_test("Down")
        p = write_suite(setup=["Setup"], teardown=["Down"], tests=["Main"])
        res = suite.run_suite(p, dry_run=True)
        by = {r["test"]: r for r in res["results"]}
        self.assertEqual(by["Setup"]["status"], "invalid")
        self.assertEqual(by["Main"]["status"], "skipped")
        self.assertEqual(by["Down"]["status"], "inconclusive")
        self.assertEqual(res["status"], "failed")

    def test_stop_on_failure_and_broken_tests_do_not_crash_the_suite(self):
        make_test("Bad", bad=True)
        make_test("Next")
        p = write_suite(stop_on_failure=True, tests=["Bad", "Next", "Missing"])
        res = suite.run_suite(p, dry_run=True)
        self.assertEqual([r["test"] for r in res["results"]], ["Bad"])
        res = suite.run_suite(write_suite(tests=["Bad", "Next", "Missing"]), dry_run=True)
        self.assertEqual(res["results"][2]["status"], "error")

    def test_per_test_data_file_and_validation_of_suite_files(self):
        t = testfile.new_test("Data")
        t["steps"] = [{"id": 1, "type": "type", "t_ms": 0, "window": {}, "validations": [], "params": {"text": "${u}"}, "description": "s"}]
        testfile.save_test(t)
        p = write_suite(tests=[{"test": "Data", "data": "u.csv", "select": "2-"}])
        (p.parent / "u.csv").write_text("u\na\nb\nc\n", encoding="utf-8")
        res = suite.run_suite(p, dry_run=True)
        self.assertEqual(res["results"][0]["iterations"]["rows_run"], 2)
        for bad in ({"tests": []}, {"tests": [{"nope": 1}]}, {"tests": ["A"], "setup": "A"}, {"tests": [{"test": "A", "tags": "x"}]}):
            with self.assertRaises(suite.SuiteError):
                suite.load_suite(write_suite(**bad))


class CliTests(unittest.TestCase):
    def setUp(self):
        helpers.use_temp_workspace()
        make_test("T")

    def test_run_exit_codes(self):
        self.assertEqual(cli.main(["run", "T", "--dry-run"]), 0)
        make_test("Bad", bad=True)
        self.assertEqual(cli.main(["run", "Bad", "--dry-run"]), 2)

    def test_edit_commands_change_the_saved_test(self):
        t, d = testfile.load_test("T")
        t["steps"].append({"id": 2, "type": "click", "t_ms": 0, "window": {}, "validations": [], "target": {"x": 5, "y": 6}, "description": "c"})
        testfile.save_test(t, d)
        self.assertEqual(cli.main(["edit", "locator", "T", "2", "xpath", "//button[@name='OK']"]), 0)
        self.assertEqual(cli.main(["edit", "order", "T", "2", "xpath,ocr,coordinates"]), 0)
        self.assertEqual(cli.main(["edit", "locator", "T", "2", "ocr_region", "--x", "1", "--y", "2", "--w", "200", "--h", "60"]), 0)
        self.assertEqual(cli.main(["edit", "loop", "T", "1", "2", "--times", "3"]), 0)
        saved, _ = testfile.load_test("T")
        tgt = [s for s in saved["steps"] if s["type"] == "click"][0]["target"]
        self.assertEqual((tgt["xpath"], tgt["locator_order"], tgt["ocr_region"]), ("//button[@name='OK']", ["xpath", "ocr", "coordinates"], [1, 2, 200, 60]))
        self.assertEqual(saved["steps"][0]["type"], "loop_start")
        self.assertEqual(cli.main(["edit", "locator", "T", "3", "xpath", "//bad["]), 2)       # click step is now id 3; bad XPath rejected
        self.assertEqual(cli.main(["run", "T", "--dry-run"]), 0)


if __name__ == "__main__":
    unittest.main()
