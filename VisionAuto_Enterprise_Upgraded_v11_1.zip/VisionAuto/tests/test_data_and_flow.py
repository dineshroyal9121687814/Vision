import json
import tempfile
import unittest
from pathlib import Path
from unittest import mock

import numpy as np

from tests import helpers
from core import datasource, editing, settings, testfile
from core.playback.backend import DryRunBackend
from core.playback.player import Player
from core.playback.resolver import Resolver


def step(i, t, **kw):
    return {"id": i, "type": t, "t_ms": 0, "window": {}, "validations": [], "description": f"s{i}", **kw}


def typed(text, i=1):
    return step(i, "type", params={"text": text})


def run(steps, data=None, select=None, **test_extra):
    helpers.use_temp_workspace()
    backend = DryRunBackend()
    test = {"name": "flow", "steps": steps, "applications": [], "variables": {}, **test_extra}
    out = Player(test, {"timeout_s": 1.0}, backend=backend, dry_run=True, data=data, data_select=select).run()
    texts = [a[1] for a in backend.actions if a[0] == "type"]
    return out, texts


class DataSourceTests(unittest.TestCase):
    def test_csv_json_inline_selection_skip_and_column_cleaning(self):
        d = Path(tempfile.mkdtemp())
        (d / "u.csv").write_text("User Name,role,skip\nann,admin,\nbob,user,yes\ncy,user,\n", encoding="utf-8")
        cols, rows = datasource.load_file(d / "u.csv")
        self.assertEqual(cols, ["User_Name", "role", "skip"])
        res = datasource.resolve({"data": {"file": "u.csv"}}, d)
        self.assertEqual([n for n, _ in res["rows"]], [1, 3])          # row 2 skipped by the skip column
        self.assertEqual([n for n, _ in datasource.resolve({"data": {"rows": [{"a": 1}, {"a": 2}, {"a": 3}]}}, d, select="2-")["rows"]], [2, 3])
        (d / "j.json").write_text(json.dumps([{"a": "x"}, {"a": "y"}]), encoding="utf-8")
        self.assertEqual(datasource.load_file(d / "j.json")[1], [{"a": "x"}, {"a": "y"}])

    def test_limits_and_path_escape_are_enforced(self):
        d = Path(tempfile.mkdtemp())
        with self.assertRaises(datasource.DataError):
            datasource.resolve({"data": {"file": "../secret.csv"}}, d)
        with self.assertRaises(datasource.DataError):
            datasource.from_rows([])
        with self.assertRaises(datasource.DataError):
            datasource.parse_selection("x-y", 5)
        with self.assertRaises(datasource.DataError):
            datasource.load_file(d / "a.exe")


class DataDrivenRunTests(unittest.TestCase):
    def test_each_row_runs_the_steps_with_its_values(self):
        out, texts = run([typed("hello ${user}")], data=[{"user": "ann"}, {"user": "bob"}, {"user": "cy"}], select="1,3")
        self.assertEqual(texts, ["hello ann", "hello cy"])
        self.assertEqual(out["data"]["rows_run"], 2)
        self.assertEqual([i["row"] for i in out["iterations"]], [1, 3])
        self.assertTrue(all(r["description"].startswith("[#") for r in out["steps"]))

    def test_builtin_row_and_iteration_variables(self):
        _, texts = run([typed("${_iteration}/${_row}")], data=[{"a": "1"}, {"a": "2"}])
        self.assertEqual(texts, ["1/1", "2/2"])

    def test_secret_columns_never_reach_the_run_file(self):
        helpers.use_temp_workspace()
        backend = DryRunBackend()
        test = {"name": "sec", "steps": [typed("${pw}")], "applications": [], "variables": {},
                "data": {"rows": [{"pw": "Sup3rSecretValue"}, {"pw": "An0therSecretValue"}], "secret_columns": ["pw"]}}
        run_out = Player(test, backend=backend, dry_run=True).run()
        self.assertEqual([a[1] for a in backend.actions if a[0] == "type"], ["Sup3rSecretValue", "An0therSecretValue"])
        blob = (Path(run_out["_dir"]) / "run.json").read_text(encoding="utf-8")
        self.assertNotIn("Sup3rSecretValue", blob)
        self.assertNotIn("An0therSecretValue", blob)
        self.assertEqual(run_out["data"]["columns"], [])

    def test_row_failure_policy_continue_vs_stop(self):
        # a row whose loop count is not a number fails that row only
        steps = [step(1, "loop_start", params={"times": "${n}"}), typed("x", 2), step(3, "loop_end")]
        rows = [{"n": "oops"}, {"n": "2"}, {"n": "1"}]
        out, texts = run(steps, data=rows)
        self.assertEqual(out["data"]["rows_run"], 3)
        self.assertEqual(out["iterations"][0]["status"], "failed")
        self.assertEqual(out["data"]["rows_failed"], 1)
        self.assertEqual(out["status"], "failed")
        self.assertEqual(texts, ["x", "x", "x"])          # rows 2 and 3 still ran (2 + 1 repetitions)
        helpers.use_temp_workspace()
        test = {"name": "stp", "steps": steps, "applications": [], "variables": {},
                "data": {"rows": rows, "on_row_failure": "stop"}}
        out = Player(test, backend=DryRunBackend(), dry_run=True).run()
        self.assertEqual(out["data"]["rows_run"], 1)

    def test_bad_data_is_reported_as_invalid_not_a_crash(self):
        helpers.use_temp_workspace()
        out = Player({"name": "bad", "steps": [typed("a")], "applications": [], "variables": {},
                      "data": {"file": "missing.csv"}}, backend=DryRunBackend(), dry_run=True,
                     base_dir=tempfile.mkdtemp()).run()
        self.assertEqual(out["status"], "invalid")
        self.assertIn("Data source", out["error"])


class ControlFlowTests(unittest.TestCase):
    def test_loop_times_and_loop_counter(self):
        out, texts = run([step(1, "loop_start", params={"times": 3}), typed("n${_loop}", 2), step(3, "loop_end")])
        self.assertEqual(texts, ["n1", "n2", "n3"])

    def test_if_else_branches_per_data_row(self):
        steps = [step(1, "if_start", condition={"type": "variable", "name": "role", "op": "equals", "value": "admin"}),
                 typed("ADMIN", 2), step(3, "else"), typed("USER", 4), step(5, "if_end")]
        _, texts = run(steps, data=[{"role": "admin"}, {"role": "guest"}])
        self.assertEqual(texts, ["ADMIN", "USER"])

    def test_break_exits_only_the_innermost_loop(self):
        steps = [step(1, "loop_start", params={"times": 5}), typed("${_loop}", 2),
                 step(3, "if_start", condition={"type": "variable", "name": "_loop", "op": "equals", "value": "2"}),
                 step(4, "break_loop"), step(5, "if_end"), step(6, "loop_end"), typed("after", 7)]
        _, texts = run(steps)
        self.assertEqual(texts, ["1", "2", "after"])

    def test_nested_loops(self):
        steps = [step(1, "loop_start", params={"times": 2}), step(2, "loop_start", params={"times": 3}),
                 typed("x", 3), step(4, "loop_end"), step(5, "loop_end")]
        _, texts = run(steps)
        self.assertEqual(len(texts), 6)

    def test_numeric_comparison_operators(self):
        for op, val, expect in (("gt", "3", ["Y"]), ("lt", "3", []), ("ge", "5", ["Y"]), ("le", "4", [])):
            steps = [step(1, "if_start", condition={"type": "variable", "name": "n", "op": op, "value": val}),
                     typed("Y", 2), step(3, "if_end")]
            _, texts = run(steps, data=[{"n": "5"}])
            self.assertEqual(texts, expect, (op, val))

    def test_structure_errors_block_the_run_before_anything_is_sent(self):
        for steps in ([step(1, "loop_start", params={"times": 2})],
                      [step(1, "break_loop")],
                      [step(1, "loop_start", params={"while": {"type": "exists", "target": {"x": 1, "y": 1}}, "max": 0}), step(2, "loop_end")],
                      [step(1, "loop_start", params={"times": 99999}), step(2, "loop_end")],
                      [step(1, "if_end")]):
            out, texts = run(steps)
            self.assertEqual(out["status"], "invalid", steps)
            self.assertEqual(texts, [])

    def test_dry_run_while_loop_with_element_condition_runs_once(self):
        cond = {"type": "exists", "target": {"x": 1, "y": 1, "name": "Next"}}
        out, texts = run([step(1, "loop_start", params={"while": cond, "max": 50}), typed("p", 2), step(3, "loop_end")])
        self.assertEqual(texts, ["p"])


class StagedOcrTests(unittest.TestCase):
    def setUp(self):
        helpers.use_temp_workspace()
        self.frame = np.zeros((2000, 3000, 3), dtype=np.uint8)
        self.r = Resolver(Path(tempfile.mkdtemp()), settings.validate({}), grab=lambda: (self.frame, (0, 0)))

    def stages(self, **t):
        return [(n, (x1 - x0, y1 - y0)) for n, (x0, y0, x1, y1) in self.r.ocr_stages({"x": 1500, "y": 1000, **t}, self.frame, (0, 0))]

    def test_default_searches_near_then_wider_then_whole_screen(self):
        self.assertEqual(self.stages(), [("near", (440, 440)), ("wider", (1056, 1056)), ("screen", (3000, 2000))])

    def test_modes_and_explicit_region(self):
        self.assertEqual([n for n, _ in self.stages(ocr_search="local_only")], ["near", "wider"])
        self.assertEqual([n for n, _ in self.stages(ocr_search="screen_only")], ["screen"])
        reg = self.stages(ocr_region=[100, 100, 300, 80])
        self.assertEqual(reg[0], ("region", (300, 80)))
        self.assertEqual(reg[-1][0], "screen")
        self.assertEqual(self.stages(ocr_radius=100)[0], ("near", (200, 200)))

    def test_ocr_stops_at_the_first_stage_that_finds_the_text_and_maps_coordinates(self):
        seen = []

        def fake(crop, label, min_confidence=0.0, near=None):
            seen.append(crop.shape[:2])
            found = crop.shape[0] == 1056
            return mock.Mock(found=found, x=10, y=20, confidence=0.9, matched_text=label)

        with mock.patch("core.ocr.ocr_engine.find_text", side_effect=fake):
            res = self.r._t_ocr({"x": 1500, "y": 1000, "text": "Save"}, {}, {"frame": None, "origin": (0, 0)})
        self.assertEqual(seen, [(440, 440), (1056, 1056)])          # whole screen never scanned
        self.assertEqual((res.x, res.y), (1500 - 528 + 10, 1000 - 528 + 20))
        self.assertEqual(res.evidence["ocr_stage"], "wider")

    def test_local_only_gives_up_instead_of_scanning_everything(self):
        with mock.patch("core.ocr.ocr_engine.find_text", return_value=mock.Mock(found=False)) as f:
            res = self.r._t_ocr({"x": 1500, "y": 1000, "text": "Save", "ocr_search": "local_only"}, {}, {"frame": None, "origin": (0, 0)})
        self.assertIsNone(res)
        self.assertEqual(f.call_count, 2)


class LocatorOrderTests(unittest.TestCase):
    def setUp(self):
        helpers.use_temp_workspace()
        self.r = Resolver(Path(tempfile.mkdtemp()), settings.validate({"engine_profile": "strict"}), grab=lambda: (np.zeros((100, 100, 3), np.uint8), (0, 0)))

    def test_default_and_custom_order(self):
        self.assertEqual(self.r.tier_order({}), ["excel", "point", "uia", "anchor", "ocr_local", "coordtext", "image", "orb", "nbimg", "ocr_wide", "vision", "ai", "heal", "scroll"])
        self.assertEqual(self.r.tier_order({"locator_order": ["ocr", "xpath", "bogus", "ocr"]}), ["ocr", "xpath"])
        self.assertEqual(self.r.tier_order({"locator_order": ["bogus"]}), self.r.DEFAULT_ORDER and list(self.r.DEFAULT_ORDER))

    def test_classic_profile_is_the_default_and_matches_the_proven_build(self):
        from core import settings as st
        opts = st.validate({})
        self.assertEqual(opts["engine_profile"], "classic")
        self.assertFalse(opts["strict_targeting"] or opts["verify_effect"] or opts["retry_no_effect"])
        r = Resolver(Path(tempfile.mkdtemp()), opts, grab=lambda: (np.zeros((100, 100, 3), np.uint8), (0, 0)))
        self.assertEqual(r.tier_order({}), ["uia", "image", "orb", "ocr", "ai", "heal", "scroll", "layout_local"])
        strict = st.validate({"engine_profile": "strict"})
        self.assertTrue(strict["strict_targeting"] and strict["verify_effect"])
        self.assertFalse(st.validate({"engine_profile": "strict", "verify_effect": False})["verify_effect"])   # explicit wins

    def test_coordinate_fallback_is_opt_in_and_window_guarded(self):
        t = {"x": 50, "y": 60}
        self.assertIsNone(self.r.resolve_once(t, {}, 1))                       # not in the default order
        t["locator_order"] = ["coordinates"]
        res = self.r.resolve_once(t, {}, 1)
        self.assertEqual((res.x, res.y, res.method), (50, 60, "coordinates(fallback)"))
        with mock.patch("core.system.winenv.foreground_window", return_value={"title": "Other app", "rect": [0, 0, 200, 200]}):
            self.assertIsNone(self.r.resolve_once(t, {"title": "Notepad"}, 1))
        with mock.patch("core.system.winenv.foreground_window", return_value={"title": "Untitled - Notepad", "rect": [0, 0, 200, 200]}):
            self.assertEqual(self.r.resolve_once(t, {"title": "Notepad"}, 1).x, 50)
        with mock.patch("core.system.winenv.foreground_window", return_value={"title": "Notepad", "rect": [0, 0, 20, 20]}):
            self.assertIsNone(self.r.resolve_once(t, {"title": "Notepad"}, 1))   # point outside the window


class EditingTests(unittest.TestCase):
    def make(self):
        helpers.use_temp_workspace()
        d = Path(tempfile.mkdtemp())
        t = {"name": "ed", "steps": [step(1, "click", target={"x": 10, "y": 20, "name": "Save", "templates": {"crop100": {"path": "assets/a.png", "click": [5, 5], "size": [10, 10]}}}),
                                      step(2, "type", params={"text": "${user}"}), step(3, "click", target={"x": 1, "y": 2})],
             "applications": [], "variables": {}}
        return t, d

    def test_locator_edits_merge_and_keep_other_locators(self):
        t, d = self.make()
        editing.set_locator(t, 1, "xpath", "//button[@name='Save']")
        editing.set_locator(t, 1, "text", "Save")
        editing.set_locator(t, 1, "ocr_region", x=5, y=6, w=300, h=80)
        editing.set_locator(t, 1, "coordinates", x=111, y=222, exact=True)
        tgt = t["steps"][0]["target"]
        self.assertEqual((tgt["xpath"], tgt["text"], tgt["ocr_region"], tgt["x"], tgt["locator_mode"]),
                         ("//button[@name='Save']", "Save", [5, 6, 300, 80], 111, "coordinates"))
        self.assertIn("crop100", tgt["templates"])                              # image crop untouched
        editing.set_locator(t, 1, "coordinates", x=1, y=2)                      # exact=False clears the hard override
        self.assertNotIn("locator_mode", t["steps"][0]["target"])

    def test_bad_edits_are_rejected_with_clear_messages(self):
        t, d = self.make()
        for call in (lambda: editing.set_locator(t, 1, "xpath", "//button["),
                     lambda: editing.set_locator(t, 1, "ocr_region", x=1, y=1, w=2, h=2),
                     lambda: editing.set_locator(t, 1, "banana", "x"),
                     lambda: editing.set_locator(t, 99, "text", "x"),
                     lambda: editing.set_locator(t, 2, "text", "x"),              # a type step has no element
                     lambda: editing.set_locator_order(t, 1, ["xpath", "nope"]),
                     lambda: editing.set_locator_order(t, 1, [])):
            with self.assertRaises(ValueError):
                call()

    def test_image_locator_copies_the_file_into_the_test(self):
        t, d = self.make()
        from core.system.imageio import imwrite
        src = Path(tempfile.mkdtemp()) / "btn.png"
        imwrite(src, np.full((40, 80, 3), 200, np.uint8))
        editing.set_locator(t, 3, "image", str(src), directory=d)
        tpl = t["steps"][2]["target"]["templates"]["crop100"]
        self.assertTrue((d / tpl["path"]).is_file())
        self.assertEqual(tpl["click"], [40, 20])

    def test_show_locators_reports_effective_order_and_stored_location(self):
        t, _ = self.make()
        editing.set_locator_order(t, 1, ["xpath", "ocr", "coordinates"])
        info = editing.show_locators(t, 1)
        self.assertEqual((info["order"], info["stored_location"], info["images"]), (["xpath", "ocr", "coordinates"], [10, 20], ["crop100"]))

    def test_set_data_copies_file_and_makes_columns_available_to_validation(self):
        t, d = self.make()
        src = Path(tempfile.mkdtemp()) / "users.csv"
        src.write_text("user,password\nann,x\n", encoding="utf-8")
        cfg = editing.set_data(t, d, file=src, secret_columns=["password"])
        self.assertEqual((cfg["file"], cfg["columns"]), ("data/users.csv", ["user", "password"]))
        self.assertTrue((d / "data" / "users.csv").is_file())
        self.assertEqual([i for i in editing.validate(t) if i["level"] == "error"], [])
        with self.assertRaises(ValueError):
            editing.set_data(t, d, file=src, secret_columns=["nope"])

    def test_wrap_in_loop_and_if_else_then_run(self):
        t, d = self.make()
        t["steps"][1]["params"] = {"text": "typed"}
        editing.wrap_in_loop(t, 2, 2, times=2)
        self.assertEqual([s["type"] for s in t["steps"]], ["click", "loop_start", "type", "loop_end", "click"])
        self.assertEqual([s["id"] for s in t["steps"]], [1, 2, 3, 4, 5])
        editing.wrap_in_if(t, 3, 3, {"type": "variable", "name": "x", "op": "empty"})
        self.assertEqual([s["type"] for s in t["steps"]][1:6], ["loop_start", "if_start", "type", "if_end", "loop_end"])
        with self.assertRaises(ValueError):
            editing.wrap_in_loop(t, 5, 1, times=2)
        with self.assertRaises(ValueError):
            editing.wrap_in_loop(t, 1, 2, times=0)


if __name__ == "__main__":
    unittest.main()
