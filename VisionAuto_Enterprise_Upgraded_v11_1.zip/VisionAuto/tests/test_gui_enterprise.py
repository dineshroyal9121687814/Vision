"""The enterprise shell and its new pages under real (offscreen) Qt."""
import os
import unittest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
try:
    from PySide6.QtWidgets import QApplication
    REAL_QT = True
except Exception:                                   # pragma: no cover
    REAL_QT = False

if REAL_QT:
    from tests import qt_noblock
    qt_noblock.install()


@unittest.skipUnless(REAL_QT, "PySide6 not available")
class ShellTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])

    def setUp(self):
        from app.gui.main_window import MODULES, MainWindow
        self.MODULES = MODULES
        self.w = MainWindow()

    def tearDown(self):
        self.w.close()

    def test_every_module_is_reachable_and_refreshes(self):
        for _, items in self.MODULES:
            for key, _, _ in items:
                self.w.go(key)
                self.assertIs(self.w.stack.currentWidget(), self.w.pages[key], key)
        self.assertEqual(len(self.w.pages), sum(len(i) for _, i in self.MODULES))

    def test_section_headers_are_not_selectable(self):
        self.w.nav.setCurrentRow(0)                        # a header row
        self.assertIsNot(self.w.stack.currentWidget(), None)
        head = self.w.nav.item(0)
        self.assertFalse(head.flags() & self.w.nav.item(1).flags().__class__.ItemIsSelectable)

    def test_search_jumps_and_unknown_search_warns(self):
        self.w.search.setText("object")
        self.w._search_go()
        self.assertIs(self.w.stack.currentWidget(), self.w.objects)
        seen = []
        from app.gui import design
        design.bus.notify.connect(lambda lv, t: seen.append((lv, t)))
        self.w.search.setText("zzzz")
        self.w._search_go()
        self.assertTrue(seen and seen[-1][0] == "warn")

    def test_theme_toggle_changes_palette_and_persists_nothing_unexpected(self):
        from app.gui import design
        self.w.apply_theme("light")
        self.assertEqual(design._current["theme"], "light")
        self.w.apply_theme("dark")
        self.assertEqual(design._current["theme"], "dark")

    def test_activity_log_masks_secrets(self):
        from app.gui import design
        design.bus.log.emit("calling api with password=hunter2secret")
        self.assertNotIn("hunter2secret", self.w.console.toPlainText())

    def test_dashboard_shows_real_counts_only(self):
        from core import analytics
        self.w.go("dashboard")
        self.w.dashboard.refresh()
        snap = analytics.snapshot()
        self.assertEqual(sum(v for _, v, _ in self.w.dashboard.donut.parts), snap["tests"])

    def test_execution_page_needs_a_ticked_test(self):
        ex = self.w.execution
        ex.refresh()
        ex._tick(False)
        ex.start(True)                                      # no test ticked -> information box (non-blocking), nothing runs
        self.assertIsNone(ex.worker)
        self.assertTrue(ex.run_btn.isEnabled())

    def test_data_page_loads_csv_validates_and_never_overwrites_source(self):
        import tempfile
        from pathlib import Path
        d = self.w.data
        with tempfile.TemporaryDirectory() as t:
            p = Path(t) / "x.csv"
            p.write_text("a,b\n1,x\n2,\n", encoding="utf-8")
            d._loaded(__import__("core.datasource", fromlist=["x"]).load_file(str(p)))
            d.path = str(p)
            d.req.setText("b")
            d.validate()
            texts = [d.report.item(i).text() for i in range(d.report.count())]
            self.assertTrue(any("row 2" in x and "required" in x for x in texts), texts)
            self.assertEqual(d.table.rowCount(), 2)

    def test_ai_page_generates_validated_steps_without_a_model(self):
        a = self.w.ai
        a.nl.setPlainText("Open notepad\nType 'hi' into Editor\nfly to the moon")
        a.generate_steps()
        self.assertIn("fly to the moon", a.out.toPlainText())
        self.assertTrue(a.save_btn.isEnabled())

    def test_plugins_page_lists_components(self):
        self.w.go("plugins")
        self.assertGreater(self.w.plugins.comps.rowCount(), 5)


if __name__ == "__main__":
    unittest.main()
