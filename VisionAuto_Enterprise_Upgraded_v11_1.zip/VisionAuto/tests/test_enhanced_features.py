"""Regression and security tests for VisionAuto platform enhancements."""
import os
import tempfile
import unittest
from pathlib import Path
import cv2
import numpy as np

from core import testfile
from core.system import imageio, winenv
from core.vision.locator import Locator
from core.playback.backend import DryRunBackend, InputBackend
from core.playback.player import Player
from core.playback.resolver import Resolver
from core.playback.validators import Validator
from core.plugins.plugin_manager import PluginManager
from core.plugins.web_plugin import WebPlugin
from core.importers.ranorex.repo_parser import parse_rxrep
from core.importers.ranorex.cs_to_steps import _lit
from core.importers.ranorex.script_safety import validate_script_source
from core.importers.uft.object_repository import parse_xml_repository
from core.review import validation_options


class SecurityAndReliabilityTests(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())

    def tearDown(self):
        import shutil
        shutil.rmtree(self.tmp, ignore_errors=True)

    def test_write_json_atomic_creates_valid_file_and_cleans_tmp(self):
        target = self.tmp / "test.json"
        data = {"hello": "world", "steps": [1, 2, 3]}
        testfile.write_json_atomic(target, data)
        self.assertTrue(target.exists())
        self.assertEqual(testfile.json.loads(target.read_text(encoding="utf-8")), data)
        self.assertFalse(target.with_suffix(".json.tmp").exists())

    def test_imageio_imwrite_is_atomic(self):
        img_path = self.tmp / "sample.png"
        img = np.zeros((50, 50, 3), dtype=np.uint8)
        self.assertTrue(imageio.imwrite(img_path, img))
        self.assertTrue(img_path.exists())
        read_img = imageio.imread(img_path)
        self.assertIsNotNone(read_img)
        self.assertEqual(read_img.shape, (50, 50, 3))

    def test_locator_handles_grayscale_templates_and_screen(self):
        locator = Locator()
        screen_gray = np.zeros((100, 100), dtype=np.uint8)
        cv2.circle(screen_gray, (50, 50), 10, 255, -1)
        tpl_gray = screen_gray[40:60, 40:60].copy()
        res = locator.find_by_template(screen_gray, tpl_gray, scales=(1.0,))
        self.assertTrue(res.found)
        self.assertEqual(res.x, 50)
        self.assertEqual(res.y, 50)

    def test_launch_app_security_restricts_dangerous_commands(self):
        player = Player({"name": "test", "steps": []}, backend=DryRunBackend(), dry_run=False, base_dir=self.tmp)
        # Attempting to invoke cmd.exe or powershell directly should be rejected
        dangerous_step = {"id": 1, "type": "launch_app", "params": {"exe": "cmd.exe /c calc"}}
        res = player._run_step(dangerous_step)
        self.assertEqual(res["status"], "failed")
        self.assertIn("restricted", res.get("error", "").lower())

        command_chain_step = {"id": 2, "type": "launch_app", "params": {"exe": "calc.exe; echo pwned"}}
        res2 = player._run_step(command_chain_step)
        self.assertEqual(res2["status"], "failed")
        self.assertIn("restricted", res2.get("error", "").lower())

    def test_repo_parser_rejects_xxe_entities(self):
        xxe_xml = self.tmp / "malicious.rxrep"
        xxe_xml.write_text('<?xml version="1.0"?><!DOCTYPE root [<!ENTITY test SYSTEM "file:///etc/passwd">]><root>&test;</root>', encoding="utf-8")
        with self.assertRaises(ValueError):
            parse_rxrep(xxe_xml)

    def test_uft_object_repository_rejects_xxe_entities(self):
        xxe_xml = self.tmp / "malicious_uft.xml"
        xxe_xml.write_text('<?xml version="1.0"?><!DOCTYPE root [<!ENTITY test SYSTEM "file:///etc/passwd">]><root>&test;</root>', encoding="utf-8")
        with self.assertRaises(ValueError):
            parse_xml_repository(xxe_xml)

    def test_cs_to_steps_handles_verbatim_string_escapes(self):
        self.assertEqual(_lit('@"hello ""world"""'), 'hello "world"')
        self.assertEqual(_lit('"normal \\"quote\\""'), 'normal "quote"')

    def test_script_safety_allows_aug_assign(self):
        script = """def run(ctx):
    x = 1
    x += 5
    ctx.delay(x)
"""
        errors = validate_script_source(script)
        self.assertEqual(errors, [])

    def test_web_plugin_detection(self):
        pm = PluginManager()
        chrome_win = {"title": "Google - Google Chrome", "process": "chrome.exe"}
        plugin = pm.get_plugin_for(chrome_win)
        self.assertIsInstance(plugin, WebPlugin)
        self.assertEqual(plugin.name, "web")

    def test_enhanced_validators(self):
        backend = DryRunBackend()
        resolver = Resolver(self.tmp, {"use_native": True})
        validator = Validator(resolver, {}, dry_run=False)

        # window_exists
        v_win = {"type": "window_exists", "expected": "NonExistentWindowXYZ123", "timeout_s": 0.05}
        res = validator.evaluate(v_win, {})
        self.assertEqual(res["status"], "failed")
        self.assertFalse(res["actual"])

        # element_enabled / element_disabled on unresolvable target
        v_en = {"type": "element_enabled", "target": {"name": "TestButton"}, "timeout_s": 0.05}
        res_en = validator.evaluate(v_en, {})
        self.assertEqual(res_en["status"], "failed")

    def test_review_validation_options_empty_description_safety(self):
        step = {"type": "click", "target": {"name": ""}}
        opts = validation_options(step)
        self.assertIsInstance(opts, list)


if __name__ == "__main__":
    unittest.main()
