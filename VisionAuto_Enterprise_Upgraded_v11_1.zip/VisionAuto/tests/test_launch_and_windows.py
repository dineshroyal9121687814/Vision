"""Start-menu launch without typing, location-first locating, and cross-window drag preparation."""
import unittest
from unittest import mock

import numpy as np

from core.playback.player import Player
from core.playback.resolver import ElementNotFound, Resolver
from core.recorder.launch_detect import compact_launches
from core.settings import validate as validate_settings

START = {"x": 320, "y": 1190, "name": "Start", "role": "Button", "automation_id": "StartButton"}


def st(i, t, proc="x.exe", title="", **kw):
    return {"id": i, "type": t, "t_ms": i * 100, "window": {"title": title, "process": proc}, "validations": [], **kw}


class StartMenuWithoutTyping(unittest.TestCase):
    """'Click Start, choose the app' (no typing) must become open_app, not 'click Start + click a pixel'."""

    def test_start_click_then_tile_click_becomes_open_app(self):
        steps = [st(1, "click", "explorer.exe", "", target=START, params={}),
                 st(2, "click", "StartMenuExperienceHost.exe", "Start", target={"name": "Calculator", "role": "ListItem"}, params={}),
                 st(3, "double_click", "ApplicationFrameHost.exe", "Calculator", target={"name": "Nine"}, params={})]
        out, changes = compact_launches(steps)
        self.assertEqual([s["type"] for s in out], ["open_app", "double_click"])
        self.assertEqual(out[0]["params"]["name"], "Calculator")
        self.assertEqual(changes[0]["replaced_steps"], [1, 2])

    def test_name_comes_from_the_tile_when_no_window_title_follows(self):
        steps = [st(1, "click", "explorer.exe", "", target=START, params={}),
                 st(2, "click", "StartMenuExperienceHost.exe", "Start", target={"name": "Notepad, Pinned", "role": "Button"}, params={})]
        out, _ = compact_launches(steps)
        self.assertEqual(out[0]["params"]["name"], "Notepad")

    def test_tile_click_inside_the_start_shell_window_is_recognised(self):
        steps = [st(1, "click", "explorer.exe", "", target=START, params={}),
                 st(2, "click", "explorer.exe", "Start", target={"name": "Paint", "role": "ListItem"}, params={}),
                 st(3, "click", "mspaint.exe", "Untitled - Paint", target={"name": "Brushes"}, params={})]
        out, _ = compact_launches(steps)
        self.assertEqual(out[0]["type"], "open_app")
        self.assertEqual(out[0]["params"]["window_title"], "Untitled - Paint")

    def test_a_lone_start_click_with_nothing_chosen_is_left_alone(self):
        steps = [st(1, "click", "explorer.exe", "", target=START, params={}),
                 st(2, "click", "app.exe", "App", target={"name": "OK"}, params={})]
        out, changes = compact_launches(steps)
        self.assertEqual(changes, [])
        self.assertEqual(len(out), 2)

    def test_typed_search_still_works(self):
        steps = [st(1, "click", "explorer.exe", "", target=START, params={}),
                 st(2, "type", "SearchHost.exe", "Search", params={"text": "cal"}),
                 st(3, "click", "SearchHost.exe", "Search", target={"name": "CoreInput", "role": "Pane"}, params={}),
                 st(4, "click", "ApplicationFrameHost.exe", "Calculator", target={"name": "Nine"}, params={})]
        out, _ = compact_launches(steps)
        self.assertEqual([s["type"] for s in out], ["open_app", "click"])

    def test_old_recording_is_repaired_when_it_is_played(self):
        test = {"name": "t", "applications": [], "variables": {}, "steps": [
            st(1, "click", "explorer.exe", "", target=START, params={}),
            st(2, "click", "StartMenuExperienceHost.exe", "Start", target={"name": "Calculator", "role": "ListItem"}, params={}),
            st(3, "double_click", "ApplicationFrameHost.exe", "Calculator", target={"name": "Nine"}, params={})]}
        p = Player(test, dry_run=True)
        self.assertEqual(p.test["steps"][0]["type"], "open_app")
        self.assertEqual(test["steps"][0]["type"], "click")          # the caller's dict is not modified


class LocationFirst(unittest.TestCase):
    def resolver(self):
        return Resolver(".", validate_settings({"engine_profile": "strict"}), grab=lambda: (np.zeros((100, 100, 3), np.uint8), (0, 0)))

    TARGET = {"name": "Nine", "role": "Button", "automation_id": "num9Button", "x": 120, "y": 340,
              "rect": [100, 320, 160, 360], "rel": [0.5, 0.5]}

    def test_point_is_the_first_tier(self):
        self.assertEqual(Resolver.DEFAULT_ORDER[:2], ("excel", "point"))

    def test_element_at_the_recorded_place_is_used_without_a_tree_search(self):
        r = self.resolver()
        el = {"name": "Nine", "role": "Button", "automation_id": "num9Button", "rect": [100, 320, 160, 360]}
        with mock.patch("core.system.winenv.element_at", return_value=el):
            res = r.resolve_once(self.TARGET, {}, 1)
        self.assertEqual((res.method, res.x, res.y), ("point", 130, 340))

    def test_a_different_element_there_falls_through(self):
        r = self.resolver()
        el = {"name": "Eight", "role": "Button", "automation_id": "num8Button", "rect": [100, 320, 160, 360]}
        with mock.patch("core.system.winenv.element_at", return_value=el):
            self.assertIsNone(r._t_point(self.TARGET, {}, {"attempt": 1}))

    def test_nothing_at_the_place_falls_through(self):
        with mock.patch("core.system.winenv.element_at", return_value={}):
            self.assertIsNone(self.resolver()._t_point(self.TARGET, {}, {"attempt": 1}))

    def test_element_moved_with_its_window_is_followed_by_rect(self):
        r = self.resolver()
        el = {"name": "Nine", "role": "Button", "automation_id": "num9Button", "rect": [300, 520, 360, 560]}
        with mock.patch("core.system.winenv.element_at", return_value=el):
            res = r._t_point(self.TARGET, {}, {"attempt": 1})
        self.assertEqual((res.x, res.y), (330, 540))


class ExcelCellLocator(unittest.TestCase):
    """'Could not find G14': UIA is switched off for Excel and empty cells look identical, so ask Excel itself."""
    T = {"name": "G14", "role": "DataItem", "automation_id": "G14", "class_name": "XLSpreadsheetCell",
         "rect": [514, 630, 594, 654], "rel": [0.5, 0.5], "x": 554, "y": 642}
    W = {"title": "Book1 - Excel", "process": "EXCEL.EXE"}

    def resolver(self):
        return Resolver(".", validate_settings({"engine_profile": "strict"}), grab=lambda: (np.zeros((100, 100, 3), np.uint8), (0, 0)))

    def test_cell_position_comes_from_excel(self):
        from core.system import excel_com
        with mock.patch.object(excel_com, "cell_screen_rect", return_value=[514, 700, 594, 724]):
            res = self.resolver().resolve_once(self.T, self.W, 1)
        self.assertEqual((res.method, res.x, res.y), ("excel", 554, 712))      # follows the cell if the sheet scrolled

    def test_it_is_the_first_tier_and_beats_a_slow_uia(self):
        self.assertEqual(Resolver.DEFAULT_ORDER[0], "excel")

    def test_not_used_outside_excel_or_for_other_controls(self):
        from core.system import excel_com
        r = self.resolver()
        with mock.patch.object(excel_com, "cell_screen_rect", side_effect=AssertionError("must not be asked")):
            self.assertIsNone(r._t_excel(self.T, {"title": "Notepad", "process": "notepad.exe"}, {"attempt": 1}))
            self.assertIsNone(r._t_excel({**self.T, "role": "Button", "class_name": "NetUIRibbonButton"}, self.W, {"attempt": 1}))

    def test_excel_unable_to_answer_falls_through(self):
        from core.system import excel_com
        with mock.patch.object(excel_com, "cell_screen_rect", return_value=None):
            self.assertIsNone(self.resolver()._t_excel(self.T, self.W, {"attempt": 1}))


class CrossWindowDrag(unittest.TestCase):
    SRC = {"title": "Book1 - Excel", "process": "EXCEL.EXE", "rect": [0, 0, 800, 600]}
    DST = {"title": "Notes - Notepad", "process": "notepad.exe", "rect": [820, 0, 1400, 600]}

    def step(self):
        return {"id": 9, "type": "drag_drop", "window": self.SRC, "to_window": self.DST,
                "target": {"x": 100, "y": 100}, "to": {"x": 1000, "y": 200}}

    def player(self):
        p = Player.__new__(Player)
        p.dry_run = False
        p.opts = {"restore_window_geometry": True, "geometry_tolerance_px": 8, "strict_targeting": False}
        p._geometry_log = []
        return p

    def patch(self, top_by_point, rects):
        from core.system import winenv
        handles = {"Book1 - Excel": 11, "Notepad": 22}
        raised, calls = [], []
        patches = [
            mock.patch.object(winenv, "find_windows", side_effect=lambda t: [handles["Book1 - Excel"]] if "Excel" in t else [handles["Notepad"]]),
            mock.patch.object(winenv, "window_info", side_effect=lambda h: {"process": "EXCEL.EXE" if h == 11 else "notepad.exe"}),
            mock.patch.object(winenv, "window_rect", side_effect=lambda h: rects[h]),
            mock.patch.object(winenv, "window_state", return_value="normal"),
            mock.patch.object(winenv, "virtual_screen", return_value=[0, 0, 1920, 1080]),
            mock.patch.object(winenv, "set_window_rect", side_effect=lambda h, r: calls.append((h, list(r))) or True),
            mock.patch.object(winenv, "window_at", side_effect=lambda x, y: {"hwnd": top_by_point(x, y, raised)}),
            mock.patch.object(winenv, "raise_window", side_effect=lambda h: raised.append(h) or True),
            mock.patch.object(winenv, "activate_window", return_value=True),
        ]
        return patches, raised, calls

    def run_arrange(self, top_by_point, rects):
        patches, raised, calls = self.patch(top_by_point, rects)
        for p in patches:
            p.start()
        self.addCleanup(lambda: [p.stop() for p in patches])
        info = self.player()._arrange_windows_for_drag(self.step(), self.DST)
        return info, raised, calls

    def test_windows_already_in_place_nothing_is_moved(self):
        info, raised, calls = self.run_arrange(lambda x, y, r: 11 if x < 810 else 22,
                                               {11: [0, 0, 800, 600], 22: [820, 0, 1400, 600]})
        self.assertEqual((raised, calls), ([], []))
        self.assertTrue(info["source_restored"] and info["destination_restored"])
        self.assertNotIn("warning", info)

    def test_small_window_is_dragged_back_to_the_recorded_place(self):
        info, raised, calls = self.run_arrange(lambda x, y, r: 11 if x < 810 else 22,
                                               {11: [0, 0, 800, 600], 22: [100, 100, 400, 400]})
        self.assertEqual(calls[0][0], 22)                    # the destination window was moved ...
        self.assertEqual(calls[0][1], [820, 0, 1400, 600])  # ... to where it was recorded

    def test_covered_destination_is_raised(self):
        info, raised, _ = self.run_arrange(lambda x, y, r: (22 if 22 in r else 11) if x > 810 else 11,
                                           {11: [0, 0, 800, 600], 22: [820, 0, 1400, 600]})
        self.assertIn(22, raised)
        self.assertNotIn("warning", info)

    def test_a_window_that_stays_covered_is_reported(self):
        info, _, _ = self.run_arrange(lambda x, y, r: 99 if x > 810 else 11,
                                      {11: [0, 0, 800, 600], 22: [820, 0, 1400, 600]})
        self.assertIn("destination", info["warning"])

    def test_strict_mode_refuses_to_drag_when_a_window_stays_covered(self):
        from core.automation.errors import WrongTarget
        patches, _, _ = self.patch(lambda x, y, r: 99 if x > 810 else 11, {11: [0, 0, 800, 600], 22: [820, 0, 1400, 600]})
        for pt in patches:
            pt.start()
            self.addCleanup(pt.stop)
        p = self.player()
        p.opts["strict_targeting"] = True
        with self.assertRaises(WrongTarget):
            p._arrange_windows_for_drag(self.step(), self.DST)

    def test_missing_destination_window_stops_before_dragging(self):
        from core.system import winenv
        p = self.player()
        with mock.patch.object(winenv, "find_windows", side_effect=lambda t: [11] if "Excel" in t else []), \
                mock.patch.object(winenv, "window_info", return_value={"process": "EXCEL.EXE"}), \
                mock.patch.object(winenv, "window_rect", return_value=[0, 0, 800, 600]), \
                mock.patch.object(winenv, "window_state", return_value="normal"), \
                mock.patch.object(winenv, "virtual_screen", return_value=[0, 0, 1920, 1080]):
            with self.assertRaises(ElementNotFound):
                p._arrange_windows_for_drag(self.step(), self.DST)


if __name__ == "__main__":
    unittest.main()
