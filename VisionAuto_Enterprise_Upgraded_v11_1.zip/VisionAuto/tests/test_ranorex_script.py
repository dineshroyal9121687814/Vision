import unittest

from tests import helpers  # noqa: F401
from core.importers.ranorex.cs_translator import Translator, _py_expr
from core.importers.ranorex.script_safety import validate_script_source

CS = '''
namespace Demo {
public partial class Rec : ITestModule {
  void ITestModule.Run()
  {
    string name = "Bob";
    int total = 0;
    for (int i = 0; i < 3; i++) {
        total += i;
        repo.App.Item.Click();
        if (total > 2 && name != null) {
            Report.Log(ReportLevel.Info, "Cat", "n=" + total);
            break;
        }
    }
    while (total < 5)
    {
        total++;
    }
    var msg = $"Hi {name}!";
    Validate.AreEqual(total, 5);
    bool there = repo.App.Item.Exists();
    foreach (var s in new string[] { "a", "b" })
    {
        repo.App.Edit.PressKeys(s);
    }
  }
}}
'''


class RanorexScriptTests(unittest.TestCase):
    def test_expression_translation_keeps_string_literals_intact(self):
        self.assertEqual(_py_expr('$"Hi {name}!"'), 'rx_format("Hi {0}!", name)')
        self.assertEqual(_py_expr('"a" + n + 1'), 'rx_concat("a", n, 1)')
        self.assertEqual(_py_expr('!done && x.Length > 3'), 'not done  and  len(x) > 3')

    def test_loops_assignments_and_exists_translate_and_pass_safety(self):
        tr = Translator()
        py = tr.translate(CS, "Rec")
        self.assertEqual(tr.todos, [])
        self.assertIn("for i in rx_range(0, 3, 1):", py)
        self.assertIn("for _w in rx_range(0, 1000):", py)
        self.assertIn("there = ctx.exists('App.Item')", py)
        self.assertEqual(validate_script_source(py), [])

    def test_unsafe_python_is_still_rejected(self):
        bad = "def run(ctx):\n    x = open('f')\n    ctx.__class__\n"
        self.assertTrue(validate_script_source(bad))
        self.assertTrue(validate_script_source("def run(ctx):\n    while True:\n        pass\n"))


if __name__ == "__main__":
    unittest.main()
