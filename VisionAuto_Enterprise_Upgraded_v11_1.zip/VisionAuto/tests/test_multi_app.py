"""
Unit and integration tests for Multi-Application Management and Execution.
"""
from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import MagicMock, patch

from core import applications, paths, testfile
from core.playback.app_context import AppContextManager, ApplicationInstance
from core.playback.player import Player
from core.reports.report import build_html


class TestApplicationsRegistry(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.reg_path = Path(self.temp_dir.name) / "applications.json"

    def tearDown(self):
        self.temp_dir.cleanup()

    def test_default_app_def(self):
        app = applications.default_app_def("Notepad App", "desktop", "notepad")
        self.assertTrue(app["id"].startswith("app_"))
        self.assertEqual(app["name"], "Notepad App")
        self.assertEqual(app["alias"], "notepad")
        self.assertEqual(app["type"], "desktop")
        self.assertEqual(app["adapter"], "desktop")
        self.assertTrue(app["close_on_exit"])

    def test_validate_app_def_valid(self):
        desktop_app = {
            "name": "Calculator",
            "alias": "calc",
            "type": "desktop",
            "exe_path": "calc.exe",
            "timeout_s": 10.0,
        }
        self.assertEqual(applications.validate_app_def(desktop_app), [])

        web_app = {
            "name": "CRM Web",
            "alias": "crm",
            "type": "web",
            "browser": "chrome",
            "url": "https://crm.local/login",
        }
        self.assertEqual(applications.validate_app_def(web_app), [])

        running_app = {
            "name": "Running Excel",
            "alias": "excel",
            "type": "running",
            "window_title": "Excel",
        }
        self.assertEqual(applications.validate_app_def(running_app), [])

    def test_validate_app_def_invalid(self):
        # Missing name
        errs = applications.validate_app_def({"alias": "test", "type": "desktop", "exe_path": "app.exe"})
        self.assertTrue(any("name" in e for e in errs))

        # Missing alias
        errs = applications.validate_app_def({"name": "Test", "type": "desktop", "exe_path": "app.exe"})
        self.assertTrue(any("alias" in e for e in errs))

        # Invalid alias characters
        errs = applications.validate_app_def({"name": "Test", "alias": "my app!", "type": "desktop", "exe_path": "app.exe"})
        self.assertTrue(any("alias" in e for e in errs))

        # Desktop missing exe
        errs = applications.validate_app_def({"name": "Test", "alias": "test", "type": "desktop"})
        self.assertTrue(any("exe_path" in e for e in errs))

        # Dangerous command injection binary
        errs = applications.validate_app_def({"name": "Test", "alias": "test", "type": "desktop", "exe_path": "powershell.exe"})
        self.assertTrue(any("restricted" in e.lower() for e in errs))

        # Negative timeout
        errs = applications.validate_app_def({
            "name": "Test", "alias": "test", "type": "desktop", "exe_path": "notepad.exe", "timeout_s": -5
        })
        self.assertTrue(any("timeout_s" in e for e in errs))

    def test_register_and_get_app(self):
        app = {
            "name": "Test Calc",
            "alias": "calc",
            "type": "desktop",
            "exe_path": "calc.exe",
        }
        reg = applications.register_app(app, path=self.reg_path)
        self.assertIn("id", reg)

        fetched_by_id = applications.get_app(reg["id"], path=self.reg_path)
        self.assertIsNotNone(fetched_by_id)
        self.assertEqual(fetched_by_id["name"], "Test Calc")

        fetched_by_alias = applications.get_app("calc", path=self.reg_path)
        self.assertIsNotNone(fetched_by_alias)
        self.assertEqual(fetched_by_alias["id"], reg["id"])

        all_apps = applications.list_apps(path=self.reg_path)
        self.assertEqual(len(all_apps), 1)
        self.assertEqual(all_apps[0]["alias"], "calc")

    def test_duplicate_alias_rejected(self):
        app1 = {"name": "App One", "alias": "my_app", "type": "desktop", "exe_path": "app1.exe"}
        app2 = {"name": "App Two", "alias": "my_app", "type": "desktop", "exe_path": "app2.exe"}
        applications.register_app(app1, path=self.reg_path)
        with self.assertRaises(ValueError) as ctx:
            applications.register_app(app2, path=self.reg_path)
        self.assertIn("already in use", str(ctx.exception))

    def test_remove_app(self):
        app = {"name": "App One", "alias": "app1", "type": "desktop", "exe_path": "app1.exe"}
        reg = applications.register_app(app, path=self.reg_path)
        self.assertTrue(applications.remove_app(reg["id"], path=self.reg_path))
        self.assertIsNone(applications.get_app(reg["id"], path=self.reg_path))
        self.assertFalse(applications.remove_app("non_existent_id", path=self.reg_path))

    def test_discover_running_apps(self):
        apps = applications.discover_running_apps()
        self.assertIsInstance(apps, list)
        for a in apps:
            self.assertIn("title", a)
            self.assertIn("process", a)
            self.assertIn("pid", a)
            self.assertIn("hwnd", a)


class TestAppContextManager(unittest.TestCase):
    def test_variable_substitution(self):
        ctx = AppContextManager(variables={"host": "api.test.org", "port": 8080, "user": "alice"})

        # String substitution
        subbed = ctx.substitute_variables("http://${host}:${port}/users/${user}")
        self.assertEqual(subbed, "http://api.test.org:8080/users/alice")

        # Missing variable preserved
        self.assertEqual(ctx.substitute_variables("Hello ${unknown}"), "Hello ${unknown}")

        # List substitution
        lst = ctx.substitute_variables(["--user", "${user}", "--host", "${host}"])
        self.assertEqual(lst, ["--user", "alice", "--host", "api.test.org"])

        # Dict substitution
        dct = ctx.substitute_variables({"url": "https://${host}", "name": "${user}"})
        self.assertEqual(dct, {"url": "https://api.test.org", "name": "alice"})

    def test_variable_get_and_set(self):
        ctx = AppContextManager()
        ctx.set_variable("token", "xyz-12345")
        self.assertEqual(ctx.get_variable("token"), "xyz-12345")
        self.assertIsNone(ctx.get_variable("missing"))
        self.assertEqual(ctx.get_variable("missing", "default_val"), "default_val")
        with self.assertRaises(ValueError):
            ctx.set_variable("", "val")

    def test_dry_run_ensure_and_switch(self):
        app1 = {"alias": "app1", "name": "App 1", "type": "desktop", "exe_path": "app1.exe"}
        app2 = {"alias": "app2", "name": "App 2", "type": "web", "browser": "chrome", "url": "https://site.org"}
        ctx = AppContextManager([app1, app2], dry_run=True)

        inst1 = ctx.switch_to("app1")
        self.assertEqual(inst1.alias, "app1")
        self.assertEqual(inst1.status, "running")
        self.assertEqual(inst1.switch_count, 1)
        self.assertEqual(ctx.active_alias, "app1")

        inst2 = ctx.switch_to("app2")
        self.assertEqual(inst2.alias, "app2")
        self.assertEqual(inst2.switch_count, 1)
        self.assertEqual(ctx.active_alias, "app2")

        # Switch back to app1
        ctx.switch_to("app1")
        self.assertEqual(inst1.switch_count, 2)
        self.assertEqual(len(ctx.switch_history), 3)

        telemetry = ctx.get_telemetry()
        self.assertEqual(telemetry["total_switches"], 3)
        self.assertEqual(len(telemetry["applications"]), 2)

    def test_cleanup_policy(self):
        ctx = AppContextManager(dry_run=False)

        # Mock launched instance
        mock_proc1 = MagicMock()
        inst1 = ApplicationInstance("launched_app", {"name": "Launched App", "close_on_exit": True})
        inst1.process = mock_proc1
        inst1.pid = 1001
        inst1.launched_by_test = True
        inst1.status = "running"
        ctx.instances["launched_app"] = inst1

        # Mock attached instance (should NOT be closed under close_test_launched)
        mock_proc2 = MagicMock()
        inst2 = ApplicationInstance("attached_app", {"name": "Attached App", "close_on_exit": True})
        inst2.process = mock_proc2
        inst2.pid = 1002
        inst2.launched_by_test = False
        inst2.status = "attached"
        ctx.instances["attached_app"] = inst2

        results = ctx.cleanup(policy="close_test_launched")
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0]["alias"], "launched_app")
        mock_proc1.terminate.assert_called_once()
        mock_proc2.terminate.assert_not_called()
        self.assertEqual(inst1.status, "stopped")
        self.assertEqual(inst2.status, "attached")


class TestMultiAppTestfileAndPlayer(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.test_dir = Path(self.temp_dir.name) / "tests" / "multi_test"
        self.test_dir.mkdir(parents=True, exist_ok=True)

    def tearDown(self):
        self.temp_dir.cleanup()

    def test_legacy_single_app_backward_compatibility(self):
        legacy_data = {
            "schema": "visionauto.test/2",
            "name": "legacy_test",
            "title": "Legacy Test",
            "app": {"process": "notepad.exe", "title": "Notepad"},
            "steps": [{"id": 1, "type": "wait", "params": {"ms": 100}}],
        }
        testfile.write_json_atomic(self.test_dir / "test.json", legacy_data)

        loaded, _ = testfile.load_test(self.test_dir)
        self.assertIn("applications", loaded)
        self.assertEqual(len(loaded["applications"]), 1)
        self.assertEqual(loaded["applications"][0]["alias"], "default")
        self.assertEqual(loaded["applications"][0]["process_name"], "notepad.exe")
        self.assertIn("variables", loaded)
        self.assertEqual(loaded["variables"], {})

    def test_player_multi_app_execution_and_switching(self):
        test_data = {
            "schema": "visionauto.test/2",
            "name": "multi_app_run",
            "title": "Multi App Run",
            "applications": [
                {"alias": "web", "name": "Chrome Browser", "type": "web", "browser": "chrome", "url": "https://example.com"},
                {"alias": "desktop", "name": "Desktop Client", "type": "desktop", "exe_path": "client.exe"},
                {"alias": "excel", "name": "Excel Reporting", "type": "desktop", "exe_path": "excel.exe"},
            ],
            "variables": {"search_term": "Ranorex"},
            "steps": [
                {"id": 1, "app": "web", "type": "wait", "description": "Open web app", "params": {"ms": 10}},
                {"id": 2, "app": "web", "type": "type", "description": "Type search term", "params": {"text": "Query: ${search_term}"}},
                {"id": 3, "app": "desktop", "type": "wait", "description": "Switch to desktop client", "params": {"ms": 10}},
                {"id": 4, "app": "excel", "type": "wait", "description": "Verify export in Excel", "params": {"ms": 10}},
                {"id": 5, "app": "web", "type": "wait", "description": "Return to web app", "params": {"ms": 10}},
            ],
        }
        testfile.write_json_atomic(self.test_dir / "test.json", test_data)

        player = Player(test_data, dry_run=True, base_dir=self.test_dir)
        res = player.run()

        self.assertIn("applications", res)
        telemetry = res["applications"]
        self.assertEqual(len(telemetry["applications"]), 3)
        self.assertEqual(telemetry["total_switches"], 4)

        # Check step results have recorded app
        steps = res["steps"]
        self.assertEqual(steps[0]["app"], "web")
        self.assertEqual(steps[1]["app"], "web")
        self.assertEqual(steps[2]["app"], "desktop")
        self.assertEqual(steps[3]["app"], "excel")
        self.assertEqual(steps[4]["app"], "web")

    def test_player_cross_app_variable_passing(self):
        test_data = {
            "schema": "visionauto.test/2",
            "name": "var_pass_test",
            "title": "Variable Passing Test",
            "applications": [
                {"alias": "app1", "name": "App One", "type": "desktop", "exe_path": "app1.exe"},
                {"alias": "app2", "name": "App Two", "type": "desktop", "exe_path": "app2.exe"},
            ],
            "variables": {},
            "steps": [
                {
                    "id": 1,
                    "app": "app1",
                    "type": "wait",
                    "description": "Read Customer ID from App 1",
                    "params": {"ms": 10},
                    "save_as": "customer_id",
                    "mock_value": "CUST-9876",
                },
                {
                    "id": 2,
                    "app": "app2",
                    "type": "type",
                    "description": "Enter Customer ID in App 2",
                    "params": {"text": "ID: ${customer_id}"},
                },
            ],
        }
        player = Player(test_data, dry_run=True, base_dir=self.test_dir)
        run_res = player.run()

        # Verify variable was saved
        self.assertEqual(player.app_context.get_variable("customer_id"), "CUST-9876")
        self.assertEqual(run_res["variables"]["customer_id"], "CUST-9876")
        self.assertIn("saved_as", run_res["steps"][0])
        self.assertEqual(run_res["steps"][0]["saved_as"]["customer_id"], "CUST-9876")


class TestMultiAppReporting(unittest.TestCase):
    def test_report_multi_app_html_rendering(self):
        run = {
            "schema": "visionauto.run/2",
            "test": "multi_test",
            "title": "Multi Application Workflow",
            "run_id": "20261028-120000",
            "kind": "native",
            "dry_run": False,
            "started_at": "2026-10-28T12:00:00",
            "finished_at": "2026-10-28T12:00:15",
            "status": "passed",
            "summary": {"total": 2, "passed": 2, "failed": 0, "skipped": 0, "duration_ms": 15000},
            "applications": {
                "applications": [
                    {"alias": "web", "type": "web", "mode": "launch", "status": "running", "pid": 4321, "switch_count": 2, "title": "CRM Portal"},
                    {"alias": "desktop", "type": "desktop", "mode": "attach", "status": "attached", "pid": 7890, "switch_count": 1, "title": "ERP System"},
                ],
                "active_application": "web",
                "total_switches": 2,
            },
            "variables": {"customer_id": "CUST-5544"},
            "steps": [
                {"id": 1, "app": "web", "type": "click", "description": "Search customer", "status": "passed", "duration_ms": 120},
                {"id": 2, "app": "desktop", "type": "type", "description": "Enter customer CUST-5544", "status": "passed", "duration_ms": 80},
            ],
        }
        html_out = build_html(run, Path("."))
        self.assertIn("Target Applications (2)", html_out)
        self.assertIn("CRM Portal", html_out)
        self.assertIn("ERP System", html_out)
        self.assertIn("Variables (1)", html_out)
        self.assertIn("customer_id", html_out)
        self.assertIn("CUST-5544", html_out)
        self.assertIn(">web</span>", html_out)
        self.assertIn(">desktop</span>", html_out)


if __name__ == "__main__":
    unittest.main()

