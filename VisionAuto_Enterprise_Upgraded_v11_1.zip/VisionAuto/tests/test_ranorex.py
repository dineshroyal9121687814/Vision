import json
import tempfile
import unittest
from pathlib import Path

from tests.helpers import use_temp_workspace

use_temp_workspace()

from core import paths, testfile  # noqa: E402
from core.importers.ranorex.cs_to_steps import convert  # noqa: E402
from core.importers.ranorex.importer import import_project  # noqa: E402
from core.importers.ranorex.keys import parse_key_sequence  # noqa: E402
from core.importers.ranorex.repo_parser import parse_rxrep  # noqa: E402
from core.importers.ranorex.runtime import run_script  # noqa: E402
from core.importers.ranorex.script_safety import validate_script_source  # noqa: E402
from core.playback.backend import DryRunBackend  # noqa: E402
from core.playback.player import Player  # noqa: E402

S = Path(__file__).parent / "ranorex_samples"


class KeysTests(unittest.TestCase):
    def test_ctrl_c(self):
        self.assertEqual(parse_key_sequence("{LControlKey down}c{LControlKey up}"),
                         [{"type": "hotkey", "params": {"keys": "ctrl+c"}}])

    def test_text_and_special_keys(self):
        out = parse_key_sequence("Hello{Tab}World{Return}")
        self.assertEqual([o["type"] for o in out], ["type", "key", "type", "key"])
        self.assertEqual(out[1]["params"]["key"], "tab")
        self.assertEqual(out[3]["params"]["key"], "enter")

    def test_shift_tab_and_shift_letters(self):
        self.assertEqual(parse_key_sequence("{LShiftKey down}{Tab}{LShiftKey up}")[0]["params"]["keys"], "shift+tab")
        self.assertEqual(parse_key_sequence("{LShiftKey down}a{LShiftKey up}")[0]["params"]["text"], "A")


class ConvertTests(unittest.TestCase):
    def setUp(self):
        self.repo = parse_rxrep(S / "Sample.rxrep")

    def test_straight_line_recording_becomes_native_steps(self):
        conv = convert((S / "Recording2.cs").read_text(), self.repo)
        self.assertTrue(conv.ok)
        kinds = [s["type"] for s in conv.steps]
        self.assertEqual(kinds[:3], ["launch_app", "wait", "click"])
        self.assertIn("hover", kinds)
        self.assertIn("hotkey", kinds)
        self.assertEqual(kinds.count("validate"), 3)
        v = [s for s in conv.steps if s["type"] == "validate"]
        self.assertEqual([x["check"]["type"] for x in v], ["element_exists", "element_not_exists", "text_equals"])
        click = next(s for s in conv.steps if s["type"] == "click")
        self.assertEqual(click["target"]["role"], "Button")
        self.assertEqual(click["window"]["title"], "Calculator")
        self.assertGreater(click["source"]["line"], 0)
        self.assertTrue(any("SomeCustomHelper" in u for u in conv.unsupported))

    def test_automation_id_from_display(self):
        conv = convert("repo.Calculator.Display.Click();", self.repo)
        self.assertEqual(conv.steps[0]["target"]["automation_id"], "CalculatorResults")
        self.assertEqual(conv.steps[0]["target"]["name"], "Display")
        self.assertEqual(conv.steps[0]["target"]["source_locator"]["kind"], "ranorex")

    def test_variables_and_control_flow_need_script(self):
        conv = convert((S / "Recording1.cs").read_text(), self.repo)
        self.assertFalse(conv.ok)


class ImportAndRunTests(unittest.TestCase):
    def test_native_import_runs_in_player_dry(self):
        res = import_project(S / "Sample.rxrep", [S / "Recording2.cs"], "Demo")
        item = res["items"][0]
        self.assertEqual(item["mode"], "native")
        test, _ = testfile.load_test(item["test"])
        self.assertEqual(test["source"]["type"], "ranorex")
        run = Player(item["test"], dry_run=True, backend=DryRunBackend()).run()
        self.assertEqual(run["status"], "inconclusive")
        self.assertEqual(run["summary"]["total"], len(test["steps"]))
        self.assertIn(item["test"], [t["name"] for t in testfile.list_tests()])
        report = json.loads(Path(item["migration_report"]).read_text(encoding="utf-8"))
        self.assertEqual(report["source_platform"], "Ranorex/C#")
        self.assertTrue(report["runtime_note"].startswith("Original source"))
        with self.assertRaises(FileExistsError):
            import_project(S / "Sample.rxrep", [S / "Recording2.cs"], "Demo")

    def test_script_mode_runs_on_same_engine(self):
        res = import_project(S / "Sample.rxrep", [S / "Recording1.cs"], "DemoScript")
        item = res["items"][0]
        self.assertEqual(item["mode"], "script")
        be = DryRunBackend()
        run = run_script(item["script"], dry_run=True, backend=be)
        self.assertEqual(run["status"], "inconclusive")
        self.assertEqual(run["kind"], "ranorex_script")
        self.assertTrue((Path(run["_dir"]) / "run.json").exists())
        # run_app, 3 clicks, delay, click, validate x2, hotkey, double-click (log/get_text/screenshot are not steps)
        self.assertEqual(run["summary"]["total"], 10)
        self.assertEqual(run["summary"]["failed"], 0)
        self.assertEqual(run["summary"]["validations"], 2)
        report = json.loads(Path(item["migration_report"]).read_text(encoding="utf-8"))
        self.assertTrue(any(row["source_line"] > 0 for row in report["unsupported_constructs"]))
        self.assertEqual(report["execution_validation"], "passed")

    def test_runner_rejects_untrusted_python_before_executing_it(self):
        with tempfile.TemporaryDirectory() as tmp:
            script = Path(tmp) / "untrusted.py"
            marker = Path(tmp) / "executed.txt"
            script.write_text(
                "def run(ctx):\n    __import__('pathlib').Path(" + repr(str(marker)) + ").touch()\n",
                encoding="utf-8",
            )
            with self.assertRaisesRegex(ValueError, "safety validation"):
                run_script(script, dry_run=True)
            self.assertFalse(marker.exists())
        self.assertTrue(validate_script_source("def run(ctx):\n    while True:\n        pass\n"))


if __name__ == "__main__":
    unittest.main()
