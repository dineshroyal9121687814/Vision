"""Validation text matching: the same value must pass however it was read; a different value must never pass."""
import unittest
from unittest import mock

from core.playback import textmatch as tm
from core.playback.validators import Validator


class TextMatchTests(unittest.TestCase):
    def ok(self, actual, expected, kind="text_equals", source="OCR", strict=False):
        return tm.match(actual, expected, kind, source, strict)[0]

    def test_user_case_accessibility_name_vs_drawn_value(self):
        self.assertTrue(self.ok("9,801", "Display is 9,801"))
        self.assertTrue(self.ok("9,801", "Display is 9,801", source="UI Automation"))

    def test_ocr_noise_on_the_same_value(self):
        for read in ("9.801", "9 801", "9,8O1", "9, 801", "9801", " 9,801\n"):
            self.assertTrue(self.ok(read, "9,801"), read)
        self.assertTrue(self.ok("Total: 1O0", "total: 100", "text_contains"))

    def test_different_values_never_match(self):
        for read in ("9,802", "9,80", "19,801", "9,8011", "", "801"):
            self.assertFalse(self.ok(read, "9,801"), read)
            self.assertFalse(self.ok(read, "Display is 9,801"), read)
        self.assertFalse(self.ok("-9,801", "9,801"))
        self.assertFalse(self.ok("Save", "Cancel"))
        self.assertFalse(self.ok("Login", "Log out", "text_contains"))

    def test_look_alikes_only_for_ocr_and_only_with_digits(self):
        self.assertFalse(self.ok("9,8O1", "9,801", source="UI Automation"))
        self.assertFalse(self.ok("Sav3", "Save"))           # no digits expected -> no O/0-style folding
        self.assertFalse(self.ok("l0gin", "Login"))

    def test_strict_mode_turns_tolerance_off(self):
        self.assertFalse(self.ok("9,801", "Display is 9,801", strict=True))
        self.assertTrue(self.ok("display is 9,801", "Display is 9,801", strict=True))     # case/space still normalised

    def test_long_text_with_one_ocr_slip(self):
        self.assertTrue(self.ok("Welcome back, Dinesh Kumarr", "Welcome back, Dinesh Kumar"))
        self.assertFalse(self.ok("Welcome back, Ramesh Kumar", "Welcome back, Dinesh Kumar"))

    def test_note_explains_the_tolerance(self):
        self.assertIn("punctuation", tm.match("9.801", "9,801", "text_equals", "OCR")[1])


class FakeResolver:
    abort_check = staticmethod(lambda: False)

    class _P:
        def get_plugin_for(self, w):
            return self

        def find_element_native(self, t, w):
            return None

    plugins = _P()
    dir = None

    def resolve_once(self, t, w, attempt=1):
        return mock.Mock(x=100, y=100, method="native")

    def grab(self):
        import numpy as np
        return np.zeros((400, 400, 3), dtype=np.uint8), (0, 0)


class ValidatorOcrTests(unittest.TestCase):
    def run_check(self, reads, expected, **extra):
        ocr = mock.Mock()
        ocr.enhanced_variants = lambda img: iter(range(len(reads) - 1))
        it = iter(reads)
        ocr.read_all_text = lambda img, **k: next(it)
        v = Validator(FakeResolver(), {"timeout_s": 0.2})
        target = {"rect": [50, 80, 150, 120], "rel": [0.5, 0.5]}
        with mock.patch.dict("sys.modules", {"core.ocr.ocr_engine": ocr, "core.ocr": mock.Mock(ocr_engine=ocr)}):
            return v.evaluate({"type": "text_equals", "expected": expected, "target": target, "timeout_s": 0, **extra}, {})

    def test_same_value_passes_when_ocr_adds_noise(self):
        r = self.run_check(["9.801"], "Display is 9,801")
        self.assertEqual(r["status"], "passed", r)
        self.assertIn("matched", r["detail"])

    def test_enhanced_retry_rescues_a_bad_first_read(self):
        r = self.run_check(["9,8", "9,801"], "9,801")
        self.assertEqual(r["status"], "passed", r)
        self.assertIn("enhanced", r["detail"])

    def test_real_mismatch_still_fails_and_reports_every_read(self):
        r = self.run_check(["9,802", "9,803"], "9,801")
        self.assertEqual(r["status"], "failed")
        self.assertIn("9,802", r["detail"])
        self.assertIn("9,803", r["detail"])

    def test_strict_validation_fails_on_label_difference(self):
        r = self.run_check(["9,801"], "Display is 9,801", match="strict")
        self.assertEqual(r["status"], "failed")


if __name__ == "__main__":
    unittest.main()
