"""REAL Excel end-to-end (Windows + installed desktop Excel + VISIONAUTO_E2E=1).  NOT run by the author (Linux).

Covers requirement 7 workflows 1-3, 11, 12: launch Excel, open a workbook with a space in its path, edit a cell,
verify it through Excel's object model, save, close, reopen and read the value back.
"""
import os
import sys
import tempfile
import unittest
from pathlib import Path

ON = sys.platform == "win32" and os.environ.get("VISIONAUTO_E2E") == "1"
ROOT = Path(__file__).resolve().parents[2]


@unittest.skipUnless(ON, "real Windows + Excel required (set VISIONAUTO_E2E=1)")
class ExcelE2E(unittest.TestCase):
    def setUp(self):
        sys.path.insert(0, str(ROOT))
        import openpyxl
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.book = str(Path(self.tmp.name) / "VisionAuto Excel E2E.xlsx")
        wb = openpyxl.Workbook()
        wb.active["A1"] = "seed"
        wb.save(self.book)

    def run_steps(self, steps):
        from core.playback.player import Player
        for i, s in enumerate(steps, 1):
            s.setdefault("id", i)
            s.setdefault("params", {})
            s.setdefault("window", {})
        return Player({"name": "excel", "steps": steps}, {"timeout_s": 30}, base_dir=self.tmp.name).run()

    def test_open_edit_save_close_reopen(self):
        from core.system import excel_com
        r = self.run_steps([{"type": "open_app", "params": {"name": "Excel", "path": self.book, "timeout_s": 60}}])
        self.assertEqual(r["status"], "passed", r["steps"])
        self.assertTrue(r["steps"][0]["method"].startswith("excel:"))
        self.assertEqual(excel_com.read_cell("A1", "VisionAuto Excel E2E.xlsx"), "seed")
        # edit through the real UI path: select A2 via the Name Box, type, Enter
        r = self.run_steps([
            {"type": "hotkey", "params": {"keys": "ctrl+g"}}, {"type": "type", "params": {"text": "A2"}}, {"type": "key", "params": {"key": "enter"}},
            {"type": "type", "params": {"text": "typed by VisionAuto"}}, {"type": "key", "params": {"key": "enter"}},
            {"type": "excel_save", "params": {"path": self.book}}])
        self.assertEqual(r["status"], "passed", r["steps"])
        self.assertEqual(excel_com.read_cell("A2", "VisionAuto Excel E2E.xlsx"), "typed by VisionAuto")
        r = self.run_steps([{"type": "excel_close", "params": {"path": self.book, "save": False}},
                            {"type": "open_app", "params": {"name": "Excel", "path": self.book}}])
        self.assertEqual(r["status"], "passed", r["steps"])
        self.assertEqual(excel_com.read_cell("A2", "VisionAuto Excel E2E.xlsx"), "typed by VisionAuto")
        self.run_steps([{"type": "excel_close", "params": {"path": self.book, "save": False}}])


if __name__ == "__main__":
    unittest.main()
