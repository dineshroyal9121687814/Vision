"""REAL-desktop end-to-end tests (Windows only).  Skipped everywhere else and unless VISIONAUTO_E2E=1.

    set VISIONAUTO_E2E=1
    python -m pytest tests/windows_e2e -v

They launch tools/e2e_fixture/fixture_app.py (two windows, duplicate "Save" buttons, combo with "Green"/"Greenish",
drop zone, native file dialog ...) plus Notepad, drive them with the Player and assert on the fixture's JSON state file
- never on screenshots.  The machine must be unlocked, not be used during the run, and at 100-150 % scaling.

Results are recorded by hand in docs/WINDOWS_E2E_TEST_RESULTS.md; this repository's author could NOT run them (Linux).
"""
import json
import os
import subprocess
import sys
import tempfile
import time
import unittest
from pathlib import Path

ON = sys.platform == "win32" and os.environ.get("VISIONAUTO_E2E") == "1"
ROOT = Path(__file__).resolve().parents[2]


@unittest.skipUnless(ON, "real Windows desktop required (set VISIONAUTO_E2E=1)")
class WindowsE2E(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        sys.path.insert(0, str(ROOT))
        cls.tmp = tempfile.TemporaryDirectory()
        cls.state_file = Path(cls.tmp.name) / "state.json"
        cls.proc = subprocess.Popen([sys.executable, str(ROOT / "tools/e2e_fixture/fixture_app.py"), str(cls.state_file)])
        end = time.time() + 20
        while time.time() < end and not cls.state_file.exists():
            time.sleep(0.2)
        assert cls.state_file.exists(), "fixture did not start"
        time.sleep(1.5)

    @classmethod
    def tearDownClass(cls):
        cls.proc.terminate()
        cls.tmp.cleanup()

    # ---- helpers
    def state(self):
        return json.loads(self.state_file.read_text(encoding="utf-8"))

    def run_steps(self, steps, **opts):
        from core.playback.player import Player
        for i, s in enumerate(steps, 1):
            s.setdefault("id", i)
            s.setdefault("params", {})
            s.setdefault("validations", [])
        o = {"timeout_s": 8, "settle_wait": True, **opts}
        return Player({"name": "e2e", "steps": steps}, o, base_dir=self.tmp.name).run()

    WIN_A = {"title": "VA Fixture A", "match": "exact", "process": "python.exe"}
    WIN_B = {"title": "VA Fixture B", "match": "exact", "process": "python.exe"}

    def click(self, xpath, win=None, **kw):
        return {"type": "click", "window": win or self.WIN_A, "target": {"xpath": xpath, "role": "Button"}, **kw}

    # ---- scenarios (numbers = section 16 of the requirements)
    def test_02_xpath_identifies_exact_button(self):
        r = self.run_steps([self.click("//pane[@automationid='pane_right']//button[@name='Save']")])
        self.assertEqual(r["status"], "passed")
        self.assertEqual(self.state()["saved"], "right")

    def test_03_automation_id(self):
        r = self.run_steps([{"type": "click", "window": self.WIN_A, "target": {"automation_id": "save_left", "name": "Save", "role": "Button"}}])
        self.assertEqual(r["status"], "passed")
        self.assertEqual(self.state()["saved"], "left")

    def test_22_ambiguous_xpath_fails_safely(self):
        before = self.state().get("saved")
        r = self.run_steps([self.click("//button[@name='Save']")])
        self.assertEqual(r["status"], "failed")
        self.assertEqual(r["steps"][0]["failure_kind"], "AmbiguousTarget")
        self.assertEqual(self.state().get("saved"), before)               # NOTHING was clicked

    def test_09_two_windows_each_with_save_exact_title_picks_the_right_one(self):
        r = self.run_steps([self.click("//button[@name='Save']", win=self.WIN_B)])
        self.assertEqual(r["status"], "passed")
        self.assertEqual(self.state()["saved"], "b")

    def test_10_main_window_mode(self):
        r = self.run_steps([{"type": "click", "window": {"process": "python.exe", "main_window": True},
                             "target": {"automation_id": "save_left", "role": "Button", "name": "Save"}}])
        # two python.exe windows of similar size: must be reported ambiguous, not guessed
        self.assertIn(r["steps"][0].get("failure_kind", "ok"), ("AmbiguousTarget", "ok"))

    def test_14_text_goes_to_the_intended_field(self):
        r = self.run_steps([{"type": "set_value", "window": self.WIN_A, "target": {"automation_id": "notes", "role": "Edit", "name": "Notes"},
                             "params": {"text": "ünïcode ✓ line"}}])
        self.assertEqual(r["status"], "passed", r)
        s = self.state()
        self.assertEqual(s["notes"], "ünïcode ✓ line")
        self.assertNotEqual(s.get("username"), "ünïcode ✓ line")

    def test_12_dropdown_exact_option(self):
        r = self.run_steps([{"type": "select_option", "window": self.WIN_A, "target": {"automation_id": "color", "role": "ComboBox", "name": "Color"},
                             "params": {"text": "Green"}}])
        self.assertEqual(r["status"], "passed", r)
        self.assertEqual(self.state()["color"], "Green")                  # not "Greenish"

    def test_13_checkbox_and_radio_state(self):
        steps = [{"type": "set_state", "window": self.WIN_A, "target": {"automation_id": "agree", "role": "CheckBox", "name": "I agree"}, "params": {"state": "check"}},
                 {"type": "set_state", "window": self.WIN_A, "target": {"automation_id": "agree", "role": "CheckBox", "name": "I agree"}, "params": {"state": "check"}},
                 {"type": "set_state", "window": self.WIN_A, "target": {"automation_id": "size_large", "role": "RadioButton", "name": "Large"}, "params": {"state": "select"}}]
        r = self.run_steps(steps)
        self.assertEqual(r["status"], "passed", r)
        s = self.state()
        self.assertIs(s["agree"], True)                                   # second 'check' did NOT toggle it off
        self.assertEqual(s["size"], "Large")

    def test_11_modal_dialog(self):
        r = self.run_steps([{"type": "click", "window": self.WIN_A, "target": {"automation_id": "open_dialog", "role": "Button", "name": "Open dialog"}},
                            {"type": "wait_for_window", "params": {"window": {"title": "VA Modal", "match": "exact"}}},
                            {"type": "click", "window": {"title": "VA Modal", "match": "exact"}, "target": {"automation_id": "modal_confirm", "role": "Button", "name": "Confirm"}}])
        self.assertEqual(r["status"], "passed", r)
        self.assertEqual(self.state()["modal"], "confirmed")

    def test_15_drag_between_containers(self):
        r = self.run_steps([{"type": "drag_drop", "window": self.WIN_A, "target": {"name": "alpha", "role": "ListItem", "automation_id": ""},
                             "to": {"automation_id": "dest_list", "role": "List", "name": "dest_list"}}])
        self.assertEqual(r["status"], "passed", r)
        self.assertIn("alpha", self.state().get("dest_list_items", []))

    def test_17_upload_through_native_file_dialog(self):
        f = Path(self.tmp.name) / "upload_me.txt"
        f.write_text("hello")
        r = self.run_steps([{"type": "upload_file", "window": self.WIN_A,
                             "target": {"automation_id": "browse", "role": "Button", "name": "Browse..."}, "params": {"path": str(f)}}])
        self.assertEqual(r["status"], "passed", r)
        self.assertEqual(Path(self.state()["browse"]).name, "upload_me.txt")

    def test_17b_missing_file_never_opens_a_dialog(self):
        r = self.run_steps([{"type": "upload_file", "window": self.WIN_A,
                             "target": {"automation_id": "browse", "role": "Button", "name": "Browse..."}, "params": {"path": r"C:\no\such\file.pdf"}}])
        self.assertEqual(r["status"], "failed")

    def test_07_quadrant_fallback_never_clicks_region_centre(self):
        # name-only target (no automation id / xpath) with the quadrant fallback enabled; result must be the button itself
        r = self.run_steps([{"type": "click", "window": self.WIN_A,
                             "target": {"text": "Open dialog", "name": "Open dialog", "search_quadrant": "all", "text_match": "exact",
                                        "locator_order": ["quadrant"]}}], use_native=False)
        self.assertIn(r["status"], ("passed", "failed"))
        if r["status"] == "passed":
            self.assertTrue(any(e[0] == "modal" or e[0] == "started" for e in self.state()["events"]))

    # Not automated here (need extra apps / manual set-up) - see docs/WINDOWS_E2E_TEST_RESULTS.md:
    # 1 Notepad text, 4 image locator, 5 OCR, 6 approximate position, 16 cross-window file drag, 18 file drop zone,
    # 19-20 multi-application workflow, 21 incorrect-locator recovery, 24 pause/resume/stop.


if __name__ == "__main__":
    unittest.main()
