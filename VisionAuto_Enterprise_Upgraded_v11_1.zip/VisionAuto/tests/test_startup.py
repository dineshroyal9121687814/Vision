"""Regression coverage for optional dependency import order at app startup."""
from __future__ import annotations

import importlib.util
import subprocess
import sys
import unittest


def _real_module_available(name: str) -> bool:
    """True only for a genuinely installed module, not a stub placed in sys.modules by test fakes."""
    try:
        return importlib.util.find_spec(name) is not None
    except (ValueError, ImportError):
        return False


class StartupImportTests(unittest.TestCase):
    @unittest.skipUnless(
        all(_real_module_available(name) for name in ("PySide6", "torch", "pynput")),
        "startup import regression requires PySide6, Torch and pynput",
    )
    def test_input_hooks_preload_before_qt_and_torch(self):
        # This reproduces the order that used to fail in a fresh process. Keep
        # it isolated because importing PySide/Torch mutates process hooks.
        code = (
            "from app.main import _preload_input_hooks; "
            "_preload_input_hooks(); "
            "import PySide6.QtWidgets; import torch; "
            "from pynput import keyboard, mouse"
        )
        completed = subprocess.run(
            [sys.executable, "-B", "-c", code],
            capture_output=True,
            text=True,
            timeout=90,
        )
        self.assertEqual(completed.returncode, 0, completed.stderr)

    @unittest.skipUnless(importlib.util.find_spec("cv2") is not None, "OCR dependencies are not installed")
    def test_ocr_capability_check_does_not_load_torch(self):
        code = (
            "from core.ocr.ocr_engine import available; available(); "
            "import sys; assert 'torch' not in sys.modules"
        )
        completed = subprocess.run(
            [sys.executable, "-B", "-c", code],
            capture_output=True,
            text=True,
            timeout=30,
        )
        self.assertEqual(completed.returncode, 0, completed.stderr)


if __name__ == "__main__":
    unittest.main()
