import json
import threading
import time
import unittest

from tests.helpers import FakeProbe, use_temp_workspace

use_temp_workspace()

from core import testfile  # noqa: E402
from core.recorder.builder import RawEvent, StepBuilder  # noqa: E402
from core.recorder.recorder import Recorder  # noqa: E402


def down(t, x, y, b="left"):
    return RawEvent("mouse_down", t, x, y, button=b)


def up(t, x, y, b="left"):
    return RawEvent("mouse_up", t, x, y, button=b)


def key(t, k, char=False):
    return RawEvent("key_down", t, key=k, is_char=char)


def keyup(t, k):
    return RawEvent("key_up", t, key=k)


class BuilderTests(unittest.TestCase):
    def build(self, events):
        out = []
        b = StepBuilder(out.append)
        for e in events:
            b.feed(e)
        b.flush_all()
        return out

    def test_click_double_right_drag(self):
        steps = self.build([
            down(0.0, 10, 10), up(0.05, 10, 10),                    # click
            down(2.0, 50, 50), up(2.05, 50, 50),                    # double click
            down(2.2, 51, 50), up(2.25, 51, 50),
            down(4.0, 80, 80, "right"), up(4.05, 80, 80, "right"),  # right click
            down(6.0, 100, 100), up(6.4, 300, 220),                 # drag & drop
        ])
        self.assertEqual([s["type"] for s in steps], ["click", "double_click", "right_click", "drag_drop"])
        self.assertEqual((steps[3]["to_x"], steps[3]["to_y"]), (300, 220))

    def test_two_slow_clicks_are_not_double(self):
        steps = self.build([down(0, 5, 5), up(0.05, 5, 5), down(1.0, 5, 5), up(1.05, 5, 5)])
        self.assertEqual([s["type"] for s in steps], ["click", "click"])

    def test_typing_backspace_and_order(self):
        evs = [down(0, 5, 5), up(0.05, 5, 5)]
        t = 1.0
        for ch in "helo":
            evs += [key(t, ch, True), keyup(t + 0.01, ch)]
            t += 0.1
        evs += [key(t, "backspace"), keyup(t, "backspace")]            # remove 'o'
        for ch in "lo":
            t += 0.1
            evs += [key(t, ch, True), keyup(t, ch)]
        evs += [key(t + 0.2, "enter"), down(t + 1, 9, 9), up(t + 1.05, 9, 9)]
        steps = self.build(evs)
        self.assertEqual([s["type"] for s in steps], ["click", "type", "key", "click"])
        self.assertEqual(steps[1]["text"], "hello")
        self.assertEqual(steps[2]["key"], "enter")

    def test_hotkey_and_shift_capital(self):
        steps = self.build([
            key(0, "ctrl"), key(0.1, "c"), keyup(0.15, "c"), keyup(0.2, "ctrl"),
            key(1, "shift"), key(1.1, "A", True), keyup(1.2, "A"), keyup(1.3, "shift"),
        ])
        self.assertEqual(steps[0]["type"], "hotkey")
        self.assertEqual(steps[0]["keys"], "ctrl+c")
        self.assertEqual((steps[1]["type"], steps[1]["text"]), ("type", "A"))

    def test_scroll_is_coalesced(self):
        evs = [RawEvent("scroll", 0.1 * i, 10, 10, dy=-1) for i in range(5)]
        steps = self.build(evs)
        self.assertEqual(len(steps), 1)
        self.assertEqual(steps[0]["dy"], -5)


class RecorderTests(unittest.TestCase):
    def test_full_session_saves_assets_journal_and_json(self):
        elements = {
            (100, 100): {"name": "Save", "role": "Button", "automation_id": "btnSave",
                         "rect": [80, 90, 140, 120]},
        }
        rec = Recorder("unit session", probe=FakeProbe(elements=elements))
        seen = []
        rec.on_step = lambda s: seen.append(s["description"])
        rec.start(listeners=False)
        t = time.monotonic()
        rec.inject(down(t, 100, 100)); rec.inject(up(t + 0.05, 100, 100))
        rec.inject(down(t + 1, 200, 200)); rec.inject(up(t + 1.5, 400, 300))      # drag
        for i, ch in enumerate("hi"):
            rec.inject(key(t + 2 + i * 0.1, ch, True))
        rec.add_validation()                                                       # last clicked item
        path = rec.stop()

        test, d = testfile.load_test(path)
        types = [s["type"] for s in test["steps"]]
        self.assertEqual(types, ["click", "drag_drop", "type", "validate"])
        click = test["steps"][0]
        self.assertEqual((click["target"]["x"], click["target"]["y"]), (100, 100))
        self.assertEqual(click["target"]["automation_id"], "btnSave")
        self.assertEqual(click["target"]["role"], "Button")
        self.assertEqual(click["target"]["rect"], [80, 90, 140, 120])
        self.assertEqual(click["target"]["rel"], [0.3333, 0.3333])
        self.assertEqual(click["description"], "Click 'Save' button in 'Notepad'")
        for size in (100, 300):
            self.assertTrue((d / click["target"]["templates"][f"crop{size}"]["path"]).exists())
        self.assertTrue((d / click["target"]["full"]).exists())
        self.assertIn("to", test["steps"][1])
        self.assertEqual(test["steps"][2]["params"]["text"], "hi")
        self.assertEqual(test["steps"][3]["check"]["type"], "element_exists")
        self.assertEqual(len(seen), 4)

        # crash safety: delete test.json, journal must rebuild it
        (d / "test.json").unlink()
        recovered, _ = testfile.load_test(d)
        self.assertEqual(len(recovered["steps"]), 4)

    def test_own_window_clicks_ignored(self):
        probe = FakeProbe(windows={(5, 5): {"title": "VisionAuto", "process": "python.exe", "pid": 999, "hwnd": 9}})
        rec = Recorder("own window", probe=probe, ignore_pids={999})
        rec.start(listeners=False)
        t = time.monotonic()
        rec.inject(down(t, 5, 5)); rec.inject(up(t + 0.05, 5, 5))     # on our toolbar: ignored
        rec.inject(down(t + 1, 50, 50)); rec.inject(up(t + 1.05, 50, 50))
        rec.stop()
        self.assertEqual(len(rec.steps), 1)

    def test_password_input_is_redacted_before_it_reaches_the_journal(self):
        class PasswordProbe(FakeProbe):
            def focused_element(self):
                return {"is_password": True, "name": "Password"}

        secret = "do-not-save-this-password"
        rec = Recorder("password redaction", probe=PasswordProbe())
        rec.start(listeners=False)
        t = time.monotonic()
        for i, ch in enumerate(secret):
            rec.inject(RawEvent("key_down", t + i * 0.01, key=ch, is_char=True))
        path = rec.stop()
        journal = (path.parent / "steps.jsonl").read_text(encoding="utf-8")
        saved = path.read_text(encoding="utf-8")
        self.assertNotIn(secret, journal)
        self.assertNotIn(secret, saved)
        test, _ = testfile.load_test(path)
        step = test["steps"][0]
        self.assertTrue(step["params"]["redacted"])
        self.assertEqual(step["params"]["text"], "")
        self.assertIn("redacted", step["description"])

    def test_stop_timeout_keeps_worker_journal_and_final_save_open(self):
        class BlockingProbe(FakeProbe):
            def __init__(self):
                super().__init__()
                self.entered = threading.Event()
                self.release = threading.Event()

            def grab(self):
                self.entered.set()
                self.release.wait(2)
                return super().grab()

        probe = BlockingProbe()
        rec = Recorder("slow stop", probe=probe)
        rec.start(listeners=False)
        t = time.monotonic()
        rec.inject(down(t, 10, 10))
        rec.inject(up(t + 0.05, 10, 10))
        self.assertTrue(probe.entered.wait(1))
        with self.assertRaisesRegex(TimeoutError, "journal remains open"):
            rec.stop(timeout=0.01)
        self.assertFalse(rec._stopped)
        self.assertFalse(rec._journal.closed)
        probe.release.set()
        path = rec.stop(timeout=2)
        recovered, _ = testfile.load_test(path)
        self.assertEqual(len(recovered["steps"]), 1)


if __name__ == "__main__":
    unittest.main()
