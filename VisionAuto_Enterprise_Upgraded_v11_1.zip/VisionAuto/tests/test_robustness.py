"""Quiet helpers, popup windows, scroll position, DPI fit, OCR minus sign, intent, video, shard, version history."""
import json
import tempfile
import threading
import time
import unittest
from pathlib import Path
from unittest import mock

import cv2
import numpy as np

from core import suite, testfile
from core.ocr import ocr_engine
from core.playback.scrollfind import ScrollFinder
from core.recorder import intent
from core.reports.video import VideoRecorder
from core.system import excel_com, quiet


class FakeProbe:
    def __init__(self):
        self.wins = [{"hwnd": 1, "title": "Excel", "process": "EXCEL.EXE", "class": "XLMAIN"}]
        self.fg = {"hwnd": 1, "title": "Excel", "process": "EXCEL.EXE", "class": "XLMAIN"}
        self.hidden, self.focused = [], []

    def windows(self): return list(self.wins)
    def foreground(self): return dict(self.fg)
    def hide(self, h): self.hidden.append(h); self.wins = [w for w in self.wins if w["hwnd"] != h]
    def focus(self, h): self.focused.append(h); self.fg = next(w for w in self.wins if w["hwnd"] == h)


class QuietTests(unittest.TestCase):
    def test_noise_rules(self):
        self.assertTrue(quiet.is_noise({"process": "ollama.exe"}))
        self.assertTrue(quiet.is_noise({"process": "ollama app.exe"}))
        self.assertFalse(quiet.is_noise({"process": "EXCEL.EXE", "title": "Book1"}))
        con = {"process": "cmd.exe", "class": "ConsoleWindowClass", "hwnd": 9}
        self.assertFalse(quiet.is_noise(con))                       # a console app under test is not noise
        self.assertTrue(quiet.is_noise(con, known=set(), consoles=True))
        self.assertFalse(quiet.is_noise(con, known={9}, consoles=True))   # it was already open

    def test_guard_hides_new_console_and_restores_focus(self):
        pr = FakeProbe()
        g = quiet.FocusGuard(probe=pr, interval_s=0.01)
        with g:
            console = {"hwnd": 7, "title": "", "process": "cmd.exe", "class": "ConsoleWindowClass"}
            pr.wins.append(console)
            pr.fg = console                      # the flash took the focus
            deadline = time.time() + 2
            while 7 not in pr.hidden and time.time() < deadline:
                time.sleep(0.01)
        self.assertIn(7, pr.hidden)
        self.assertIn(1, pr.focused)             # the Excel window got the focus back
        self.assertEqual(pr.fg["hwnd"], 1)

    def test_guard_leaves_existing_windows_alone(self):
        pr = FakeProbe()
        pr.wins.append({"hwnd": 5, "title": "", "process": "cmd.exe", "class": "ConsoleWindowClass"})
        with quiet.FocusGuard(probe=pr, interval_s=0.01):
            time.sleep(0.05)
        self.assertEqual(pr.hidden, [])

    def test_llm_call_runs_under_guard(self):
        from core.ai.llm import OllamaClient
        c = OllamaClient()
        c._ok = True
        entered = []
        class G:
            def __enter__(s): entered.append(1)
            def __exit__(s, *a): return False
        with mock.patch("core.ai.llm.quiet.FocusGuard", G), mock.patch("urllib.request.urlopen") as u:
            u.return_value.__enter__.return_value.read.return_value = b'{"response": " hi "}'
            self.assertEqual(c.generate("x"), "hi")
        self.assertEqual(entered, [1])


class ScrollPosition(unittest.TestCase):
    def test_jump_to_recorded_position_before_wheel(self):
        class R:
            governor = mock.Mock(allowed=lambda *a: False)
            calls = 0
            def resolve_once(self, target, window, attempt=1, only=None):
                self.calls += 1
                return mock.Mock(evidence={}, method="uia") if jumped else None
        jumped = []
        wheel = []
        f = ScrollFinder(R(), lambda *a: wheel.append(a), None, {"use_native": True}, sleep=lambda s: None,
                         getpct=lambda x, y: {"v": 0.0}, setpct=lambda x, y, v=-1, h=-1: jumped.append(v) or True)
        tg = {"name": "Zed", "container": {"rect": [0, 0, 100, 200], "role": "list", "scroll_pct": {"v": 80.0}}}
        res = f.find(tg, {})
        self.assertEqual(jumped, [80.0])
        self.assertEqual(res.evidence["strategy"], "scroll-position")
        self.assertEqual(wheel, [])              # no wheel steps needed

    def test_direction_hint_comes_from_position(self):
        seen = []
        class R:
            governor = mock.Mock(allowed=lambda *a: False)
            def resolve_once(self, *a, **k): return None
        f = ScrollFinder(R(), lambda x, y, dx, dy: seen.append(dy), None, {"scroll_find_steps": 2, "use_native": True},
                         sleep=lambda s: None, getpct=lambda x, y: {"v": 90.0}, setpct=lambda *a, **k: False)
        with mock.patch.object(ScrollFinder, "_region", return_value=None):
            f.find({"name": "X", "container": {"rect": [0, 0, 100, 200], "role": "tree", "scroll_pct": {"v": 10.0}}}, {})
        self.assertTrue(seen and seen[0] > 0)    # recorded position is above where we are: wheel UP first

    def test_pick_option_types_ahead_even_when_container_is_unknown(self):
        typed = []
        class R:
            governor = mock.Mock(allowed=lambda *a: False)
            n = 0
            def resolve_once(self, *a, **k):
                self.n += 1
                return mock.Mock(evidence={}, method="image") if typed else None
        f = ScrollFinder(R(), lambda *a: None, lambda t, i: typed.append(t), {"use_native": False}, sleep=lambda s: None,
                         getpct=lambda *a: None, setpct=lambda *a, **k: False)
        res = f.find({"name": "Germany", "intent": "pick_option", "container": {"rect": [0, 0, 100, 200], "role": "pane"}}, {})
        self.assertEqual(typed, ["Germany"])
        self.assertEqual(res.evidence["strategy"], "type-ahead")

    def test_menus_never_type_ahead(self):
        typed = []
        class R:
            governor = mock.Mock(allowed=lambda *a: False)
            def resolve_once(self, *a, **k): return None
        f = ScrollFinder(R(), lambda *a: None, lambda t, i: typed.append(t), {"use_native": False, "scroll_find_steps": 1},
                         sleep=lambda s: None, getpct=lambda *a: None, setpct=lambda *a, **k: False)
        with mock.patch.object(ScrollFinder, "_region", return_value=None):
            f.find({"name": "Open", "intent": "pick_option", "container": {"rect": [0, 0, 9, 9], "role": "menu"}}, {})
        self.assertEqual(typed, [])


class DpiFit(unittest.TestCase):
    WIN = [0, 0, 1920, 1080]

    def test_correct_rect_is_kept(self):
        self.assertEqual(excel_com.fit_to_window([100, 200, 160, 220], self.WIN, 1.25), [100, 200, 160, 220])

    def test_rect_too_big_by_scale_is_corrected(self):
        got = excel_com.fit_to_window([2000, 1100, 2100, 1130], self.WIN, 1.25)
        self.assertEqual(got, [1600, 880, 1680, 904])

    def test_untrustworthy_rect_is_refused(self):
        self.assertIsNone(excel_com.fit_to_window([5000, 5000, 5100, 5030], self.WIN, 1.0))

    def test_no_window_rect_trusts_answer(self):
        self.assertEqual(excel_com.fit_to_window([1, 2, 3, 4], None, 1.5), [1, 2, 3, 4])


class MinusSign(unittest.TestCase):
    @staticmethod
    def pic(text):
        im = np.full((26, 70, 3), 255, np.uint8)
        cv2.putText(im, text, (18, 19), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 0, 0), 1, cv2.LINE_AA)
        return im

    def test_detects_sign(self):
        for t in ("-7", "-12", "-305"):
            self.assertTrue(ocr_engine.leading_minus(self.pic(t)), t)
        for t in ("7", "12", "305"):
            self.assertFalse(ocr_engine.leading_minus(self.pic(t)), t)

    def test_unsigned_reading_is_never_returned_for_a_negative_picture(self):
        ocr_engine._cache.clear()
        with mock.patch.object(ocr_engine, "engines", return_value=["tesseract"]), \
                mock.patch.object(ocr_engine, "_tesseract_line", return_value="7"):
            self.assertEqual(ocr_engine.read_small(self.pic("-7"), expected="-7"), ["-7"])
            ocr_engine._cache.clear()
            self.assertEqual(ocr_engine.read_small(self.pic("7"), expected="7"), ["7"])


def step(i, type_, **kw):
    return {"id": i, "type": type_, **kw}


class Intent(unittest.TestCase):
    def test_dropdown_open_and_pick(self):
        steps = [step(1, "click", target={"role": "ComboBox", "name": "Country"}),
                 step(2, "click", target={"role": "ListItem", "name": "Germany", "container": {"role": "List"}},
                      window={"popup": True, "owner_title": "Form"})]
        intent.annotate(steps)
        self.assertEqual([s["intent"] for s in steps], ["open_dropdown", "pick_option"])
        self.assertEqual(steps[1]["opener"], 1)
        self.assertEqual(steps[1]["target"]["intent"], "pick_option")

    def test_scroll_then_click_is_scroll_to_find(self):
        steps = [step(1, "scroll", params={"dy": -3}),
                 step(2, "click", target={"role": "ListItem", "name": "Row 40", "container": {"role": "List"}})]
        intent.annotate(steps)
        self.assertEqual(steps[0]["intent"], "scroll_to_find")
        self.assertEqual(steps[0]["intent_for"], 2)

    def test_enter_value_and_drags(self):
        steps = [step(1, "click", target={"role": "Edit", "name": "Qty"}), step(2, "type"),
                 step(3, "drag_drop", window={"title": "A", "process": "a"}, to_window={"title": "B", "process": "b"}),
                 step(4, "drag_drop", window={"title": "A"}, target={"container": {"rect": [1, 2, 3, 4]}},
                      to={"container": {"rect": [1, 2, 3, 4]}})]
        intent.annotate(steps)
        self.assertEqual([s["intent"] for s in steps], ["enter_value", "click", "drag_cross", "drag_reorder"])

    def test_model_can_only_choose_from_fixed_list(self):
        steps = [step(1, "click", target={"role": "ComboBox", "name": "X"}), step(2, "click", target={"role": "Pane"})]
        llm = mock.Mock(available=lambda: True, generate=lambda p: "banana")
        self.assertEqual(intent.refine(steps, llm), 0)
        llm = mock.Mock(available=lambda: True, generate=lambda p: "pick_option.")
        self.assertEqual(intent.refine(steps, llm), 1)
        self.assertEqual(steps[1]["intent"], "pick_option")
        self.assertEqual(intent.refine(steps, None), 0)


class Video(unittest.TestCase):
    def test_writes_a_playable_file(self):
        with tempfile.TemporaryDirectory() as d:
            frames = iter(range(1000))
            grab = lambda: (np.full((101, 203, 3), next(frames) % 255, np.uint8), (0, 0))  # noqa: E731
            v = VideoRecorder(Path(d) / "run.avi", fps=15, grab=grab, sleep=lambda s: time.sleep(0.005))
            for _ in range(5):
                v.capture_once()
            name = v.stop()
            self.assertEqual(name, "run.avi")
            cap = cv2.VideoCapture(str(Path(d) / "run.avi"))
            self.assertEqual(int(cap.get(cv2.CAP_PROP_FRAME_COUNT)), 5)
            self.assertEqual((int(cap.get(3)), int(cap.get(4))), (202, 100))   # even size
            cap.release()

    def test_nothing_recorded_returns_none(self):
        with tempfile.TemporaryDirectory() as d:
            self.assertIsNone(VideoRecorder(Path(d) / "x.avi", grab=lambda: None).stop())


class Shard(unittest.TestCase):
    def test_shards_cover_everything_once(self):
        tests = [{"name": f"t{i}"} for i in range(7)]
        parts = [suite.select_shard(tests, f"{i}/3") for i in (1, 2, 3)]
        self.assertEqual(sorted(t["name"] for p in parts for t in p), sorted(t["name"] for t in tests))
        self.assertEqual([len(p) for p in parts], [3, 2, 2])

    def test_bad_shard(self):
        for bad in ("0/3", "4/3", "x", "1-3"):
            with self.assertRaises(suite.SuiteError):
                suite.parse_shard(bad)
        self.assertIsNone(suite.parse_shard(None))


class History(unittest.TestCase):
    def test_every_change_is_kept_and_restorable(self):
        with tempfile.TemporaryDirectory() as d:
            d = Path(d)
            t = {"name": "demo", "steps": [{"id": 1, "type": "wait", "params": {"ms": 1}}]}
            testfile.save_test(t, d)
            self.assertEqual(testfile.list_versions(d), [])
            t2 = {**t, "steps": t["steps"] + [{"id": 2, "type": "wait", "params": {"ms": 2}}]}
            testfile.save_test(t2, d)
            testfile.save_test(t2, d)                      # unchanged -> no new version
            versions = testfile.list_versions(d)
            self.assertEqual(len(versions), 1)
            self.assertEqual(versions[0]["steps"], 1)
            testfile.restore_version(d, versions[0]["id"])
            self.assertEqual(len(json.loads((d / "test.json").read_text())["steps"]), 1)
            self.assertEqual(len(testfile.list_versions(d)), 2)    # the version we replaced is kept too


class CheckboxState(unittest.TestCase):
    def player(self, states):
        from core.playback.player import Player
        from core.settings import validate
        p = Player.__new__(Player)
        p.dry_run = False
        p.opts = validate({"engine_profile": "strict"})
        p.backend = mock.Mock()
        self.states = list(states)
        return p

    def read(self, x, y):
        s = self.states.pop(0) if len(self.states) > 1 else self.states[0]
        return {"state": {"toggle": s}} if s else {}

    def test_recording_stores_the_state_to_reach(self):
        on = step(1, "click", target={"role": "CheckBox", "state": {"toggle": "off"}})
        off = step(2, "click", target={"role": "CheckBox", "state": {"toggle": "on"}})
        radio = step(3, "click", target={"role": "RadioButton", "state": {"selected": False}})
        btn = step(4, "click", target={"role": "Button"})
        intent.annotate([on, off, radio, btn])
        self.assertEqual([on["ensure_state"], off["ensure_state"], radio["ensure_state"]], ["on", "off", "selected"])
        self.assertNotIn("ensure_state", btn)

    def test_already_checked_is_not_clicked_again(self):
        p = self.player(["on"])
        res = {}
        with mock.patch("core.playback.player.winenv.element_at", self.read):
            self.assertTrue(p._state_already("on", mock.Mock(x=5, y=6), res))
            self.assertFalse(p._state_already("off", mock.Mock(x=5, y=6), res))
        p.backend.click.assert_not_called()

    def test_click_that_did_not_register_is_repeated_once(self):
        p = self.player(["off", "on"])
        res = {}
        with mock.patch("core.playback.player.winenv.element_at", self.read), mock.patch("time.sleep"):
            p._confirm_state("on", mock.Mock(x=5, y=6), "left", res)
        self.assertEqual(p.backend.click.call_count, 1)
        self.assertIn("clicked again", res["state_check"])

    def test_unreadable_state_is_never_guessed(self):
        p = self.player([""])
        with mock.patch("core.playback.player.winenv.element_at", self.read), mock.patch("time.sleep"):
            p._confirm_state("on", mock.Mock(x=5, y=6), "left", {})
        p.backend.click.assert_not_called()


class ScrollEconomy(unittest.TestCase):
    def test_consecutive_and_cancelling_scrolls(self):
        def sc(i, dy, x=100):
            return step(i, "scroll", params={"dx": 0, "dy": dy}, window={"title": "W"}, target={"x": x, "y": 50})
        steps = [sc(1, -3), sc(2, -2), step(3, "key"), sc(4, -5), sc(5, 5), step(6, "key")]
        notes = intent.compact_scrolls(steps)
        self.assertEqual([(s["type"], (s.get("params") or {}).get("dy")) for s in steps], [("scroll", -5), ("key", None), ("key", None)])
        self.assertEqual(len(notes), 3)

    def test_scrolls_in_different_places_are_kept(self):
        steps = [step(1, "scroll", params={"dx": 0, "dy": -3}, window={"title": "W"}, target={"x": 10, "y": 10}),
                 step(2, "scroll", params={"dx": 0, "dy": -3}, window={"title": "W"}, target={"x": 500, "y": 10})]
        self.assertEqual(intent.compact_scrolls(steps), [])
        self.assertEqual(len(steps), 2)

    def player(self, now, want=60.0):
        from core.playback.player import Player
        from core.settings import validate
        p = Player.__new__(Player)
        p.dry_run = False
        p.opts = validate({})
        p.resolver = mock.Mock()
        p.resolver._prepare = lambda t, w: t
        p._next_step = {"type": "click", "window": {}, "target": {"name": "Row 40",
                        "container": {"rect": [0, 0, 100, 200], "scroll_pct": {"v": want}}}}
        return p

    def test_already_at_position_nothing_happens(self):
        p = self.player(60.4)
        with mock.patch("core.playback.player.winenv.scroll_percent_at", return_value={"v": 60.4}), \
                mock.patch("core.playback.player.winenv.set_scroll_percent_at") as setp:
            self.assertIn("already", p._scroll_to_recorded_position({"window": {}}, {}))
        setp.assert_not_called()

    def test_jumps_straight_to_recorded_position(self):
        p = self.player(0)
        with mock.patch("core.playback.player.winenv.scroll_percent_at", return_value={"v": 0.0}), \
                mock.patch("core.playback.player.winenv.set_scroll_percent_at", return_value=True) as setp, \
                mock.patch("time.sleep"):
            self.assertIn("60%", p._scroll_to_recorded_position({"window": {}}, {}))
        setp.assert_called_once()

    def test_unknown_position_falls_back_to_wheel(self):
        p = self.player(0)
        with mock.patch("core.playback.player.winenv.scroll_percent_at", return_value=None):
            self.assertEqual(p._scroll_to_recorded_position({"window": {}}, {}), "")


class WrongElement(unittest.TestCase):
    WIN = {"title": "Book1 - Excel", "rect": [0, 0, 1920, 1080]}

    def close_step(self, x=600, y=400):
        return {"id": 5, "type": "click", "window": dict(self.WIN),
                "target": {"x": x, "y": y, "name": "Close", "role": "Button", "rect": [1860, 0, 1920, 32],
                           "container": {"rect": [0, 0, 5, 5], "role": "table"}}}

    def test_close_named_on_a_cell_is_repaired(self):
        from core.recorder import sanity
        steps = [self.close_step()]
        notes = sanity.repair_steps(steps)
        self.assertEqual(len(notes), 1)
        tg = steps[0]["target"]
        self.assertNotIn("name", tg)
        self.assertEqual((tg["x"], tg["y"]), (600, 400))
        self.assertIn("identity_dropped", tg)

    def test_real_close_button_is_kept(self):
        from core.recorder import sanity
        st = self.close_step(1890, 14)
        self.assertEqual(sanity.repair_steps([st]), [])
        self.assertEqual(st["target"]["name"], "Close")

    def test_element_not_under_the_click_is_dropped_at_recording(self):
        from core.recorder import sanity
        el, why = sanity.clean_element({"name": "Save", "rect": [0, 0, 50, 20]}, 500, 500, [0, 0, 900, 900])
        self.assertEqual(el, {})
        self.assertTrue(why)
        el, why = sanity.clean_element({"name": "Save", "rect": [0, 0, 50, 20]}, 10, 10, [0, 0, 900, 900])
        self.assertEqual(el["name"], "Save")

    def test_player_repairs_on_load_and_refuses_close_click(self):
        from core.playback.player import ElementNotFound, Player
        from core.settings import validate
        p = Player.__new__(Player)
        p.dry_run = False
        st = self.close_step()
        with self.assertRaises(ElementNotFound):
            p._refuse_stray_chrome_click(st, mock.Mock())
        p._refuse_stray_chrome_click(self.close_step(1890, 14), mock.Mock())          # a real title-bar close is allowed


class NoUninvitedScroll(unittest.TestCase):
    def resolver(self, scrolls):
        from core.playback.resolver import Resolver
        r = Resolver.__new__(Resolver)
        r.o = {"scroll_find": True}
        r._scrolled = False
        r.recording_scrolls = scrolls
        r.scrollfinder = mock.Mock()
        return r

    def test_grid_without_recorded_scroll_is_never_scrolled(self):
        r = self.resolver(False)
        self.assertIsNone(r._t_scroll({"container": {"role": "table"}, "name": "G14"}, {}, {"attempt": 1}))
        r.scrollfinder.find.assert_not_called()

    def test_list_or_dropdown_still_scrolls_without_recorded_scroll(self):
        r = self.resolver(False)
        r._t_scroll({"container": {"role": "list"}, "name": "Germany"}, {}, {"attempt": 1})
        r.scrollfinder.find.assert_called_once()

    def test_recorded_scroll_allows_it(self):
        r = self.resolver(True)
        r._t_scroll({"container": {"role": "table"}, "name": "G14"}, {}, {"attempt": 1})
        r.scrollfinder.find.assert_called_once()


class ExcelMinimalScroll(unittest.TestCase):
    class Win:
        def __init__(self, top, rows, left=1, cols=10):
            self.ScrollRow, self.ScrollColumn = top, left
            self.VisibleRange = mock.Mock(Row=top, Column=left, Rows=mock.Mock(Count=rows), Columns=mock.Mock(Count=cols))

    def test_below_scrolls_just_enough(self):
        w = self.Win(1, 20)
        excel_com._scroll_minimally(w, mock.Mock(Row=25, Column=3))
        self.assertEqual((w.ScrollRow, w.ScrollColumn), (6, 1))        # cell becomes the last visible row, columns untouched

    def test_above_and_left(self):
        w = self.Win(50, 20, left=8)
        excel_com._scroll_minimally(w, mock.Mock(Row=10, Column=2))
        self.assertEqual((w.ScrollRow, w.ScrollColumn), (10, 2))


class NoOcrNeededForTypedValues(unittest.TestCase):
    from tests.test_ocr_hybrid import TARGET, WIN, _Resolver

    def validator(self, opts=None):
        from core.playback.validators import Validator
        return Validator(self._Resolver(dict(self.TARGET)), opts or {})

    def test_formula_bar_reads_the_cell_without_com_or_ocr(self):
        v = self.validator()
        with mock.patch.object(excel_com, "read_cell", return_value=None), \
                mock.patch("core.playback.validators.winenv.focused_element", return_value={}), \
                mock.patch("core.playback.validators.winenv.excel_formula_bar", return_value=(self.TARGET["name"], "2")):
            r = v.evaluate({"type": "text_contains", "expected": "2", "target": self.TARGET, "timeout_s": 0}, self.WIN)
        self.assertEqual(r["status"], "passed", r)
        self.assertIn("formula bar", r["detail"])

    def test_formula_bar_of_another_cell_is_not_used(self):
        v = self.validator({"use_ocr": False})
        with mock.patch.object(excel_com, "read_cell", return_value=None), \
                mock.patch("core.playback.validators.winenv.focused_element", return_value={}), \
                mock.patch("core.playback.validators.winenv.excel_formula_bar", return_value=("Z99", "2")):
            text, _ = next(v._text_candidates(self.TARGET, self.WIN))
        self.assertIsNone(text)

    def test_short_value_ocr_mismatch_is_not_a_failure(self):
        v = self.validator()
        reads = iter([("1", "OCR")])
        with mock.patch.object(v, "_text_candidates", return_value=reads):
            r = v.evaluate({"type": "text_contains", "expected": "2", "target": self.TARGET, "timeout_s": 0}, self.WIN)
        self.assertEqual(r["status"], "skipped", r)
        self.assertIn("not verified", r["detail"])

    def test_ocr_match_still_passes_and_setting_can_restore_the_old_strictness(self):
        v = self.validator()
        with mock.patch.object(v, "_text_candidates", return_value=iter([("2", "OCR")])):
            self.assertEqual(v.evaluate({"type": "text_contains", "expected": "2", "target": self.TARGET, "timeout_s": 0},
                                        self.WIN)["status"], "passed")
        v = self.validator({"ocr_short_mismatch": "fail"})
        with mock.patch.object(v, "_text_candidates", return_value=iter([("1", "OCR")])):
            self.assertEqual(v.evaluate({"type": "text_contains", "expected": "2", "target": self.TARGET, "timeout_s": 0},
                                        self.WIN)["status"], "failed")

    def test_exact_source_mismatch_still_fails(self):
        v = self.validator()
        with mock.patch.object(v, "_text_candidates", return_value=iter([("1", "Excel")])):
            self.assertEqual(v.evaluate({"type": "text_contains", "expected": "2", "target": self.TARGET, "timeout_s": 0},
                                        self.WIN)["status"], "failed")


class AnyApplicationText(unittest.TestCase):
    """The same ladder for every application, not only Excel."""
    TGT = {"name": "Quantity", "role": "Edit", "rect": [100, 100, 200, 124], "rel": [0.5, 0.5]}
    WIN = {"title": "Order form", "process": "orders.exe"}

    def validator(self, found=True):
        from core.playback.validators import Validator
        from tests.test_ocr_hybrid import _Resolver
        return Validator(_Resolver(None if not found else dict(self.TGT)), {"use_ocr": False})

    def test_focused_field_answers_for_any_app(self):
        v = self.validator()
        with mock.patch("core.playback.validators.winenv.focused_element",
                        return_value={"name": "Quantity", "role": "Edit", "value": "2", "rect": [100, 100, 200, 124]}):
            self.assertEqual(next(v._text_candidates({**self.TGT}, self.WIN)), ("2", "focused field"))

    def test_other_focused_control_is_ignored(self):
        v = self.validator()
        with mock.patch("core.playback.validators.winenv.focused_element",
                        return_value={"name": "Price", "role": "Edit", "value": "9", "rect": [300, 300, 400, 324]}):
            text, _ = next(v._text_candidates({**self.TGT}, self.WIN))
        self.assertNotEqual(text, "9")

    def test_classic_control_text_is_used_before_ocr(self):
        from core.playback.validators import Validator
        from tests.test_ocr_hybrid import _Resolver
        v = Validator(_Resolver({**self.TGT}), {"use_ocr": True})
        with mock.patch("core.playback.validators.winenv.focused_element", return_value={}), \
                mock.patch("core.playback.validators.winenv.element_at", return_value={}), \
                mock.patch("core.playback.validators.winenv.win32_text_at", return_value="2"):
            self.assertEqual(next(v._text_candidates({"rect": [100, 100, 200, 124]}, self.WIN)),
                             ("2", "Windows control text"))

    def test_short_value_policy_is_not_excel_specific(self):
        v = self.validator()
        with mock.patch.object(v, "_text_candidates", return_value=iter([("1", "OCR")])):
            r = v.evaluate({"type": "text_equals", "expected": "2", "target": self.TGT, "timeout_s": 0}, self.WIN)
        self.assertEqual(r["status"], "skipped")


def _screen():
    rng = np.random.default_rng(3)
    base = rng.integers(0, 255, (500, 800, 3), dtype=np.uint8)
    return base


class VisualNeighbours(unittest.TestCase):
    def test_capture_keeps_textured_crops_with_offsets(self):
        from core.vision import visual_neighbors as vn
        fr = _screen()
        fr[150:350, 300:500] = 200                                  # a blank area: must be skipped
        items = vn.capture(fr, (0, 0), 400, 250)
        self.assertTrue(items)
        for it in items:
            self.assertEqual(it["img"].shape[:2], (36, 72))
            self.assertGreaterEqual(float(it["img"].std()), vn.MIN_TEXTURE)

    def test_crops_outside_the_window_are_not_taken(self):
        from core.vision import visual_neighbors as vn
        items = vn.capture(_screen(), (0, 0), 400, 250, bounds=[350, 200, 450, 300])
        self.assertEqual(items, [])

    def test_votes_agree_on_the_click_point(self):
        from core.vision import visual_neighbors as vn
        found = [(510, 250, 110, 0), (400, 302, 0, 52), (700, 100, -110, 0)]     # third one is a wrong match
        x, y, votes, spread = vn.vote(found)
        self.assertEqual((x, y, votes), (400, 250, 2))
        self.assertLess(spread, 2)

    def test_resolver_finds_the_click_from_pictures_alone(self):
        import tempfile
        from core.playback.resolver import Resolver
        from core.settings import validate
        from core.system.imageio import imwrite
        from core.vision import visual_neighbors as vn
        screen = _screen()
        items = vn.capture(screen, (0, 0), 400, 250)
        self.assertGreaterEqual(len(items), 2)
        with tempfile.TemporaryDirectory() as d:
            nbs = []
            for k, it in enumerate(items):
                (Path(d) / "assets").mkdir(exist_ok=True)
                imwrite(Path(d) / f"assets/n{k}.png", it["img"])
                nbs.append({"path": f"assets/n{k}.png", "dx": it["dx"], "dy": it["dy"], "size": it["size"]})
            moved = np.roll(screen, (30, 50), axis=(0, 1))          # the whole window moved by (50, 30)
            moved[230:270, 380:420] = 0                              # and the element itself looks different now
            r = Resolver(Path(d), validate({}), grab=lambda: (moved, (0, 0)))
            res = r.resolve_once({"visual_neighbors": nbs, "x": 400, "y": 250}, {}, only=("nbimg",))
        self.assertIsNotNone(res)
        self.assertEqual(res.method, "neighbour-image")
        self.assertLessEqual(abs(res.x - 450) + abs(res.y - 280), 3)


class TesterInputs(unittest.TestCase):
    def test_collect_write_load_apply(self):
        from core import inputs
        test = {"name": "t", "steps": [
            {"id": 1, "type": "click", "description": "Click 'Qty'", "target": {"name": "Qty", "templates": {"c": 1}}},
            {"id": 2, "type": "type", "description": "Type '2' into 'Qty'", "params": {"text": "2"}, "target": {"name": "Qty"}},
            {"id": 3, "type": "type", "params": {"text": "", "redacted": True}},
            {"id": 4, "type": "click", "target": {"x": 5, "y": 5}}]}
        plan = inputs.collect(test)
        self.assertEqual([i["step"] for i in plan["inputs"]], [2, 3])
        self.assertEqual(plan["weak"], [4])
        self.assertEqual(plan["clicks"][0]["found_by"], "name")
        with tempfile.TemporaryDirectory() as d:
            path = inputs.write(d, test)
            doc = json.loads(path.read_text())
            self.assertEqual(doc["values"], {"2": "2"})              # the secret is never written
            doc["values"]["2"] = "7"
            path.write_text(json.dumps(doc))
            over = inputs.load(d)
            self.assertEqual(over, {2: "7"})
            self.assertEqual(inputs.apply(test, over), 1)
        self.assertEqual(test["steps"][1]["params"]["text"], "7")
        self.assertEqual(test["steps"][2]["params"]["redacted"], True)

    def test_ask_keeps_recorded_value_on_enter(self):
        from core import inputs
        plan = {"inputs": [{"step": 2, "label": "Type", "value": "2", "secret": False},
                           {"step": 3, "label": "Pwd", "value": "", "secret": True}]}
        self.assertEqual(inputs.ask(plan, input_fn=lambda q: ""), {})
        self.assertEqual(inputs.ask(plan, input_fn=lambda q: "9"), {2: "9"})


class TypingFocusAndScrollNotches(unittest.TestCase):
    def player(self, steps):
        from core.playback.player import Player
        from core.settings import validate
        p = Player.__new__(Player)
        p.dry_run = False
        p.opts = validate({"scroll_notch_ms": 0, "engine_profile": "strict"})
        p.test = {"steps": steps}
        p.backend = mock.Mock()
        p.should_stop = lambda: False
        return p

    TG = {"name": "Qty", "role": "Edit", "x": 10, "y": 10, "rect": [0, 0, 50, 20]}

    def run_guard(self, steps, focused):
        p = self.player(steps)
        p.opts["strict_targeting"] = True
        p._resolve = lambda tg, st, tag: mock.Mock(x=10, y=10)
        res = {}
        seq = focused if isinstance(focused, list) else None
        kw = {"side_effect": seq + [seq[-1]] * 5} if seq else {"return_value": focused}
        with mock.patch("core.playback.player.winenv.focused_element", **kw):
            p._ensure_typing_focus(steps[-1], res)
        return p, res

    def test_refocuses_when_focus_is_elsewhere(self):
        steps = [{"id": 1, "type": "click", "target": self.TG}, {"id": 2, "type": "type", "target": self.TG, "window": {}}]
        other, mine = {"name": "Other", "role": "Edit", "rect": [200, 200, 300, 220]}, {"name": "Qty", "role": "Edit", "rect": [0, 0, 50, 20]}
        p, res = self.run_guard(steps, [other, mine])          # focus really moves to the field after the click
        p.backend.click.assert_called_once()
        self.assertIn("refocused", res)

    def test_refuses_to_type_when_the_field_cannot_take_focus(self):
        from core.automation.errors import WrongTarget
        steps = [{"id": 1, "type": "click", "target": self.TG}, {"id": 2, "type": "type", "target": self.TG, "window": {}}]
        with self.assertRaises(WrongTarget):
            self.run_guard(steps, {"name": "Other", "role": "Edit", "rect": [200, 200, 300, 220]})

    def test_no_click_when_focus_is_right_or_unknown(self):
        steps = [{"id": 1, "type": "click", "target": self.TG}, {"id": 2, "type": "type", "target": self.TG, "window": {}}]
        for fe in ({"name": "Qty", "role": "Edit", "rect": [0, 0, 50, 20]}, {}):
            p, res = self.run_guard(steps, fe)
            p.backend.click.assert_not_called()

    def test_tab_through_forms_is_never_disturbed(self):
        steps = [{"id": 1, "type": "click", "target": self.TG}, {"id": 2, "type": "type", "target": self.TG, "window": {}},
                 {"id": 3, "type": "key", "params": {"key": "tab"}},
                 {"id": 4, "type": "type", "target": self.TG, "window": {}}]
        p, res = self.run_guard(steps, {"name": "Other", "role": "Edit", "rect": [200, 200, 300, 220]})
        p.backend.click.assert_not_called()

    def test_button_target_is_not_a_field(self):
        tg = {**self.TG, "role": "Button"}
        steps = [{"id": 1, "type": "click", "target": tg}, {"id": 2, "type": "type", "target": tg, "window": {}}]
        p, res = self.run_guard(steps, {"name": "Other", "role": "Edit", "rect": [200, 200, 300, 220]})
        p.backend.click.assert_not_called()

    def test_scroll_is_replayed_notch_by_notch(self):
        p = self.player([])
        p._scroll_notches(5, 5, 0, -7)
        self.assertEqual(p.backend.scroll.call_count, 7)
        self.assertTrue(all(c.args[3] == -1 for c in p.backend.scroll.call_args_list))
        p.backend.reset_mock()
        p._scroll_notches(5, 5, 2, 0)
        self.assertEqual([c.args[2:] for c in p.backend.scroll.call_args_list], [(1, 0), (1, 0)])

    def test_pyautogui_backend_sends_whole_notches_on_windows(self):
        from core.playback import backend
        b = backend.PyAutoGUIBackend.__new__(backend.PyAutoGUIBackend)
        b.pyautogui = mock.Mock()
        b.move = lambda x, y: None
        with mock.patch.object(backend.sys, "platform", "win32"):
            b.scroll(1, 1, 0, -3)
        b.pyautogui.scroll.assert_called_once_with(-360)


class ChordsAndContext(unittest.TestCase):
    def test_ctrl_click_and_ctrl_drag_keep_their_modifiers(self):
        from core.recorder.builder import RawEvent, StepBuilder
        out = []
        b = StepBuilder(out.append)
        ev = lambda k, t, x=10, y=10, key="": RawEvent(kind=k, t=t, x=x, y=y, key=key)  # noqa: E731
        for e in (ev("key_down", 0.0, key="ctrl"), ev("mouse_down", 0.1), ev("mouse_up", 0.15),
                  ev("mouse_down", 3.0, 50, 50), ev("mouse_up", 3.4, 300, 300), ev("key_up", 3.5, key="ctrl"),
                  ev("mouse_down", 5.0), ev("mouse_up", 5.05)):
            b.feed(e)
        b.flush_all()
        self.assertEqual(out[0]["modifiers"], ["ctrl"])
        self.assertEqual(out[1]["type"], "drag_drop")
        self.assertEqual(out[1]["modifiers"], ["ctrl"])
        self.assertEqual(out[2]["modifiers"], [])

    def test_modifiers_land_in_step_params_and_window_kind_is_recorded(self):
        from core.recorder.recorder import _window_record
        self.assertEqual(_window_record({"title": "Open", "process": "x.exe", "kind": "dialog"})["kind"], "dialog")
        self.assertTrue(_window_record({"title": "", "process": "x.exe", "kind": "menu"})["popup"])
        self.assertNotIn("kind", _window_record({"title": "Main", "process": "x.exe", "kind": "main"}))

    def test_unnamed_control_is_found_by_its_tooltip(self):
        from core.plugins.base_plugin import Plugin
        with mock.patch("core.plugins.base_plugin.winenv.find_by_help", return_value={"rect": [1, 1, 2, 2]}) as f:
            r = Plugin().find_element_native({"help": "Save all", "role": "Button", "rect": [0, 0, 10, 10]}, {"title": "App"})
        self.assertEqual(r, {"rect": [1, 1, 2, 2]})
        f.assert_called_once()

    def test_tooltip_windows_are_noise_for_the_recorder(self):
        from core.system import winenv
        self.assertEqual(winenv.window_kind(0), "main")
        self.assertEqual(winenv.tooltip_text(), "")


if __name__ == "__main__":
    unittest.main()
