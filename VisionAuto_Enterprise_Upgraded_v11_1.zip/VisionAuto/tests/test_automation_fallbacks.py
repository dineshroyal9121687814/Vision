import unittest

from core.automation.errors import AmbiguousTarget
import tempfile
import types
from pathlib import Path
from unittest import mock

import cv2
import numpy as np

from core.ocr import ocr_engine
from core.playback.backend import DryRunBackend, PyAutoGUIBackend, create_backend
from core.playback.resolver import Resolver
from core.self_healing.healer import HealResult
from core.system.imageio import imwrite
from core.system import winenv
from core.system.winenv import _native_candidates_ambiguous
from core.vision.locator import Locator, LocatorResult
from tests.helpers import make_frame


class OcrFallbackTests(unittest.TestCase):
    def test_fuzzy_ocr_match_and_scaled_coordinates(self):
        frame = np.zeros((20, 40, 3), dtype=np.uint8)
        result = ([(10, 10), (30, 10), (30, 16), (10, 16)], "Setings", 0.95)
        with mock.patch.object(ocr_engine, "_results", return_value=[result]):
            match = ocr_engine.find_text(frame, "Settings")
        self.assertTrue(match.found)
        self.assertEqual((match.x, match.y), (20, 13))
        self.assertGreater(match.confidence, 0.8)


class InputBackendTests(unittest.TestCase):
    def test_dry_run_remains_explicit_and_deterministic(self):
        self.assertIsInstance(DryRunBackend(), DryRunBackend)

    def test_pyautogui_backend_is_available_when_requested(self):
        fake = mock.Mock()
        with mock.patch.dict("sys.modules", {"pyautogui": fake}):
            backend = create_backend("pyautogui")
        self.assertIsInstance(backend, PyAutoGUIBackend)
        backend.click(10, 20)
        fake.click.assert_called_once_with(button="left", clicks=1, interval=0.05)

    def test_near_duplicate_native_candidates_are_declined(self):
        self.assertTrue(_native_candidates_ambiguous([100, 112]))
        self.assertFalse(_native_candidates_ambiguous([100, 140]))

    def test_missing_named_window_does_not_search_the_foreground_window(self):
        desktop = mock.Mock()
        desktop.windows.return_value = []
        with mock.patch.object(winenv, "IS_WINDOWS", True), \
             mock.patch.dict("sys.modules", {"pywinauto": types.SimpleNamespace(Desktop=lambda **_kw: desktop)}), \
             mock.patch.object(winenv, "foreground_window") as foreground:
            result = winenv.find_native("Missing recorded app", name="Save")
        self.assertIsNone(result)
        foreground.assert_not_called()

    def test_named_window_ui_element_in_background_is_not_a_click_target(self):
        background = mock.Mock()
        background.handle = 42
        desktop = mock.Mock()
        desktop.windows.return_value = [background]
        with mock.patch.object(winenv, "IS_WINDOWS", True), \
             mock.patch.dict("sys.modules", {"pywinauto": types.SimpleNamespace(Desktop=lambda **_kw: desktop)}), \
             mock.patch.object(winenv, "foreground_window", return_value={"hwnd": 7}):
            result = winenv.find_native("Notepad", name="Save")
        self.assertIsNone(result)
        background.descendants.assert_not_called()


class TemplateScaleTests(unittest.TestCase):
    def test_scaled_match_maps_the_recorded_click_offset(self):
        rng = np.random.default_rng(77)
        template = rng.integers(0, 256, (24, 32, 3), dtype=np.uint8)
        scaled = cv2.resize(template, (40, 30), interpolation=cv2.INTER_LINEAR)
        screen = np.full((140, 180, 3), 16, dtype=np.uint8)
        left, top = 71, 43
        screen[top:top + 30, left:left + 40] = scaled

        match = Locator().find_by_template(screen, template)
        self.assertTrue(match.found)
        self.assertAlmostEqual(match.scale, 1.25)
        x, y = Resolver._template_target(match.x, match.y, (9, 6), template.shape[:2], match.scale, (0, 0))
        self.assertEqual((x, y), (left + 11, top + 8))

    def test_repeated_identical_templates_are_flagged_as_ambiguous(self):
        rng = np.random.default_rng(202)
        template = rng.integers(0, 256, (28, 34, 3), dtype=np.uint8)
        screen = np.full((140, 220, 3), 12, dtype=np.uint8)
        screen[20:48, 25:59] = template
        screen[80:108, 145:179] = template

        match = Locator().find_by_template(screen, template)
        self.assertFalse(match.found)
        self.assertTrue(match.ambiguous)
        self.assertGreaterEqual(match.second_confidence, Locator.TEMPLATE_THRESHOLD)

    def test_resolver_does_not_fall_through_to_visual_only_recovery_on_ambiguity(self):
        screen = make_frame(1000, 700, seed=3)
        template = screen[200:500, 350:650].copy()
        screen[100:400, 650:950] = template
        with tempfile.TemporaryDirectory() as tmp:
            assets = Path(tmp) / "assets"
            assets.mkdir()
            imwrite(assets / "target.png", template)
            # The recorded spot (100, 650) is nowhere near either look-alike: neither can be preferred, so decline.
            target = {"x": 100, "y": 650, "name": "repeated target", "templates": {
                "crop300": {"path": "assets/target.png", "click": [150, 150]}}}
            resolver = Resolver(tmp, {"use_native": False, "use_ocr": False, "use_ai": False},
                                grab=lambda: (screen, (0, 0)))
            # Strict targeting: ambiguity is an explicit failure (AmbiguousTarget), never "fall through and click".
            with self.assertRaises(AmbiguousTarget):
                resolver.resolve_once(target, {}, attempt=1)
            # Both look-alikes inside the same search area around the recorded spot: still ambiguous.
            near_both = dict(target, x=650, y=300, ocr_radius=400)
            with self.assertRaises(AmbiguousTarget):
                resolver.resolve_once(near_both, {}, attempt=1)

    def test_stored_location_disambiguates_look_alikes_by_searching_near_it_first(self):
        screen = make_frame(1000, 700, seed=3)
        template = screen[200:500, 350:650].copy()
        screen[100:400, 650:950] = template                      # a second, identical element far to the right
        with tempfile.TemporaryDirectory() as tmp:
            assets = Path(tmp) / "assets"
            assets.mkdir()
            imwrite(assets / "target.png", template)
            target = {"x": 500, "y": 350, "name": "repeated target", "templates": {
                "crop300": {"path": "assets/target.png", "click": [150, 150]}}}
            resolver = Resolver(tmp, {"use_native": False, "use_ocr": False, "use_ai": False},
                                grab=lambda: (screen, (0, 0)))
            found = resolver.resolve_once(target, {}, attempt=1)
            self.assertEqual((found.x, found.y, found.evidence["stage"]), (500, 350, "near"))
            screen_only = dict(target, search_scope="screen_only")        # whole screen: the recorded spot still decides
            found = resolver.resolve_once(screen_only, {}, attempt=1)
            self.assertEqual((found.x, found.y), (500, 350))
            self.assertIn("recorded position", found.evidence["disambiguated_by"])
            no_prior = {k: v for k, v in screen_only.items() if k not in ("x", "y")}   # nothing recorded: genuinely ambiguous
            with self.assertRaises(AmbiguousTarget):
                resolver.resolve_once(no_prior, {}, attempt=1)

    def test_resolver_rejects_low_confidence_feature_match(self):
        frame = make_frame(400, 400, seed=19)
        template = frame[100:300, 100:300].copy()
        resolver = Resolver(None, {"use_native": False, "use_ocr": False, "use_ai": False},
                            grab=lambda: (frame, (0, 0)))
        with mock.patch.object(resolver, "_tpl", side_effect=[(template, (100, 100)), (template, (100, 100))]), \
             mock.patch.object(resolver.locator, "find_by_template", return_value=LocatorResult(False)), \
             mock.patch.object(resolver.locator, "find_point_by_features",
                               return_value=LocatorResult(True, 100, 100, 0.25, "orb")), \
             mock.patch.object(resolver.healer, "heal", return_value=HealResult(False)):
            found = resolver.resolve_once({"x": 200, "y": 200}, {}, attempt=1)
        self.assertIsNone(found)


if __name__ == "__main__":
    unittest.main()
