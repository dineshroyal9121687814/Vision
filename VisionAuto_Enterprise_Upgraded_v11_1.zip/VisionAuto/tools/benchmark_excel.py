"""Benchmark: old vs new data entry. Run:  python -m tools.benchmark_excel [cells]

1. File level  - 'old' = open/set one cell/save per cell (what cell-by-cell automation costs), 'new' = one open, one save.
2. Playback    - a recorded 'type, Tab, type, Tab ...' sequence with the settle wait (old) vs fast_entry (new) vs one
                 fill_table step. Uses a synthetic screen and a recording backend, so it measures the *engine overhead*
                 per step; real Excel adds its own latency to every keystroke, which fast_entry/fill_table also avoid.
"""
from __future__ import annotations

import os
import sys
import tempfile
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
os.environ["VISIONAUTO_HOME"] = tempfile.mkdtemp(prefix="va_bench_")

import numpy as np  # noqa: E402

from core import excel_io  # noqa: E402
from core.playback.backend import DryRunBackend  # noqa: E402
from core.playback.player import Player  # noqa: E402


def file_level(n_cells: int) -> dict:
    d = Path(tempfile.mkdtemp(prefix="va_bx_"))
    from openpyxl import Workbook, load_workbook
    cols = 5
    rows = [[f"r{r}c{c}" for c in range(cols)] for r in range(n_cells // cols)]
    # old: one open + one save per cell
    p = d / "old.xlsx"
    Workbook().save(p)
    t = time.perf_counter()
    for r, row in enumerate(rows, 1):
        for c, v in enumerate(row, 1):
            wb = load_workbook(p)
            wb.active.cell(row=r, column=c, value=v)
            wb.save(p)
    old = time.perf_counter() - t
    t = time.perf_counter()
    excel_io.write_table(d / "new.xlsx", rows)
    new_ = time.perf_counter() - t
    same = excel_io.read_table(d / "new.xlsx") == excel_io.read_table(p)
    return {"cells": len(rows) * cols, "old_s": old, "new_s": new_, "speedup": old / new_ if new_ else 0, "identical_content": same}


def playback(n_cells: int) -> dict:
    frame = np.random.default_rng(1).integers(0, 255, (300, 400, 3), dtype=np.uint8)
    out = {}
    typing = []
    for i in range(n_cells):
        typing += [{"id": 2 * i + 1, "type": "type", "params": {"text": f"v{i}"}, "window": {}, "validations": []},
                   {"id": 2 * i + 2, "type": "key", "params": {"key": "tab"}, "window": {}, "validations": []}]
    for label, opts, steps in (
            ("old (settle after every step)", {"settle_wait": True, "fast_entry": False}, typing),
            ("new fast_entry", {"settle_wait": True, "fast_entry": True}, typing),
            ("new fill_table (1 step)", {"settle_wait": True, "fast_entry": True},
             [{"id": 1, "type": "fill_table", "window": {}, "validations": [],
               "params": {"rows": [[f"v{i}" for i in range(n_cells)]]}}])):
        p = Player({"name": "bench", "steps": steps}, {"use_native": False, "use_ocr": False, "use_ai": False, "retry_enabled": False,
                                                       **opts}, backend=DryRunBackend(), grab=lambda: (frame, (0, 0)))
        from core.system import clipboard

        class Clip:
            t = ""
            def get(self): return self.t
            def set(self, t): self.t = t
        clipboard._backend = Clip()
        t = time.perf_counter()
        run = p.run()
        out[label] = {"seconds": round(time.perf_counter() - t, 2), "status": run["status"], "steps": len(steps)}
    return out


if __name__ == "__main__":
    n = int(sys.argv[1]) if len(sys.argv) > 1 else 200
    fl = file_level(n)
    print(f"FILE LEVEL  {fl['cells']} cells: old {fl['old_s']:.2f}s  new {fl['new_s']:.3f}s  speed-up x{fl['speedup']:.0f}  identical content: {fl['identical_content']}")
    big = [[i, f"user {i}", i * 1.5, "x"] for i in range(100_000)]
    d = Path(tempfile.mkdtemp())
    t = time.perf_counter()
    excel_io.write_table(d / "big.xlsx", big)
    w = time.perf_counter() - t
    t = time.perf_counter()
    back = excel_io.read_table(d / "big.xlsx")
    print(f"LARGE       400,000 cells written in {w:.2f}s, read back in {time.perf_counter() - t:.2f}s ({len(back)} rows)")
    for k, v in playback(n).items():
        print(f"PLAYBACK    {k:32s} {v['seconds']:7.2f}s  ({v['steps']} steps, {v['status']})")
