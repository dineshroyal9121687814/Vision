"""VisionAuto Windows E2E fixture application (PySide6).

Two top-level windows with deliberately AMBIGUOUS content so the engine's safety rules can be proved on a real desktop:

  Window "VA Fixture A"   - left/right panes that BOTH contain a button named "Save" (ids save_left / save_right),
                            text fields (username, notes), a combo box (color), a check box (agree), radio buttons,
                            a source list and a destination list (drag between containers), a file drop zone,
                            a "Browse..." button (native file dialog), a modal dialog button, a status label.
  Window "VA Fixture B"   - a second application window with its own list that accepts drops (cross-window drag)
                            and a second "Save" button.

Every outcome is written to the status label AND to the JSON file given as argv[1] (read by the test, so assertions
never depend on screen scraping).   Run:  python tools/e2e_fixture/fixture_app.py out.json
"""
import json
import sys

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QApplication, QButtonGroup, QCheckBox, QComboBox, QDialog, QFileDialog, QGroupBox, QHBoxLayout,
                               QLabel, QLineEdit, QListWidget, QMainWindow, QPushButton, QRadioButton, QVBoxLayout, QWidget)

OUT = sys.argv[1] if len(sys.argv) > 1 else "fixture_state.json"
STATE: dict = {"events": []}


def record(key, value):
    STATE[key] = value
    STATE["events"].append([key, value])
    with open(OUT, "w", encoding="utf-8") as f:
        json.dump(STATE, f)


def named(w, name, text=None):
    w.setObjectName(name)
    w.setAccessibleName(text if text is not None else name)
    return w


class DropList(QListWidget):
    def __init__(self, name, accept_files=False):
        super().__init__()
        named(self, name)
        self.setAcceptDrops(True)
        self.setDragEnabled(True)
        self.setDefaultDropAction(Qt.MoveAction)
        self.accept_files = accept_files

    def dragEnterEvent(self, e):
        e.acceptProposedAction()

    def dragMoveEvent(self, e):
        e.acceptProposedAction()

    def dropEvent(self, e):
        if e.mimeData().hasUrls():
            for u in e.mimeData().urls():
                self.addItem(u.toLocalFile())
            record(f"{self.objectName()}_files", [self.item(i).text() for i in range(self.count())])
            e.acceptProposedAction()
        else:
            super().dropEvent(e)
            record(f"{self.objectName()}_items", [self.item(i).text() for i in range(self.count())])


class DropZone(QLabel):
    def __init__(self):
        super().__init__("Drop files here")
        named(self, "dropzone", "Drop files here")
        self.setAcceptDrops(True)
        self.setMinimumHeight(60)
        self.setFrameShape(QLabel.Box)

    def dragEnterEvent(self, e):
        e.acceptProposedAction()

    def dropEvent(self, e):
        names = [u.toLocalFile() for u in e.mimeData().urls()]
        self.setText("Uploaded: " + ", ".join(n.split("/")[-1].split("\\")[-1] for n in names))
        record("dropzone", names)


def pane(title, side):
    box = named(QGroupBox(title), f"pane_{side}", title)
    lay = QVBoxLayout(box)
    btn = named(QPushButton("Save"), f"save_{side}", "Save")
    btn.clicked.connect(lambda: record("saved", side))
    lay.addWidget(btn)
    return box


class WindowA(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("VA Fixture A")
        self.resize(900, 640)
        root = QWidget()
        self.setCentralWidget(root)
        grid = QVBoxLayout(root)
        row = QHBoxLayout()
        row.addWidget(pane("Left", "left"))
        row.addWidget(pane("Right", "right"))
        grid.addLayout(row)
        self.username = named(QLineEdit(), "username", "Username")
        self.notes = named(QLineEdit(), "notes", "Notes")
        self.username.textChanged.connect(lambda t: record("username", t))
        self.notes.textChanged.connect(lambda t: record("notes", t))
        grid.addWidget(self.username)
        grid.addWidget(self.notes)
        self.color = named(QComboBox(), "color", "Color")
        self.color.addItems(["Red", "Green", "Greenish", "Blue"])                   # Green vs Greenish: exact option matters
        self.color.currentTextChanged.connect(lambda t: record("color", t))
        grid.addWidget(self.color)
        self.agree = named(QCheckBox("I agree"), "agree", "I agree")
        self.agree.toggled.connect(lambda v: record("agree", v))
        grid.addWidget(self.agree)
        group = QButtonGroup(self)
        for n in ("Small", "Medium", "Large"):
            rb = named(QRadioButton(n), f"size_{n.lower()}", n)
            rb.toggled.connect(lambda v, n=n: v and record("size", n))
            group.addButton(rb)
            grid.addWidget(rb)
        lists = QHBoxLayout()
        self.src = DropList("source_list")
        self.dst = DropList("dest_list")
        self.src.addItems(["alpha", "beta", "gamma"])
        lists.addWidget(self.src)
        lists.addWidget(self.dst)
        grid.addLayout(lists)
        grid.addWidget(DropZone())
        browse = named(QPushButton("Browse..."), "browse", "Browse...")
        browse.clicked.connect(self.browse)
        grid.addWidget(browse)
        modal = named(QPushButton("Open dialog"), "open_dialog", "Open dialog")
        modal.clicked.connect(self.modal)
        grid.addWidget(modal)
        self.status = named(QLabel("Ready"), "status", "Ready")
        grid.addWidget(self.status)

    def browse(self):
        path, _ = QFileDialog.getOpenFileName(self, "Open")
        if path:
            self.status.setText("Selected: " + path.split("/")[-1])
            record("browse", path)

    def modal(self):
        d = QDialog(self)
        d.setWindowTitle("VA Modal")
        lay = QVBoxLayout(d)
        ok = named(QPushButton("Confirm"), "modal_confirm", "Confirm")
        ok.clicked.connect(lambda: (record("modal", "confirmed"), d.accept()))
        lay.addWidget(ok)
        d.exec()


class WindowB(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("VA Fixture B")
        self.resize(420, 400)
        root = QWidget()
        self.setCentralWidget(root)
        lay = QVBoxLayout(root)
        lay.addWidget(DropList("b_list", accept_files=True))
        save = named(QPushButton("Save"), "save_b", "Save")
        save.clicked.connect(lambda: record("saved", "b"))
        lay.addWidget(save)


if __name__ == "__main__":
    app = QApplication(sys.argv)
    a, b = WindowA(), WindowB()
    a.move(40, 40)
    b.move(1000, 40)
    a.show()
    b.show()
    record("started", True)
    sys.exit(app.exec())
