#!/usr/bin/env sh
# Launch VisionAuto (desktop automation targets are Windows; the app and the tests also start elsewhere).
cd "$(dirname "$0")" || exit 1
[ -d .venv ] || { python3 -m venv .venv && .venv/bin/python -m pip install -r requirements.txt; } || exit 1
exec .venv/bin/python -m app
