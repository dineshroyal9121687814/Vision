@echo off
rem Launch VisionAuto (creates .venv and installs requirements on first run).
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (
  py -3 -m venv .venv || goto :err
  .venv\Scripts\python -m pip install -r requirements.txt || goto :err
)
.venv\Scripts\python -m app
exit /b %errorlevel%
:err
echo Setup failed. Install Python 3.10+ and run again.
pause
exit /b 1
