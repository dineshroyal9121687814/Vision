# Excel launch, accuracy and regression fixes - report

**Verification level: unit tests with fakes only (579 pass; the same 2 unrelated `test_open_app.py` tests failed before any change).
Nothing here was run against real Excel or a real Windows desktop** - this environment is Linux. Real-Excel scripts are in
`tests/windows_e2e/test_excel_e2e.py` (not run). Do not treat Excel launching as proven until they pass on your machine.

## 0. The Calculator failure in your screenshot (caused by my previous upgrade)
`Open 'Calculator'` -> *"13 windows match process explorer.exe"*. Root cause: the strict window-targeting I added ran its
"which window is this step in?" check **before** `open_app`, using the *recorded* window (title empty, process `explorer.exe` =
the Start/launcher host). 13 explorer windows matched -> ambiguity -> step failed before anything launched.
Fix (`core/playback/player.py::_ensure_window`): launch steps (`open_app`, `launch_app`, `excel_save`, `excel_close`) skip the
window pre-check because they create/own their window; and a legacy recording with only a process name (no title, nothing chosen
by the user) is no longer enforced - exactly the old behaviour. An *explicitly* chosen window (match mode / Main Window) stays strict.
Tests: `OpenAppRegression` (3).

## 1. Excel launch - root causes found in the code
| # | Cause | Where | Fix |
|---|---|---|---|
| E1 | `subprocess.Popen(value.split())` splits `C:\Program Files\Microsoft Office\root\Office16\EXCEL.EXE` into `C:\Program` + `Files\...` -> FileNotFoundError | `launcher.start_method`, `plan` policy check | `launcher.split_command` keeps paths with spaces whole (also handles quoted exe + switches) |
| E2 | A bare `excel.exe` goes through CreateProcess, which ignores the *App Paths* registry key Office installs itself under -> only worked if Office was on PATH | same | `FileNotFoundError` on a bare name falls back to `os.startfile` (ShellExecute); `excel_launch.find_excel_exe` reads App Paths then Program Files\Office* |
| E3 | Excel was not in the known-apps table at all | `launcher.KNOWN_APPS` | added (`excel.exe`, alias "Microsoft Excel") |
| E4 | "Success" = any window whose title contains "Excel" exists (Start screen, splash, a browser tab) | `launcher.wait_for_window` | new `core/system/excel_launch.py`: success only when COM answers **and** `Application.Ready` **and** the requested workbook is open **and** its own window HWND (`Window.Hwnd`) is in front |
| E5 | Running Excel instance never reused; workbook chosen by title | - | attach via `GetActiveObject`; workbook matched by **full path**; opened in the running instance if absent; Protected View is reported, never silently bypassed (`enable_editing: true` to opt in) |
| E6 | Launching a file used the exe + split path | - | `Popen([exe, path])` list form; missing file / non-Excel type fail before anything starts |
New steps: `open_app` with `params.path` (routes Excel to the new launcher), `excel_save` (Save / SaveAs, checks `Saved`), `excel_close`
(explicit `save` true/false so no "Save changes?" dialog is left behind; verifies the workbook is gone).
Tests: `LauncherFixes` (4), `ExcelLaunch` (10).

## 2. Recorded actions executed accurately
* **Nothing is silently skipped.** The default `scroll_mode` was `adaptive`, which *skipped* a recorded scroll when the next target
  looked visible. Default is now `exact`; `adaptive` is opt-in and the skipped step is reported as `outcome: skipped_by_policy` with the reason.
  (Jumping a list straight to its recorded scroll position is kept - it reaches the recorded state, it does not skip it.)
* Repeated identical clicks are replayed individually (regression test).
* Already in place from the previous upgrade and now extended: ambiguity -> stop, target identity vet, disabled controls refused,
  read-back verification, per-step trace. Each step now also records `intended` vs `actual` target, `container`, `scrolled`, duration.
* `compact_launches` (rewrites a recorded Start-menu click sequence into one `open_app`) is unchanged and still writes `recording_notes`;
  it is a recording-time conversion, not a replay-time skip. **Not audited further.**

## 3-5. Scrolling, dropdowns, drag and drop
* **Dropdown (custom / popup):** open -> look for the exact option in the pop-up that belongs to the window -> if not visible, wheel-scroll the list
  and look again (up to `max_scrolls`, default 8) -> type-ahead + Enter -> read the value back. Duplicate option names stop as ambiguous.
  The recorded coordinate is never used. Native lists still use the UIA SelectionItem pattern first. Tests: `DropdownScrolling` (4).
* **Scrolling / neighbourhood detection / drag across windows:** the existing `scrollfind.py` (UIA scroll-into-view, type-ahead,
  scroll-position jump, wheel search) and neighbour anchors were **not rewritten**; the strict window resolution from the previous
  upgrade applies to them. Gaps: no new work on "scroll the correct one of several containers", horizontal scroll in Excel, virtualised
  tables, Excel<->other-app drag, or File Explorer -> upload-area drag with destination verification.

## Changed files
`core/system/excel_launch.py` (new), `core/system/launcher.py`, `core/playback/player.py`, `core/playback/actions_ext.py`,
`core/settings.py`, `tests/test_excel_and_accuracy.py` (new, 23 tests), `tests/windows_e2e/test_excel_e2e.py` (new, not run).

## Remaining limitations / what you must verify on Windows
1. Everything Excel-specific (COM attach, `Ready`, `Window.Hwnd`, Protected View, bringing the window to front) is unverified on real Excel.
   Run: `set VISIONAUTO_E2E=1` then `python -m pytest tests/windows_e2e/test_excel_e2e.py -v` and send me the output.
2. Excel launched elevated vs VisionAuto non-elevated (or the reverse) cannot be driven through COM/UIA - not handled.
3. Several Excel workbooks open and `open_app` given no path: the window is not guessed (first workbook only if exactly one is open).
4. Excel scrolling (vertical/horizontal), cell-grid dropdowns, Excel<->app drag, file drop on upload areas: not newly implemented/tested.
5. The Step Editor was not given the new step types (`excel_save`, `excel_close`, `open_app` path); use the test JSON for now.
