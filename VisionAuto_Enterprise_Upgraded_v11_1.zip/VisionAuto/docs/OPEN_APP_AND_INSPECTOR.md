# Opening apps reliably, many apps in one run, and the Inspector

## Why "cal" was typed but Calculator never opened
A recording of *Start -> type "cal" -> click the first result* contained a click on the **CoreInput pane** (the whole
968x832 search flyout) at a fixed pixel. On replay that click fired a few milliseconds after typing - before Windows
Search had drawn any result - and the pixel only means "Calculator" on the machine it was recorded on.
The player also never waited after `type`. Two fixes:

1. **`open_app` step** replaces the whole Start-menu sequence. The recorder merges it automatically when you press Stop;
   old recordings are repaired with `python -m core.cli fix <test>` (the original is kept as `test.json.pre_fix.bak`).
   ```json
   {"type": "open_app", "params": {"name": "Calculator", "window_title": "Calculator", "timeout_s": 15}}
   ```
   Strategies, tried in order until the window exists: explicit `exe` -> built-in table (calc.exe ...) -> the real Start
   catalogue (`Get-StartApps`, fuzzy match, launched with `shell:AppsFolder\<AppID>`) -> Win key + typing + **Enter**
   (never a pixel click). Shells (`cmd`, `powershell` ...) are refused. Failure lists every strategy tried.
2. **`type` now waits for the screen to settle** like clicks do, so a following step never races the UI.

`validate_test` also warns (`blind_container_click`) about any click whose recorded element is a big pane with no
automation id - that is the pattern that caused this.

## Many applications, one test (the "for loop")
`workspace/tests/apps_matrix` + `apps.csv`: every row = one app. Every column is a variable, so the same steps run per row
and validation points can use the columns too (`window title contains ${title}`).
```
python -m core.cli run apps_matrix                 # all rows
python -m core.cli run apps_matrix --rows 1-2      # some rows
python -m core.cli run apps_matrix --data mine.csv # your own list: app,title[,anything else]
```
Add columns for what you want to check (`expected_text`, `button`...) and use `${expected_text}` in validations / typed text.
`on_row_failure: continue` (default in the example) keeps going when one app fails; the report shows each row.

## Inspector (Microsoft-Inspect style)
GUI: **Inspector** page - pick a window, *Capture tree*, or *Pick under mouse (3 s)*; the tree shows
Window > Pane > Tab > Group > Button, with properties and a window-scoped XPath you can copy.
CLI:
```
python -m core.cli inspect --window Calculator --find Nine --xpath
python -m core.cli inspect --point 640,410
```
New recordings also store, per element, `path` (breadcrumb) and `inspect_xpath` (e.g.
`/window[@name='Calculator']//button[@automationid='num9Button']`). The resolver tries the normal UIA lookup first and
then this window-scoped path as a second chance, before any image / OCR tier. Everything is scoped to one top-level window.

## Local AI model
Optional and never required (Ollama, `qwen2.5-coder:1.5b`, offline). With setting `use_llm: true` it is used only to break
a tie between look-alike Start-menu entries. Deterministic rules decide everything else - that is what keeps runs repeatable.

## Not verified yet
All of this is covered by 278 automated tests on Linux with mocks. It has **not** been run on a real Windows desktop;
run `python -m core.cli run cal` once and send `workspace/logs` + the run folder if any step fails.

## OCR validation: "same value but FAILED" (fixed)
Cause: a validation recorded from UI Automation stores the accessibility name (`Display is 9,801`); when UIA cannot read
the control the validator falls back to OCR, which sees only the drawn text (`9,801`, or noisy `9.801` / `9,8O1`), and the
old exact comparison failed. Now (`core/playback/textmatch.py`): accessibility labels are not part of the drawn value,
spaces/punctuation are ignored, OCR look-alikes (O/0, l/1, S/5, B/8) and separator differences are tolerated for numbers,
and small / low-contrast text is re-read upscaled and inverted before giving up. The report says which tolerance was needed
(`matched ignoring the accessibility label ...`). A different value never passes (`9,802`, `9,80`, `19,801`, `-9,801`).
Add `"match": "strict"` to a validation to switch the tolerance off.

## Local AI and training data
* Settings -> **Set up local AI automatically**, and a one-time question on first launch: downloads the official Ollama
  installer, refuses to run it unless Windows says its signature is valid and signed by Ollama, installs per-user, starts
  the service and pulls the model. Install only ever happens after the user says yes.
* `workspace/dataset/` (local, never uploaded): every recording and run appends privacy-reduced rows (target features, which
  locator tier worked, confidence, result, validation outcome). Typed text, data-row values, secrets and screenshots are
  **not** stored unless you enable them. `python -m core.cli dataset stats|export FILE.zip`; off with `collect_training_data=false`.
