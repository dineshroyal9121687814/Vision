# VisionAuto – Project audit (v6 → v7 upgrade)

Method: every module under `app/` and `core/` was listed and the files behind each requested feature were read;
the original suite was run first (300 tests; 299 passed, 1 failed because it depended on the user's own recordings).
No PySide6 and no Windows were available in the audit environment, so GUI code was audited by reading and exercised
through `tests/fake_qt.py` only.

## 1. Existing features (kept)
Recorder (`core/recorder`), player with UIA/XPath/image/ORB/OCR/AI locators and self-healing (`core/playback`),
multi-application context (`core/playback/app_context.py`, `core/applications.py`), data-driven runs
(`core/datasource.py`), loops/if, suites + JUnit, Ranorex/UFT importers, Inspector, HTML report, local-AI
(Ollama) helpers, settings, redaction, GUI pages (Dashboard, Record, Tests, Applications, Inspector, Reports, Import, Settings).

## 2. Findings

| # | Area | Finding | Source file(s) | Status |
|---|------|---------|----------------|--------|
| 1 | Excel speed | After **every** step the player polls the screen until it is stable (`_settle`: ≥0.17 s, up to 1.5 s). Typing into N cells = 2N steps ⇒ N×(≥0.34 s) of pure waiting. | `core/playback/player.py` (`run_step`, `_settle`) | Fixed: `fast_entry`, `fill_table` |
| 2 | Excel speed | No bulk path: a block of cells could only be entered key by key (15 ms/char). | `core/playback/backend.py`, `player.py` | Fixed: `fill_table` (one paste), `type` `paste:true` |
| 3 | Data files | XLSX read capped at 5 000 rows/20 MB and only for test data; no writer, no progress, no cancel, no formatting-safe write, no sheet choice. | `core/datasource.py` | Added `core/excel_io.py`, `core/excel_com.py` (datasource unchanged) |
| 4 | Controls | **No Pause/Resume anywhere.** Stop was a bare flag; no Cancel. | `app/gui/workers.py`, `library_page.py` | Fixed: `core/execution.py` state machine |
| 5 | Close | `closeEvent` silently refused to close while a worker ran (user stuck); a recording in progress was ignored. | `app/gui/main_window.py` | Fixed |
| 6 | Diagnosis | A new `CognitiveEngine()` was built on every failure with the **default** Ollama URL, ignoring Settings, and probed `localhost:11434` (1.5 s timeout) each time. | `core/playback/player.py` | Fixed: one engine from settings, offline stub when LLM is off |
| 7 | Retry | Only "no-input-sent" failures retried, fixed backoff, no user question, no policy, no history. | `player.py` (`_run_with_retries`) | Added `core/retry.py` policy |
| 8 | Evidence | Failure screenshot name `fail_stepNNN.jpg` was overwritten by the next attempt. | `player.py` | Fixed |
| 9 | Reports | No delete, search, filter, sort; deletion helper did not exist. | `app/gui/pages/reports_page.py`, `core/testfile.py` | Added `core/reports/manage.py`, new page |
| 10 | Reports | HTML report had no retry history, no restarts; CSS for `cancelled` missing. | `core/reports/report.py` | Fixed |
| 11 | Test cases | No test-case management, no storage path setting, no topic-wise files. | – | Added `core/testcases.py`, page |
| 12 | AI generation | Only step parsing (`parse_intent_to_step`); no requirement → case generation. | `core/ai/cognitive.py` | Added `core/testgen.py` |
| 13 | Applications | Registry table single-select; **Launch ran on the GUI thread** (freeze) and discarded the context object; no path validation before launch. | `app/gui/pages/applications_page.py` | Fixed: `LaunchWorker`, multi-select |
| 14 | Settings | One invalid key reset **all** user settings to defaults (`settings.load`). | `core/settings.py` | Fixed (per-key fallback) |
| 15 | Settings | Page generated every key as a raw widget (enum values typed as free text). | `settings_page.py` | Fixed: grouped, combo boxes |
| 16 | Tests | `test_real_recordings_are_repaired` assumed the user's recordings were all "Calculator" (one is Excel). | `tests/test_open_app.py` | Fixed |
| 17 | Reliability | `Stop` then cleanup steps: the resolver's abort check also aborts cleanup steps after a Stop (cleanup may be skipped). | `player.py` | **Not changed** – documented |
| 18 | Reliability | `ResourceWarning`: `dataset.stats()` leaves files open. | `core/dataset.py:160` | **Not changed** – cosmetic |
| 19 | Security | `fill_table`/`${}` substitution: a data cell containing `${x}` is treated as a variable (strict ⇒ error). | `app_context.substitute_variables` | Documented; use `file` mode |
| 20 | Not audited in depth | Startup-delay/unexpected-termination handling of launched apps (`app_context.py`), plugins (`core/plugins`), importers. | – | Existing behaviour kept |

## 3. Performance bottlenecks
Settle polling per step (finding 1); per-character typing; per-failure LLM probe (finding 6); XLSX read of whole sheet
into memory (acceptable, now chunked with progress); report page rebuilt by re-reading every `run.json` on each refresh
(kept; fine for hundreds of runs).

## 4. UI/UX problems
No pause/cancel; no empty states; Settings page unusably long and untyped; Reports without delete; Applications launch
froze the window; one-colour flat theme without light mode; Dashboard without failure signal.

## 5. Implementation plan (what was done, in order)
`execution.py` → `retry.py` + player integration → `excel_io.py`/`excel_com.py`/`fill_table` → `testcases.py` →
`testgen.py` → `reports/manage.py` + report additions → GUI (workers, Library controls, Reports, Test Cases, Settings,
Applications, theme, close handling) → tests → docs → package.
