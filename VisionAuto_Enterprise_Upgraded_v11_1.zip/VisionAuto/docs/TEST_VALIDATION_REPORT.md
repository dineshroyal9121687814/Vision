# Test validation report

Environment: Linux sandbox, Python 3, PySide6 6.12 running **offscreen**. **No Windows, no desktop Excel, no real applications.**

Result of the full suite (`QT_QPA_PLATFORM=offscreen python -m pytest tests`): **532 passed, 2 failed**.

The 2 failures are old and not hidden:
- `tests/test_open_app.py::PlayerTests::test_blind_container_click_is_flagged_and_fixed_test_is_clean`
- `tests/test_open_app.py::PlayerTests::test_cli_fix_rewrites_and_keeps_a_backup`
Both depend on the shipped sample workspace state; they failed before this release too and are unrelated to the new code.

New in this release and covered: analytics, object repository (reliability, search, advice), data manager (preview, validation,
export csv/json/xlsx, mapping), integrations, AI assistant (no-model path), security helpers (secret masking, path safety), and
the new shell (every module reachable, search, theme, log masking, dashboard counts, execution guard, data page, AI page, plugins).

Measured here (sandbox, 4 tests / 87 objects): dashboard snapshot 3 ms, object collection 4 ms, main window build ~260 ms.
These are not Windows numbers.

Not verified: real UIA / COM / input injection / OCR accuracy, multi-monitor and DPI behaviour, Ollama, long runs. Please run
the MANUAL_TESTER_SCENARIOS on Windows before relying on any result.
