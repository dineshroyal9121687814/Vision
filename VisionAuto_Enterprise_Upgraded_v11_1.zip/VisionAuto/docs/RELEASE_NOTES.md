# Release notes - v8 Enterprise

New: workspace shell, design system (painter icons, KPI cards, charts, toasts), Dashboard from real data, Object Repository,
Data Manager, Execution Center (queue + pause/resume/stop/cancel), AI Assistant, Plugins & Integrations, activity log with
secret masking, `core/analytics`, `core/object_repo`, `core/datamgr`, `core/integrations`, `core/ai_assistant`, `core/security`.
Fixes: Authorization/Bearer headers are now masked in logs; page backgrounds paint under the stylesheet.
Compatibility: tests, runs, settings and history folders are read unchanged; no data is migrated or deleted.
Known limits: see TEST_VALIDATION_REPORT.md (nothing verified on Windows) and COMPETITIVE_ANALYSIS.md.
Not done: shared object repository with inheritance, scheduler, distributed execution, plugin installer, cloud AI.
