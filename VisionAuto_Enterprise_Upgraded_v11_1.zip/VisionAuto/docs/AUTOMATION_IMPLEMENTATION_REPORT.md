# Automation implementation report

Status legend: **Done** = implemented and unit-tested; **Partial** = implemented, with a stated gap; **Not done**.
"Unit-tested" means logic tests with mocks / synthetic images. **Nothing below has been run against a real Windows desktop**
(see `WINDOWS_E2E_TEST_RESULTS.md`).

## New / changed modules
| Path | Purpose |
|---|---|
| `core/automation/errors.py` | `AmbiguousTarget`, `LowConfidenceTarget`, `WrongTarget`, `WindowNotFound`, `PostconditionFailed` |
| `core/automation/window_target.py` | window spec (exact / contains / regex, process, exe, pid & hwnd hints, Main Window, owner) and `resolve_window` |
| `core/automation/guard.py` | pipeline step 5/6: confidence gate, identity check, disabled/outside-window refusal |
| `core/automation/position.py` | absolute / window / normalized / container / anchor position locator, re-derived from current geometry |
| `core/automation/quadrants.py` | four-quadrant (+ recursive) search; quadrants are regions, never click targets |
| `core/automation/textloc.py` | OCR text locator: exact / contains / startswith / regex / fuzzy, case flag, container separation |
| `core/automation/locator_test.py` | live XPath preview: validity, match count, candidates (rects), ambiguity warning, container scope |
| `core/automation/target_config.py` | the per-step Target Configuration (validate / apply / extract) |
| `core/system/uia_actions.py` | UIA Value / SelectionItem / Toggle / ExpandCollapse patterns, native file-dialog submit |
| `core/playback/actions_ext.py` | verified actions: `set_value`, `append_value`, `clear_value`, `read_value`, `select_option`, `set_state`, `upload_file`, `wait_for_window` |
| `core/playback/{player,resolver,backend}.py`, `core/system/winenv.py`, `core/xpath/locate.py`, `core/plugins/base_plugin.py`, `core/settings.py` | integration (strict window resolution, ambiguity propagation, `position` + `quadrant` tiers, outcome/trace, `release_all`) |
| `app/gui/step_editor.py` | Target Configuration rows + new action types (existing look unchanged) |
| `tools/e2e_fixture/fixture_app.py`, `tests/windows_e2e/` | Windows fixture app and real-desktop test scripts (**not run**) |

New settings (all in the normal settings file): `strict_targeting` (true), `min_action_confidence` (0.85),
`allow_blind_coordinates` (false), `verify_typing` (true), `require_postcondition` (false).

## Requirement-by-requirement
| § | Requirement | Status | Notes |
|---|---|---|---|
| 1 | Strict pipeline, no guessing, meaningful failures | **Partial** | app -> window -> locator -> vet (confidence, identity, enabled, in-window) -> action -> read-back -> trace. Uniqueness enforced for XPath, native lookup, image. Failure carries candidates/evidence + existing screenshot. "Alternative suggestions" only for XPath heal. |
| 2 | Window identification | **Partial** | all match modes, process/exe, pid/hwnd hints (validated against criteria), Main Window, owner/pop-up, stale HWND check, ambiguity lists candidates. Stored in `step["window"]`, validated at playback. Gap: no interactive "pick one of the matching windows" dialog - the run stops and lists them. |
| 3 | Locator configuration | **Partial** | XPath (existing engine) now unique-or-fail; preview function with count/candidates/warning; UIA existing; image ambiguity -> fail; OCR modes (see textloc) wired into the quadrant tier only; position tier. Gaps: no live preview/highlight UI, no "generate from Inspector" button wiring, OCR modes not yet in the main OCR tier, multiple template variants / threshold UI not added. |
| 4 | Four-quadrant fallback | **Done (logic)** | order, recursion, overlap margin, candidate list, ambiguity; placed right after the image tier when requested. No GUI preview of quadrants. |
| 5 | Container-aware | **Partial** | container-scoped XPath works and is tested; container stored for position locator. Not done: automatic container-scoped native/UIA search from the `container` field, container image. |
| 6 | Action library | **Partial** | added value / dropdown / check-radio / upload / wait-window actions (verified). Existing mouse/keyboard/drag/scroll/wait actions kept. **Not done**: table/grid, tree, tab, menu actions; mouse down/up and key down/up as standalone step types; read-clipboard-safe restore audit. |
| 7 | Drag-and-drop | **Partial** | existing cross-window arrange now uses strict window resolution and refuses a covered window. Verification relies on step validations. Not done: File Explorer -> app transfer verification, tree/list-specific handling. |
| 8 | File upload | **Partial** | `upload_file`: file existence + extension check, click Browse, find THE dialog of the same process, set the File-name edit via UIA, press the dialog's default button, prove the dialog closed. Not done: drop-zone upload and Explorer drag, progress/error handling. |
| 9 | Multi-application | **Partial** | existing app aliases + every step resolves its own window by HWND. Untested on a real workflow. |
| 10 | Recorder captures intent | **Not changed** | existing recorder already stores UIA/XPath/templates/intent; not re-audited. |
| 11 | Inspector / locator builder | **Not changed** (only `locator_test` backend added) |
| 12 | Self-healing | **Partial** | healed locators no longer pass as exact; below 0.85 refused. Approve/save UI not added; events are logged by the existing heal log. |
| 13 | Validation & debugging | **Partial** | `outcome` (verified/unverified), `trace` per step, `failure_kind/failure_detail`. Not done: "show intended element before executing" debug overlay. |
| 14 | GUI | **Partial** | Step Editor: window match, Main Window, container, quadrant, text match, ambiguity flag, new actions. Nothing else touched. |
| 15 | Technical reliability | **Partial** | stale-HWND handling, release_all, cancellation releases input. Not audited: DPI manifest, multi-monitor, thread safety. |
| 16 | Real E2E tests | **Not run** | fixture + scripts written; see results doc. |
| 17 | Performance | **Not addressed** |

## Intentional behaviour changes (existing tests updated)
* Ambiguity now raises instead of returning `None` (2 tests in `test_automation_fallbacks.py`).
* 0.82-confidence healing needs `min_action_confidence <= 0.82` (1 test in `test_player.py` opts in explicitly).
* Window activation is by HWND, not by title (2 tests rewritten, 1 added).
* A covered drag destination fails in strict mode (drag-geometry tests set `strict_targeting: False`; one strict test added).
* Refocusing a field must actually take focus before typing (1 test adjusted, 1 added).
Turn everything off with `strict_targeting: false` to get the previous behaviour.

## Tests
`tests/test_strict_targeting.py`: 44 tests (window targeting, position maths, quadrant search incl. real template matching,
guard, XPath ambiguity/preview, text modes, verified actions with a fake UIA layer, resolver integration, target config).
Whole suite: 556 passed, 11 skipped, 2 failed - the same 2 (`test_open_app.py`: blind-container-click lint) failed before any change;
`tests/test_gui_upgrade.py` cannot be collected without PySide6 (also before any change).
