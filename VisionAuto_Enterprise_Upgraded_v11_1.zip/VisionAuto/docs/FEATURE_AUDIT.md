# VisionAuto feature audit

## Engineering Audit & Transformation — 2026-10-28

This document tracks implemented, partially implemented, broken, and verified capabilities across VisionAuto.

### 1. Defect Register & Resolution Summary

| ID | Severity | Category | Defect Description | Resolution & Evidence |
|---|---|---|---|---|
| **DEF-01** | **P0** | Security / Sandbox | `core/playback/player.py` `launch_app` executed arbitrary command lines via `subprocess.Popen` without binary sanitization, allowing shell injection or malicious script execution from untrusted tests. | **Resolved**: Added strict validation against dangerous shells (`cmd.exe`, `powershell`, `pwsh`, `bash`, `wscript`), forbidden command chain symbols (`;`, `&`, `\|`, `` ` ``, `$`), and sanitized executable paths. Verified by regression tests in `test_enhanced_features.py`. |
| **DEF-02** | **P1** | Security / XXE | `core/importers/ranorex/repo_parser.py` and `core/importers/uft/object_repository.py` parsed external XML files with standard ElementTree without entity expansion guards, susceptible to Billion Laughs DoS and file disclosure attacks. | **Resolved**: Implemented entity validation blocking `<!ENTITY` definitions before parsing. Verified by unit tests in `test_enhanced_features.py`. |
| **DEF-03** | **P1** | Reliability / Data Loss | `core/testfile.py` `write_json_atomic` wrote to temporary files without calling `os.fsync` before `os.replace`, risking torn or incomplete writes during process crashes or power interruptions. | **Resolved**: Added explicit flush and `os.fsync(f.fileno())` prior to atomic replacement, with exception cleanup of orphaned `.tmp` files. Verified by unit test. |
| **DEF-04** | **P1** | Reliability / Asset Loss | `core/system/imageio.py` `imwrite` wrote directly to final image paths. Mid-write failure or disk-full events corrupted screenshot templates. | **Resolved**: Made `imwrite` atomic using temporary files and safe atomic rename. Verified by unit test. |
| **DEF-05** | **P1** | Concurrency / Stability | `core/recorder/recorder.py` wrote journal events from background worker thread while `stop()` closed the handle on main thread without synchronization. Unhandled listener exceptions leaked file handles. | **Resolved**: Added thread-safe synchronization lock `_journal_lock` around journal writes and closure. Enclosed listener startup in `try/finally` cleanup. Verified by unit tests. |
| **DEF-06** | **P1** | Core Architecture / Typing | `core/playback/backend.py` defined `InputBackend` with ellipsis (`...`) methods instead of formal abstract base class enforcement, allowing missing methods in custom backends to fail silently. | **Resolved**: Converted `InputBackend` to an `abc.ABC` with `@abc.abstractmethod` decorators across all 9 required input actions. |
| **DEF-07** | **P1** | Importer Accuracy | `core/importers/ranorex/repo_parser.py` RxPath concatenation between parent folders and child elements omitted `/` separators when child paths did not start with `/`. | **Resolved**: Added explicit path separator logic `prefix + sep + own`. Verified by repository parsing tests. |
| **DEF-08** | **P1** | Importer Robustness | `core/importers/ranorex/cs_to_steps.py` decoded string literals using `unicode_escape` directly on raw bytes, crashing on non-ASCII or non-escaped characters. Verbatim strings (`@"..."`) did not unescape doubled quotes `""`. | **Resolved**: Implemented dedicated C# string unescape handler supporting verbatim quotes and robust escape fallback. Verified by unit tests. |
| **DEF-09** | **P2** | Script Safety | `core/importers/ranorex/script_safety.py` AST whitelist lacked `ast.AugAssign` (`+=`, `-=`), causing translated scripts with arithmetic increments to fail validation. | **Resolved**: Added `ast.AugAssign` to allowed nodes and validated that assignment targets are strictly local variable names. Verified by unit tests. |
| **DEF-10** | **P2** | Locator Engine | `core/vision/locator.py` `find_by_template` and `find_point_by_features` assumed 3-channel BGR images, crashing on 1-channel grayscale screen buffers or template crops. | **Resolved**: Added dimension and channel checks (`screen.ndim == 3`) before calling `cv2.cvtColor`. Verified by unit tests. |
| **DEF-11** | **P2** | Windows Platform | `core/system/winenv.py` defined `proc_t` callback with `ctypes.c_int` for `HWND` and `LPARAM`, truncating 64-bit pointers on Windows x64. | **Resolved**: Updated signature to use `ctypes.c_void_p, ctypes.c_void_p`. |
| **DEF-12** | **P2** | Technology Adapters | Lacked web browser application adapter for Chrome, Edge, Firefox, Brave, and Opera. | **Resolved**: Implemented `WebPlugin` in `core/plugins/web_plugin.py` and registered in `PluginManager`. Verified by unit tests. |
| **DEF-13** | **P2** | Assertions & Validation | Lacked built-in assertions for `window_exists`, `element_enabled`, `element_disabled`, and `attribute_equals`. | **Resolved**: Added implementations in `core/playback/validators.py`. Verified by unit tests. |

---

### 2. Feature Inventory & Verification Levels

- **Level 0**: Not implemented.
- **Level 1**: Code exists, not verified.
- **Level 2**: Unit-tested with automated regression tests.
- **Level 3**: Integration-tested across subsystem boundaries.
- **Level 4**: Verified against live desktop applications.
- **Level 5**: Repeatedly validated across heterogeneous target environments.

| Feature Area | Implementation Status | Level | Automated Coverage | Remaining Limitations |
|---|---|---:|---|---|
| **Desktop GUI Shell** | Implemented (PySide6) | Level 2–3 | `tests/test_gui_flow.py` | Requires interactive session for manual touch/feel |
| **Input Event Recording** | Implemented (pynput + UIA probe) | Level 2–3 | `tests/test_recorder.py` | Hooks require user permission on elevated desktops |
| **Playback & Wait Engine** | Implemented (`Player` + condition waits) | Level 3 | `tests/test_player.py` | Windows UIA call timeouts depend on OS response |
| **Multi-Tier Locator Chain** | Implemented (UIA -> Template -> ORB -> OCR -> AI) | Level 2–3 | `tests/test_automation_fallbacks.py`, `test_enhanced_features.py` | OCR requires EasyOCR/Tesseract installation |
| **Safe Self-Healing** | Implemented (Ring search + backup) | Level 3 | `tests/test_player.py` | Healed locators committed only on 100% test pass |
| **Windows Desktop Adapter** | Implemented (Win32, WPF, WinForms via UIA) | Level 2–3 | `tests/test_automation_fallbacks.py` | UAC prompts and secure desktops block automation |
| **Web Browser Adapter** | Implemented (`WebPlugin` for Chrome/Edge/Firefox) | Level 2 | `tests/test_enhanced_features.py` | Full CDP protocol integration planned for remote debugging |
| **Ranorex Migration** | Implemented (`.rxrep`, `.cs`, RxPath) | Level 2–3 | `tests/test_ranorex.py`, `test_enhanced_features.py` | `.rximg` binary image containers require re-cropping |
| **UFT Migration** | Implemented (VBScript + XML OR) | Level 2–3 | `tests/test_uft.py`, `test_enhanced_features.py` | Binary `.tsr` repositories not supported (XML export required) |
| **HTML Reporting** | Implemented (Self-contained, dark mode) | Level 2 | `tests/test_reports.py` | PDF export not yet implemented |
| **Atomic Durability** | Implemented (`write_json_atomic` + `imwrite`) | Level 3 | `tests/test_enhanced_features.py` | Fully validated against simulated disk write interruption |
| **Application Registry** | Implemented (`core/applications.py`, validation & discovery) | Level 2–3 | `tests/test_multi_app.py` | Validates desktop, web, running apps; blocks shell injection |
| **Multi-App Execution Engine** | Implemented (`AppContextManager`, switching & lifecycle) | Level 2–3 | `tests/test_multi_app.py` | Cleanly isolates test-launched processes; preserves attached apps |
| **Cross-App Variable Passing** | Implemented (`${var}` interpolation & `save_as` capture) | Level 2–3 | `tests/test_multi_app.py` | Safe regex interpolation without eval() execution |
| **Multi-App GUI Management** | Implemented (`ApplicationsPage`, `StepFormDialog`) | Level 2–3 | `tests/test_multi_app.py`, `test_gui_flow.py` | Live process discovery, control hierarchy inspector |
| **Multi-App Reporting** | Implemented (Consolidated HTML telemetry & app badges) | Level 2–3 | `tests/test_multi_app.py` | Displays per-step app badges, switch counts, variable values |


## 2026-11-01 hardening pass (multi-application)

| ID | Sev | Defect | Resolution |
|---|---|---|---|
| DEF-14 | P1 | A step naming an unknown app alias synthesized a definition and attached to any window titled like the alias | `UnknownApplication`; validation blocks the run first |
| DEF-15 | P1 | Process attach used substring match in both directions; an empty process name matched the first discovered app | Exact (case/`.exe`-insensitive) match |
| DEF-16 | P1 | Several windows with the same title: the first was silently chosen | `AmbiguousTarget` with a listing; opt-in `allow_ambiguous` |
| DEF-17 | P1 | Launch-wait timeout only logged a warning; the test went on to act on a missing window | `TimeoutError`, owned process stopped, failure shown in report |
| DEF-18 | P1 | Cleanup ran only on the normal path; engine exceptions left launched apps running | Guaranteed on crash; cleanup steps; cleanup results now stored in `run.json`/report |
| DEF-19 | P1 | Variables (incl. passwords) were written verbatim to `run.json` / report | Secret redaction of names and values everywhere |
| DEF-20 | P2 | `${typo}` was typed literally into the app | Strict substitution fails the step; validation flags it earlier |
| DEF-21 | P2 | Window re-activated only when switching apps | Re-activated every step; failure to activate fails the step |
| DEF-22 | P2 | A JSON list as `test.json` crashed the loader with `AttributeError` | `TestFormatError`; unsupported `schema_version` rejected |
| DEF-23 | P2 | Classical embedder gave 0.0 similarity for near-identical flat shades | Soft histogram bins + colour layout features |
| DEF-24 | P3 | `test_startup` crashed at import when Qt stub present | Guarded `find_spec` |

Added: `core/validation.py`, `core/redaction.py`, `core/locators.py`, `core/project_io.py`, `core/reports/junit.py`,
`core/tools/process_killer.py`, schema_version 3 with in-memory migration (`test.pre-v3.json` keeps the original on first save).
