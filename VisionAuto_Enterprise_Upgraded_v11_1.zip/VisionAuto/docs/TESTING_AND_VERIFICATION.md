# Testing and verification

Audit date: 2026-10-28. All commands were run from the repository root on Windows 11 with the checked-in `.venv` and Python 3.12. Tests use synthetic UI probes, dry-run backends, and temporary workspaces.

## Commands

```powershell
$env:PYTHONDONTWRITEBYTECODE = "1"
$env:QT_QPA_PLATFORM = "offscreen"
.\.venv\Scripts\python.exe -B -m unittest discover -s tests -t . -v
```

`-B` prevents Python from rewriting bytecode. Tests do not mutate the user's `workspace/` data directory; test fixtures dynamically route `VISIONAUTO_HOME` to isolated temporary folders.

## Results Summary

| Run | Result | Scope | Execution Time |
|---|---|---|---|
| **Mission Baseline** | **80 tests, OK** | Existing synthetic unit and GUI-flow tests | 33.343s |
| **Milestone A & B Fixes** | **80 tests, OK** | Thread safety, atomic IO, launch validation | 14.295s |
| **Final Full Suite (with Enhanced Tests)** | **91 tests, OK (100% PASS)** | Full test suite including security, XXE, WebPlugin, grayscale templates, atomic write, and enhanced validations | **14.301s** |
| **Multi-Application Enterprise Suite** | **106 tests, OK (100% PASS)** | Multi-application registry, dynamic variable passing (${var}), cross-app execution, lifecycle isolation, and consolidated reporting | **35.189s** |
| **Dual AI Models (Vision & Cognitive)** | **113 tests, OK (100% PASS)** | Deep UI Neural Feature Embedder (128-dim normalized embedding) and Cognitive Reasoning Engine (NL intent parsing, root-cause failure diagnostics, self-healing suggestions) | **25.958s** |

## Verification Levels Breakdown

- **Level 0**: Not implemented.
- **Level 1**: Code exists, not verified.
- **Level 2**: Unit-tested with automated regression tests.
- **Level 3**: Integration-tested across subsystem boundaries.
- **Level 4**: Verified against live desktop applications.
- **Level 5**: Repeatedly validated across heterogeneous target environments.

| Area | Evidence | Level | Limits |
|---|---|---:|---|
| **Recorder & Journal Safety** | `tests/test_recorder.py`, `tests/test_enhanced_features.py` (atomic writes, `_journal_lock`) | Level 2–3 | Automated hooks tested synthetically; live physical keyboard/mouse hook requires interactive session |
| **Password Redaction** | `tests/test_settings_security.py` | Level 2 | Relies on target application exposing UIA password control type |
| **Atomic File & Image Persistence** | `tests/test_enhanced_features.py` (`write_json_atomic`, `imwrite` with tmp & replace) | Level 3 | Validated with file system fault recovery simulations |
| **Security & Command Execution** | `tests/test_enhanced_features.py` (`launch_app` restriction, XXE rejection) | Level 2–3 | Verified against command-injection, shell-invocation, and XXE attack vectors |
| **Visual Locator & Scale Matching** | `tests/test_automation_fallbacks.py`, `tests/test_enhanced_features.py` | Level 2 | Tested across color & grayscale templates, scaling factors, and ambiguity boundaries |
| **Self-Healing Pipeline** | `tests/test_player.py` (`test_heavily_changed_ui_self_heals_and_updates_test`) | Level 3 | Unit & synthetic multi-tier fallback verified; live application UI shifts require real app runs |
| **Technology Plugins** | `tests/test_enhanced_features.py` (`WebPlugin`, `PluginManager`) | Level 2 | Browser detection verified for Chrome, Edge, Firefox, Brave, Opera |
| **Enhanced Validations** | `tests/test_enhanced_features.py` (`window_exists`, `element_enabled`, `attribute_equals`) | Level 2 | Evaluates active/background windows, UIA attributes, and condition timeouts |
| **Ranorex & UFT Importers** | `tests/test_ranorex.py`, `tests/test_uft.py`, `tests/test_enhanced_features.py` | Level 2–3 | Verified with sample `.rxrep`, `.cs`, `.vbs`, and XML object repositories |
| **GUI Flow & Step Editor** | `tests/test_gui_flow.py`, `tests/test_step_editor.py` | Level 2–3 | Tested with offscreen Qt; verify interactive rendering manually on launch |

## Real-World Smoke Testing Protocol

To verify live automation against a real Windows application (e.g., Windows Calculator or Notepad):
1. Launch desktop app: `.\.venv\Scripts\python.exe -m app`
2. Go to **Recorder**, name the test (e.g., `calc_smoke`), and click **Start recording**.
3. Perform actions on Calculator (`2 + 3 =`).
4. Press **F9** to stop recording.
5. In **Review dialog**, inspect suggested validations, tick `Equals 5`, click **Save and finish**.
6. In **Library**, select `calc_smoke` and click **Run**.
7. Confirm that the run completes with **Status: passed**, and inspect the generated `report.html`.


## 2026-11-01 multi-application hardening pass

Baseline before changes: 112 tests, 1 failure (`test_vision_ai_matcher_similarity`: the classical embedder scored two
near-identical flat buttons 0.0), 1 error (`test_startup` crashed at collection when a fake `PySide6` stub from another
test module was in `sys.modules`). Both fixed. Suite after: 174 tests (`python -m unittest discover -s tests -t .`) and
173 passed / 1 skipped under `pytest` on Linux, Python 3.13.

New file `tests/test_hardening.py` (61 tests): pre-run validation, strict aliasing, ambiguity, launch timeout, lost
application, failure policies, cleanup after failure/cancel/crash, retries, secret redaction, JUnit, scoped locators,
schema migration, project export/import, and the Ranorex/UFT process killer.

| Area | Level | Evidence |
|---|---|---|
| Pre-run validation, failure policy, retries, redaction, JUnit | Unit + dry-run integration | `tests/test_hardening.py` |
| Window/process ambiguity, launch timeout, app lost | **Mocked** (`winenv`, `subprocess` patched) | not proof against real apps |
| Process killer | Unit (fake processes) + **one real-process test** (a detached `UFT.exe` look-alike, found and stopped) on Linux | real Ranorex/UFT binaries NOT tested |
| GUI changes (Stop Ranorex/UFT button, pre-run validation dialog) | Constructed under the Qt stub only | not clicked in real PySide6 |

**Not executed (needs Windows + real software):** real UI Automation attach/launch of Chrome, a desktop app and Excel in
one test; real PySide6 GUI walk-through; real Ranorex/UFT installs for the killer's process-name list; elevated-process
`AccessDenied` behaviour. Run `python -m core.tools.process_killer` on a machine with Ranorex/UFT running to confirm the
names before using `--kill`.
