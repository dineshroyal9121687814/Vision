# VisionAuto – E2E framework, evidence-based targeting, step palette, custom steps

## 1. The O7 failure ("matches two or more places … refusing to click")
Cause: the strict image guard (added earlier) refused when identical pictures (repeated Excel cells / rows) matched in
several places, even though the recording knew *where* the click happened and *what* was there.

Now (`core/automation/evidence.py`, `Resolver._disambiguate_image`, `Resolver._probe_neighbours`):
1. **Identity first** – Excel COM address, UI Automation id/name, recorded XPath, neighbours (unchanged order).
2. **Recorded spot + text** – the recorded point is moved with the window; UIA is asked what is *there*; the name must
   match the recording. (`point` tier)
3. **Neighbourhood search** – nothing with that identity at the spot → probe 1–2 cells/rows/buttons around it
   (step = the recorded element size). Accepted only when exactly ONE neighbour carries the recorded name.
4. **Look-alike pictures** – all matches are collected; candidates whose UIA text contradicts the recording are dropped;
   the nearest to the recorded spot wins **only if clearly nearer** (≥2× closer than the runner-up) and within
   1.5× the picture size. Evidence is stored (`disambiguated_by`, `distance_px`, `text_verified`).
5. Still ambiguous (equidistant, nothing recorded, no text proof) → refuse with `AmbiguousTarget`. Never a coin toss.
Settings: `disambiguate_by_position`, `disambiguation_radius_px`, `probe_neighbours`, `neighbour_radius`.
Images/OCR remain available but are *secondary* evidence, not the decider.

## 2. Data-driven: one test, many rows
Already in the engine and verified by tests: `--data users.csv --rows 1-3,5`, or `data` inside the test (inline rows /
CSV / JSON / XLSX). Every column is `${column}`; `${_row}`, `${_iteration}` built in; `skip` column; `restart_apps`
between rows; `on_row_failure: stop|continue`; secret columns masked. The report lists each iteration's status.

## 3. Step palette (no code)
`core/steplib/catalog.py` – every action grouped (Mouse, Keyboard, Forms & lists, Windows & apps, Excel, Waits & checks,
Flow control, Data, Custom) with typed fields and dropdown choices (key names, check types, scroll directions, set-state
values …). *Select from dropdown*, *Drag and drop* with **source element + window → destination container + window**.
`build_step()` turns the form into a valid step (names the missing field); `suggest()` proposes next steps (after
`type` → Enter/Tab/Check; with data columns → "Type ${column}"). `visionauto steps palette` prints it.
You can insert your own steps anywhere in a recording (Step Editor / `edit` commands).

## 4. Custom steps written by the AI (stored separately)
`core/steplib/custom.py` → `workspace/custom_steps/<name>.py + .json`.
`visionauto steps new NAME "what it must do"` asks the local AI (Ollama) to draft `def run(ctx, **args)`; or give
`--code file.py` (e.g. code written by any AI assistant). Static check rejects `os/subprocess/eval/open/dunder` and
non-allow-listed imports; saved as **draft**; `steps show`, then `steps approve NAME`. Only approved methods run (unless
`allow_unreviewed_custom_steps`). Use in a test as `{"type":"custom","params":{"method":"NAME","args":{"who":"${user}"}}}`;
`ctx.expect(cond, msg)` makes the step FAIL when the outcome is wrong. NOTE: this is a mistake/abuse guard plus a human
review gate, not a hardened sandbox.

## 5. Also fixed
`core/validation.py` did not list `set_value, append_value, clear_value, read_value, select_option, set_state,
upload_file, wait_for_window, excel_save, excel_close` as known step types – added (plus `custom`).

## 6. Honest limits
Developed and tested in a Linux container (607+ unit tests). Windows / Excel / real UIA behaviour of the new tiers is
unit-tested with simulated UIA only; run `tests/windows_e2e` on Windows (`VISIONAUTO_E2E=1`) before trusting it.
The Ollama-based generator needs Ollama running; otherwise paste code with `--code`. GUI has the `custom` action in the
Step Editor; a richer drag-from-container picker UI is not built yet (the data model and `catalog.build_step` support it).
Changed behaviour: `test_stored_location_disambiguates…` now expects position-based resolution on a whole-screen search.

---
# v4 addendum – resolution ladder, before/after evidence, repeat-previous, AI vision

## Ladder (default `Resolver.DEFAULT_ORDER`)
1. **Identity**: Excel COM, UI Automation (name/id/role), recorded XPath, neighbours/anchor.
2. `ocr_local` – text read next to the recorded spot / in its pane.
3. `coordtext` – the recorded coordinate (moved with the window) is used **only if the required text is read there**.
   (UIA-verified coordinates + neighbour probing are the `point` tier above.)
4. pictures (`image`, `orb`, `nbimg`) – look-alikes decided by position + text, never refused if evidence is clear.
5. `ocr_wide` – text anywhere in the window, then on the whole screen.
6. `vision` – a local AI model LOOKS at the screenshot (`core/ai/vision_advisor.py`, Ollama vision model, setting
   `use_vision_ai`). Its point is a candidate only: acted on when the label is read at that point (UIA or OCR).
   A target without text is never clicked on the AI's word alone.
7. **Repeat the previous step**, then resolve once more (`repeat_previous_policy`): `safe` (default) repeats only
   navigation (tab / menu / tree / link / list item), hover, waits, steps marked `idempotent`, or a previous click that had
   changed nothing; never typing, drag, Add/Submit-like buttons. `always` / `never` available. Reported in the run
   as `repeated_previous`.
8. Fail with the full trace (what was tried, why each rung failed, screenshot).
Custom order per target still possible with `locator_order`.

## Before / after check on every click (`verify_effect`)
The pointer moves to the spot, the region (320x200) is captured, the click is sent with EXACTLY the recorded button,
click count and modifiers, and the same region is compared (up to `effect_wait_s`). Nothing changed -> repeated once
(left/right single click, not for check boxes / toggles / menu items / modifier clicks) -> still nothing: warning
"nothing visibly changed" and the step is *unverified*; `strict_effect: true` makes it FAIL. Result in `steps[].effect`.
Typed text: read back via UI Automation; when the field is not readable (custom controls) the typed text must be
seen by OCR next to the focused field (`ocr_verify_typing`).

## Button / modifier audit
Tests replay left, right, middle, double, Ctrl, Shift+Ctrl click and a right-button Ctrl-drag and assert the backend gets
exactly that button / count / modifiers. If you still see a wrong button on a real machine, send the recorded step JSON.

## Honest limits
Everything above is unit-tested with simulated screens/UIA in Linux; not yet run on a real Windows desktop. The vision tier
needs `ollama pull qwen2.5vl:3b` (or set another model); without it the tier silently stays off. OCR checks add ~0.2-3 s
per step; disable with `verify_effect` / `ocr_verify_typing` for speed. "Typed in the wrong place" is guarded by the
focus check before typing and by the read-back after; the cause on your machine still needs a failing recording to prove.

---
# v5 – full audit
- Static check (pyflakes) over core/app/tools: no undefined names or real defects.
- **Safety fix**: a click that changed nothing was repeated even on buttons (Save / Send / Submit could run twice). Now the
  repeat happens only on controls where a second click is harmless (tab, list/tree/data item, edit, text, pane, link, image);
  buttons are reported ("nothing visibly changed"), never repeated.
- **Gap closed**: controls UI Automation gives no name (custom-drawn, Excel grids without COM, canvases) now get the label
  OCR-read at record time (`ocr_label`, setting `record_ocr_label`). The local-OCR / coordinate-text / AI-vision rungs use it;
  the whole-screen search never does (noisy text must not decide alone).
- The 2 long-standing red tests depended on a user recording (`workspace/tests/cal`) that has since changed; they now use a
  self-contained Start-menu recording. Suite: 628 passed, 25 skipped (Windows-only E2E), 0 failed; GUI tests 14 passed.
- Still to be proven on a real Windows desktop: UIA behaviour of the neighbour probe, effect check timing, Excel flows.

---
# v6 – back to the click path that worked (BESTWORKING), plus the real root cause of wrong cells
**What went wrong in v2–v5.** Each version put more in front of the click: strict refusals, text/OCR before pictures, an
effect check with a repeated click, neighbour probing, focus/state re-clicks, handle-pinned window activation, a Windows
COM tier for Excel. None of it was proven on a real desktop, and together it moved clicks away from the build that worked
(v10 / BESTWORKING: UI Automation -> picture -> ORB -> OCR -> AI -> self-heal).

**Fix 1 - `engine_profile` (Settings > Playback).** Default **classic** = the BESTWORKING click path: that tier order, no
refusals, no effect check / repeated click, no neighbour probe, no AI-vision, no focus/state re-clicks, title-based
window activation. **strict** = everything from v2-v5 (opt-in). Anything you set explicitly in settings.json wins over the profile.
Things that cannot change where a click lands (data rows, step palette, custom steps, reports, Excel save/close) stay on.

**Fix 2 - the real cause of "clicks land in the wrong place" (found in YOUR Test1 recording, also present in v10).**
Picture matching hid look-alikes: the "second best" search blanked the whole 300 px around the best match, so the cell one
row below (24 px away, same score) was never seen as a competitor, and the pick landed 1-2 rows off with confidence 0.99.
Now the competitor window is only a few pixels, so look-alike cells are detected, and then:
  1. window at its recorded position and size -> the recorded coordinate decides (`coordinates(layout)`);
  2. else the look-alike nearest the recorded spot (with its text confirmed when UI Automation can read it);
  3. strict profile: if still undecidable it refuses instead of guessing.
**Measured on real recordings** (stored pictures + stored full-screen frames, `tests/test_real_recording.py`):
Test1 Excel session v10 14/17 clicks on the right cell -> now 17/17; test11000 42/44 -> 44/44; cal 32/33 -> 33/33; aaa unchanged.
This is a replay of recorded frames, not a live Windows run - please run your Test1 again and send the report if any step is off.

New settings: `engine_profile`, `layout_coordinates`, `scroll_jump` (classic: scrolls replay as wheel notches).

---
# v7 – Excel Start screen, drag distance, dropdowns
* **Excel "not opened" + Blank workbook needing a retry.** `open_app Excel` used the COM launcher, which waits for a *workbook*;
  a recording that starts at Excel's Start screen (click "Blank workbook") never has one. Now the COM launcher is used only when
  the step names a workbook file (`params.path`); otherwise the normal launcher (the build that worked) runs, then the app's
  window is brought to the front and given 0.5 s to finish drawing before the next click.
* **Drag / Ctrl+drag distance.** Source and destination were resolved independently; each could be "right" yet the drag
  came out one row short or long. The player now compares the replayed vector with the recorded one (tolerance max(10 px, 4 %))
  and moves the weaker end (picture match) to keep the recorded distance; both weak + window unchanged -> recorded coordinates.
  Ctrl/Shift/Alt are held before the button goes down and released after (unchanged). Reported as `drag_vector_corrected`.
  Cross-window drags are left to the window-position logic.
* **Dropdowns.** A step recorded as "opens a list" is now verified (the screen near it must change) and clicked again once if
  nothing opened - in every profile. An option click first moves onto the item (hover highlight), then clicks.

## v8 - right-click mini toolbar and header right-click
- A caption-less transient window of the recorded app (Excel mini toolbar, context menu, drop-down list) in front no longer fails
  `window title contains ...` validations or window activation (`winenv.is_transient_of`); the owner is not re-focused, so the menu stays open.
- Classic profile gets a last tier `layout_local`: window at recorded position/size + recorded picture >= 0.6 at the recorded point -> click it
  (fixes plain column headers like 'B' that failed before any input on early attempts).
- Not verified on real Windows.

## v8.1 (built from v8, NOT v9)
- Merged cell (M9): last-tier `layout_local` accepts the recorded point when a cell/merged block is under it.
- Text check on a plain typed box whose located point now shows another control (Name Box) -> 'not verified' instead of failed. Cells/rows keep v8 strict behaviour.

## v10 - plan (written BEFORE the code)
Findings from reading the v8 code:
1. **Cell check "H9 contains 2 (found 'Book1' via Windows control text)"** - with Excel COM unavailable the immediate check falls to
   `win32_text_at`, which returns the *top-level window's* caption for a worksheet cell. That is never a cell value. Fix: for spreadsheet
   cell targets ignore Windows-control text (and any read equal to the window title); the remaining readers (editor, formula bar, OCR)
   decide, and a 1-4 character OCR-only read is "not verified", not a failure.
2. **Dropdown option not found** - the classic profile's tier list had no `scroll` tier, so scroll-to-find existed but never ran.
   Plan: add `scroll` to the classic order, only for options of a drop-down / list (intent `pick_option` or list-like container), so a
   sheet or page is never scrolled on its own.
3. **Scroll search strategy** (in this order): replay the amount the user scrolled (recorded notches, recorded direction, looking after
   every notch) -> keep going the same way to the end -> reverse and scan the whole list to the other end (small steps so no row is
   skipped) -> type-ahead (item text) and look -> last resort keyboard select: type the item text (or its first letters) and press Enter,
   marked as a warning in the report.
4. **Cell fallbacks** (`layout_local` for merged cells) only after the normal tiers had ~1 s (attempt >= 3), so a cell that is merely
   slow to appear is not clicked blindly.
Tests: unit tests for each of the above with fake scroller/locator; full suite.

### v10 - implemented
Done as planned: caption-as-cell-value bug fixed, `scroll` tier in classic order (options of lists only), recorded-scroll replay -> full two-way scan (1 notch/step, up to 120 steps, 25 s) -> type-ahead -> keyboard select (type text + Enter, warned; setting `keyboard_option_fallback`), merged-cell fallback delayed to attempt >= 3. Tests: tests/test_v10_dropdown_and_cells.py. Not verified on real Windows.

## v11 - gap analysis against Ranorex / UFT / TestComplete
See docs/FEATURE_MATRIX_V11.md. New: expressions (`core/playback/expr.py`), value comparison (`compare.py`), reusable modules
(`core/modules.py`), `set_variable` / `run_command` / `http_request` / `sql_query` / `screenshot` (`core/playback/stepkit.py`), `value_check`
validation, soft checks (`on_fail: continue`), pattern analysis (`core/recorder/patterns.py`), `patterns` and `schedule` CLI commands, GUI
"Add step…" and "What does it do?". Tests: tests/test_v11_kit.py.

## v11.1 - "F8 row contains 1 (found 'Name Box')"
For Excel cell checks, a located point that is not a worksheet cell (Name Box, Formula Bar, ribbon) is no longer a text source; the cell is
read where it was RECORDED (window unchanged) by UI Automation value, then OCR centred there. Unreadable -> "not verified", never a wrong value.
