# Architect review: gaps vs. the toughest tools

## Closed in this release
| Gap | Fix |
|---|---|
| Popup dropdown windows vs window-ensure | Recording stores `popup` + `owner_title`; playback never demands a popup to be the active window, it brings the owner forward and lets the locators find the item |
| Virtualized lists | Container scroll position (UIA percent) recorded; playback jumps straight to it, then wheel-scans in the right direction |
| 125 % DPI Excel cell position | Excel's answer is checked against the real window rectangle, corrected by the DPI factor, or refused (other locators take over) |
| Drag destination sampled after drop | A sampler thread records what is under the pointer WHILE dragging; the last sample before the drop is used |
| OCR drops the minus of "-7" | The picture is checked for a minus mark; an unsigned reading is never returned for a negative picture |
| Ollama console flash / focus loss | All helper processes start without a console; model is loaded once before the run; a focus guard hides new console/Ollama windows and gives the focus back; the recorder ignores them |
| Check boxes | Recording stores the state to reach (`ensure_state`); playback reads the state, skips the click if already set, verifies after, repeats once |
| Unnecessary scrolling | Consecutive scrolls merged, cancelling scrolls removed, scroll skipped when the target is visible or the list is already at the recorded position, otherwise one exact position jump |
| Understanding the user | `intent` per step (open_dropdown, pick_option, scroll_to_find, enter_value, drag_*), rules first; optional local model labels only the ambiguous steps from a fixed word list |
| Test history | Every changed save keeps `history/test.<time>.json` (last 30); `visionauto versions TEST [--restore ID]` |
| Parallel / CI | `suite --shard 2/4` for several machines; JUnit and HTML reports already existed (earlier note saying they were missing was wrong) |
| Video | `record_video` setting: low-rate `run.avi` linked from the report |

## Still open
1. **All of it is unit-tested on Linux only.** Run on real Windows + Excel + your apps before release; expect small fixes.
2. One desktop runs one GUI test at a time; "parallel" means several machines via `--shard`.
3. Popup detection uses window style/class heuristics; exotic toolkits (Electron, Java, SAP, games) need their own adapters.
4. Ollama's own runner may still flash a console on some versions; it is now hidden within ~80 ms and focus restored, not prevented.
5. Minus detection is a picture heuristic; very small fonts / unusual fonts may miss it (then the result is a plain OCR read).
6. Excel drag of a cell (step 36, I14 empty): consider recording it as Cut/Paste (not done; waiting for your answer).
7. Web / Java / SAP adapters, remote execution dashboard, per-step video clips are not built.
8. Two pre-existing failing tests in `tests/test_open_app.py` (sample workspace dependency).
