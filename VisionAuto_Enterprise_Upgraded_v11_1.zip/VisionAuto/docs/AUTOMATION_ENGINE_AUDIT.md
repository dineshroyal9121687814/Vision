# Automation engine audit - why VisionAuto clicked the wrong thing

Scope: `core/playback/*`, `core/xpath/*`, `core/system/winenv.py`, `core/system/uia_tree.py`, `core/plugins/*`,
`core/vision/*`, `core/ocr/*`, `core/self_healing/*`, `app/gui/step_editor.py`.  Method: read the whole execution path
(Player.run_step -> _ensure_window -> _execute -> Resolver.resolve -> tiers -> backend) and look for every place where the
engine *chooses* instead of *proving*.  Findings were reproduced as unit tests where the logic is OS independent; nothing
here was reproduced on a real desktop (this audit was done on Linux).

## Root causes of "I clicked one thing and it did another"

| # | Root cause (before) | Where | Effect | Fixed by |
|---|---|---|---|---|
| R1 | **Ambiguity was treated as "not found"**: when UI Automation / XPath / template matching saw 2+ candidates the tier returned `None` and the Resolver silently fell through to OCR, AI and self-heal, which then clicked *something* | `resolver.resolve_once` tiers, `winenv.find_native`, `xpath/locate.py` | the classic wrong-button click | `AmbiguousTarget` exception that is **not** swallowed by the tier loop or the UIA governor |
| R2 | XPath with several matches was resolved by "closest to where it used to be" (`near=`) | `xpath/locate.py` -> `find_best(near=...)` | duplicate-named buttons in different panes: nearest wins, often the wrong one | strict mode (default): >1 visible match = `AmbiguousTarget` with the candidate list |
| R3 | A healed XPath (`via: xpath-heal`) was returned as `method="native", confidence=1.0` | `resolver._from_native` | a guess was indistinguishable from an exact hit | now `method="xpath-heal"`, real score, subject to the confidence gate |
| R4 | Fuzzy tiers (ORB / OCR / AI / heal) accepted at `min_recovery_confidence = 0.72` and acted on automatically | `resolver`, `healer` | "similar text" buttons clicked | `guard.vet`: fuzzy results need >= `min_action_confidence` (0.85) |
| R5 | Window = "title contains" + **first** matching HWND (`find_windows(title)[0]`, `activate_window(title)`) | `player._ensure_window`, `_hwnd_of`, `uia_tree.snapshot_window` | two "Untitled - Notepad" windows: input went to whichever enumerated first | `core/automation/window_target.py`: one unique HWND or `AmbiguousTarget`; the HWND is stored as `window['_hwnd']` and used by UIA tree, native lookup and rect provider |
| R6 | Native lookup only searched the **foreground** window and could redirect to it | `winenv.find_native` | wrong window searched when focus moved | search exactly the resolved HWND (`hwnd=` parameter) |
| R7 | Window rect for relative coordinates = "foreground or first title match" | `resolver._default_rect_provider` | recorded points rebased against the wrong window | prefers the resolved `_hwnd` |
| R8 | Stored-coordinate fallback (`coordinates(fallback)`) could still fire after every locator failed | `resolver._t_coordinates` | blind click at an old position | refused unless the user chose a coordinate/position locator or enabled `allow_blind_coordinates` |
| R9 | "Success" = the input event was sent; no read-back for typing / clicks | `player._execute` | typed into the wrong field, reported passed | `outcome: verified | unverified`, typed text read back, `PostconditionFailed`, optional `require_postcondition` |
| R10 | After re-clicking a field to refocus it, typing proceeded even if focus was still elsewhere | `player._ensure_typing_focus` | text typed into the previously focused control | focus is proven (`_assert_focus_on`) or the step fails before typing |
| R11 | Cross-window drag only *warned* when the destination was still covered | `player._arrange_windows_for_drag` | drop landed on the covering window | strict mode raises `WrongTarget` before the mouse goes down |
| R12 | No identity check between configured target and resolved element | - | an element at the right place with the wrong id was accepted | `guard.identity_mismatch` (automation id / control type); disabled controls refused |
| R13 | Failures could leave mouse buttons / modifier keys pressed | `backend` | stuck Ctrl/mouse | `backend.release_all()` after every failure/abort; held inputs tracked in the pynput backend |

## What was already good (kept, not duplicated)
Strict placeholder substitution, app aliases/`AppContextManager`, DPI/monitor geometry (`core/system/geometry.py`),
stateful checkbox clicks (`ensure_state`), UIA governor with time budgets, template matching with ambiguity detection,
OCR engine stack, retry/diagnosis, run reports and failure screenshots.

## Not investigated in depth
DPI awareness of the process manifest, multi-monitor negative coordinates, UIA provider quirks (Qt/Electron/WPF), thread
safety of the OCR pool, and performance of full-screen grabs.  See `KNOWN_LIMITATIONS.md`.
