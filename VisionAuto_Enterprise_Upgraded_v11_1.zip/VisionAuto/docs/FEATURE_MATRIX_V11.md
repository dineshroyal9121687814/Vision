# VisionAuto feature matrix (v11) - vs Ranorex, UFT One, TestComplete, WinAppDriver/Appium, SikuliX

Legend: **Have** = already in the framework before v11 · **Added** = built in v11 (tested) · **Partial** = exists, with a stated limit ·
**Not yet** = honestly not there (not claimed).

## 1. Recording and playback
| Feature (tool that has it) | Status |
|---|---|
| Record mouse / keyboard / drag / right-click / modifiers (all) | Have |
| Record into readable steps with descriptions (Ranorex, UFT) | Have |
| Element identification: UIA name / id, XPath (RanoreXPath), image, OCR text, neighbours (Ranorex, UFT) | Have |
| Resolver ladder + self-healing + AI vision fallback (UFT "smart identification", TestComplete) | Have |
| Dropdown option search: recorded scroll → whole list → type-ahead → keyboard (Ranorex list handling) | Have (v10) |
| Merged-cell / popup / mini-toolbar handling | Have (v8/v10) |
| Excel-specific actions (COM) | Have (needs pywin32 + Excel; otherwise UI fallbacks) |
| Recovery of unexpected windows (UFT recovery scenarios) | Have (`recovery` rules) |
| Plain-language explanation of what a recording does; forms, logins, repeated work | **Added** `patterns` (CLI + "What does it do?" button) |
| Turn repeated actions into a loop over their values, keeping the replay identical | **Added** `patterns --apply` |
## 2. Steps a tester can add without code
| Feature | Status |
|---|---|
| Palette of grouped steps with plain-language forms | Have (CLI) → **Added** GUI "Add step…" dialog (generated from the palette) |
| Variables, arithmetic, text/date/random functions (UFT parameters / Ranorex variables) | **Added** `set_variable` + safe `=expression` |
| Reusable modules with arguments (Ranorex modules, UFT reusable actions) | **Added** `call_test` (cycle-safe) |
| Run program / script, check exit code and output | **Added** `run_command` |
| Web-service / REST calls with status + JSON field checks (UFT service test, TestComplete) | **Added** `http_request` |
| Database set-up / verification (UFT DB checkpoints, TestComplete DB tables) | **Added** `sql_query` (SQLite; read-only unless allowed). ODBC/other DBs: **Not yet** |
| Evidence screenshots on demand | **Added** `screenshot` |
| If / else / loops / break / data rows / secret columns | Have |
| Custom steps written by AI when a step is missing | Have |
## 3. Checks (checkpoints)
| Feature | Status |
|---|---|
| Element exists / not exists / enabled / state / attribute / window / process / file / clipboard / image / region baseline | Have |
| Text equals / contains with robust matching | Have |
| Numbers with tolerance, between, >, <, regex, dates, in-list, length, empty (UFT/Ranorex "match") | **Added** `value_check` |
| Soft checks: report the failure but keep running (TestComplete "check continue") | **Added** `on_fail: continue` |
| Table / grid cell checkpoints | Partial (Excel cells via COM; generic grids via text/UIA reads) |
## 4. Running and reporting
| Feature | Status |
|---|---|
| Suites, tags, shards, data rows, retries, per-step policies | Have |
| HTML / JUnit report, screenshots, video, AI failure diagnosis | Have |
| Run at a time / daily / weekly (Task Scheduler, cron) | **Added** `schedule` (prints / installs the command) |
| Import of Ranorex and UFT scripts | Have |
## 5. Not claimed
Mobile devices, remote Citrix pixel-only automation beyond the image tiers, ODBC/Oracle direct checkpoints, parallel multi-machine grid
orchestration (sharding exists, a central controller does not), and **nothing in this build was run on real Windows**: unit and replay tests only.
