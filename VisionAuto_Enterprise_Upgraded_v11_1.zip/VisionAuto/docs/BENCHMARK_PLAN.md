# VisionAuto and Ranorex benchmark plan

Status: **plan only; no comparative measurements have been collected**. A fair claim requires an available Ranorex installation, equivalent licensed projects, and runs on the same Windows machine. Do not treat synthetic unit tests as benchmark results.

## Comparison setup

- Use one documented Windows machine, display resolution, DPI scale, CPU, memory, OS build, app versions, and dependency versions. Keep the machine idle during measured runs.
- Build equivalent workflows in VisionAuto and Ranorex for the same disposable applications. Include a standard Win32 app and one WPF or Windows Forms app; report each technology separately.
- Use the same starting state, data, waits, and expected outcomes. Randomize product order and run each scenario at least 30 times for reliability metrics.
- Keep authoring, execution, migration, and diagnosis studies separate. Record the operator's experience and use the same operator pool for both products.
- Preserve project files, run logs, screenshots, and a machine-readable results CSV. Record product version and configuration with every result.

## Metrics and definitions

| Metric | Measurement and denominator | Initial pass criterion |
|---|---|---|
| Initial test authoring time | Minutes from a clean project to the first correct passing workflow; report median across operators and workflows | Compare medians; no absolute pass threshold |
| Element identification success | Correct intended element found / all locator attempts with ground-truth target | At least 95%; report per locator type and app |
| Playback success | Runs with all intended actions and independent assertions passing / all scheduled runs | At least 95% over 30 or more runs per workflow |
| False-target selection | Actions applied to the wrong control / all attempted target actions; manually adjudicate screenshots and app state | Zero observed false-target clicks; any occurrence is a safety failure |
| Dynamic UI recovery | Correct recovery after a controlled layout/theme/text change / all changed-layout attempts | At least 90%, with false-target count reported separately |
| Self-healing accuracy | Correct proposed locator updates / all proposed updates, with proposals independently reviewed | At least 95% precision; also report recall and rejected proposals |
| Mean execution time | Wall-clock duration from run start to terminal result for successful equivalent runs | Report mean, median, standard deviation and sample count; no speed claim without significance analysis |
| Failure diagnosis time | Minutes from a seeded failure to a correct root-cause classification; fixed time limit per attempt | Compare median and fraction correctly diagnosed within the limit |
| Test maintenance effort | Engineer minutes and changed locator/action count to restore the same workflow after controlled UI changes | Compare per change type and report all attempts |
| Migration success | Imported workflows that pass independent behavioral assertions / all selected source workflows; report unsupported constructs separately | Report parsing, conversion, execution, and behavioral equivalence as separate rates |
| Repeated-run consistency | Workflows with identical terminal result and equivalent asserted app state / repeated runs | At least 95%; report flaky workflows and state mismatches |

## Procedure and evidence

1. Publish a sanitized scenario set and expected state assertions before implementation. Include static, dynamic, ambiguous, and missing-control cases.
2. Time authoring and migration from a blank target project. Do not exclude failed attempts from denominators.
3. For locator tests, label the intended control in advance and adjudicate every selected target, including failed and recovered cases.
4. Seed failures and UI changes from a fixed script. Capture product logs, screenshots, run IDs, and timestamps using each tool's supported reporting path.
5. Repeat reliability scenarios at least 30 times. Report raw numerator/denominator, confidence intervals, exclusions, and all inconclusive runs.
6. Have reviewers who did not build the tests score diagnosis and self-healing outcomes against a written answer key.
7. Run a separate migration corpus containing representative `.rxrep`, recording, and C# constructs. An import that parses is not counted as successful until the resulting test passes behavior assertions.

## Current results

| Product | Result |
|---|---|
| VisionAuto | Unmeasured. Existing repository tests are synthetic unit/flow tests and do not provide the required repeated desktop runs. |
| Ranorex | Unmeasured. No Ranorex runtime or licensed comparative execution was available for this work. |

No performance or superiority conclusion can be drawn until this plan is run and raw evidence is retained.
