# Security review

Review date: 2026-10-28. This is a comprehensive source, threat-model, and regression-test review covering application lifecycle, persistence, execution sandbox, and imported format ingestion.

## Findings addressed

| Finding | Severity | Change and evidence |
|---|---|---|
| **XXE in XML Repositories** (`.rxrep` & UFT XML exports) | **P1 / High** | Ranorex `.rxrep` and UFT XML repository parsers previously parsed XML files without blocking XML entity declarations. An attacker could craft a malicious repository with entity expansion (Billion Laughs) or external entity file read. Both `repo_parser.py` and `object_repository.py` now explicitly inspect and reject `<!ENTITY` definitions before parsing. Unit tests in `test_enhanced_features.py` verify that malicious XML files with entities are safely rejected. |
| **Arbitrary Code / Command Execution via `launch_app`** | **P1 / High** | `Player._run_step` previously executed `subprocess.Popen([p["exe"]] + ...)` without validating the executable or command parameters. Shell wrappers (`cmd.exe`, `powershell.exe`, `bash`) or chained commands (`;`, `&`, `|`) in imported or edited tests could execute unintended commands. `launch_app` now inspects the binary name, rejects shell wrappers, forbids command-chaining punctuation, and safely tokenizes arguments. Regression test in `test_enhanced_features.py` verifies blocked commands. |
| **Data Loss / Torn File Writes on Crash (`write_json_atomic`)** | **P1 / High** | `write_json_atomic` wrote to `.tmp` without calling `os.fsync` before `os.replace`, and left dangling `.tmp` files on exceptions. It now opens the temporary file, writes, flushes, executes `os.fsync(f.fileno())`, atomically replaces the target, and cleans up temporary files if an exception occurs. Verified in `test_enhanced_features.py`. |
| **Corrupt Image Writes on Mid-Execution Crash (`imageio.imwrite`)** | **P2 / Medium** | `imwrite` previously wrote directly to the target image path. Mid-write interruptions or disk-full events produced corrupt images. `imwrite` now writes to a `.tmp` file and performs an atomic `os.replace`, cleaning up on failure. Verified in `test_enhanced_features.py`. |
| **Recorder Journal Race Condition & Resource Leaks** | **P1 / High** | `Recorder._journal` write was called from the background worker thread without synchronization, while `stop()` closed it from the main thread. Additionally, exceptions during listener startup left the journal file handle unclosed. Added `_journal_lock = threading.Lock()` protecting all write/flush/close operations, and guaranteed cleanup on listener failure. |
| **64-bit HWND Pointer Truncation on Windows** | **P2 / Medium** | In `core/system/winenv.py`, `_find_windows` registered `proc_t = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_int, ctypes.c_int)`. On 64-bit Windows, pointer-sized handles (`HWND` and `LPARAM`) were truncated to 32-bit `c_int`. Corrected signature to `ctypes.c_void_p, ctypes.c_void_p`. |
| UI Automation password exposure | High | UIA descriptions check `is_password` and never query value/text getters for marked password controls. Keystrokes are recorded as redacted markers, and playback halts without attaching screenshots. |
| Non-finite or excessively large timeout values | High | Global options, locator waits, validations, and explicit wait steps reject non-finite, negative, or over-limit durations. |
| Local model endpoint credentials | Medium | Settings and `OllamaClient` reject userinfo in endpoint URLs and enforce HTTPS for non-loopback HTTP endpoints. |

## Existing safeguards observed

- Ranorex-generated Python is parsed and checked against a restricted AST before execution. Imports, arbitrary calls, dynamic loops, and unsupported syntax are rejected. Augmented assignments (`ast.AugAssign`) are validated to ensure targets are local variables only.
- Imported project overwrite is guarded with explicit confirmation flags (`--overwrite`).
- HTML reports escape user text and constrain embedded screenshot paths to the run directory.
- Subprocess launching uses argument lists and avoids `shell=True`.
- OCR, local AI, and model dependencies are optional at runtime; no cloud API or data exfiltration is required.

## Remaining risks & recommendations

1. **Password Detection Limits**: Relies on target application exposing the Windows UI Automation `is_password` attribute. For applications drawing custom password boxes without accessibility interfaces, keystrokes cannot be distinguished from ordinary text automatically.
2. **Execution Sandbox**: While AST validation strictly controls translated script execution, running third-party Python scripts inherently carries risk. Scripts should be reviewed before execution.
3. **Workspace Isolation**: Test definitions are stored in the local workspace directory (`workspace/tests/`). User permissions on this directory dictate access control.


## v8 additions
- `core/security.py`: secrets (password/token/api key/Authorization/Bearer/URL credentials) are masked in log files and in the
  GUI activity log; `safe_join` stops path traversal; `command_ok` rejects shell metacharacters in launch paths.
- AI Assistant never executes generated steps; it saves only on confirmation and never over an existing test.
- Data Manager and exports refuse to overwrite the source file.
- Limits: masking is pattern-based (unusual secret formats can slip through); no credential vault exists.
