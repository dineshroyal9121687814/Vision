# User guide

**Dashboard** - tests, executions, success rate, tests currently failing, self-healed locators, average duration, a 14-day
trend, latest result per test, recent executions, tests needing attention, application health, most frequent failing steps.
Empty workspace = zeros and "-", never invented numbers. Dry runs are not counted as executions.

**Recorder / Applications** - record clicks, typing, drags and scrolls; applications are opened by name or path.

**Test Explorer / Test Designer** - list, edit, delete and review tests; Test Designer generates cases per topic.

**Object Repository** - every recorded element with application, window, type, best locator, reliability and last success.
Reliability is *measured* from real runs when they exist ("measured over N runs") and otherwise *estimated* from the strongest
recorded locator (labelled "never run"). You can rename an element, set its group, drop a wrong recorded name, export/import
JSON, and list weak locators with advice. Every edit saves a version in the test's `history/` folder.

**Data Manager** - open CSV / XLSX / JSON, see the first rows, map columns to a test's `${variables}` (missing variables are
listed), validate required / numeric / unique columns, bulk find-and-replace in a column, edit cells, and export a copy.
The source file is never overwritten.

**Execution Center** - tick one or more tests and press Start (or Dry run). Pause/Resume act between steps; Stop ends after the
current step and keeps the report; Cancel is final. A failed step can ask "retry?" with a countdown (limits in Settings ->
Failure recovery; there are no endless retries). Selecting a failed step shows its likely cause and suggested fixes.

**Reports & Analytics** - run reports (HTML, JUnit), search, delete.

**AI Assistant** - (1) sentences -> steps (rule parser; unknown lines are listed, never guessed; saved only when you press Save,
never over an existing test), (2) requirements -> positive/negative/boundary cases, (3) explain a failed run, (4) regression
suggestions. Works with no model; Ollama only adds wording.

**Plugins & Integrations** - read-only view of technology plugins and which optional components are installed.

**Shortcuts** - top-bar box jumps to a module (type part of its name, Enter). Theme button switches light/dark.
