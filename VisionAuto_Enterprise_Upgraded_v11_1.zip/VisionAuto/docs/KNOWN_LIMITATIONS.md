# Known limitations (honest list)

## Verification
1. **No real Windows run.** All new Windows-specific code (`uia_actions`, `winenv.enumerate_windows`, `find_native(hwnd=)`,
   file-dialog driving) is untested against real applications.  Treat as *implemented, unproven*.
2. The 2 pre-existing failing tests (`test_open_app.py`, blind-container-click lint) and the GUI test file that needs PySide6
   were not investigated.

## Behaviour you may notice
3. Stricter by default: some previously "working" replays will now stop with `AmbiguousTarget` / `LowConfidenceTarget`.  That is
   intended; fix with a unique XPath, an exact window title, a container, or lower `min_action_confidence`.
4. Steps with no validation finish as `passed` + `outcome: unverified` unless `require_postcondition` is on.
5. Typing read-back only works for plain Edit/Document controls whose value UIA can read; custom-drawn fields stay unverified.
6. `select_option` on custom (non-native) dropdowns clicks the option found by the normal resolver in a pop-up context and
   verifies by reading the control's value - if the control exposes no value it is unverified.

## Not implemented
7. Table/grid, tree, tab and menu actions; standalone mouse-down/up and key-down/up steps.
8. Drag verification beyond user validations; Explorer -> application file drag; drop-zone upload; upload progress/error handling.
9. Container-scoped *native* search from the `container` field (container-scoped **XPath** works); container image locator.
10. GUI: live locator preview/highlight, quadrant preview, interactive "choose among matching windows", approve-healed-locator
    dialog, Inspector-based capture of a position (position locators must currently be created by the Inspector/recorder code
    path or by editing the test JSON), "show intended element before executing" overlay.
11. OCR match modes (exact/regex/fuzzy...) are used by the quadrant tier; the main OCR tier keeps its previous matching.
12. Recorder and Inspector were not changed. Performance work (caching, region-limited OCR) not done.
13. Quadrant search cannot find a target larger than a quadrant's overlap margin that straddles a border *and* is not matched
    by the whole-window template tier; text split across a border is not merged.
14. Main Window heuristic: visible, titled, unowned, non-tool window; with several similar top-level windows it reports
    ambiguity instead of choosing.

## Added with the Excel / accuracy fix
15. Excel launch, save and close are implemented against Excel's COM object model and are **unproven on real Excel**.
16. `scroll_mode` default changed to `exact` (nothing silently skipped); `adaptive` is opt-in and reported as `skipped_by_policy`.
17. Custom-dropdown scrolling scrolls at a fixed offset below the field (`list_offset_px`, default 90); an unusual pop-up position may need that value changed.
