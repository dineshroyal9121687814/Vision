# Windows end-to-end test results

**Result: NOT RUN.**  The upgrade was produced in a Linux container with no Windows desktop, no UI Automation and no
PySide6.  Therefore **no claim is made that real desktop automation works**; everything in
`AUTOMATION_IMPLEMENTATION_REPORT.md` is verified only by unit tests with mocks / synthetic screenshots.

## How to run (on a Windows 10/11 machine, unlocked, nobody touching mouse/keyboard)
```
pip install -r requirements.txt
set VISIONAUTO_E2E=1
python -m pytest tests/windows_e2e -v
```
The suite launches `tools/e2e_fixture/fixture_app.py` (two windows, duplicate "Save" buttons, combo with "Green"/"Greenish",
drop zone, native file dialog) and asserts on its JSON state file.  Paste the output into the table below.

## Scenario status (numbers = requirements §16)
| # | Scenario | Script | Result |
|---|---|---|---|
| 1 | Notepad exact text | manual (not scripted) | not run |
| 2 | XPath identifies one button | `test_02_*` | not run |
| 3 | Automation ID | `test_03_*` | not run |
| 4 | Image locator | not scripted | not run |
| 5 | OCR locator | not scripted | not run |
| 6 | Approximate position relative to window | covered by unit tests only | not run on Windows |
| 7 | Four-quadrant search | `test_07_*` | not run |
| 8 | Element inside a container | `test_02_*` (container-scoped XPath) | not run |
| 9 | Specific window among several | `test_09_*` | not run |
| 10 | Main Window | `test_10_*` | not run |
| 11 | Modal dialog | `test_11_*` | not run |
| 12 | Exact dropdown option (Green vs Greenish) | `test_12_*` | not run |
| 13 | Checkbox / radio state | `test_13_*` | not run |
| 14 | Text into specific field | `test_14_*` | not run |
| 15 | Drag between containers | `test_15_*` | not run |
| 16 | Drag a file between windows | not scripted | not run |
| 17 | Upload via native file dialog | `test_17_*`, `test_17b_*` | not run |
| 18 | Upload via drop zone | not scripted | not run |
| 19 | Switch between two applications | not scripted | not run |
| 20 | Multi-application workflow | not scripted | not run |
| 21 | Recover from incorrect locator | unit tests only | not run on Windows |
| 22 | Ambiguous matches fail safely | `test_22_*` | not run |
| 23 | Result verified after each action | unit tests (fake UIA) | not run on Windows |
| 24 | Pause / resume / stop / cancel | existing unit tests only | not run on Windows |

## Unverified assumptions in the Windows code (check first if a test fails)
* Qt exposes `setObjectName` as UIA AutomationId and `setAccessibleName` as Name (expected for Qt 6).
* `pywinauto` `Desktop.from_point`, `iface_value`, `expand/collapse/select` behave as assumed in `core/system/uia_actions.py`.
* The native Open dialog exposes the file-name edit as automation id `1148` and the default button as `1`.
* `EnumWindows` + `window_info` classify pop-ups/tool windows as in `winenv.enumerate_windows`.
* Both fixture windows run in `python.exe`, so process name alone cannot separate them (that is the point of the test).

## Excel scenarios (added with the Excel fix) - all NOT RUN
`tests/windows_e2e/test_excel_e2e.py::test_open_edit_save_close_reopen` covers: launch Excel, open a workbook whose path contains a
space, edit a cell through the UI, verify through Excel COM, save, close, reopen, read back.  Not scripted: Excel scrolling
(vertical/horizontal), dropdown-after-scroll in Excel, switching Excel <-> another app, Excel -> app drag, file drop on upload area.
