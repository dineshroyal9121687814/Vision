# VisionAuto v7 – Implementation report

Environment used for development/testing: Linux sandbox, Python 3.12, **no Windows, no PySide6 (offline), no Excel,
no Ollama model**. Everything below that touches those is marked accordingly.

## 1. Features implemented
| Area | What | Where |
|------|------|-------|
| Excel / data speed | `fast_entry` (no settle wait between consecutive type/key steps), `fill_table` step (whole block in **one** paste, special characters quoted, clipboard restored), `type` with `paste:true` | `core/playback/player.py`, `core/excel_io.py` |
| Bulk data I/O | CSV/TSV/XLSX/JSON read+write, one open/one atomic save, chunked progress + cancel, sheet/start-cell, formulas written as text, illegal control chars stripped (counted), `.bak` before modifying an existing workbook, clear errors (missing file/sheet/column, corrupt or locked workbook, bad start cell) | `core/excel_io.py`, `TableWorker` |
| Open Excel (COM) | Single `Range.Value2` assignment with ScreenUpdating/Events/Calculation switched off and always restored | `core/excel_com.py` (**fake-COM tested only**) |
| Run controls | State machine Start/Pause/Resume/Stop/Cancel/Close; pause at step boundary and resumes at the next step; Stop keeps partial report (`aborted`); Cancel ⇒ report `cancelled`; both end pending questions and join the worker | `core/execution.py`, `PlayWorker`, `library_page.py`, `main_window.closeEvent` |
| Safe close | Cancels + joins an active run (after confirmation), refuses while recording, waits for other workers | `main_window.py` |
| Failure recovery | capture error + screenshot (unique per attempt) → diagnosis (settings-driven engine) → classify (permanent / no-input-sent / input-sent) → ask user (dialog with countdown) → corrective action (refocus window / wait longer) → retry; modes retry-step / restart-test / stop; max attempts, delay, answer timeout, timeout action retry/skip/stop, ask/auto, stop-after-N-failures; every attempt in `retry_history`; abandoned restarts in `restarts` | `core/retry.py`, `player.py`, `retry_dialog.py`, Settings |
| Reports | search/filter/sort, open report/folder, delete one/selected/old (confirmation, only that run folder, symlink/depth/run.json guards, locked-file report, immediate refresh); HTML shows retry history, restarts, retry count, cancelled | `core/reports/manage.py`, `reports_page.py`, `report.py` |
| Test cases | create/edit/clone/delete, topic folders, search/filter/sort, import/export (JSON/CSV/tree), reusable steps `{"use": name}`, `${variables}`, configurable storage folder (validated, existing cases **copied**, never deleted) | `core/testcases.py`, `testcases_page.py`, Settings |
| AI generation | requirement/story/scenario → positive, negative, boundary, validation, UI, error-handling, regression cases with id/title/description/preconditions/data/steps/expected/priority/category; numeric-range & length boundary analysis; auth/payment/form heuristics; optional local-LLM extras (`source: ai`); duplicate detection (vs batch and saved); requirement coverage; review/edit before save; separate files `Topic/topic_category.json`; user-chosen output folder; **never** a result/passed status | `core/testgen.py`, Test Cases → Generate |
| Applications | multi-select, validate path before launch, launch several in a worker (no freeze), per-app result | `applications_page.py`, `LaunchWorker` |
| Data-driven GUI | "Data file…" button runs a test per row of CSV/XLSX/JSON with row selection | `library_page.py` |
| Settings | grouped, typed controls; retry, storage, theme, fast entry; one bad key no longer resets all | `settings_page.py`, `core/settings.py` |
| UI | colourful light/dark theme (button kinds, coloured cards, status colours), empty states, dashboard failure card, themed live switch | `theme.py`, `common.py`, pages |
| Tooling | `tools/benchmark_excel.py`; `run_visionauto.bat/.sh` | |

## 2. Bugs fixed
Per-step settle cost; no pause; Stop-only abort; close blocked forever while running; diagnosis engine rebuilt per failure
and ignoring settings; screenshot evidence overwritten by retries; Applications launch on the GUI thread; one invalid
setting wiped all settings; report CSS for `cancelled`; a test that assumed every recording was Calculator.
Details and file names: `docs/PROJECT_AUDIT.md`.

## 3. Files changed
New: `core/{execution,retry,excel_io,excel_com,testcases,testgen}.py`, `core/reports/manage.py`,
`app/gui/retry_dialog.py`, `app/gui/pages/testcases_page.py`, `tools/benchmark_excel.py`, `tests/test_upgrade.py`,
`tests/test_gui_upgrade.py`, `docs/PROJECT_AUDIT.md`, `docs/IMPLEMENTATION_REPORT.md`, `run_visionauto.{bat,sh}`.
Modified: `core/{paths,settings,validation}.py`, `core/playback/player.py`, `core/reports/report.py`,
`app/main.py`, `app/gui/{main_window,theme,workers}.py`, `app/gui/pages/{applications,common,dashboard,library,reports,settings}_page.py`,
`tests/{fake_qt,test_open_app}.py`, `requirements.txt`, `README.md`.
Workspace data (`workspace/`) is byte-identical to the original.

## 4. New dependencies
`openpyxl>=3.1` (was optional, now listed); `pywin32>=306` (Windows, optional, only for `core/excel_com.py`).

## 5. Tests executed / results
`python -m unittest discover -s tests -t .` → **368 tests, OK (2 skipped: real-Qt-only paths)**
(300 original + 68 new; the one original failure was fixed – it depended on the user's own recordings).
New coverage: Excel/CSV/JSON bulk I/O (types, formulas-as-text, control chars, formatting & other sheets kept, backup, progress,
cancel leaves no temp file, 20 000 rows, clipboard quoting, error messages), COM writer (fake COM), controller transitions,
pause/resume/stop/cancel on a real `Player` in a thread (no orphan thread), fast entry, `fill_table` (one paste, special chars,
clipboard restored, path escape refused), retry policy (classification, user answer, timeout actions, bounds, permanent failure,
input-already-sent safety, stop answer, restart mode, stop-after-N, dry-run, report content), report management (filter/sort,
delete one/selected/old, dangerous paths refused, missing folder, locked file), test cases (CRUD, clone, move, no faked result,
storage change + migration, import/export, reusable steps, topic delete confined), generator (topic split, all categories & fields,
boundary values, separate files, custom output, duplicates/coverage, LLM merge, bad LLM output), settings persistence,
GUI-layer logic (Reports filter+delete+refresh, Settings persistence & invalid path, worker state signals, retry question
round-trip, close handling, Test Cases generate→save).

## 6. Performance (measured here, `python -m tools.benchmark_excel 200`)
| Measurement | Old | New |
|-------------|-----|-----|
| File: 200 cells, open+set+save per cell vs one save (modelled baseline) | 1.47 s | 0.005 s (≈290×), identical content |
| File: 400 000 cells | – | write 2.6 s, read 5.0 s |
| Playback engine, 200 cells = 400 `type`/`key` steps, synthetic static screen | **68.7 s** | **0.19 s** (`fast_entry`) / **0.42 s** (one `fill_table`) |
The playback numbers are *engine overhead* with a synthetic screen and a recording backend – real Excel adds its own latency
per keystroke, which `fill_table` also avoids, but the real-world ratio was **not** measured (no Windows/Excel here).

## 7. Known limitations (honest list)
* **GUI not run under real Qt.** PySide6 could not be installed offline; GUI code was verified by compiling, by reading, and through
  `tests/fake_qt.py` (logic only). Layout, QSS rendering (both themes), dialogs and the signal/thread behaviour under real Qt are **unverified**. Expect possible small visual/API issues; run the checklist below.
* **Nothing was run on Windows**: clipboard paste into Excel, COM writer, UIA playback, window activation, Start-menu launch.
* "Configured AI provider" = local Ollama only (as in the existing app). Diagnosis falls back to rules when the model is off; never tested against a live model here.
* Pause takes effect between steps; Ranorex/UFT script runs can Stop/Cancel but not Pause.
* Retrying a step after input was already sent is **off by default** (`retry_allow_after_input`) because it can repeat a click/payment; the user can still approve it in the dialog (approval = explicit consent).
* Generated cases are documentation-level test cases, not executable recordings; rule-based generation is heuristic (coverage is keyword-overlap, an approximation). They are never marked passed.
* openpyxl may drop features it cannot round-trip (charts, pivot tables, some images) when modifying an existing workbook – a `.bak` is made; for such files use the paste/COM path.
* `fill_table` pastes text: Excel may still convert leading zeros/dates (option `text_prefix` adds an apostrophe – verify on your Excel).
* Cleanup steps may be skipped after Stop (pre-existing, finding 17). Startup-delay/unexpected-termination handling of launched apps and plugins were not re-audited in depth (finding 20). No new CLI commands for the new features. Light theme/responsive layout only partially verified (settings page scrolls; others unchanged).

## 8. Windows manual testing checklist
1. `pip install -r requirements.txt` ; `run_visionauto.bat` → app opens, no traceback in `workspace/logs/visionauto.log`; both themes (Settings → Theme → Save) look correct.
2. Excel: record "type + Tab" across 20 cells; run before/after (`fast_entry` off/on in Settings) and time it. Add a `fill_table` step (rows) with a cell containing a tab, a quote, a newline, `007`, `=1+1`; check cells match; clipboard content restored.
3. Open workbook in Excel, call `core.excel_com.write_block(...)` from a Python shell: block appears, formulas stay text, ScreenUpdating/Calculation back to the previous values (also after a forced error).
4. Run a test: Pause (button text → Resume, current step finishes, nothing more runs), Resume (continues with the next step), Stop (partial report `aborted`), Cancel (report `cancelled`), then check no `python.exe` worker remains. Close the window mid-run: confirmation → run cancelled → app exits.
5. Retry: break a locator, run; dialog shows diagnosis + countdown; test Retry / Give up / Stop / no answer (fallback per Settings); open the report → retry history + screenshots per attempt.
6. Reports: search, filter, sort; delete one (only that folder disappears), multi-select delete, "Delete old…"; open a report in the browser and try deleting it (locked-file message on Windows).
7. Test Cases: generate for two topics, edit one case, save to a custom folder → separate `Topic/topic_category.json` files; change storage folder in Settings → cases copied, old folder intact.
8. Applications: select two apps with Ctrl-click → Launch selected (UI stays responsive); a wrong path reports a clear error.
