# Scenario catalog - what a 20-year manual tester / 15-year automation engineer needs

Status: **Done** = implemented + unit-tested here. **Done\*** = implemented, needs a Windows run to verify.
**Partial** = part of the need. **Gap** = not available (listed honestly at the end).

## 1. Finding things when the screen is not exactly as recorded
| Scenario | How VisionAuto handles it | Status |
|---|---|---|
| Same app, different **window size / position** than when recorded | Window rect + state are recorded; before each step the window is restored to it (`restore_window_geometry`, tolerance `geometry_tolerance_px`) | Done\* |
| A **pop-up / dialog opens at an unexpected size** | Same restore applied to the dialog; if it refuses to resize (fixed-size), all recorded positions, zones and OCR regions are **translated** to where it really is | Done / Done\* |
| Window **off-screen / on another monitor / larger than the screen** | Target rect is clamped onto the virtual screen (shrunk if needed) | Done\* |
| App with **panes** (VS Code: explorer, editor, terminal, status bar) | **Zone recorded per element**: UI Automation container -> else image-layout split at pane dividers -> else 3x3 grid. Playback searches zone first | Done (layout/grid), Done\* (UIA) |
| Two identical buttons in different panes | Search order *near stored spot -> zone -> window -> screen*; first unambiguous hit wins; look-alikes in the **same** area are refused, not guessed | Done |
| Element moved / renamed / restyled | XPath-signature + image + OCR self-heal, `suggested_xpath` | Done |
| Slow clicks in big / Electron apps | UI Automation lookups are **time-boxed** (`native_budget_s`), Chromium/Electron apps (VS Code, Chrome, Teams...) start with visual locators, retries back off, settle looks only at the window | Done (measured 16x for the visual part), Done\* (UIA part) |
| OCR where exactly | explicit `ocr_region` -> `ocr_radius` around stored spot -> zone -> window -> screen (`search_scope`) | Done |

## 2. Mouse and keyboard
| Scenario | How | Status |
|---|---|---|
| **Drag and drop within a window** | `drag_drop` with press-hold, 18-step glide, destination wiggle + hover, guaranteed release | Done\* |
| **Drag from window X to window Y** | Destination window recorded (`to_window`), restored to its recorded place, destination found in *its* window; `drop_mode: position` drops at the same place in the destination window, `relative` keeps the distance | Done\* |
| Drag from a place to a place (no element) | Window-relative position mapping (survives moved/resized windows) | Done |
| Drag handle / slider / reorder list | `relative` mode + tunable `steps`, `hold_ms`, `hover_ms` (`edit drag`) | Done |
| Ctrl/Shift/Alt + click, + drag (multi-select, copy-drag) | `params.modifiers`, always released even on error | Done |
| Right-click, double-click, middle-click, hover, scroll, hotkeys, typing, key sequences | existing steps | Done |
| **Scroll until an item appears** (long lists, logs) | `scroll_until` with bounded `max_scrolls` | Done |
| Select text / copy / paste | hotkeys + `set_clipboard` + clipboard validation | Done\* |

## 3. Waiting and unexpected situations
| Scenario | How | Status |
|---|---|---|
| Wait for a spinner to disappear / a window to appear / text to show | `wait_until` (exists, not_exists, text_contains/equals, variable) with timeout and poll | Done |
| **Unexpected pop-up** (update prompt, "Save changes?", licence nag) | `recovery` rules per test: click a button by text, press a key, hotkey or close; failed step is retried once; max 25 per run | Done\* |
| Slow response / performance | `max_duration_ms` per step -> fails with measured time | Done |
| Flaky first click | retries with backoff, element wait, re-resolution | Done |

## 4. Test design
| Scenario | How | Status |
|---|---|---|
| Same flow, many inputs (valid / invalid / boundary) | data-driven: CSV, TSV, JSON, XLSX, inline; row select; skip column; secret columns | Done |
| Repeat N times / until done; branch on state | `loop_start`, `if_start`/`else`, `break_loop`, all bounded | Done |
| Smoke / regression packs, setup / teardown | `suite.json` with tags, setup, teardown, per-test data | Done |
| Cross-application workflows | multi-app sessions with startup order | Done |
| Migrate old Ranorex / UFT tests | importers incl. VBScript control flow | Partial |

## 5. Checking results
text equals/contains, element exists / not exists / enabled / disabled, window title / exists, attribute, state, image visible, and new:
**text inside a region or pane** (e.g. terminal output), **visual baseline** compare with tolerance, **clipboard**, **file exists / contains**
(home, workspace, temp only; content never logged), **process running / not running**, **response time**.

## Honest gaps
Web DOM / cross-browser, mobile, SAP/Java object trees, UAC / secure-desktop prompts (no tool can click them), CAPTCHA, hardware
or driver testing, load/performance testing at scale, accessibility audits, localization checks (OCR language packs needed),
mixed-DPI multi-monitor edge cases, parallel execution, a debugger, defect-tracker / test-management integration, live object spy UI.
**GUI wiring**: the new options are available through the JSON format, `core.editing` and `python -m core.cli edit ...`; the Qt screens
do not have controls for them yet. **Windows verification**: everything marked Done\* has unit tests with the Windows calls mocked
but has not been run against real applications.
