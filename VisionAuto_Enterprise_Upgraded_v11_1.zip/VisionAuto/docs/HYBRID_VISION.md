# Hybrid vision: how VisionAuto finds and reads things

OCR is the **last resort**, not the default. Each question has an ordered list of cheaper, more reliable sources.

**Clicking (locating an element)** - `core/playback/resolver.py`
1. UI Automation (time-boxed; skipped for apps where it is slow)
2. Image template (300 px then 100 px crop, multi-scale)  <- the main visual tier
3. ORB feature matching
4. OCR of the element's label - only after the image tiers had a second poll, local area first, one pass unless unclear
5. AI similarity, self-heal ring search

**Reading a value (text validations)** - `core/playback/validators.py`
1. UI Automation *value/text* (the UIA *name* is ignored when it is only a cell address such as `G8`)
2. Excel cell value through COM (`core/system/excel_com.py`) - exact, no pixels
3. OCR of the element's rectangle, short-value reader (`ocr_engine.read_small`): pointer parked away, cell border removed,
   crop to the ink, upscale, digits-only allow-list when the expected value is numeric, result cached per picture.
   If OCR is turned off in Settings the check is reported **skipped**, never passed.

**OCR engines** (`core/ocr/ocr_engine.py`): RapidOCR (fast, onnxruntime, no torch) -> EasyOCR -> Tesseract; a broken or
missing engine is skipped. Setting `ocr_engine` pins one.

**Mouse pointer** (`core/vision/pointer.py`): never painted into a capture; before a region is read, a pointer over it is
moved to the window title bar (setting `park_pointer`).

Why lone digits failed before: detection-based OCR skips a single character in a cell and the cell's green selection frame
confuses it; `read_small` removes the frame and reads the glyph as a line.

## Speed (what made runs slow, and what changed)

Measured in the recorded runs: a click via OCR took **121 s**, a skipped text check **77 s**, one failed typed step **95 s**,
normal template clicks 1.0-1.9 s each.

| Cause | Fix |
|---|---|
| Validations called UI Automation directly, with no time limit - a tree walk in Excel / big apps takes seconds, on **every** typed step | All validation lookups go through the same time-boxed governor as clicking; an app flagged slow skips UIA |
| Excel values read by UIA / OCR | Excel COM first (milliseconds, exact) |
| Typed-value check ran before Enter (cell in edit mode: nothing can read it) and against the *clicked* cell, not the cell Enter moved to | Checked after the commit key, in the cell that was active when typing (`active_cell()`), via COM |
| OCR engines (EasyOCR on CPU, 3 full-screen passes) | RapidOCR first; OCR locate has a budget (`ocr_budget_s`, 8 s) after which OCR location is off for the run; results cached per picture |
| Every failure asked the local LLM (20 s each, again on every retry) | One diagnosis per distinct failure, LLM timeout 6 s |
| 300 px picture searched over the whole screen before the 100 px picture was tried near the stored spot | Both pictures in the small area first, then larger areas |
| Settle polling grabbed the whole desktop after every action | Grabs only the window; a click followed by typing waits at most 0.3 s |

## Locator order (per step, editable with `locator_order`)

0. **excel** - Excel cells only: ask Excel (COM) where the addressed cell is on screen (exact, ms, no UIA or picture needed)
1. **point** - one UI Automation query: is the recorded element (id / name + role) still at the recorded place? (text + location, milliseconds; follows the window if it moved)
2. **uia** - search the tree by name / id / path
3. **image** - template match (300 px then 100 px, near area first)
4. **orb** - feature matching
5. **ocr** - last resort, time-boxed (`ocr_budget_s`)
6. **ai** - similarity recovery, **heal** - bounded ring search

## Start-menu launches
"Click Start, choose the app" (with or without typing) is merged into one `open_app` step at record time, and any older
recording is repaired the same way when it is played (the file on disk is not changed).

## Drags between windows (same app or another app)
The recorder stores both windows' size, position and state. Before such a drag the player: restores each window to the
recorded size/place (a small window is moved back to where it was), raises a window that is covered at its own drag point
(no focus change), gives the source the focus, and reports what it did (`window_layout` in the step result, with a
warning if a window is still covered). Single-window steps are untouched.

## Scrolling, neighbours and drag (architect pass)

**Recording** stores, for every click and for both ends of a drag: the nearest scrollable container and up to six neighbouring elements with their (dx, dy) offsets from the point.

**Playback order** is unchanged (excel → point → uia → anchor → image → orb → ocr → ai → heal) and `scroll` runs once at the end if the element is still not found and a container was recorded.

**Scroll-to-find** (`core/playback/scrollfind.py`): native ScrollIntoView → type-ahead (only list/listbox/combobox/listview) → wheel scan in both directions, stopping when the picture stops changing. Adaptive mode (`scroll_mode=adaptive`) skips scrolling when the element is already visible; `exact` always replays recorded scroll.

**Drag and drop**: the held-button drag auto-scrolls at the window edge when the destination is not visible; cross-window drags first arrange windows as recorded.

## Helpers, check boxes, scroll economy
* `core/system/quiet.py`: no-console subprocesses, `FocusGuard` (hides new console/Ollama windows, restores focus), used around every model call and the pre-run warm-up (`llm_warmup`).
* Check boxes and radio buttons record `ensure_state`; playback reaches the state instead of toggling blindly (`ensure_state` setting).
* Scrolling: bursts merged at record time; at playback a scroll is skipped when the target is visible or the list is already at the recorded position, otherwise one exact jump to the recorded position.
* `record_video`, `suite --shard`, `versions` CLI: see ARCHITECT_REVIEW.md.

## Text sources and what is recorded (read this when a check fails)
**Reading text, best first (any application):** UI Automation value → the focused field when it is the recorded control → UI Automation / Windows control text (WM_GETTEXT) at the located spot → OCR (last resort). Excel adds COM, the in-cell editor and the Formula Bar (Name Box must name the cell) at the top. An input's UI Automation *name* is only its caption, never its value.
If only OCR can read a value of 1-4 characters and OCR disagrees, the check is reported **not verified** (skipped), never failed - pixels are a coin toss for "1" vs "2". Set `ocr_short_mismatch` to `fail` for the strict behaviour. The detail line says why COM was unavailable.

**Recorded per click / drag:** position, picture (300 px + 100 px), UIA identity, UIA help text and the tooltip showing at that moment, neighbours with distances, scroll container + scroll position, modifier keys held (Ctrl+click, Ctrl+drag = copy), window identity and its **kind** (main / dialog / menu / popup), destination window for cross-window drags, the state to reach for check boxes. Tooltip windows themselves are never recorded as targets. An unnamed toolbar icon is found again by its help text / tooltip.
Not supported: pressing two *mouse buttons* at the same instant.

## Click pictures, neighbours, inputs
* Every click / drag stores: the 300 px and 100 px pictures, up to six **visual neighbours** (72x36 crops with their offset from the click) and an annotated `assets/sNNN_*_context.jpg` (red cross = click, green boxes = neighbours) to look at in review.
* Playback tier order: excel → point → uia → anchor (named neighbours) → image → orb → **nbimg** (neighbour pictures vote for the click point) → ocr → ai → heal → scroll.
* Typing: before a `type` step the recorded field is clicked again if it lost the keyboard focus (`ensure_focus`) - unless Tab / Enter / arrows / a drag happened since the click.
* Scrolling is replayed one wheel notch at a time (`scroll_notch_ms`); the pyautogui backend now sends whole notches (it used to send 1/120 of one).
* `visionauto inputs TEST [--ask | --write]`: lists every click (how it is found: name / neighbours / picture / position only) and every typed value; `--ask` prompts for values, `--write` creates `inputs.json` next to the test, which playback applies automatically. Secrets are never written to it.
