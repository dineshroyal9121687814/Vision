# Data-driven tests, loops, if/else, locators and suites

## 1. Run one test with many data rows
```
python -m core.cli edit data MyTest --file users.csv --secret password --on-row-failure continue
python -m core.cli run MyTest                       # every row
python -m core.cli run MyTest --rows 1-3,5          # only these rows
python -m core.cli run MyTest --data other.csv      # one-off data file (can be anywhere)
```
Every column is a variable: type `${user}` / `${password}` in any step. Built-ins: `${_row}`, `${_iteration}`, `${_loop}`.
A `skip` column with `yes/true/1` skips that row. Columns named in `--secret` (and any column called password,
token, secret ...) are scrubbed from run.json and the report for **every** row. `--restart-apps` closes and
relaunches the application between rows. Limits: 5 000 rows, 200 columns, 20 MB.

## 2. Loops and if/else (no code)
```
python -m core.cli edit loop MyTest 3 6 --times 5                  # repeat steps 3..6 five times (${_loop} = 1..5)
python -m core.cli edit if   MyTest 3 6 --variable role=equals=admin --else-from 5
```
In JSON: `loop_start {"params": {"times": 3}}` or `{"params": {"while": <condition>, "max": 50}}`, `loop_end`,
`if_start {"condition": ...}`, `else`, `if_end`, `break_loop`. Conditions: `exists`, `not_exists`, `text_contains`,
`text_equals` (on a target element) and `variable` (`equals, not_equals, contains, not_contains, empty, not_empty,
gt, lt, ge, le`). Loops are capped at 1 000 iterations and a run at 50 000 executed steps, so nothing can hang.

## 3. Change how an element is found - without re-recording
```
python -m core.cli edit show    MyTest 4
python -m core.cli edit locator MyTest 4 xpath "//button[@name='Save']"          # or --dialect ranorex
python -m core.cli edit locator MyTest 4 text  "Save"                             # OCR label
python -m core.cli edit locator MyTest 4 image button.png
python -m core.cli edit locator MyTest 4 coordinates --x 640 --y 410 [--exact]    # --exact = always click here
python -m core.cli edit locator MyTest 4 ocr_region --x 500 --y 380 --w 300 --h 80
python -m core.cli edit locator MyTest 4 ocr_radius 300
python -m core.cli edit order   MyTest 4 xpath,uia,image,ocr,coordinates
```
Each edit is merged: changing the XPath keeps the recorded image crops. **OCR search order** (default
`local_then_screen`): the exact `ocr_region` if you set one -> a square of `ocr_radius` px around the stored location
-> 2.4x wider -> whole screen. `ocr_search` can be `local_only` (never scan the whole screen) or `screen_only`.
Tiers: `uia, xpath, image, orb, ocr, ai, heal, coordinates`. `coordinates` as a tier is an opt-in blind click that only
fires when the expected window is in front and the point is inside it.

## 4. Suites
`docs/examples/suite.json`: ordered tests, setup/teardown (teardown always runs), tags, per-test data and row selection.
```
python -m core.cli suite suite.json --tag smoke --exclude-tag slow
```
Writes `suite_result.json` and `suite_junit.xml`; exit code 0 = passed, 1 = failed.

## 5. Window size, zones, drag & drop, pop-ups, timing
```
python -m core.cli edit zone      MyTest 4 --rect 300,560,1200,780 --name terminal     # search this part of the window first
python -m core.cli edit drag      MyTest 6 --hold-ms 400 --hover-ms 600 --drop-mode position
python -m core.cli edit modifiers MyTest 7 ctrl,shift                                  # Ctrl+Shift+click
python -m core.cli edit limit     MyTest 7 --ms 2000                                   # fail if the step takes > 2 s
python -m core.cli edit recovery  MyTest --window "Update available" --action click_text --value Later
```
Settings (settings.json / options): `restore_window_geometry` (true), `geometry_tolerance_px` (8), `native_policy`
(auto|always|never), `native_budget_s` (1.5), `settle_max_s` (1.5), `search_scope` / `ocr_search`, `ocr_radius`,
`drag_steps`, `drag_hold_ms`, `drag_hover_ms`.
