# Competitive analysis (evidence-based)

Method: what VisionAuto does today is taken from this repository and its tests. Statements about Ranorex, TestComplete and
Tricentis Tosca are only about their *publicly described product categories*; **no head-to-head benchmark was run**, so this
document makes no claim that VisionAuto is faster, more reliable or more complete than any of them.

| Area | VisionAuto (verified in code/tests, Linux sandbox) | Gap vs. mature suites |
|---|---|---|
| Record / replay | clicks, typing, drags, scroll, popups, tooltips; JSON steps | no cross-browser web, no mobile |
| Locators | UIA, anchors, images, neighbours, OCR, AI, healing with report | far fewer verified applications; no large app-compat matrix |
| Object repository | per-test elements, reliability, versioned edits | no shared repository across tests with inheritance |
| Data-driven | CSV/XLSX/JSON, mapping, validation | no database / API data sources |
| Execution | pause/resume/stop/cancel, retry policy, shard, JUnit/HTML | no distributed agents / grid, no scheduler |
| AI | rules-first, optional local Ollama, validated output | no cloud model integration by design |
| Reporting | HTML, JUnit, trend and failure ranking on dashboard | no long-term DB, no CI dashboards |
| Maturity | 532 automated tests passing here | **nothing verified on Windows/Excel in this build** |

Honest conclusion: VisionAuto is a focused Windows desktop recorder/replayer with strong text-first locators. Enterprise
breadth (web, mobile, SAP/Java toolkits, grids, role-based collaboration) is not implemented.
