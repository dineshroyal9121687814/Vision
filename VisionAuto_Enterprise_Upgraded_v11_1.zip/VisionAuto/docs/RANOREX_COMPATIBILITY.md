# Ranorex compatibility and migration

Audit date: 2026-10-28. The Ranorex importer provides deterministic parsing and translation of supported Ranorex artifacts into VisionAuto tests and sandboxed execution scripts. It is not an emulation layer for proprietary Ranorex binaries.

## Conversion Matrix

| Construct / Feature | Status | Verification Level | Implementation Details & Limitations |
|---|---|---:|---|
| **`.rxrep` XML Repository** | **Supported** | Level 2–3 | Parses Ranorex XML object repositories (`repo_parser.py`). Extracts hierarchical folders, elements, RxPath expressions, roles, automation IDs, and labels. Rejects malicious `<!ENTITY` definitions (XXE protection). Resolves child paths with proper `/` separators. Tested with `Sample.rxrep`. |
| **Straight-line C# Recordings (`.cs`)** | **Supported** | Level 2–3 | Translates `Click`, `DoubleClick`, `PressKeys`, `EnsureVisible`, `MoveTo`, `Keyboard.Press`, `Delay.Milliseconds`, `Validate.Exists`, `Validate.NotExists`, `Validate.AttributeEqual`, `Report.Log`. Converts into native `visionauto.test/2` JSON. |
| **C# Control Flow & Variables** | **Partially Supported (Script Mode)** | Level 2–3 | If recordings contain variables (`int`, `string`, `bool`), `if`/`else` branches, or bounded `for` loops, converts into a sandboxed Python module with `def run(ctx):`. Validated against `script_safety.py` AST whitelist before execution. |
| **Augmented Assignments (`+=`, `-=`)** | **Supported** | Level 2 | Whitelisted in AST safety checker (`ast.AugAssign`) targeting local names. |
| **Verbatim String Literals (`@"..."`)** | **Supported** | Level 2 | Properly unescapes doubled quotes (`""` -> `"`) and backslashes in C# strings. |
| **Key Sequences (`{LControlKey down}c...`)** | **Supported** | Level 2 | Parses Ranorex key token strings into VisionAuto `key`, `hotkey`, and modifier sequences. |
| **Object Repository RxPaths** | **Supported** | Level 2–3 | Translates Ranorex XPath predicates (`form[@title='...']//button[@text='...']`) into Windows UI Automation locators and fallbacks. |
| **`.rximg` Image Assets** | **Manual Review** | Level 1 | Binary Ranorex screenshot containers are logged in `migration_report.json` as requiring visual capture or template re-cropping. |
| **`.rxrec` Recording Files** | **Partial** | Level 1 | XML-based `.rxrec` action blocks map directly to the corresponding `.cs` code files; direct C# translation is preferred. |
| **Data-Driven Test Tables / Parameters** | **Partial** | Level 1–2 | Supports parameter substitution in straight-line actions. Parameter dictionaries can be passed at import time. |
| **Full Ranorex Test Suite (`.rxtst`)** | **Manual Review** | Level 1 | Suite hierarchy and module execution sequence should be organized via VisionAuto test library or batch runner. |

## Migration Workflow

1. **Inspect Repository**:
   ```powershell
   .\.venv\Scripts\python.exe -m core.importers.ranorex.cli inspect --rxrep MyProject.rxrep
   ```
2. **Import Project**:
   ```powershell
   .\.venv\Scripts\python.exe -m core.importers.ranorex.cli import --rxrep MyProject.rxrep --cs Recording1.cs Recording2.cs --project MyProject
   ```
3. **Inspect Migration Report**:
   VisionAuto generates `workspace/imported/MyProject/migration_report.json` containing:
   - Line-by-line conversion status.
   - Converted action mappings.
   - Unsupported lines marked as `# TODO`.
   - Unresolved elements or missing `.rximg` templates.
4. **Run Converted Test**:
   - Native converted tests: `.\.venv\Scripts\python.exe -m core.playback.playback --name MyProject__Recording1`
   - Script-mode tests: `.\.venv\Scripts\python.exe -m core.importers.ranorex.cli run --script workspace/imported/MyProject/Module.py`

## Truthful Assessment vs. Ranorex Studio

- **Where VisionAuto matches or excels**:
  - Open, portable test format (`visionauto.test/2` JSON + SQLite/assets).
  - Multi-tier visual fallbacks (UI Automation -> Template -> ORB -> OCR -> Local AI) that execute without requiring Ranorex agent licensing.
  - Transparent crash recovery and journaling that never loses recorded steps.
  - Fast execution engine (91 unit tests executed in 14.3 seconds).
- **Where Ranorex Studio currently has more maturity**:
  - Out-of-the-box support for 15+ proprietary technology plugins (Delphi, Qt widget internals, legacy PowerBuilder, Flex).
  - Native `.rximg` binary image asset editor.
  - Interactive recording spy tree viewer with live highlighting overlay.

## How compatibility is built (clean-room)
VisionAuto does not decompile, copy or load Ranorex binaries (`Ranorex.Core.dll` etc. are licensed software, and unmodified
Ranorex C# cannot run without them). Compatibility comes from the publicly documented RanoreXPath syntax and from reading
the user's **own** project files (`.rxrep`, `.cs` recordings, `.rxrec`) and translating them. Anything the translator cannot
convert is listed in `migration_report.json` and fails loudly at run time instead of being skipped.
