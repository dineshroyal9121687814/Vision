# VisionAuto roadmap

This roadmap describes deliverable phases for the canonical `visionauto.test/2` application. Dates are intentionally omitted; phases advance on evidence and review.

## Current checkpoint (2026-10-26)

- Starting point was branch `codex/visionauto-complete-merge` at `0ec892f`; the working tree already had user edits and workspace artifacts, which were preserved.
- Addressed in this session: UIA password value suppression and redacted recording, recorder stop timeout safety, foreground-only title assertion, validated atomic settings persistence, and finite bounded wait validation.
- Baseline: 63 unit tests reported `OK` but the process had a Qt shutdown failure; after adding explicit test teardown, all 75 tests pass with exit code 0. Targeted regressions are recorded in `docs/TESTING_AND_VERIFICATION.md`.
- Real desktop/browser/Ranorex integrations and comparative benchmarks remain unverified.

## Next five priorities

1. Run a documented smoke session against disposable Notepad and Calculator windows, including password-field detection, hook capture, cancellation and playback.
2. Make UI Automation, OCR and AI resolution honor a shared end-to-end deadline even when a platform call blocks; report per-tier time spent and failures.
3. Add a sanitized Ranorex project corpus for repository paths, image assets, recording constructs, data and suite lifecycle; classify every unresolved construct.
4. Add a real browser adapter only with a controlled local sample app and repeatable integration tests.
5. Add CI for portable unit tests and Windows-specific tests; keep tests requiring an interactive desktop in a separately labeled manual job.

## Phase 1: Recorder and playback reliability

- Keep recording on the event queue and preserve the crash-safe `steps.jsonl` journal.
- Exercise mouse, keyboard, shortcuts, drag, scrolling, window activation, cancellation, and review against a real Windows application.
- Maintain synthetic regressions for moved, resized, noisy, repeated, and missing controls.
- Make every locator decision report its tier, confidence, and relevant evidence. Fail safely when candidates are ambiguous.
- Preserve a backup and history for approved repository updates; make timeouts and cancellation visible in reports.

**Exit evidence:** full unit suite passes; Windows GUI and integration smoke job passes; recovery never executes a click after an ambiguous or low-confidence match.

## Phase 2: Ranorex migration

- Obtain sanitized `.rxrep`, `.rximg`, `.rxrec`, and C# samples from supported Ranorex versions.
- Expand repository path resolution, image asset mapping, keyboard sequences, waits, validations, parameters, and supported control flow.
- Emit a migration report with converted lines, unsupported constructs, runtime dependencies, assumptions, manual review items, and source-line mapping.
- Keep direct Ranorex runtime requirements explicit; generated Python modules use VisionAuto's shared runner only where behavior is translated and validated.

**Exit evidence:** compatibility corpus documents each construct; every unsupported statement is surfaced; round-trip/source mappings and imported test execution are covered by fixtures.

## Phase 3: Local AI and model lifecycle

- Define provider configuration for Ollama and compatible local ONNX models.
- Add explicit list, select, download, checksum verification, cancellation, and removal flows.
- Display model license, storage size, compatibility, and estimated memory before download/use.
- Keep startup offline and model-free unless the user opts in. Validate generated output before it can affect tests or code.

**Exit evidence:** tests cover offline operation, interrupted downloads, checksum mismatch, unsupported models, cancellation, and no automatic large download.

## Phase 4: UFT migration

- Specify a separate VBScript importer subset and input formats before implementation.
- Add object repository parsing, common actions, checkpoints, parameters, and bounded control-flow support.
- Preserve source locations and report unsupported operations and assumptions; do not conflate UFT and Ranorex translation.
- Grow a sanitized compatibility corpus as conversion rules are added.

**Exit evidence:** each supported operation has a fixture and expected VisionAuto step; unsupported statements appear in a machine-readable migration report.

## Phase 5: Technology adapters

- Define a capability contract for native UIA, browser/CDP, Java, SAP, Win32/WPF, and remote desktop scenarios.
- Implement an adapter only when a concrete system can be queried and exercised in CI or a documented manual harness.
- Distinguish native element access from vision-only coordinates in the UI and report.

**Exit evidence:** adapter-specific integration tests, capability documentation, and explicit fallback behavior for unavailable runtimes.

## Phase 6: Reporting and enterprise readiness

- Keep HTML reporting as the baseline and validate accessibility, evidence references, and long-run performance.
- Add timeline, PDF, or video export only with artifact-level tests and safe cleanup/retention behavior.
- Define credentials, remote-run isolation, audit retention, workspace backup, and policy controls before enabling distributed execution.
- Add CI coverage across supported Python and Windows versions and publish a reproducible release/install path.

**Exit evidence:** documented support matrix, secure remote execution review, CI green across supported environments, and upgrade/migration documentation.
