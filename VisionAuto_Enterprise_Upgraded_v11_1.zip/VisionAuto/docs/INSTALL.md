# Installation

Requirements: Windows 10/11 (the automation itself is Windows-only), Python 3.10+.

```
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
python -m app
```
or double-click `run_visionauto.bat`. On Linux/macOS the GUI, data tools, reports and the AI Assistant start, but UI Automation,
Excel COM, window handling and input injection need Windows.

Optional components (the Plugins & Integrations page lists which are present on your machine; nothing is installed for you
unless you press the Settings -> local AI setup button):
- OCR: RapidOCR / EasyOCR / Tesseract (only used when text is not readable any other way)
- Excel COM: pywin32 + desktop Excel
- Local AI: Ollama (optional; every AI feature has a rule-based fallback)

Data lives in `workspace/` next to the app (tests, runs, logs, settings.json). Upgrading = unzip the new version and copy your
old `workspace/` folder over; its contents are read as they are.
