# VisionAuto vs Ranorex vs UFT - an honest feature comparison

Legend: **Yes** = implemented and covered by automated tests here. **Yes\*** = implemented but needs a Windows run to
verify (cannot be exercised on the Linux build machine). **Partial** = works for part of the use case. **No** = missing.
Ranorex / UFT columns reflect general product knowledge and may be out of date - check the vendors' current docs.

## Finding the element (the area VisionAuto is built around)
| Capability | Ranorex | UFT One | VisionAuto |
|---|---|---|---|
| UI Automation / accessibility properties | Yes | Yes | Yes\* |
| XPath / RanoreXPath, regex operator `~` | Yes (RanoreXPath) | No (object properties) | Yes (real XPath 1.0 + `~`) |
| Generated unique XPath for a recorded element | Yes (Spy) | n/a | Yes |
| Image template matching, multi-scale | Yes (image-based) | Yes (Insight) | Yes |
| ORB feature matching (scale/rotation tolerant) | No | No | Yes |
| OCR text locator | Partial | Yes | Yes |
| **OCR searches near the stored position first, then wider, then whole screen** | No | No | **Yes** (`ocr_search`, `ocr_radius`, `ocr_region`) |
| Stored coordinates as opt-in last resort, guarded by foreground-window check | n/a | n/a | Yes |
| AI visual similarity | No | Yes (AI object detection) | Yes (classical / optional ONNX) |
| Self-healing of moved/renamed elements | No | Partial | Yes (XPath-signature + image + commit-after-pass) |
| **User-editable locator order per element** | No | No | **Yes** (`locator_order`) |
| Edit one locator without losing the others | Partial | Partial | Yes (`core.editing`, CLI) |
| Restore window size / position recorded at test time | No | No | Yes\* |
| Zone-aware search (pane of the window recorded with the element) | No | No | Yes (UIA container / layout / grid) |
| Drag & drop across windows, hold/hover tuning, modifier keys | Yes | Yes | Yes\* |
| Unexpected pop-up recovery rules | Partial (code) | Yes (recovery scenarios) | Yes\* |
| Time-boxed UI Automation (no multi-second tree walks per click) | No | No | Yes |
| Interactive object spy / highlighter UI | Yes (mature) | Yes (mature) | Partial (capture-based; no live tree spy) |

## Test logic
| Capability | Ranorex | UFT One | VisionAuto |
|---|---|---|---|
| Data-driven (CSV / Excel / JSON / inline) | Yes | Yes (data table) | Yes (CSV, TSV, JSON, XLSX\*, inline) |
| Row selection, skip rows, row-failure policy, restart app per row | Yes | Yes | Yes |
| Secret data columns kept out of reports | Partial | Partial | Yes (every row) |
| Loops (N times / while condition) with hard caps | Yes (code) | Yes (code) | Yes (no-code steps, capped) |
| If / else on element existence, text, variable | Yes (code) | Yes (code) | Yes (no-code steps) |
| Break, nested blocks | Yes | Yes | Yes |
| Scripted tests (C# / VBScript) | Yes | Yes | Partial - imports Ranorex C# subset and UFT VBScript, runs them in a sandbox; no IDE |
| Suites, setup/teardown, tags, per-test data | Yes | Yes (test batch) | Yes (`suite.json`) |
| Parallel / distributed execution | Yes (agents) | Yes (UFT Digital Lab / ALM) | No |
| Debugger (breakpoints, step into) | Yes | Yes | No |

## Checkpoints / validation
Both products have rich checkpoint types. VisionAuto: window exists/title, element exists / not exists / enabled /
disabled, text equals / contains, attribute equals, state, image visible. No table/grid, bitmap-diff or DB checkpoints yet.

## Technologies
| | Ranorex | UFT One | VisionAuto |
|---|---|---|---|
| Win32 / WinForms / WPF desktop | Yes | Yes | Yes\* (UIA) |
| Web DOM (Selenium-style) | Yes | Yes | No - visual/OCR only inside a browser |
| Java, SAP, mainframe, Oracle, etc. object-level | Partial | Yes | No (visual/UIA only) |
| Mobile (Android / iOS) | Yes | Yes | No |
| Apps with poor accessibility, Citrix / remote desktop / games | Weak | Partial | **Strong (image + OCR + AI)** |
| API / DB / REST testing | Partial | Yes (UFT API) | No |

## Reporting, CI, migration
| | Ranorex | UFT One | VisionAuto |
|---|---|---|---|
| HTML report with screenshots, JUnit XML | Yes | Yes | Yes |
| Command-line runner for CI | Yes | Yes | Yes (`python -m core.cli`) |
| Test-management / ALM integrations | Yes | Yes | No |
| Import Ranorex tests | - | - | Partial (C# subset, `.rxrep`) |
| Import UFT tests | - | - | Partial (VBScript incl. control flow; `.tsr/.bdb/.xls` need export) |

## Where VisionAuto is not (yet) a replacement
Web/Selenium, mobile, SAP/Java object-level automation, parallel agents, debugger, test-management integrations, API/DB
testing, and a polished live object spy. The honest pitch: for **Windows desktop apps where recognition is hard**,
VisionAuto's layered, user-orderable locators with localized-then-global OCR are the main advantage; for broad
technology coverage, Ranorex and UFT are far ahead. Measure on your own applications before deciding.
