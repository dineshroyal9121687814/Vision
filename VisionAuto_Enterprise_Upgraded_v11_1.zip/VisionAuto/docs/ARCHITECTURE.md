# VisionAuto Architecture

Audit and update date: 2026-10-28.
VisionAuto is engineered as a modular, desktop-native test automation platform with full separation between the PySide6 user interface and the core headless automation engine.

## 1. System Component Map

```
┌────────────────────────────────────────────────────────────────────────┐
│                        Desktop UI (PySide6)                            │
│  Dashboard │ Library │ Recorder Bar │ Step Editor │ Review │ Reports  │
└───────────────────────────────────┬────────────────────────────────────┘
                                    │ (PySide6 Signals / Workers)
┌───────────────────────────────────▼────────────────────────────────────┐
│                    VisionAuto Core Engine (Headless)                   │
├───────────────────────────────────┬────────────────────────────────────┤
│  Recording Subsystem              │  Playback & Scheduling             │
│  - Event Hook Queue (pynput)      │  - Player (Sequential, Waits)      │
│  - StepBuilder State Machine      │  - Condition-based Wait Engine     │
│  - Synchronized Journal (JSONL)   │  - Failure Isolation & Screenshots │
├───────────────────────────────────┼────────────────────────────────────┤
│  Semantic-First Locator Engine    │  Safe Self-Healing Subsystem       │
│  - Tier 1: Windows UI Automation  │  - Confidence Scoring & Threshold  │
│  - Tier 2: Multi-Scale Template   │  - Expanding Ring Search           │
│  - Tier 3: ORB Feature Matching   │  - Backup Management (test.json.bak│
│  - Tier 4: Fuzzy OCR Text Engine  │  - Commit-on-Pass Guard            │
│  - Tier 5: Local AI Similarity    │                                    │
├───────────────────────────────────┼────────────────────────────────────┤
│  Technology Adapters (Plugins)    │  Validation & Assertion Engine     │
│  - WebPlugin (Chrome, Edge, etc.) │  - Window Title & Existence        │
│  - ElectronPlugin & Win32/WPF     │  - Element Presence, State, Enabled│
│  - CitrixPlugin (Visual-only)     │  - Text Content & Attribute Equals │
├───────────────────────────────────┼────────────────────────────────────┤
│  Migration & Conversion Engine    │  Persistence & Reporting           │
│  - Ranorex Parser (.rxrep, .cs)   │  - Fsync Atomic JSON & Image IO    │
│  - UFT VBScript & XML Parser      │  - Standalone Self-Contained HTML  │
│  - AST Safety Checker             │  - Structured JSON Run Log         │
└───────────────────────────────────┴────────────────────────────────────┘
```

## 2. Core Architectural Decisions

### A. Decoupled Core Engine
The entire automation engine (`core/`) has zero dependencies on Qt or GUI components. It runs completely headless via CLI:
```powershell
.\.venv\Scripts\python.exe -m core.playback.playback --name my_test
.\.venv\Scripts\python.exe -m core.recorder.recorder --name my_test
```
This enables direct execution in continuous integration (CI) pipelines, scheduled cron/automation tasks, and command-line test runners.

### B. InputBackend Strategy (`core/playback/backend.py`)
All physical and synthetic interactions flow through `InputBackend`, an explicit Python `abc.ABC` interface:
- `PynputBackend`: Low-level physical input for Windows desktop sessions.
- `PyAutoGUIBackend`: Fallback input backend when OS hooks or desktop accessibility restrictions apply.
- `DryRunBackend`: In-memory recording mock for headless CI, fast assertions, and test simulation.

### C. Atomic Durability Model (`core/testfile.py` & `core/system/imageio.py`)
To prevent test corruption or asset loss from sudden process termination or power loss:
1. All JSON persistence (`test.json`, `settings.json`, `run.json`) writes to a `.tmp` file, calls `os.fsync(fd)` to guarantee physical disk write, and uses atomic `os.replace`.
2. All screenshot crops and template captures use atomic `.tmp` image writes with cleanup on failure.
3. Keystroke and click journaling (`steps.jsonl`) writes each action in real-time under a dedicated thread lock (`_journal_lock`) so unexpected termination never loses recorded steps.

### D. Semantic-First Multi-Tier Locator Chain (`core/playback/resolver.py`)
Locators are evaluated hierarchically to maximize speed and eliminate false-target clicks:
1. **Windows UI Automation / Accessible Tree**: Queries name, role, class, and automation ID within the active window.
2. **Multi-Scale Template Matching**: Evaluates visual appearance across scale variations (0.8x to 1.25x) with strict ambiguity detection (rejects matches if two controls look identical within 0.025 confidence).
3. **ORB Feature Keypoints**: Homography matching for scaled or rotated controls.
4. **Fuzzy OCR Text Recognition**: Locates controls by visible text when accessibility trees are absent (e.g. game engines, legacy Win32, remote apps).
5. **Local AI Similarity**: Embedded semantic similarity search.

### E. Safe Self-Healing Protocol (`core/self_healing/healer.py`)
- Self-healing never silently clicks an uncertain target. Candidates must exceed `min_recovery_confidence` (default 0.72).
- Recovered templates are stored in memory and committed to disk **only after the entire test suite passes**. If any assertion fails, healed locators are discarded to prevent recording corrupted targets.
- A restorable backup (`test.json.bak`) is always maintained.

### F. Technology Plugins (`core/plugins/`)
- `WebPlugin`: Identifies Chrome, Edge, Firefox, Brave, and Opera browser processes.
- `ElectronPlugin`: Identifies Slack, Teams, VS Code, Discord, Postman, etc.
- `CitrixPlugin`: Enforces pixel/vision-only fallback mode when remote desktop APIs cannot expose accessibility trees.
- `GenericPlugin`: Standard Win32, WPF, and WinForms automation.

### G. Application Management & Multi-Application Architecture (`core/applications.py` & `core/playback/app_context.py`)
VisionAuto supports multi-application enterprise testing across disparate environments (e.g., Web, Win32/WPF, Excel) within a single unified test case:
1. **Application Registry (`workspace/applications.json`)**:
   - Manages registered desktop and web applications with validation against dangerous command injection or path traversal.
   - Live discovery of top-level windows and processes via `discover_running_apps()`.
   - Control hierarchy inspection via UI Automation with `inspect_window_hierarchy()`.
2. **Multi-Application Test Definition (`visionauto.test/2`)**:
   - Tests declare an `applications` array with target applications and their lifecycle mode (`launch`, `attach`, or `attach_or_launch`).
   - 100% backward compatibility: single-app legacy tests automatically synthesize a default application definition on load.
   - Individual steps declare an `app` alias targeting specific applications.
3. **Application Execution & Context Manager (`AppContextManager`)**:
   - Automated window focus activation and switching between applications.
   - Dynamic cross-application variable passing (`${var_name}`) with safe string interpolation and `save_as` value capture.
   - Isolated lifecycle cleanup: terminates only processes launched by the test runner (`close_test_launched`), leaving attached user processes untouched.
4. **Consolidated Multi-Application Reporting (`report.html`)**:
   - Comprehensive telemetry documenting all applications involved, switch counts, execution status, and captured runtime variables.
   - Visual application badges on every executed step.

### H. Dual-Engine AI Architecture: Vision & Cognitive Models (`core/ai/`)
VisionAuto integrates a multimodal dual-engine AI architecture for resilient, intelligent testing:
1. **Model 1: Visual AI Element Embedder (`core/ai/models/neural_embedder.py` & `core/ai/embedder.py`)**:
   - Acts as the visual perception engine ("The Eye").
   - Extracts 128-dimensional L2-normalized deep neural feature embeddings on local CPU (<20ms).
   - Invariant to theme changes (dark/light mode), color variations, button styling, and resolution shifts.
   - Tri-tier backend support: ONNX Runtime (`embedder.onnx`), local PyTorch deep neural embedding (`neural`), and classical histogram/gradient fallback.
2. **Model 2: Cognitive Reasoning Engine (`core/ai/cognitive.py` & `core/ai/llm.py`)**:
   - Acts as the intelligence and understanding engine ("The Brain").
   - **Natural Language Step Parser**: Converts human-written instructions into structured VisionAuto test steps.
   - **Intelligent Root-Cause Diagnostics**: Automatically diagnoses step and assertion failures (e.g., unexpected modal dialogs, window mismatches, slow async render) and attaches actionable recommendations.
   - **Smart Self-Healing Candidate Evaluator**: Evaluates candidate controls when locators break and selects the best semantic and role match.
   - **Dual Mode Execution**: Leverages local SLM (e.g. Qwen 2.5 via Ollama) when online, with an offline deterministic semantic expert engine when disconnected.
   - **Interactive Reporting**: Embeds AI diagnostic cards directly into consolidated HTML test reports.
