# VisionAuto - Enterprise edition (v8)

> **v8 - new workspace shell.** Grouped sidebar (Dashboard, Recorder, Applications, Test Explorer, Test Designer, **Object
> Repository**, **Data Manager**, **Execution Center**, Reports & Analytics, **AI Assistant**, Inspector, **Plugins &
> Integrations**, Import, Settings), top bar with module search and light/dark switch, activity log + progress bar at the bottom,
> toast notifications. The Dashboard shows only numbers computed from your tests and runs (no sample data).
> Details: `docs/RELEASE_NOTES.md`, `docs/USER_GUIDE.md`, `docs/INSTALL.md`, `docs/TEST_VALIDATION_REPORT.md`,
> `docs/COMPETITIVE_ANALYSIS.md`. **Not verified on real Windows or real Excel** - see the validation report.
>
> Existing tests, runs and settings are read as before (nothing is migrated or deleted).

# VisionAuto

> **v7 - upgrade:** fast data entry (`fast_entry`, `fill_table`, bulk CSV/XLSX/JSON I/O), real **Pause / Resume / Stop /
> Cancel**, AI-assisted **failure diagnosis + retry policy** (ask first, fall back after a timeout), **Reports** with search and
> safe delete, **Test Cases** page with topic-wise AI generation (`Topic/topic_category.json`), configurable storage folder,
> multi-application launch, light/dark colour theme. Audit: `docs/PROJECT_AUDIT.md`; what was done, measured and what is
> still unverified (GUI under real Qt, everything on Windows): `docs/IMPLEMENTATION_REPORT.md`.
>
> Start: `run_visionauto.bat` (Windows) / `./run_visionauto.sh`, or `pip install -r requirements.txt && python -m app`.
> Tests: `python -m unittest discover -s tests -t .` · Benchmark: `python -m tools.benchmark_excel 200`.
>
> Quick use: **Tests** → select a test → Run / Pause / Stop / Cancel; **Data file…** runs it once per row.
> A `fill_table` step (`params: {"rows": [[...]]}` or `{"file": "data.csv"}`) pastes a whole block into the focused grid at once.
> **Settings → Failure recovery** controls retries; **Settings → Storage** moves the test case folder (cases are copied, never deleted).


> **v5 - open_app, Inspector, many-apps runs:** Start-menu launches are now one reliable `open_app` step (fixes "typed but
> Calculator never opened"), `python -m core.cli fix <test>` repairs old recordings, an **Inspector** page shows the
> Window > Pane > Tab > Button tree with XPaths, and `workspace/tests/apps_matrix` runs one test over a CSV of apps.
> See `docs/OPEN_APP_AND_INSPECTOR.md`.

Record interactions in supported Windows applications, replay them through native UI Automation and visual
fallbacks, and check the results. Coverage depends on the application's accessibility support; verify compatibility
with each target application.

```
pip install -r requirements.txt
python -m app                      # desktop app
```



## Newest: window geometry, zones, drag & drop, scenario steps
Window size/position/state are recorded and restored on playback (fixed-size dialogs are handled by translating
coordinates); every element remembers the **zone** (pane) it was in and the resolver searches near-the-spot -> zone ->
window -> screen for images, ORB and OCR; UI Automation lookups are time-boxed so big/Electron apps are not slowed down;
drag & drop works within and across windows with hold/hover/modifiers; new steps `wait_until`, `scroll_until`,
`window_action`, `set_clipboard`; per-test pop-up `recovery` rules; `max_duration_ms`; new checkpoints (text in
region/pane, visual baseline, clipboard, file, process). Catalog and honest gaps: `docs/MANUAL_TESTER_SCENARIOS.md`.
Tests: 260. Windows-only parts are unit-tested with mocks but not yet run on real applications; no GUI controls yet
(JSON, `core.editing`, `python -m core.cli edit ...`).

## Latest additions: data-driven runs, loops, editable locators, suites
* **Data-driven testing**: CSV / TSV / JSON / XLSX / inline rows, row selection, skip column, secret columns, per-row
  restart. **Loops and if/else** as no-code steps (bounded). **Staged OCR**: search the stored region/location first,
  then wider, then the whole screen. **User-orderable locators** per element (`uia, xpath, image, orb, ocr, ai, heal,
  coordinates`). **Editing API + CLI** (`core/editing.py`, `python -m core.cli edit ...`). **Suites** with tags,
  setup/teardown and JUnit (`core/suite.py`). See `docs/DATA_DRIVEN_AND_FLOW.md` and the honest feature
  comparison in `docs/COMPARISON.md`.
* **Not wired into the GUI yet**: the Tests/Run pages do not have buttons for data files, loop/if blocks, locator order
  or suites - use the CLI / `core.editing` API (the engine, tests and JSON format are complete). Test count is now 228.

## What's new in this version

### 1. Real XPath engine (`core/xpath`, `core/system/uia_tree.py`)
Locators are no longer limited to a parsed RanoreXPath subset. A step target may carry `"xpath"` and the
resolver evaluates it as genuine **XPath 1.0** against a live UI Automation tree snapshot of the target window:
all axes, `and`/`or`, `contains()`, `starts-with()`, `position()`, `count()`, unions, plus the Ranorex regex
operator `@text~'^[0-9]$'`. Names are case-insensitive; `dialect: "ranorex"` uses Ranorex roles (`form`, `text`,
`container`...), `"uia"` uses control types (`window`, `edit`...). Absolute paths start at a virtual desktop, so
`/form[@title='Calculator']//button[@text='7']` works exactly as in Ranorex.
* More than one visible match is **never guessed**: it is resolved by proximity to the recorded position only if
  that separates them clearly, otherwise the resolver falls through to the image/OCR/AI tiers.
* **XPath self-healing**: if the path no longer matches, every node is scored against the recorded signature
  (automation id, name, role, class, text, position). It heals only if the best score is >= 0.80 *and* clearly
  ahead of the runner-up, and it returns a regenerated `suggested_xpath`.
* `generate_xpath()` produces the shortest unique XPath (automation id -> name -> anchored path -> positional).
* Password controls never expose their value to XPath.
Locator order is now: **UIA/XPath -> image template -> ORB features -> OCR text -> AI similarity -> self-heal.**

### 2. UFT / VBScript migration - control flow now supported (`core/importers/uft`)
Straight-line scripts still become native tests. Everything else is parsed by a full VBScript parser and executed
by a sandboxed interpreter on the *same* Player/Resolver/report engine:
`If/ElseIf/Else` (block + single line), `For`, `For Each`, `Do/Loop While|Until`, `While/Wend`, `Select Case`
(`Is`, `To`, lists), `Sub`/`Function` (recursion, `ByRef`), `Dim/ReDim/Const`, arrays, `With`, `Exit`,
`On Error Resume Next` + `Err`, ~90 VBScript functions, `Scripting.Dictionary`, `VBScript.RegExp`,
`DataTable` (CSV export), `Parameter()`, `Environment`, `RunAction`, `ExecuteFile` (project folder only),
`Reporter.ReportEvent`, `SystemUtil.Run`, descriptive programming (`"text:=OK|micclass:=Button"`), and the
test-object methods Click / DblClick / Set / Type / Select / Exist / GetROProperty / GetTOProperty /
WaitProperty / CheckProperty / Activate / Close / Navigate / CaptureBitmap.
```
python -m core.importers.uft.cli --script Login.vbs --repository OR.xml --name Login [--force-script] [--action Login=Login.vbs]
python -m core.importers.uft.cli run --script workspace/imported/Login/Login.vbs --data table.csv [--all-iterations] [--dry-run]
```
Safety: no `eval`/`exec`; statement budget + time budget + recursion limit stop endless loops; `Execute`, `Eval`,
`Class`, `GoTo`, `SetSecure`, `WScript.Shell`, `FileSystemObject`, `ADODB`, process killing are refused. Unsupported
syntax and methods are listed in `migration_report.json` at import time **and fail loudly at run time** - never
silently skipped. Imported scripts appear on the Tests page as "UFT script".

### 3. Ranorex migration - broader C# coverage
`for(int i..)`, bounded `while`, `++/--/+=`, `break/continue`, string interpolation, `string.Format`, `.Length`,
`.ToString()`, `Convert.*`, string concatenation with numbers, `Exists()`, `Validate.IsTrue/IsFalse/AreEqual/
AttributeContains`, `GetAttributeValue`, and multi-line/same-line braces. Imported repository items now carry their
real RanoreXPath (`target.xpath`) so the XPath engine above uses it. Generated scripts still pass the AST safety
validator (loops are clamped to 10 000 iterations by `rx_range`, `while` to 1 000).

## Status of this version - read before trusting it
* **Verified here (automated, 196 tests, Linux, no display):** XPath engine, VBScript parser/interpreter, UFT
  script import + dry-run through the real Player, Ranorex translator + safety validator, all 174 original tests.
* **NOT verified (needs Windows + a real app):** `core/system/uia_tree.py` (live UIA snapshot via pywinauto), the
  XPath tier inside a live resolver run, real clicking/typing from UFT scripts, the GUI changes (Tests-page "UFT
  script" label, step-editor XPath storage - these compile but the Qt tests need PySide6). Run the suite on Windows
  first, then try Notepad/Calculator.
* **Not claimed:** this does not "surpass" Ranorex or UFT. Those products have mature spy/inspector tools, web
  (Selenium/DOM) and SAP/Java/.NET object-level automation, licensing, and years of field testing. VisionAuto's real
  differentiator is the layered fallback (UIA/XPath -> image -> OCR -> AI) that works on apps without good
  accessibility; whether it wins for *your* applications must be measured on them.
* **UFT limits:** binary `.tsr/.bdb` repositories and `.xls` data tables are not read (export to XML / CSV);
  `Click x, y` offsets are ignored; `.Object`, `ChildObjects`, `Description.Create`, checkpoints stored in
  the test's binary files, table/grid cell methods, `Class` are not supported.
* **Ranorex limits:** `switch`, `try/catch`, custom classes/methods called across files, `.rxtst` suites, data
  connectors and `.rximg` image repositories are not converted (listed as `# TODO`). The `.rxrep` parser is still
  based on documented structure and has not been run against a real Ranorex project.

## The workflow

1. **Record** - name the test, press *Start recording*. The window minimises and a small always-on-top bar appears:
   `● REC 00:42   12 steps   [Pause] [✓ Validate] [■ Stop]`. It shows the last thing recorded in plain English
   ("Click 'Save' button in 'Untitled - Notepad'"). Hotkeys: **F9** stop, **F8** validate the item under the mouse.
   Recorded: click, double click, right click, drag and drop, scroll, typed text (one step per burst), shortcuts,
   Enter/Tab/Esc/arrows. For every action the available control metadata, window, image crops and selected screenshots
   are stored. UI Automation password fields are never queried for their values; typed input in those fields is
   recorded as redacted and playback blocks until a secure secret input provider exists.
2. **Review** - when you press Stop, the recording is analysed (labels read from the screen where the app exposes none,
   plain-English descriptions, suggested validation points, title and summary). A review screen lists every step; tick the
   validation points you want, select steps and press *Use selected steps as validation points*, delete steps you don't want.
3. **Run** - *Tests -> Run*. VisionAuto confirms or activates the recorded app, then finds each element again by UI
   Automation -> image -> feature match -> OCR text -> AI similarity -> nearby search, waiting until it is visible.
   The recording bar shows the last click's screen coordinate; hover over it to inspect saved element metadata. If an
   element moved or changed, the new appearance is saved back to the test (`test.json.bak` is kept) and the run continues.
4. **Report** - every run writes `run.json` and a self-contained `report.html`.

Tests are plain JSON (`workspace/tests/<name>/test.json`) and are written step by step while recording
(`steps.jsonl`), so a crash never loses a recording. Closing the review window keeps the captured test in the library;
only the confirmed **Discard recording** button removes it. The **Tests** page reads from this workspace folder.

### Fallbacks and OCR

Element resolution uses every available signal in a safe order: Windows UI
Automation, saved image templates, feature matching, OCR text, AI similarity,
and self-healing near the recorded position. OCR uses EasyOCR with
pre-processing and fuzzy matching, and can fall back to Tesseract when
EasyOCR is unavailable. Input playback supports `pynput` and `pyautogui`;
`input_backend: "auto"` tries `pynput` first and falls back to `pyautogui`
when desktop hooks are restricted.

## Ranorex
*Import Ranorex* page, or:
```
python -m core.importers.ranorex.cli inspect --rxrep MyProject.rxrep          # check the repository was understood
python -m core.importers.ranorex.cli import  --rxrep MyProject.rxrep --cs Recording1.cs Recording2.cs --project MyProject
python -m core.playback.playback --name MyProject__Recording1                  # imported recordings run like any test
python -m core.importers.ranorex.cli run --script workspace/imported/MyProject/Module.py   # imported code modules
```
Straight-line recordings become normal tests (validation points, reports, self-healing). Code with `if/foreach/variables`
becomes a Python script that runs on the same engine. Unsupported C# lines are listed (`# TODO`), never silently dropped;
`--llm` lets a small local model (Ollama, e.g. `qwen2.5-coder:1.5b`) try them and its output is only used if it is valid Python.
Imported repository targets preserve their Ranorex path, automation id, control role, and display text so the same
native/OCR/image/AI fallback chain is used after migration.
Each import writes a `migration_report.json` with converted source-line mappings, unsupported constructs, runtime notes,
and the `.rximg` limitation. Existing imports are protected from accidental overwrite; pass `--overwrite` to replace them.

## UFT / VBScript migration

The separate UFT importer converts a conservative straight-line subset into the same `visionauto.test/2` format and
writes a `migration_report.json` beside the test. It supports common `Click`, `Set`, `Type`, `Exist`, `Sync`, and
selected `CheckProperty` / `WaitProperty` operations for web and Windows controls. XML exports of object repositories
are accepted; native binary `.tsr` files, control flow, custom functions, and unsupported checks are reported for
manual review. Supply `Parameter()` or `DataTable.Value()` inputs explicitly:

```
python -m core.importers.uft.cli --script Login.vbs --repository ObjectRepository.xml --name Login --parameter username=alice
```

The importer does not run UFT scripts or claim full UFT compatibility. See `docs/FEATURE_AUDIT.md` for its current
subset and limitations.

## Stop stuck Ranorex / UFT processes

Ranorex Studio / Spy / Agent and UFT One (plus their automation agents) can stay running and hold UI Automation hooks or
licences. VisionAuto can list and stop them:

```
python -m core.tools.process_killer                    # list only (default, safe)
python -m core.tools.process_killer --kill             # asks first, then terminates; force-kills survivors
python -m core.tools.process_killer --product uft --kill --yes
kill_ranorex_uft.bat                                   # Windows double-click wrapper
```
In the app: **Applications -> Stop Ranorex / UFT...** lists the processes and asks before stopping anything.
Only exact vendor process names are touched (Ranorex family, `UFT.exe`, `QTPro.exe`, `QtpAutomationAgent.exe`, ...);
VisionAuto's own process, parents and children are always skipped. Check the list on your installation first: vendors
rename binaries between versions, and `--extra-name <exe>` adds one.

## Multi-application tests: safety rules

* A test is validated before anything launches (`core/validation.py`): unknown or duplicate aliases, applications missing
  from this machine's registry, startup-dependency cycles, undefined `${variables}`, bad retries/policies. The Tests page
  shows the errors and refuses to run; the player also refuses (status `invalid`, nothing launched).
* A step naming an alias the test does not define fails; it never grabs a window by guessing.
* Ambiguous targets (several windows with the same title, several instances of one process) are refused with a list,
  unless the application sets `allow_ambiguous`. Process matching is exact, never substring.
* The target window is re-activated before **every** step; a missing window fails the step.
* Launch timeouts fail the step and stop the process that run started; attached/pre-existing apps are never closed.
* `failure_policy`: `stop` (default), `continue`, `skip_app` (skip the failed application's remaining steps only).
  Steps marked `"cleanup": true` run after success, failure and cancellation. `retries` (max 5) re-run only failures
  that sent no input (target not found, or a read-only `validate` step).
* Secret variables (`*password*`, `*token*`, `*secret*`, ..., or listed in `secret_variables`) are scrubbed from
  `run.json`, `report.html` and `junit.xml`.
* Each run writes `run.json`, `report.html` and `junit.xml` (CI). `core.project_io.export_project()` / `import_project()` export and import a
  project zip with machine paths and credentials stripped (`core/project_io.py`); `core/locators.py` is a per-application
  locator repository that refuses cross-application matches.

## CLI
```
python -m core.recorder.recorder --name my_test        # F9 stop, F8 validate
python -m core.playback.playback --name my_test [--dry-run] [--continue-on-failure]
python -m core.reports.report my_test                  # regenerate the newest report
python -m unittest discover -s tests -t .              # test suite
```

## Layout
```
app/            PySide6 desktop app (thin: all logic lives in core/)
core/recorder   hooks -> event queue -> StepBuilder -> steps   (hooks never do heavy work)
core/playback   Player, Resolver (locator chain), Validator, input backend
core/ai         describe (plain English), analyze (labels, suggestions), llm (optional Ollama), embedder/ai_engine
core/review.py  review-screen logic (no GUI)      core/reports   HTML report
core/importers  Ranorex importer                  core/plugins   per-technology adapters (UIA today)
core/system     Windows access: DPI, windows, UI Automation, screen capture
```

## Status - read before demoing
* **Tested (automated, originally 75 tests; the suite now has 196):** step building (click/double/right/drag/scroll/typing/hotkeys), journaling and crash
  recovery, locator chain and self-heal on synthetic screens, validations, Ranorex conversion and script mode, review logic,
  HTML report, settings validation and recovery, password redaction, and the whole post-recording flow through the GUI layer with synthetic input.
* **Step editing:** Tests -> select a recorded test -> **Edit steps**. Add, edit, delete, or reorder actions; set a text,
  UI Automation, supported Ranorex XPath, image-template, or coordinate locator. Saving keeps `visionauto.test/2` and
  backs up the previous definition as `test.json.bak`. Ranorex XPath predicates map to supported UIA metadata; this is
  not a general XPath execution engine.
* **Dry-run status:** dry runs simulate backend actions and are reported as *inconclusive*, with simulated actions and
  assertions marked *skipped*. They do not prove application behavior.
* **Not yet exercised in a live desktop session:** real mouse/keyboard capture, UI Automation on target applications,
  and visible-window interactions. The GUI flow tests use Qt offscreen/synthetic input. Run `python -m unittest discover -s tests -t .`
  on your machine first, then record against Notepad or Calculator. Send the `workspace/logs/visionauto.log` if anything misbehaves.
* **Known limits:** OCR needs `easyocr` (downloads models on first use); the AI-similarity tier uses a classical embedding
  until you drop an ONNX model in `core/ai/models/`; SAP / Java / Electron have no dedicated native tier yet (UI Automation
  where the app exposes it, vision otherwise); Citrix/RDP is vision-only by design; the `.rxrep` parser follows the documented
  format and has not been run against a real Ranorex project; PDF/video report export is not implemented.
* **Sensitive input:** if the target application exposes the UI Automation password flag, the recorder redacts that
  input before it reaches the test journal. Secure secret variables are not implemented, and apps that do not expose
  password metadata cannot be identified reliably.
