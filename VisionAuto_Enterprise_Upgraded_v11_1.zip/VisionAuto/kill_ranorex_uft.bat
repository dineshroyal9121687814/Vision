@echo off
rem Lists Ranorex and UFT processes, then asks before stopping them.
rem   kill_ranorex_uft.bat            -> list + confirm
rem   kill_ranorex_uft.bat --yes      -> no confirmation prompt
rem   kill_ranorex_uft.bat --product uft
cd /d "%~dp0"
python -m core.tools.process_killer --kill %*
pause
